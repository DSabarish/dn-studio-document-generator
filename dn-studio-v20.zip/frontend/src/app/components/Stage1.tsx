// FILE: frontend/src/app/components/Stage1.tsx
// "Do third" additions on top of "do second":
//   - Speaker name editing: click any SPEAKER_N label to rename in-place
//     All utterance pills and swimlane labels update live
//     Renamed names flow to Stage2 via the JSON download
//   - Confidence per utterance: colour-coded badge (green/amber/red) in utterances tab
//   - Document type descriptions in Stage2 card (done there, not here)
//   - Segment tooltip shows per-segment confidence on hover (swimlane)

import { useState, useRef, useEffect } from 'react';
import { Upload, ChevronDown } from 'lucide-react';
import {
  startDiarisation,
  streamDiarisation,
  uploadDiarisationJson,
  getDiarisationJsonUrl,
  getDiarisationHtmlUrl,
  type DiarisationResult,
  type Segment,
} from '../api';

interface Stage1Props {
  onDiarisationComplete: (data: DiarisationResult) => void;
  onClearSession: () => void;
  existingResult?: DiarisationResult | null;
}

const STEPS = [
  { pct: 0,   label: 'Uploading file' },
  { pct: 5,   label: 'Converting audio to WAV' },
  { pct: 15,  label: 'Loading Whisper model' },
  { pct: 20,  label: 'Transcribing speech' },
  { pct: 50,  label: 'Extracting speaker embeddings' },
  { pct: 70,  label: 'Running speaker clustering' },
  { pct: 82,  label: 'Computing t-SNE' },
  { pct: 90,  label: 'Writing diarization JSON' },
  { pct: 95,  label: 'Building HTML view' },
  { pct: 100, label: 'Complete ✓' },
];

const SPK_COLORS = ['#8b5cf6','#10b981','#f97316','#eab308','#3b82f6','#ec4899','#06b6d4','#84cc16'];

type ProcessPhase = 'idle' | 'uploading' | 'processing' | 'done';
type ActiveTab    = 'preview' | 'utterances' | 'json';

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}
function fmtDur(sec: number): string {
  if (sec >= 60) return Math.floor(sec / 60) + 'm ' + Math.round(sec % 60) + 's';
  return Math.round(sec) + 's';
}
function confColor(c: number): string {
  if (c >= 0.85) return '#22c55e';  // green
  if (c >= 0.65) return '#f59e0b';  // amber
  return '#ef4444';                  // red
}
function confLabel(c: number): string {
  if (c >= 0.85) return 'high';
  if (c >= 0.65) return 'med';
  return 'low';
}

export function Stage1({ onDiarisationComplete, onClearSession, existingResult }: Stage1Props) {

  // ── Processing state ──────────────────────────────────────────────────────
  const [isDragging,    setIsDragging]    = useState(false);
  const [phase,         setPhase]         = useState<ProcessPhase>('idle');
  const [uploadPct,     setUploadPct]     = useState(0);
  const [progress,      setProgress]      = useState(0);
  const [statusMsg,     setStatusMsg]     = useState('');
  const [logLines,      setLogLines]      = useState<string[]>([]);
  const [error,         setError]         = useState('');
  const [processingSec, setProcessingSec] = useState(0);

  // ── Config state ──────────────────────────────────────────────────────────
  const [whisperModel,   setWhisperModel]   = useState('base.en');
  const [speakerCount,   setSpeakerCount]   = useState('auto');
  const [removeFillers,  setRemoveFillers]  = useState(true);
  const [removeStutters, setRemoveStutters] = useState(true);

  // ── Output state ──────────────────────────────────────────────────────────
  const [activeTab,   setActiveTab]   = useState<ActiveTab>('preview');
  const [audioSrc,    setAudioSrc]    = useState<string | null>(null);
  const [audioDur,    setAudioDur]    = useState(0);
  const [audioTime,   setAudioTime]   = useState(0);
  const [activeUttId, setActiveUttId] = useState<number | null>(null);

  // ── Speaker name editing state ────────────────────────────────────────────
  // Maps speaker_id → display name (editable)
  const [nameMap,      setNameMap]      = useState<Record<string, string>>({});
  const [editingSp,    setEditingSp]    = useState<string | null>(null);  // which speaker is being edited
  const [editingName,  setEditingName]  = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  // ── Refs ──────────────────────────────────────────────────────────────────
  const audioRef      = useRef<HTMLAudioElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef  = useRef<HTMLInputElement>(null);
  const jsonInputRef  = useRef<HTMLInputElement>(null);
  const stopStream    = useRef<(() => void) | null>(null);
  const logEndRef     = useRef<HTMLDivElement>(null);
  const uttRefs       = useRef<Record<number, HTMLDivElement | null>>({});
  const timerRef      = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef      = useRef<number>(0);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logLines]);
  // FIX Stage1 L1: use ref to track current audioSrc so cleanup sees latest value
  const audioSrcRef = useRef<string | null>(null);

  useEffect(() => () => {
    stopStream.current?.();
    clearInterval(timerRef.current!);
    if (audioSrcRef.current) URL.revokeObjectURL(audioSrcRef.current);
  }, []);

  // Focus the edit input whenever editingSp changes
  useEffect(() => {
    if (editingSp) setTimeout(() => editInputRef.current?.select(), 30);
  }, [editingSp]);

  // Sync nameMap with existingResult:
  // - When result is cleared (null), reset nameMap
  // - When new result arrives, add missing speakers without overwriting existing renames
  useEffect(() => {
    if (!existingResult) {
      // FIX Stage1 STATE: clear renames when session is cleared
      setNameMap({});
      uttRefs.current = {};
      return;
    }
    const speakers = [...new Set(existingResult.segments.map(s => s.speaker_id))].sort();
    setNameMap(prev => {
      const next: Record<string, string> = {};
      // Only carry forward renames for speakers that exist in new result
      speakers.forEach(sp => { next[sp] = prev[sp] || sp; });
      return next;
    });
    // FIX Stage1 L2: clear stale utterance refs on new result
    uttRefs.current = {};
  }, [existingResult]);

  // ── Audio time → active utterance → auto-scroll ──────────────────────────
  // We store audioTime in a ref to avoid re-running this on every 16ms tick.
  // The effect only calls setState/scrollIntoView when the active segment changes.
  const audioTimeRef   = useRef(0);
  const activeUttIdRef = useRef<number | null>(null);

  useEffect(() => {
    audioTimeRef.current = audioTime;
    if (!existingResult) return;
    const seg = existingResult.segments.find(
      s => audioTime >= s.start && audioTime < s.end
    );
    const id = seg?.utterance_id ?? null;
    if (id !== activeUttIdRef.current) {
      activeUttIdRef.current = id;
      setActiveUttId(id);
      if (id !== null && uttRefs.current[id]) {
        uttRefs.current[id]?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [audioTime, existingResult]);

  // ── Derived data ──────────────────────────────────────────────────────────
  const res      = existingResult;
  const speakers = res ? [...new Set(res.segments.map(s => s.speaker_id))].sort() : [];

  const colorMap: Record<string, string> = {};
  speakers.forEach((sp, i) => { colorMap[sp] = SPK_COLORS[i % SPK_COLORS.length]; });

  const totalDur = res ? Math.max(...res.segments.map(s => s.end), 1) : 1;

  const talkTime: Record<string, number> = {};
  if (res) speakers.forEach(sp => {
    talkTime[sp] = res.segments.filter(s => s.speaker_id === sp)
      .reduce((a, s) => a + (s.end - s.start), 0);
  });

  const wordCount = res
    ? res.segments.reduce((a, s) => a + s.text.trim().split(/\s+/).filter(Boolean).length, 0)
    : 0;

  const avgConf = res && res.segments.length > 0
    ? Math.round(res.segments.reduce((a, s) => a + s.confidence, 0) / res.segments.length * 100)
    : 0;

  const durStr = res ? fmtDur(res.duration_sec) : '';

  // ── Speaker name editing handlers ─────────────────────────────────────────
  function startEdit(sp: string) {
    setEditingSp(sp);
    setEditingName(nameMap[sp] || sp);
  }

  function commitEdit() {
    if (!editingSp) return;
    const trimmed = editingName.trim();
    if (trimmed) {
      setNameMap(prev => ({ ...prev, [editingSp]: trimmed }));
    }
    setEditingSp(null);
  }

  function cancelEdit() {
    setEditingSp(null);
  }

  function handleEditKey(e: React.KeyboardEvent) {
    if (e.key === 'Enter')  { e.preventDefault(); commitEdit(); }
    if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
  }

  // Returns display name for a speaker_id
  function displayName(spId: string): string {
    return nameMap[spId] || spId;
  }

  // Build the modified JSON for download (with renamed speaker_names)
  function buildRenamedJson(): string {
    if (!res) return '[]';
    const renamed = res.segments.map(s => ({
      ...s,
      speaker_name: displayName(s.speaker_id),
    }));
    return JSON.stringify(renamed, null, 2);
  }

  // ── Audio player handlers ─────────────────────────────────────────────────
  function handleAudioFileLoad(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    // Revoke previous URL using ref (not stale closure state)
    if (audioSrcRef.current) URL.revokeObjectURL(audioSrcRef.current);
    const url = URL.createObjectURL(f);
    audioSrcRef.current = url;
    setAudioSrc(url);
    setAudioTime(0);
  }

  function seekTo(sec: number) {
    if (audioRef.current) {
      audioRef.current.currentTime = sec;
      audioRef.current.play().catch(() => {});
    }
  }

  function handleLaneSegClick(e: React.MouseEvent, seg: Segment) {
    e.stopPropagation();
    seekTo(seg.start);
  }

  function handleLaneBarClick(e: React.MouseEvent<HTMLDivElement>) {
    if (!res) return;
    const rect  = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    seekTo(ratio * totalDur);
  }

  const playheadPct = audioDur > 0 ? (audioTime / audioDur) * 100 : 0;

  // ── Step status ───────────────────────────────────────────────────────────
  const displayPct = phase === 'uploading' ? Math.round(uploadPct * 0.05) : progress;
  function stepStatus(s: typeof STEPS[0]) {
    if (displayPct > s.pct) return 'done';
    if (displayPct >= s.pct - 10) return 'active';
    return 'pending';
  }

  // ── Pipeline handlers ─────────────────────────────────────────────────────
  async function doAudio(file: File) {
    setPhase('uploading'); setError(''); setProgress(0); setUploadPct(0); setLogLines([]); setProcessingSec(0); setProcessingSec(0);
    setStatusMsg('Uploading ' + file.name + ' (' + (file.size / 1024 / 1024).toFixed(1) + ' MB)…');
    startRef.current = Date.now();

    try {
      const n     = speakerCount === 'auto' ? null : parseInt(speakerCount);
      const jobId = await startDiarisation(file,
        { whisperModel, numSpeakers: n, removeFillers, removeStutters },
        (loaded, total) => {
          const pct = Math.round((loaded / total) * 100);
          setUploadPct(pct);
          setStatusMsg('Uploading… ' + pct + '% (' + (loaded/1024/1024).toFixed(1) + ' / ' + (total/1024/1024).toFixed(1) + ' MB)');
        }
      );

      setPhase('processing');
      setStatusMsg('Upload complete — pipeline starting…');
      timerRef.current = setInterval(() => {
        setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      }, 1000);

      stopStream.current = streamDiarisation(
        jobId,
        (p) => {
          if (p.pct != null && p.pct >= 0) setProgress(p.pct);
          if (p.log) { setLogLines(prev => [...prev, p.log!]); setStatusMsg(p.log!); }
        },
        (result) => {
          clearInterval(timerRef.current!);
          setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
          if (result.status === 'error') {
            setError((result as any).error || 'Diarisation failed'); setPhase('idle');
          } else {
            setPhase('done'); setProgress(100);
            onDiarisationComplete(result as DiarisationResult);
          }
        },
        (err) => { clearInterval(timerRef.current!); setError(err); setPhase('idle'); }
      );
    } catch (e: any) {
      clearInterval(timerRef.current!); setPhase('idle');
      setError(e.message || 'Failed to start diarisation');
    }
  }

  async function doJson(file: File) {
    setPhase('uploading'); setError(''); setStatusMsg('Uploading JSON…'); setProcessingSec(0); setProcessingSec(0);
    startRef.current = Date.now();
    try {
      const r = await uploadDiarisationJson(file);
      setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      setPhase('done'); onDiarisationComplete(r);
    } catch (e: any) { setError(e.message || 'Upload failed'); setPhase('idle'); }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) f.name.endsWith('.json') ? doJson(f) : doAudio(f);
  }

  const isProcessing = phase === 'uploading' || phase === 'processing';
  const hasRenames   = res && speakers.some(sp => nameMap[sp] && nameMap[sp] !== sp);

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="flex-1 bg-[#111] text-white overflow-auto">
      <div className="p-6">

        {/* Title row */}
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl font-bold">Stage 1 — Diarisation</h1>
          <div className="flex gap-3">
            {res && <span className="px-5 py-2 bg-white text-black rounded-full text-sm font-semibold">JSON ready</span>}
            <button onClick={onClearSession}
              className="px-5 py-2 bg-[#2a2a2a] text-white rounded-full hover:bg-[#333] transition text-sm">
              Clear session
            </button>
          </div>
        </div>
        <p className="text-[#888] text-sm mb-6">Run once — reuse the JSON for every document</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-lg text-red-400 text-sm">{error}</div>
        )}

        {/* ── Input + Config grid ────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-6 mb-6">

          {/* Input card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Input</h3>
            <p className="text-[#888] text-xs mb-4">Upload audio/video — or skip if you already have a JSON</p>

            <div
              onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={onDrop}
              onClick={() => !isProcessing && fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center transition-all duration-200 mb-4 ${
                isProcessing ? 'cursor-default border-[#444]' :
                isDragging   ? 'cursor-pointer border-white bg-white/5' :
                               'cursor-pointer border-[#444] hover:border-[#666]'
              }`}
            >
              {isProcessing ? (
                <div className="space-y-3">
                  <div className="text-sm font-medium text-white">
                    {phase === 'uploading' ? '⬆ Uploading…' : '⚙ Processing…'}
                  </div>
                  <div className="text-[#888] text-xs truncate px-2">{statusMsg}</div>

                  {phase === 'uploading' && (
                    <div>
                      <div className="w-full bg-[#2a2a2a] rounded-full h-2.5 overflow-hidden mb-1">
                        <div className="h-2.5 rounded-full bg-blue-500 transition-all duration-300" style={{ width: uploadPct + '%' }} />
                      </div>
                      <div className="text-[#888] text-xs">{uploadPct}% uploaded</div>
                    </div>
                  )}
                  {phase === 'processing' && (
                    <div>
                      <div className="w-full bg-[#2a2a2a] rounded-full h-2.5 overflow-hidden mb-1">
                        <div className="h-2.5 rounded-full transition-all duration-500"
                          style={{ width: progress + '%', background: 'linear-gradient(90deg,#6366f1,#8b5cf6)' }} />
                      </div>
                      <div className="text-[#888] text-xs font-mono">{progress}% · {fmtDur(processingSec)} elapsed</div>
                    </div>
                  )}

                  <div className="space-y-0.5 text-left mt-1">
                    {STEPS.slice(1).map(s => {
                      const st = stepStatus(s);
                      return (
                        <div key={s.pct} className={`flex items-center gap-2 text-xs transition-colors ${
                          st === 'done' ? 'text-green-400' : st === 'active' ? 'text-purple-300 font-semibold' : 'text-[#555]'
                        }`}>
                          <span className="w-3 text-center flex-shrink-0">
                            {st === 'done' ? '✓' : st === 'active' ? '›' : '·'}
                          </span>
                          <span>{s.label}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <>
                  <Upload className={`mx-auto mb-3 ${isDragging ? 'text-white' : 'text-[#666]'}`} size={32} />
                  <div className="font-medium mb-1">Drop audio / video here</div>
                  <div className="text-[#666] text-xs">mp3, mp4, m4a, wav, mkv — any format</div>
                </>
              )}
            </div>

            <input ref={fileInputRef} type="file"
              accept="audio/*,video/*,.mp3,.mp4,.m4a,.wav,.mkv,.ogg,.flac,.webm"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doAudio(f); e.target.value = ''; }} />

            {isProcessing && logLines.length > 0 && (
              <div className="bg-[#0a0a0a] rounded-lg p-3 font-mono text-[10px] text-[#666] max-h-24 overflow-y-auto mb-3">
                {logLines.slice(-20).map((l, i) => <div key={i}>{l}</div>)}
                <div ref={logEndRef} />
              </div>
            )}

            <div className="text-center text-[#666] text-xs my-3">or</div>

            <button onClick={() => jsonInputRef.current?.click()} disabled={isProcessing}
              className="w-full px-4 py-3 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium disabled:opacity-50">
              Upload existing diarization_response.json
            </button>
            <input ref={jsonInputRef} type="file" accept=".json" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doJson(f); e.target.value = ''; }} />
          </div>

          {/* Config card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Pipeline config</h3>
            <p className="text-[#888] text-xs mb-4">Adjust before running</p>
            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs block mb-2">Whisper model</label>
                <div className="relative">
                  <select value={whisperModel} onChange={e => setWhisperModel(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="tiny.en">tiny.en (fastest)</option>
                    <option value="base.en">base.en</option>
                    <option value="small.en">small.en</option>
                    <option value="medium.en">medium.en (best accuracy)</option>
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>
              <div>
                <label className="text-[#888] text-xs block mb-2">Speaker count</label>
                <div className="relative">
                  <select value={speakerCount} onChange={e => setSpeakerCount(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="auto">Auto-detect (silhouette)</option>
                    {[2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} speakers</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeFillers} onChange={e => setRemoveFillers(e.target.checked)} className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove fillers</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeStutters} onChange={e => setRemoveStutters(e.target.checked)} className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove stutters</span>
              </label>
              <button onClick={() => fileInputRef.current?.click()} disabled={isProcessing}
                className="w-full px-4 py-3 bg-white text-black rounded-lg hover:bg-gray-200 transition font-semibold disabled:opacity-50">
                {phase === 'uploading'  ? '⬆ Uploading… ' + uploadPct + '%' :
                 phase === 'processing' ? '⚙ Processing… ' + progress + '%' :
                 'Run diarisation'}
              </button>
            </div>
          </div>
        </div>

        {/* ── OUTPUT SECTION ─────────────────────────────────────────────── */}
        {res && (
          <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">

            {/* Stats row */}
            <div className="grid grid-cols-3 sm:grid-cols-6 border-b border-[#2a2a2a]">
              {[
                { label: 'Speakers',   value: String(res.n_speakers) },
                { label: 'Utterances', value: String(res.n_utterances) },
                { label: 'Duration',   value: durStr },
                { label: 'Words',      value: wordCount.toLocaleString() },
                { label: 'Processed',  value: processingSec > 0 ? fmtDur(processingSec) : '—' },
                { label: 'Confidence', value: avgConf + '%' },
              ].map(({ label, value }, i) => (
                <div key={label} className={`p-4 text-center ${i < 5 ? 'border-r border-[#2a2a2a]' : ''}`}>
                  <div className="text-[#666] text-[10px] uppercase tracking-wider mb-1">{label}</div>
                  <div className={`text-xl font-bold ${
                    label === 'Confidence'
                      ? avgConf >= 85 ? 'text-green-400' : avgConf >= 65 ? 'text-yellow-400' : 'text-red-400'
                      : 'text-white'
                  }`}>{value}</div>
                </div>
              ))}
            </div>

            {/* Tab bar + audio loader */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-[#2a2a2a]">
              <div className="flex gap-1 bg-[#111] rounded-lg p-1">
                {(['preview','utterances','json'] as ActiveTab[]).map(t => (
                  <button key={t} onClick={() => setActiveTab(t)}
                    className={`px-3 py-1.5 text-xs rounded-md transition-all ${
                      activeTab === t ? 'bg-[#2a2a2a] text-white' : 'text-[#888] hover:text-white'
                    }`}>
                    {t === 'utterances' ? 'Utterances' : t.charAt(0).toUpperCase() + t.slice(1)}
                  </button>
                ))}
              </div>
              <button onClick={() => audioInputRef.current?.click()}
                className="px-3 py-1.5 bg-[#2a2a2a] text-[#888] hover:text-white rounded-lg text-xs transition border border-[#333] hover:border-[#555]">
                {audioSrc ? '⟳ Change audio file' : '▶ Load audio to play'}
              </button>
              <input ref={audioInputRef} type="file" accept="audio/*,video/*" className="hidden"
                onChange={handleAudioFileLoad} />
            </div>

            {/* Audio player */}
            {audioSrc && (
              <div className="px-5 py-3 border-b border-[#2a2a2a] bg-[#0d0d0d] flex items-center gap-4">
                <audio ref={audioRef} src={audioSrc}
                  onTimeUpdate={() => { if (audioRef.current) setAudioTime(audioRef.current.currentTime); }}
                  onLoadedMetadata={() => { if (audioRef.current) setAudioDur(audioRef.current.duration); }}
                  className="flex-1 h-8" controls style={{ accentColor: '#8b5cf6' }} />
                <span className="text-[#666] text-xs font-mono whitespace-nowrap">
                  {fmtTime(audioTime)} / {fmtTime(audioDur || totalDur)}
                </span>
              </div>
            )}

            {/* ── TAB: Preview — swimlane with speaker name editing ──────── */}
            {activeTab === 'preview' && (
              <div className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="text-[#666] text-[10px] uppercase tracking-wider">
                    Speaker lanes — click a name to rename
                  </div>
                  {hasRenames && (
                    <span className="text-[#555] text-[10px]">✎ names edited · download JSON to save</span>
                  )}
                </div>

                <div className="space-y-3">
                  {speakers.map(sp => {
                    const segs     = res.segments.filter(s => s.speaker_id === sp);
                    const color    = colorMap[sp];
                    const pct      = Math.round((talkTime[sp] / totalDur) * 100);
                    const isActive = segs.some(s => audioTime >= s.start && audioTime < s.end);
                    const name     = displayName(sp);
                    const isEditing = editingSp === sp;

                    return (
                      <div key={sp} className="flex items-center gap-3">

                        {/* Speaker label — click to edit */}
                        <div className="w-28 flex-shrink-0 text-right">
                          {isEditing ? (
                            <input
                              ref={editInputRef}
                              value={editingName}
                              onChange={e => setEditingName(e.target.value)}
                              onKeyDown={handleEditKey}
                              onBlur={commitEdit}
                              className="w-full bg-[#0f0f0f] text-white text-xs border border-[#8b5cf6] rounded px-1.5 py-0.5 text-right focus:outline-none"
                              style={{ borderColor: color }}
                            />
                          ) : (
                            <button
                              onClick={() => startEdit(sp)}
                              title="Click to rename"
                              className={`w-full text-right text-xs font-medium truncate hover:underline transition-colors cursor-text ${
                                isActive ? 'text-white' : 'text-[#888] hover:text-white'
                              }`}
                              style={{ color: isActive ? 'white' : undefined }}
                            >
                              {name}
                              {name !== sp && (
                                <span className="text-[#444] ml-1 not-italic" title={'Originally: ' + sp}>✎</span>
                              )}
                            </button>
                          )}
                          <div className="text-[#444] text-[10px] mt-0.5">{pct}% talk</div>
                        </div>

                        {/* Lane bar */}
                        <div
                          className="flex-1 h-7 bg-[#0a0a0a] rounded-lg relative overflow-hidden cursor-pointer border border-[#1e1e1e]"
                          onClick={handleLaneBarClick}
                        >
                          {segs.map(seg => {
                            const left       = (seg.start / totalDur) * 100;
                            const width      = Math.max(0.3, ((seg.end - seg.start) / totalDur) * 100);
                            const isActiveSeg = audioTime >= seg.start && audioTime < seg.end;
                            const conf       = seg.confidence;
                            return (
                              <div
                                key={seg.utterance_id}
                                className="absolute top-1 rounded-sm cursor-pointer"
                                style={{
                                  left: left + '%',
                                  width: width + '%',
                                  height: '20px',
                                  backgroundColor: color,
                                  opacity: isActiveSeg ? 1 : 0.72,
                                  boxShadow: isActiveSeg ? '0 0 0 1.5px ' + color : 'none',
                                  // Bottom strip: confidence heat (red=low, green=high)
                                  borderBottom: '2px solid ' + confColor(conf),
                                }}
                                title={fmtTime(seg.start) + ' · ' + name + ' · conf ' + Math.round(conf * 100) + '% · ' + seg.text.slice(0, 80)}
                                onClick={e => handleLaneSegClick(e, seg)}
                              />
                            );
                          })}

                          {/* Playhead */}
                          {audioSrc && playheadPct > 0 && (
                            <div className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
                              style={{ left: playheadPct + '%' }} />
                          )}

                          {/* Time ruler ticks */}
                          {Array.from({ length: Math.floor(totalDur / 30) }, (_, i) => (
                            <div key={i}
                              className="absolute top-0 bottom-0 w-px bg-[#1a1a1a] pointer-events-none"
                              style={{ left: ((i + 1) * 30 / totalDur * 100) + '%' }} />
                          ))}
                        </div>
                      </div>
                    );
                  })}

                  {/* Time axis */}
                  <div className="flex items-center gap-3">
                    <div className="w-28 flex-shrink-0" />
                    <div className="flex-1 flex justify-between text-[#333] text-[10px] font-mono px-0.5">
                      <span>0:00</span>
                      <span>{fmtTime(totalDur / 4)}</span>
                      <span>{fmtTime(totalDur / 2)}</span>
                      <span>{fmtTime(totalDur * 3 / 4)}</span>
                      <span>{fmtTime(totalDur)}</span>
                    </div>
                  </div>

                  {/* Confidence legend */}
                  <div className="flex items-center gap-3 mt-1">
                    <div className="w-28 flex-shrink-0" />
                    <div className="flex items-center gap-4 text-[10px] text-[#555]">
                      <span>Confidence stripe:</span>
                      {[['#22c55e','≥85% high'],['#f59e0b','65–84% medium'],['#ef4444','<65% low']].map(([c,l]) => (
                        <span key={l} className="flex items-center gap-1">
                          <span className="inline-block w-4 h-1 rounded-full" style={{ backgroundColor: c as string }} />
                          {l}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ── TAB: Utterances — with confidence badge ────────────────── */}
            {activeTab === 'utterances' && (
              <div className="overflow-hidden">
                {/* Column headers */}
                <div className="flex items-center gap-4 px-5 py-2 border-b border-[#1e1e1e] bg-[#111]">
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-12 flex-shrink-0">Time</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-24 flex-shrink-0">Speaker</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider flex-1">Transcript</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-12 text-right flex-shrink-0">Conf.</span>
                </div>

                <div className="max-h-96 overflow-y-auto">
                  {res.segments.map(seg => {
                    const isActive = seg.utterance_id === activeUttId;
                    const color    = colorMap[seg.speaker_id] || '#888';
                    const conf     = seg.confidence;
                    const cColor   = confColor(conf);
                    const cLabel   = confLabel(conf);

                    return (
                      <div
                        key={seg.utterance_id}
                        ref={el => { uttRefs.current[seg.utterance_id ?? 0] = el; }}
                        onClick={() => seekTo(seg.start)}
                        className={`flex items-start gap-4 px-5 py-2.5 cursor-pointer border-b border-[#161616] transition-colors ${
                          isActive ? 'bg-[#1a1630]' : 'hover:bg-[#1a1a1a]'
                        }`}
                      >
                        {/* Time */}
                        <span className="text-[#555] text-xs font-mono w-12 flex-shrink-0 pt-0.5">
                          {fmtTime(seg.start)}
                        </span>

                        {/* Speaker pill — shows renamed name */}
                        <span
                          className="text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0 mt-0.5 w-24 text-center truncate"
                          style={{ backgroundColor: color + '20', color, border: '1px solid ' + color + '44' }}
                          title={displayName(seg.speaker_id) !== seg.speaker_id ? 'Originally: ' + seg.speaker_id : undefined}>
                          {displayName(seg.speaker_id)}
                        </span>

                        {/* Text */}
                        <span className={`text-sm leading-relaxed flex-1 ${isActive ? 'text-white' : 'text-[#bbb]'}`}>
                          {seg.text}
                          {isActive && audioSrc && (
                            <span className="text-red-400 text-xs ml-2 animate-pulse">▶</span>
                          )}
                        </span>

                        {/* Confidence badge */}
                        <span
                          className="text-[10px] font-semibold px-1.5 py-0.5 rounded w-12 text-right flex-shrink-0 font-mono"
                          style={{ color: cColor }}
                          title={'ASR confidence: ' + Math.round(conf * 100) + '%'}>
                          {Math.round(conf * 100)}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── TAB: JSON ─────────────────────────────────────────────── */}
            {activeTab === 'json' && (
              <div className="p-5">
                <pre className="bg-[#0a0a0a] rounded-lg p-4 text-xs text-[#888] overflow-auto max-h-64 font-mono border border-[#1e1e1e]">
                  {JSON.stringify(res.segments.slice(0, 5), null, 2)}
                </pre>
                <p className="text-[#555] text-xs mt-2">
                  First 5 of {res.n_utterances} utterances shown. Download for full data.
                </p>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-3 p-5 border-t border-[#2a2a2a]">
              {/* Renamed JSON download — uses modified data if names were edited */}
              {hasRenames ? (
                <button
                  onClick={() => {
                    const blob = new Blob([buildRenamedJson()], { type: 'application/json' });
                    const url  = URL.createObjectURL(blob);
                    const a    = document.createElement('a');
                    a.href = url; a.download = 'diarization_response.json';
                    a.click(); URL.revokeObjectURL(url);
                  }}
                  className="px-5 py-2.5 bg-white text-black rounded-lg hover:bg-gray-100 transition text-sm font-semibold">
                  ↓ Download JSON (with renamed speakers)
                </button>
              ) : (
                <a href={getDiarisationJsonUrl()} download="diarization_response.json"
                  className="px-5 py-2.5 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium">
                  Download JSON
                </a>
              )}
              {res.html_path && (
                <a href={getDiarisationHtmlUrl()} download="diarization_view.html"
                  className="px-5 py-2.5 bg-[#2a2a2a] text-[#888] rounded-lg hover:bg-[#333] hover:text-white transition text-sm">
                  Open full HTML view
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
