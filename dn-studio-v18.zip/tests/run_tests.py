#!/usr/bin/env python3
"""
run_tests.py  —  Self-contained regression runner for DN-Studio
================================================================
Runs all 102 tests using only Python stdlib (unittest + unittest.mock).
No pytest, fastapi, or network access required.

Usage:
    python3 tests/run_tests.py
    python3 tests/run_tests.py -v          # verbose
    python3 tests/run_tests.py ClassName   # run one class only

Exit code 0 = all pass, 1 = failures.
"""

from __future__ import annotations

import ast
import copy
import json
import logging
import os
import re
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, call, patch

# ── Path setup ────────────────────────────────────────────────────────────────
REPO_ROOT   = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = REPO_ROOT / "scripts"
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# ── Shared test data ──────────────────────────────────────────────────────────
SAMPLE_TRANSCRIPT = [
    {"utterance_id": 0, "speaker_name": "Alice",
     "text": "The deployment target is end of month.", "start": 0.0, "end": 3.5},
    {"utterance_id": 1, "speaker_name": "Bob",
     "text": "I will update the API docs by Friday.",  "start": 3.6, "end": 7.2},
]

SAMPLE_SCHEMA = {
    "_GUIDE": {"_comment": "regression test schema"},
    "meta": {
        "meeting_title": {
            "title": "Meeting Title", "description": "Title of this meeting.",
            "format": "String", "value": None, "trace": None,
        },
        "date": {
            "title": "Meeting Date", "description": "Date of meeting.",
            "format": "String", "value": None, "trace": None,
        },
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# FIX 1 — chain2 imports shared helpers
# ══════════════════════════════════════════════════════════════════════════════
class TestFix1SharedImports(unittest.TestCase):
    """chain2_brd_response must use shared llm_utils helpers, not local copies."""

    @classmethod
    def setUpClass(cls):
        cls.src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")

    def test_imports_from_llm_utils(self):
        self.assertIn("from llm_utils import", self.src)

    def test_imports_invoke_with_retry(self):
        self.assertIn("invoke_with_retry", self.src)

    def test_imports_extract_json(self):
        self.assertIn("extract_json", self.src)

    def test_imports_load_json(self):
        self.assertIn("load_json", self.src)

    def test_imports_save_json(self):
        self.assertIn("save_json", self.src)

    def test_no_local_extract_json_definition(self):
        matches = re.findall(r"^def (extract_json)\s*\(", self.src, re.MULTILINE)
        self.assertEqual(matches, [], "chain2 must not define its own extract_json")

    def test_no_local_load_json_definition(self):
        self.assertFalse(re.search(r"^def load_json\s*\(", self.src, re.MULTILINE))

    def test_no_local_save_json_definition(self):
        self.assertFalse(re.search(r"^def save_json\s*\(", self.src, re.MULTILINE))


# ══════════════════════════════════════════════════════════════════════════════
# FIX 2 — invoke_with_retry wrapper
# ══════════════════════════════════════════════════════════════════════════════
class TestFix2InvokeWithRetry(unittest.TestCase):

    def setUp(self):
        from llm_utils import invoke_with_retry, MAX_RETRY_ATTEMPTS
        self.invoke_with_retry = invoke_with_retry
        self.MAX_RETRY_ATTEMPTS = MAX_RETRY_ATTEMPTS

    def test_function_exists_and_callable(self):
        self.assertTrue(callable(self.invoke_with_retry))

    def test_success_on_first_attempt(self):
        mc = MagicMock()
        mc.invoke.return_value = {"fields": [{"path": "x", "value": "v"}]}
        result = self.invoke_with_retry(mc, {}, required_key="fields", label="t")
        self.assertIsNotNone(result)
        self.assertIn("fields", result)
        self.assertEqual(mc.invoke.call_count, 1)

    def test_retries_on_exception(self):
        mc = MagicMock()
        mc.invoke.side_effect = [Exception("fail"), Exception("fail"),
                                  {"fields": [{"value": "ok"}]}]
        with patch("llm_utils.time.sleep"):
            result = self.invoke_with_retry(mc, {}, required_key="fields", label="t")
        self.assertIsNotNone(result)
        self.assertEqual(mc.invoke.call_count, 3)

    def test_returns_none_after_all_failures(self):
        mc = MagicMock()
        mc.invoke.side_effect = Exception("always fails")
        with patch("llm_utils.time.sleep"):
            result = self.invoke_with_retry(mc, {}, required_key="fields", label="t")
        self.assertIsNone(result)
        self.assertEqual(mc.invoke.call_count, self.MAX_RETRY_ATTEMPTS)

    def test_returns_none_on_missing_required_key(self):
        mc = MagicMock()
        mc.invoke.return_value = {"wrong_key": []}
        with patch("llm_utils.time.sleep"):
            result = self.invoke_with_retry(mc, {}, required_key="fields", label="t")
        self.assertIsNone(result)

    def test_sleeps_between_attempts(self):
        mc = MagicMock()
        mc.invoke.side_effect = [Exception("fail"), {"fields": []}]
        sleep_vals = []
        with patch("llm_utils.time.sleep", side_effect=lambda s: sleep_vals.append(s)):
            self.invoke_with_retry(mc, {}, required_key="fields", label="t")
        self.assertEqual(len(sleep_vals), 1)
        self.assertGreater(sleep_vals[0], 0)

    def test_max_retry_attempts_is_3(self):
        self.assertEqual(self.MAX_RETRY_ATTEMPTS, 3)

    def test_source_has_retry_loop(self):
        src = (SCRIPTS_DIR / "llm_utils.py").read_text(encoding="utf-8")
        self.assertIn("for attempt in range(1, MAX_RETRY_ATTEMPTS + 1)", src)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3 — Atomic write in upload_transcript
# ══════════════════════════════════════════════════════════════════════════════
class TestFix3AtomicWrite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.app_src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        # Extract upload_transcript function body
        m = re.search(r"async def upload_transcript.*?(?=\n@app|\nclass |\Z)",
                      cls.app_src, re.DOTALL)
        cls.fn_body = m.group() if m else ""

    def test_source_uses_os_replace(self):
        self.assertIn("os.replace", self.app_src)

    def test_source_uses_mkstemp(self):
        self.assertIn("mkstemp", self.app_src)

    def test_upload_transcript_uses_os_replace(self):
        self.assertIn("os.replace", self.fn_body)

    def test_upload_transcript_no_direct_dest_write(self):
        direct = re.findall(r'open\(dest\s*,\s*["\']wb?["\']', self.fn_body)
        self.assertEqual(direct, [], "Must not open dest directly for writing")

    def test_tmp_suffix_is_dot_tmp(self):
        self.assertIn('.tmp"', self.fn_body)

    def test_atomic_write_pattern_stdlib(self):
        """Validate the atomic write pattern works correctly using stdlib only."""
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "output.json")
            content = b'{"ok": true}'
            tmp_fd, tmp_path = tempfile.mkstemp(dir=d, suffix=".tmp")
            try:
                with os.fdopen(tmp_fd, "wb") as fh:
                    fh.write(content)
                os.replace(tmp_path, dest)
            except Exception:
                os.unlink(tmp_path)
                raise
            self.assertTrue(os.path.exists(dest))
            self.assertFalse(os.path.exists(tmp_path))
            self.assertEqual(open(dest, "rb").read(), content)

    def test_no_tmp_file_left_on_success(self):
        """No leftover .tmp files after successful atomic write."""
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "out.json")
            tmp_fd, tmp_path = tempfile.mkstemp(dir=d, suffix=".tmp")
            with os.fdopen(tmp_fd, "wb") as fh:
                fh.write(b"{}")
            os.replace(tmp_path, dest)
            tmps = [f for f in os.listdir(d) if f.endswith(".tmp")]
            self.assertEqual(tmps, [])


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3b — Atomic write in rename_speakers
# ══════════════════════════════════════════════════════════════════════════════
class TestFix3bAtomicRename(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        m = re.search(r"def rename_speakers.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL)
        cls.fn_body = m.group() if m else ""

    def test_rename_uses_os_replace(self):
        self.assertIn("os.replace", self.fn_body)

    def test_rename_uses_mkstemp(self):
        self.assertIn("mkstemp", self.fn_body)

    def test_rename_has_tmp_suffix(self):
        self.assertIn(".tmp", self.fn_body)

    def test_rename_cleans_up_on_exception(self):
        """Verify exception handler removes tmp file."""
        self.assertIn("os.unlink", self.fn_body)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 4 — Local numpy RNG
# ══════════════════════════════════════════════════════════════════════════════
class TestFix4LocalRng(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.app_src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")

    def test_no_live_random_seed(self):
        for line in self.app_src.splitlines():
            stripped = line.strip()
            if "random.seed" in stripped and not stripped.startswith("#"):
                self.fail(f"Live random.seed() call: {stripped!r}")

    def test_uses_numpy_default_rng(self):
        self.assertIn("default_rng(42)", self.app_src)

    def test_uses_rng_local_variable(self):
        self.assertIn("_rng.random()", self.app_src)

    def test_does_not_mutate_global_random_state(self):
        # Source inspection: random.seed may appear only in comments, not as live call
        fn_match = re.search(r"def _build_diar_analytics.*?(?=\ndef [a-z]|\Z)",
                              self.app_src, re.DOTALL)
        body = fn_match.group() if fn_match else ""
        live_seed = [l for l in body.splitlines()
                     if "random.seed" in l and not l.strip().startswith("#")]
        self.assertEqual(live_seed, [],
                         f"Live random.seed call in _build_diar_analytics: {live_seed}")
        self.assertIn("default_rng(42)", body)
        self.assertIn("_rng.random()", body)

    def test_scatter_uses_rng_not_module_random(self):
        fn_match = re.search(r"def _build_diar_analytics.*?(?=\ndef [a-z]|\Z)",
                              self.app_src, re.DOTALL)
        body = fn_match.group() if fn_match else ""
        # Must not call random.random() — only _rng.random()
        bad = re.findall(r'(?<![_\w])random\.random\(\)', body)
        self.assertEqual(bad, [], "Must use _rng.random(), not random.random()")

    def test_rng_is_seeded_for_determinism(self):
        """default_rng must use a fixed seed (42) for reproducible scatter."""
        self.assertIn("default_rng(42)", self.app_src)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 5 — Step validation in /api/run
# ══════════════════════════════════════════════════════════════════════════════
class TestFix5StepValidation(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        m = re.search(r"def start_pipeline.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL)
        cls.fn_body = m.group() if m else ""

    def test_valid_steps_set_defined(self):
        self.assertIn("_VALID_STEPS", self.fn_body)

    def test_raises_http_exception_on_invalid(self):
        self.assertIn("HTTPException", self.fn_body)

    def test_valid_range_is_0_to_6(self):
        self.assertIn("range(7)", self.fn_body)

    def test_invalid_steps_detected(self):
        self.assertIn("invalid", self.fn_body.lower())

    def test_returns_400_status_code(self):
        self.assertIn("400", self.fn_body)

    def test_validation_before_thread_spawn(self):
        """Validation block must appear before threading.Thread call."""
        valid_pos  = self.fn_body.find("_VALID_STEPS")
        thread_pos = self.fn_body.find("threading.Thread")
        self.assertGreater(thread_pos, valid_pos,
                           "Validation must happen before thread is spawned")

    def test_valid_steps_full_range(self):
        """Steps 0-6 must all be valid."""
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        self.assertIn("set(range(7))", src)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 6 — MOM core fill failure is fatal
# ══════════════════════════════════════════════════════════════════════════════
class TestFix6MomFatalFail(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")
        m = re.search(r"def _run_mom_passes.*?(?=\ndef [a-z]|\Z)", cls.src, re.DOTALL)
        cls.fn_body = m.group() if m else ""

    def test_raises_runtime_error_on_core_fail(self):
        self.assertIn("raise RuntimeError", self.fn_body)

    def test_error_message_mentions_retry(self):
        # RuntimeError may use f-strings, multiline concat, etc. — check for content
        m = re.search(r'RuntimeError.*?(?:retry|attempt|failed)',
                      self.fn_body, re.DOTALL | re.IGNORECASE)
        self.assertIsNotNone(m,
            "RuntimeError must mention 'retry', 'attempt', or 'failed'")

    def test_error_message_mentions_mom(self):
        m = re.search(r'RuntimeError\(["\'](.+?)["\']', self.fn_body)
        if m:
            self.assertIn("MOM", m.group(1))

    def test_fix6_comment_present(self):
        self.assertIn("Fix 6", self.src)

    def test_action_items_fallback_on_failure(self):
        """If action items fail, code must set value=[] not crash."""
        self.assertIn("action_items", self.fn_body)
        self.assertIn('[]', self.fn_body)

    def test_core_fail_check_before_action_items(self):
        """RuntimeError check must precede action-items extraction."""
        raise_pos  = self.fn_body.find("raise RuntimeError")
        action_pos = self.fn_body.find("action_items", raise_pos + 1)
        self.assertGreater(action_pos, raise_pos)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 7 — Dropped fields warning
# ══════════════════════════════════════════════════════════════════════════════
class TestFix7DroppedFieldsWarning(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")

    def test_generic_pass_has_dropped_warning(self):
        fn = re.search(r"def _run_generic_pass.*?(?=\ndef [a-z]|\Z)", self.src, re.DOTALL)
        self.assertIn("dropped", fn.group().lower())

    def test_mom_pass_has_dropped_warning(self):
        fn = re.search(r"def _run_mom_passes.*?(?=\ndef [a-z]|\Z)", self.src, re.DOTALL)
        self.assertIn("dropped", fn.group().lower())

    def test_warning_logs_expected_count(self):
        self.assertIn("len(leaves)", self.src)

    def test_warning_logs_returned_count(self):
        self.assertIn("returned", self.src)

    def test_fix7_comment_present(self):
        self.assertIn("Fix 7", self.src)

    def test_warning_uses_log_warning_level(self):
        self.assertIn("log.warning", self.src)

    def test_warning_triggered_when_llm_drops(self):
        """Simulate: 3 fields requested, LLM returns 1 → warning expected."""
        sys.path.insert(0, str(SCRIPTS_DIR))
        import importlib
        # We verify by reading source logic: returned < len(leaves) triggers warning
        fn = re.search(r"def _run_generic_pass.*?(?=\ndef [a-z]|\Z)", self.src, re.DOTALL)
        body = fn.group()
        # Must compare returned count vs expected
        self.assertTrue(
            "returned < len(leaves)" in body or
            "len(leaves) - returned" in body,
            "Must compare returned fields vs expected"
        )


# ══════════════════════════════════════════════════════════════════════════════
# FIX 8 — stop_job only sets flag
# ══════════════════════════════════════════════════════════════════════════════
class TestFix8StopJobFlag(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        m = re.search(r"def stop_job.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL)
        cls.fn_body = m.group() if m else ""
        m2 = re.search(r"def _pipeline_thread.*?(?=\ndef [a-z_]|\Z)", src, re.DOTALL)
        cls.thread_body = m2.group() if m2 else ""

    def test_endpoint_sets_stop_requested_flag(self):
        self.assertIn("_stop_requested", self.fn_body)

    def test_endpoint_does_not_set_status_stopped(self):
        bad = re.search(r'job\[.status.\]\s*=\s*.stopped.', self.fn_body)
        self.assertIsNone(bad, "stop_job endpoint must NOT set status='stopped'")

    def test_endpoint_returns_stop_requested(self):
        self.assertIn("stop_requested", self.fn_body)

    def test_thread_checks_stop_flag(self):
        self.assertIn("_stop_requested", self.thread_body)

    def test_thread_sets_status_stopped(self):
        self.assertIn('"stopped"', self.thread_body)

    def test_fix8_comment_present(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        self.assertIn("Fix 8", src)

    def test_endpoint_returns_ok_true(self):
        self.assertIn('"ok": True', self.fn_body)

    def test_flag_set_to_true(self):
        self.assertIn("_stop_requested\"] = True", self.fn_body)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 10 — extract_json logs raw preview on failure
# ══════════════════════════════════════════════════════════════════════════════
class TestFix10ExtractJsonLogging(unittest.TestCase):

    def setUp(self):
        from llm_utils import extract_json
        self.extract_json = extract_json

    def _capture_debug_logs(self, text):
        msgs = []
        class H(logging.Handler):
            def emit(self, r): msgs.append(r.getMessage())
        h = H(); h.setLevel(logging.DEBUG)
        logger = logging.getLogger("llm_utils")
        old_level = logger.level
        logger.setLevel(logging.DEBUG)
        logger.addHandler(h)
        try:
            self.extract_json(text)
        finally:
            logger.removeHandler(h)
            logger.setLevel(old_level)
        return msgs

    def test_logs_on_no_opening_brace(self):
        msgs = self._capture_debug_logs("no json here")
        self.assertTrue(
            any("raw" in m.lower() or "preview" in m.lower() for m in msgs),
            f"No raw preview logged. Got: {msgs}"
        )

    def test_logs_on_unmatched_braces(self):
        msgs = self._capture_debug_logs('{"unclosed": "object"')
        self.assertTrue(any("raw" in m.lower() or "preview" in m.lower() for m in msgs))

    def test_no_exception_on_bad_input(self):
        try:
            self.extract_json("not json at all!!!")
            self.extract_json("")
            self.extract_json("{bad: json}")
        except Exception as e:
            self.fail(f"extract_json raised unexpectedly: {e}")

    def test_success_returns_dict(self):
        result = self.extract_json('{"key": "value"}')
        self.assertEqual(result, {"key": "value"})

    def test_preview_not_full_dump(self):
        """Log messages must not reproduce the full input text."""
        long_garbage = "x" * 5000
        msgs = self._capture_debug_logs(long_garbage)
        for m in msgs:
            self.assertLess(len(m), 1000,
                            f"Log message too long ({len(m)} chars) — not truncated")

    def test_fix10_comment_in_source(self):
        src = (SCRIPTS_DIR / "llm_utils.py").read_text(encoding="utf-8")
        self.assertIn("Fix 10", src)

    def test_logs_on_json_decode_error(self):
        # Valid-looking JSON with syntax error after brace
        msgs = self._capture_debug_logs('{"key": unquoted_value }')
        # Should not raise; may or may not log depending on cleanup
        self.assertIsNone(None)  # just confirm no exception


# ══════════════════════════════════════════════════════════════════════════════
# FIX 11 — retryDelay regex corrected
# ══════════════════════════════════════════════════════════════════════════════
class TestFix11RetryDelayRegex(unittest.TestCase):

    def setUp(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS, BASE_RETRY_BACKOFF_SECS
        self.retry_delay = retry_delay
        self.RETRY_BUFFER_SECS = RETRY_BUFFER_SECS
        self.BASE = BASE_RETRY_BACKOFF_SECS

    def test_parses_single_quoted_integer(self):
        v = self.retry_delay(Exception("retryDelay: '5s'"), 1)
        self.assertAlmostEqual(v, 5.0 + self.RETRY_BUFFER_SECS)

    def test_parses_double_quoted_integer(self):
        v = self.retry_delay(Exception('retryDelay: "10s"'), 1)
        self.assertAlmostEqual(v, 10.0 + self.RETRY_BUFFER_SECS)

    def test_parses_float_delay(self):
        v = self.retry_delay(Exception("retryDelay: '2.5s'"), 1)
        self.assertAlmostEqual(v, 2.5 + self.RETRY_BUFFER_SECS, places=3)

    def test_parses_dict_style(self):
        v = self.retry_delay(Exception("{'retryDelay': '30s'}"), 1)
        self.assertAlmostEqual(v, 30.0 + self.RETRY_BUFFER_SECS)

    def test_parses_large_delay(self):
        v = self.retry_delay(Exception("message: 'Rate', retryDelay: '60s'"), 1)
        self.assertAlmostEqual(v, 60.0 + self.RETRY_BUFFER_SECS)

    def test_fallback_attempt_1(self):
        v = self.retry_delay(Exception("generic error"), 1)
        self.assertEqual(v, self.BASE ** 1)

    def test_fallback_attempt_2(self):
        v = self.retry_delay(Exception("generic error"), 2)
        self.assertEqual(v, self.BASE ** 2)

    def test_fallback_attempt_3(self):
        v = self.retry_delay(Exception("generic error"), 3)
        self.assertEqual(v, self.BASE ** 3)

    def test_exponential_values_are_2_4_8(self):
        exc = Exception("no hint")
        self.assertEqual(self.retry_delay(exc, 1), 2)
        self.assertEqual(self.retry_delay(exc, 2), 4)
        self.assertEqual(self.retry_delay(exc, 3), 8)

    def test_old_broken_regex_did_not_work(self):
        """Prove the old pattern was broken (never matched digits)."""
        old_broken = r"['\"]retryDelay['\"]:\s*['\"](\\ d+(?:\\.\\ d+)?)s?['\"]"
        self.assertIsNone(re.search(old_broken, "retryDelay: '5s'"),
                          "Old broken pattern must not match — confirms Fix 11 was necessary")

    def test_new_regex_matches_all_formats(self):
        pattern = r"retryDelay['\"]?\s*[:\s]+['\"]?(\d+(?:\.\d+)?)s?['\"]?"
        cases = [
            ("retryDelay: '5s'",              "5"),
            ('retryDelay: "10s"',             "10"),
            ("{'retryDelay': '5s'}",          "5"),
            ("message: x, retryDelay: '30s'", "30"),
            ('retryDelay: "2.5s"',            "2.5"),
        ]
        for text, expected in cases:
            m = re.search(pattern, text)
            self.assertIsNotNone(m, f"Pattern failed to match: {text!r}")
            self.assertEqual(m.group(1), expected)

    def test_fix11_comment_in_source(self):
        src = (SCRIPTS_DIR / "llm_utils.py").read_text(encoding="utf-8")
        self.assertIn("Fix 11", src)


# ══════════════════════════════════════════════════════════════════════════════
# llm_utils CORE
# ══════════════════════════════════════════════════════════════════════════════
class TestLlmUtilsCore(unittest.TestCase):

    def setUp(self):
        from llm_utils import (
            extract_json, collect_leaves, is_leaf, write_back,
            to_str, save_json, load_json,
        )
        self.extract_json   = extract_json
        self.collect_leaves = collect_leaves
        self.is_leaf        = is_leaf
        self.write_back     = write_back
        self.to_str         = to_str
        self.save_json      = save_json
        self.load_json      = load_json

    # extract_json
    def test_extract_simple_object(self):
        self.assertEqual(self.extract_json('{"a": 1}'), {"a": 1})

    def test_extract_markdown_fenced(self):
        self.assertEqual(self.extract_json('```json\n{"b": 2}\n```'), {"b": 2})

    def test_extract_trailing_comma(self):
        self.assertEqual(self.extract_json('{"a": 1,}'), {"a": 1})

    def test_extract_nested_object(self):
        r = self.extract_json('{"outer": {"inner": [1, 2, 3]}}')
        self.assertEqual(r, {"outer": {"inner": [1, 2, 3]}})

    def test_extract_empty_string_returns_none(self):
        self.assertIsNone(self.extract_json(""))

    def test_extract_plain_text_returns_none(self):
        self.assertIsNone(self.extract_json("no json here"))

    def test_extract_text_before_json(self):
        self.assertEqual(self.extract_json('Here: {"x": 9}'), {"x": 9})

    def test_extract_escape_sequences(self):
        r = self.extract_json('{"msg": "line1\\nline2"}')
        self.assertIsNotNone(r)
        self.assertIn("msg", r)

    def test_extract_array_alone_returns_none(self):
        """extract_json only finds objects {}."""
        self.assertIsNone(self.extract_json("[1, 2, 3]"))

    # collect_leaves
    def test_collect_leaves_flat(self):
        schema = {
            "f1": {"title": "F1", "description": "d", "value": None},
            "f2": {"title": "F2", "description": "d", "value": None},
        }
        paths = [p for p, _ in self.collect_leaves(schema)]
        self.assertIn("f1", paths)
        self.assertIn("f2", paths)

    def test_collect_leaves_nested(self):
        schema = {"meta": {"title": {"title": "T", "description": "D", "value": None}}}
        self.assertEqual(self.collect_leaves(schema)[0][0], "meta.title")

    def test_collect_leaves_list(self):
        schema = {"items": [{"name": {"title": "N", "description": "D", "value": None}}]}
        self.assertEqual(self.collect_leaves(schema)[0][0], "items[0].name")

    def test_collect_leaves_empty(self):
        self.assertEqual(self.collect_leaves({}), [])

    def test_collect_leaves_preserves_leaf_content(self):
        schema = {"f": {"title": "T", "description": "D", "value": "existing"}}
        leaves = self.collect_leaves(schema)
        self.assertEqual(leaves[0][1]["value"], "existing")

    # is_leaf
    def test_is_leaf_valid(self):
        self.assertTrue(self.is_leaf({"title": "T", "description": "D", "value": None}))

    def test_is_leaf_missing_value(self):
        self.assertFalse(self.is_leaf({"title": "T", "description": "D"}))

    def test_is_leaf_not_dict(self):
        self.assertFalse(self.is_leaf("string"))
        self.assertFalse(self.is_leaf(42))
        self.assertFalse(self.is_leaf(None))

    def test_is_leaf_empty_dict(self):
        self.assertFalse(self.is_leaf({}))

    # write_back
    def test_write_back_flat(self):
        filled = {"f1": {"title": "T", "description": "D", "value": None, "trace": None}}
        self.write_back(filled, "f1", "hello", {"utterance_id": [0]})
        self.assertEqual(filled["f1"]["value"], "hello")
        self.assertEqual(filled["f1"]["trace"], {"utterance_id": [0]})

    def test_write_back_nested(self):
        filled = {"meta": {"title": {"title": "T", "description": "D", "value": None, "trace": None}}}
        self.write_back(filled, "meta.title", "My Meeting", None)
        self.assertEqual(filled["meta"]["title"]["value"], "My Meeting")

    def test_write_back_why_null(self):
        filled = {"f1": {"title": "T", "description": "D", "value": None, "trace": None}}
        self.write_back(filled, "f1", None, None, why_null="not_mentioned")
        self.assertEqual(filled["f1"]["why_null"], "not_mentioned")

    # save_json / load_json
    def test_save_load_roundtrip(self):
        data = {"key": "value", "nums": [1, 2, 3]}
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "test.json")
            self.save_json(data, path)
            self.assertEqual(self.load_json(path), data)

    def test_save_json_creates_parent_dirs(self):
        with tempfile.TemporaryDirectory() as d:
            nested = os.path.join(d, "a", "b", "c", "out.json")
            self.save_json({"x": 1}, nested)
            self.assertTrue(os.path.exists(nested))

    def test_save_json_unicode(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "uni.json")
            data = {"name": "日本語テスト"}
            self.save_json(data, path)
            self.assertEqual(self.load_json(path), data)

    # to_str
    def test_to_str_dict(self):
        result = self.to_str({"a": 1})
        self.assertEqual(json.loads(result), {"a": 1})

    def test_to_str_scalar_int(self):
        self.assertEqual(self.to_str(42), "42")

    def test_to_str_scalar_str(self):
        self.assertEqual(self.to_str("hello"), "hello")


# ══════════════════════════════════════════════════════════════════════════════
# EDGE CASES
# ══════════════════════════════════════════════════════════════════════════════
class TestEdgeCases(unittest.TestCase):

    def test_collect_leaves_skips_non_leaf_dicts(self):
        from llm_utils import collect_leaves
        schema = {"group": {"nested": {"title": "T", "description": "D", "value": None}}}
        leaves = collect_leaves(schema)
        self.assertEqual(len(leaves), 1)
        self.assertEqual(leaves[0][0], "group.nested")

    def test_unsupported_mode_raises_value_error(self):
        """run_fill must raise ValueError for unknown modes before any LLM call."""
        src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")
        self.assertIn("SUPPORTED_MODES", src)
        self.assertIn("unsupported mode", src)

    def test_extract_json_handles_multiple_objects(self):
        """extract_json should return the FIRST complete object."""
        from llm_utils import extract_json
        r = extract_json('{"first": 1} {"second": 2}')
        self.assertEqual(r, {"first": 1})

    def test_extract_json_deeply_nested(self):
        from llm_utils import extract_json
        deep = json.dumps({"a": {"b": {"c": {"d": "value"}}}})
        r = extract_json(deep)
        self.assertEqual(r["a"]["b"]["c"]["d"], "value")

    def test_write_back_list_path(self):
        from llm_utils import write_back, collect_leaves
        schema = {"items": [{"name": {"title": "N", "description": "D", "value": None, "trace": None}}]}
        filled = copy.deepcopy(schema)
        write_back(filled, "items[0].name", "Alice", None)
        self.assertEqual(filled["items"][0]["name"]["value"], "Alice")

    def test_mom_action_items_empty_list_when_extraction_fails(self):
        """If action result is falsy, action_items.items.value must be []."""
        src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")
        # Source must handle falsy action_result
        self.assertIn("action_items", src)
        fn = re.search(r"if action_result:.*?else:.*?filled.*?action_items.*?\[\]",
                       src, re.DOTALL)
        # Check the else branch sets [] via source inspection
        else_branch = re.search(
            r'else:.*?filled\["action_items"\]\["items"\]\["value"\]\s*=\s*\[\]',
            src, re.DOTALL
        )
        self.assertIsNotNone(else_branch,
                             "Must set action_items.items.value=[] on extraction failure")

    def test_generic_fill_raises_on_all_retries_failed(self):
        """_run_generic_pass must raise RuntimeError if invoke_with_retry returns None."""
        src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")
        fn = re.search(r"def _run_generic_pass.*?(?=\ndef [a-z]|\Z)", src, re.DOTALL)
        self.assertIn("raise RuntimeError", fn.group())

    def test_save_json_overwrites_existing_file(self):
        from llm_utils import save_json, load_json
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "out.json")
            save_json({"v": 1}, path)
            save_json({"v": 2}, path)
            self.assertEqual(load_json(path), {"v": 2})

    def test_collect_leaves_ignores_guide_comments(self):
        """_GUIDE / _comment nodes are not leaves and must be skipped."""
        from llm_utils import collect_leaves
        schema = {
            "_GUIDE": {"_comment": "ignore me"},
            "real_field": {"title": "T", "description": "D", "value": None},
        }
        leaves = collect_leaves(schema)
        paths = [p for p, _ in leaves]
        self.assertNotIn("_GUIDE._comment", paths)
        self.assertIn("real_field", paths)

    def test_concurrent_atomic_writes_no_corruption(self):
        """Two threads writing to the same dest atomically — last one wins cleanly."""
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "shared.json")
            errors = []

            def write_val(v):
                try:
                    tmp_fd, tmp_path = tempfile.mkstemp(dir=d, suffix=".tmp")
                    content = json.dumps({"v": v}).encode()
                    with os.fdopen(tmp_fd, "wb") as fh:
                        fh.write(content)
                    os.replace(tmp_path, dest)
                except Exception as e:
                    errors.append(e)

            threads = [threading.Thread(target=write_val, args=(i,)) for i in range(8)]
            for t in threads: t.start()
            for t in threads: t.join()

            self.assertEqual(errors, [])
            self.assertTrue(os.path.exists(dest))
            data = json.loads(open(dest).read())
            self.assertIn("v", data)


# ══════════════════════════════════════════════════════════════════════════════
# OUTPUT FORMATTING
# ══════════════════════════════════════════════════════════════════════════════
class TestOutputFormatting(unittest.TestCase):

    def test_write_back_does_not_add_extra_keys(self):
        from llm_utils import write_back
        leaf = {"title": "T", "description": "D", "value": None, "trace": None}
        filled = {"f1": leaf.copy()}
        write_back(filled, "f1", "val", "trace_obj")
        allowed = {"title", "description", "value", "trace", "why_null", "format"}
        extra = set(filled["f1"].keys()) - allowed
        self.assertEqual(extra, set(), f"Unexpected keys added: {extra}")

    def test_save_json_produces_indented_output(self):
        from llm_utils import save_json
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "out.json")
            save_json({"a": 1}, path)
            text = open(path).read()
            self.assertIn("\n", text, "save_json should produce indented (pretty) JSON")

    def test_filled_schema_retains_guide_section(self):
        """_GUIDE section must survive a fill pass (never mutated)."""
        from llm_utils import collect_leaves, write_back
        schema = {
            "_GUIDE": {"_comment": "do not touch"},
            "field": {"title": "F", "description": "d", "value": None, "trace": None},
        }
        filled = copy.deepcopy(schema)
        leaves = collect_leaves(schema)
        for path, _ in leaves:
            write_back(filled, path, "value", None)
        self.assertEqual(filled["_GUIDE"]["_comment"], "do not touch")

    def test_to_str_list_is_json(self):
        from llm_utils import to_str
        result = to_str([1, 2, 3])
        self.assertEqual(json.loads(result), [1, 2, 3])

    def test_write_back_value_none_allowed(self):
        from llm_utils import write_back
        filled = {"f": {"title": "T", "description": "D", "value": "old", "trace": None}}
        write_back(filled, "f", None, None, why_null="not_mentioned")
        self.assertIsNone(filled["f"]["value"])
        self.assertEqual(filled["f"]["why_null"], "not_mentioned")

    def test_normalised_action_items_structure(self):
        """_apply_action_items output must have action/owner/deadline keys."""
        src = (SCRIPTS_DIR / "llm_filler.py").read_text(encoding="utf-8")
        fn = re.search(r"def _apply_action_items.*?(?=\ndef [a-z]|\Z)", src, re.DOTALL)
        body = fn.group()
        self.assertIn('"action"', body)
        self.assertIn('"owner"', body)
        self.assertIn('"deadline"', body)

    def test_json_output_is_valid_after_write_back(self):
        from llm_utils import collect_leaves, write_back, save_json, load_json
        schema = copy.deepcopy(SAMPLE_SCHEMA)
        filled = copy.deepcopy(schema)
        for path, _ in collect_leaves(schema):
            write_back(filled, path, "test_value", {"utterance_id": [0]})
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "out.json")
            save_json(filled, path)
            reloaded = load_json(path)
        self.assertEqual(reloaded["meta"]["meeting_title"]["value"], "test_value")


# ══════════════════════════════════════════════════════════════════════════════
# PLAYGROUND UI (static/structural validation)
# ══════════════════════════════════════════════════════════════════════════════
class TestPlaygroundUI(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.html = (REPO_ROOT / "frontend.html").read_text(encoding="utf-8")

    def test_view_playground_present(self):
        self.assertIn('id="view-playground"', self.html)

    def test_nav_playground_button(self):
        self.assertIn('id="nb-playground"', self.html)

    def test_schema_editor_present(self):
        self.assertIn('id="pg-schema-ta"', self.html)

    def test_js_editor_present(self):
        self.assertIn('id="pg-js-ta"', self.html)

    def test_output_panel_present(self):
        self.assertIn('id="pg-json-out"', self.html)

    def test_output_actions_panel(self):
        self.assertIn('id="pg-output-actions"', self.html)

    def test_download_docx_button(self):
        self.assertIn('id="pg-dl-docx-btn"', self.html)

    def test_playground_run_api_call(self):
        self.assertIn("/api/playground/run", self.html)

    def test_playground_result_api_call(self):
        self.assertIn("/api/playground/result/", self.html)

    def test_line_numbers_present(self):
        self.assertIn("pg-line-nums", self.html)

    def test_syntax_highlighting_classes(self):
        for cls_name in ["pg-json-key", "pg-json-string", "pg-json-number", "pg-json-null"]:
            self.assertIn(cls_name, self.html)

    def test_playground_functions_present(self):
        for fn in ["pgInit", "pgRun", "pgPoll", "pgShowResults", "pgDownloadDocx",
                   "pgValidate", "pgRenderPreview", "pgRenderJsonViewer"]:
            self.assertIn(fn, self.html)

    def test_no_duplicate_transcript_imported(self):
        count = self.html.count("let _transcriptImported")
        self.assertEqual(count, 1, f"_transcriptImported declared {count} times")

    def test_all_nav_views_present(self):
        for view_id in ["view-pipeline", "view-playground", "view-prepare",
                        "view-results", "view-studio"]:
            self.assertIn(f'id="{view_id}"', self.html)

    def test_scroll_sync_implemented(self):
        self.assertIn("pgSyncScroll", self.html)

    def test_live_validation_implemented(self):
        self.assertIn("pgValidate", self.html)

    def test_field_summary_implemented(self):
        self.assertIn("pgRenderFieldSummary", self.html)

    def test_download_json_implemented(self):
        self.assertIn("pgDownloadJson", self.html)


# ══════════════════════════════════════════════════════════════════════════════
# PACKAGE INTEGRITY
# ══════════════════════════════════════════════════════════════════════════════
class TestPackageIntegrity(unittest.TestCase):

    def _path(self, *parts):
        return REPO_ROOT.joinpath(*parts)

    def test_llm_utils_present(self):
        self.assertTrue(self._path("scripts", "llm_utils.py").exists())

    def test_llm_filler_present(self):
        self.assertTrue(self._path("scripts", "llm_filler.py").exists())

    def test_chain2_present(self):
        self.assertTrue(self._path("scripts", "chain2_brd_response.py").exists())

    def test_chain_mom_present(self):
        self.assertTrue(self._path("scripts", "chain_mom.py").exists())

    def test_generic_chain_fill_present(self):
        self.assertTrue(self._path("scripts", "generic_chain_fill.py").exists())

    def test_generic_docx_runner_present(self):
        self.assertTrue(self._path("scripts", "generic_docx_runner.py").exists())

    def test_app_py_present(self):
        self.assertTrue(self._path("app.py").exists())

    def test_frontend_html_present(self):
        self.assertTrue(self._path("frontend.html").exists())

    def test_validation_report_present(self):
        self.assertTrue(self._path("VALIDATION_REPORT.md").exists())

    def test_test_regression_present(self):
        self.assertTrue(self._path("tests", "test_regression.py").exists())

    def test_test_app_present(self):
        self.assertTrue(self._path("tests", "test_app.py").exists())

    def test_requirements_txt_present(self):
        self.assertTrue(self._path("requirements.txt").exists())

    def test_all_python_files_valid_syntax(self):
        py_files = list(REPO_ROOT.rglob("*.py"))
        py_files = [f for f in py_files if "__pycache__" not in str(f)]
        for f in py_files:
            with self.subTest(file=f.name):
                try:
                    ast.parse(f.read_text(encoding="utf-8"))
                except SyntaxError as e:
                    self.fail(f"Syntax error in {f}: {e}")

    def test_readme_present(self):
        self.assertTrue(self._path("README.md").exists())

    def test_brd_prompts_present(self):
        self.assertTrue(self._path("prompts", "brd-system-prompt.json").exists())

    def test_mom_prompts_present(self):
        self.assertTrue(self._path("prompts", "mom-schema-prompt.json").exists())


# ══════════════════════════════════════════════════════════════════════════════
# Runner
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="DN-Studio regression test runner")
    parser.add_argument("class_filter", nargs="?", default=None,
                        help="Run only tests in this class")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    loader = unittest.TestLoader()
    suite  = unittest.TestSuite()

    all_classes = [
        TestFix1SharedImports,
        TestFix2InvokeWithRetry,
        TestFix3AtomicWrite,
        TestFix3bAtomicRename,
        TestFix4LocalRng,
        TestFix5StepValidation,
        TestFix6MomFatalFail,
        TestFix7DroppedFieldsWarning,
        TestFix8StopJobFlag,
        TestFix10ExtractJsonLogging,
        TestFix11RetryDelayRegex,
        TestLlmUtilsCore,
        TestEdgeCases,
        TestOutputFormatting,
        TestPlaygroundUI,
        TestPackageIntegrity,
    ]

    for cls in all_classes:
        if args.class_filter is None or args.class_filter in cls.__name__:
            suite.addTests(loader.loadTestsFromTestCase(cls))

    verbosity = 2 if args.verbose else 1
    runner = unittest.TextTestRunner(verbosity=verbosity, stream=sys.stdout)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)


