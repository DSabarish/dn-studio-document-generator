# Diarisation

Diarisation identifies *who* spoke *when* in an audio recording. DN-Studio combines Whisper (speech-to-text) with Resemblyzer (speaker embeddings) and scikit-learn clustering.

---

## Process

1. **Transcription** — Faster-Whisper segments the audio into utterances with timestamps and confidence scores. Filler words (um, uh, er) are cleaned automatically.

2. **Embedding extraction** — Each segment is encoded into a 256-dimensional speaker embedding using Resemblyzer's VoiceEncoder. Segments shorter than 0.4s are skipped.

3. **Speaker clustering** — AgglomerativeClustering with cosine distance as primary, SpectralClustering as fallback. A temporal connectivity matrix gives a small pull to adjacent segments within 2s of each other.

4. **Post-processing** — Median filter smoothing (window 3–9 depending on segment count), then orphan merging: isolated single segments shorter than 1.5s that are sandwiched between the same speaker on both sides are re-assigned.

5. **Confidence scoring** — Each segment gets a `spk_confidence` score: cosine similarity between its embedding and the speaker centroid. Per-speaker mean confidence is logged.

---

## Speaker count

| Setting | Behaviour |
|---------|-----------|
| `num_speakers: 2` | Fixed at 2 speakers |
| `num_speakers: null` | Auto-detect |

Auto-detection uses two methods and votes:
- **Eigengap** — on the normalised Laplacian of the cosine affinity matrix
- **Ward linkage elbow** — on the distance series of a hierarchical clustering

If both methods agree, that count is used. If they differ by 1, the lower value is used. Otherwise the eigengap result wins.

---

## Whisper model trade-offs

| Model    | Speed  | Accuracy | GPU needed |
|----------|--------|----------|------------|
| tiny     | ~10x   | Basic    | No         |
| base     | ~7x    | Good     | No         |
| small    | ~4x    | Better   | Recommended |
| large-v2 | ~1x    | Best     | Yes        |

"Speed" is relative to audio duration. `tiny` processes a 1-hour recording in roughly 6–10 minutes on CPU.

---

## Transcript JSON format

```json
[
  {
    "utterance_id": 0,
    "speaker_id": "SPEAKER_0",
    "speaker_name": "Alice",
    "text": "Let's start with the agenda.",
    "start": 0.0,
    "end": 3.4,
    "confidence": 0.94,
    "spk_confidence": 0.91
  }
]
```

`utterance_id` is sequential from 0 and is used by all downstream LLM chains as the citation reference.

---

## Importing an existing transcript

If you already have a diarised transcript (from another tool or a previous run), use the **Transcript JSON** tab on the Input page. The file must match the format above. Steps 0 and 1 are automatically skipped.

Minimum required fields per utterance: `utterance_id`, `speaker_name`, `text`.


