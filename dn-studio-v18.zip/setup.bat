@echo off
echo.
echo  ============================================
echo   DN-Studio — Setup
echo  ============================================
echo.

REM Try to find Python (3.10+ required)
python --version >nul 2>&1
if %errorlevel% equ 0 (
  set PYTHON_CMD=python
  goto FOUND_PYTHON
)
py --version >nul 2>&1
if %errorlevel% equ 0 (
  set PYTHON_CMD=py
  goto FOUND_PYTHON
)
echo  [ERROR] Python not found. Please install Python 3.10+ from https://python.org
pause
exit /b 1

:FOUND_PYTHON
echo  Python found: 
%PYTHON_CMD% --version

REM Create virtual environment
echo  Creating virtual environment...
%PYTHON_CMD% -m venv venv
if %errorlevel% neq 0 (
  echo  [ERROR] Failed to create venv.
  pause
  exit /b 1
)

REM Activate and install
echo  Activating virtual environment...
call venv\Scripts\activate

echo  Upgrading pip...
python -m pip install --upgrade pip -q

echo  Installing Python dependencies (this may take a few minutes)...
pip install -r requirements.txt
if %errorlevel% neq 0 (
  echo  [ERROR] pip install failed.
  pause
  exit /b 1
)

REM Install Node.js packages
echo  Installing Node.js packages...
node --version >nul 2>&1
if %errorlevel% equ 0 (
  cd scripts
  npm install
  cd ..
  echo  Done.
) else (
  echo  [WARN] Node.js not found — install from https://nodejs.org
)

echo.
echo  ============================================
echo   Setup complete! Now run start.bat
echo  ============================================
echo.
pause
