@echo off
title Doc Studio
color 0A
cd /d "%~dp0"

echo.
echo  ============================================
echo   DN-Studio v4.0 - Starting
echo  ============================================
echo.
echo  Folder: %~dp0
echo.

REM Activate virtual environment if it exists (created by setup.bat)
if exist "venv\Scripts\activate.bat" (
  echo  Activating virtual environment...
  call venv\Scripts\activate.bat
) else (
  echo  [WARN] No venv found. Run setup.bat first for best results.
)

python --version >nul 2>&1
if %errorlevel% neq 0 goto NO_PYTHON

node --version >nul 2>&1
if %errorlevel% neq 0 goto NO_NODE

ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 echo  [WARN] ffmpeg not in PATH - audio conversion may fail

:INSTALL_DEPS
echo  Checking and installing Python dependencies...
pip install -r requirements.txt -q
if %errorlevel% neq 0 (
  echo  [ERROR] pip install failed. Check your internet connection.
  pause
  goto END
)
echo  Done.

:DEPS_OK
if exist "scripts\node_modules\docx" goto NODE_OK
echo  Installing docx npm package (one time)...
cd scripts
npm install docx --silent
cd ..
echo  Done.

:NODE_OK
echo  Starting Doc Studio at http://localhost:8000 ...
echo.
start "Doc Studio Server" cmd /k "cd /d "%~dp0" && (if exist venv\Scripts\activate.bat call venv\Scripts\activate.bat) && python app.py"
timeout /t 5 /nobreak >nul

set /a PING_COUNT=0
:PING_LOOP
set /a PING_COUNT+=1
if %PING_COUNT% gtr 30 goto SERVER_FAIL
python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/api/ping')" >nul 2>&1
if %errorlevel% neq 0 (
  timeout /t 2 /nobreak >nul
  goto PING_LOOP
)

echo  Server ready - opening browser...
start "" http://localhost:8000
echo.
echo  ============================================
echo   Doc Studio running at http://localhost:8000
echo   BRD pipeline + MOM + custom doc types
echo   Close the Server window to stop.
echo  ============================================
echo.
pause
goto END

:SERVER_FAIL
echo.
echo  [ERROR] Server failed to start after 60 seconds.
echo  Check the "Doc Studio Server" window for error details.
echo  Common fixes:
echo    1. Run setup.bat first to install all dependencies
echo    2. Check configuration.yaml has a valid experiment name
echo    3. Make sure port 8000 is not already in use
echo.
pause
goto END

:NO_PYTHON
echo  [ERROR] Python not found. Install Python and try again.
pause
goto END

:NO_NODE
echo  [ERROR] Node.js not found. Install from https://nodejs.org
pause
goto END

:END
