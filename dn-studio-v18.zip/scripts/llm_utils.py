"""
llm_utils.py — Shared utilities for DN-Studio LLM chain scripts.

Centralises functions used across all LLM callers:
    - JSON I/O helpers
    - LLM JSON extraction / cleaning
    - Schema leaf traversal
    - Rate-limit aware retry delay
    - Shared model builder  (build_model)
    - Shared retry wrapper  (invoke_with_retry)
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

MAX_RETRY_ATTEMPTS      = 3
BASE_RETRY_BACKOFF_SECS = 2   # 2 → 4 → 8 seconds (exponential fallback)
RETRY_BUFFER_SECS       = 2   # added on top of server-suggested delay


# ── JSON I/O ──────────────────────────────────────────────────────────────────

def load_json(path: str) -> Any:
    """Load and return parsed JSON from *path*."""
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_json(data: Any, path: str) -> None:
    """Serialise *data* to *path*, creating parent directories as needed."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


def to_str(obj: Any) -> str:
    """Pretty-print *obj* as JSON if it is a dict/list, else ``str()``."""
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)


# ── JSON extraction ───────────────────────────────────────────────────────────

def extract_json(text: str) -> Optional[Dict]:
    """
    Robustly extract the first complete JSON object from *text*.

    Handles:
    - Markdown code fences (```json … ```)
    - Trailing commas before ] / }
    - Escaped characters inside string values

    Fix 10: logs the raw text preview when extraction fails, enabling
    faster debugging of LLM response format issues.
    """
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    start = text.find("{")
    if start == -1:
        log.debug("extract_json: no opening brace found. Raw preview: %.200s", text)
        return None

    depth = 0
    end = -1
    in_string = False
    escape = False

    for i, ch in enumerate(text[start:], start):
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"' and not escape:
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break

    if end == -1:
        log.debug("extract_json: unmatched braces. Raw preview: %.200s", text[:200])
        return None

    json_str = re.sub(r",\s*([}\]])", r"\1", text[start:end])
    try:
        return json.loads(json_str)
    except json.JSONDecodeError as exc:
        # Fix 10: log raw response so developers can diagnose model output issues
        log.debug("extract_json: JSONDecodeError: %s. Raw preview: %.200s", exc, text[:200])
        return None


# ── Schema leaf traversal ─────────────────────────────────────────────────────

def is_leaf(node: Any) -> bool:
    """
    Return True if *node* is a schema leaf: a dict with at minimum
    ``title``, ``description``, and ``value`` keys.
    """
    return (
        isinstance(node, dict)
        and "title"       in node
        and "description" in node
        and "value"       in node
    )


def collect_leaves(node: Any, path: str = "") -> List[Tuple[str, Dict]]:
    """
    Recursively walk *node* and return every leaf as ``(dotpath, leaf_dict)``.

    Paths use dot-notation for dict keys and bracket-notation for list indices,
    e.g. ``"meta.attendees[0].name"``.
    """
    leaves: List[Tuple[str, Dict]] = []
    if is_leaf(node):
        leaves.append((path, node))
    elif isinstance(node, dict):
        for k, v in node.items():
            child_path = f"{path}.{k}" if path else k
            leaves.extend(collect_leaves(v, child_path))
    elif isinstance(node, list):
        for i, item in enumerate(node):
            leaves.extend(collect_leaves(item, f"{path}[{i}]"))
    return leaves


def write_back(filled: Any, path: str, value: Any, trace: Any,
               why_null: Optional[str] = None) -> None:
    """
    Navigate *filled* via *path* and set ``value``, ``trace``,
    and optionally ``why_null`` on the target leaf.
    """
    parts = [p for p in re.split(r"\.|[\[\]]", path) if p]
    node = filled
    for part in parts[:-1]:
        node = node[int(part)] if part.isdigit() else node[part]
    last = parts[-1]
    target = node[int(last)] if last.isdigit() else node[last]
    target["value"] = value
    target["trace"] = trace
    if why_null:
        target["why_null"] = why_null


# ── Retry delay ───────────────────────────────────────────────────────────────

def retry_delay(exc: Exception, attempt: int) -> float:
    """
    Return how many seconds to sleep before the next LLM attempt.

    Parses the server-suggested ``retryDelay`` from Gemini 429 responses.
    Falls back to exponential back-off: 2 → 4 → 8 seconds.

    Args:
        exc:     The caught exception (its string representation is inspected).
        attempt: 1-based attempt number (used for fallback exponent).
    """
    # Fix 11: corrected retryDelay regex — original used \\d in a raw string
    # which matched literal backslash+d, not a digit. New pattern also handles
    # plain/unquoted Gemini error formats for broader compatibility.
    match = re.search(
        r"retryDelay['\"]?\s*[:\s]+['\"]?(\d+(?:\.\d+)?)s?['\"]?",
        str(exc),
    )
    if match:
        suggested = float(match.group(1))
        log.info(
            "   ⏳ Rate limit — server requests %.0fs wait (attempt %d/%d)",
            suggested, attempt, MAX_RETRY_ATTEMPTS,
        )
        return suggested + RETRY_BUFFER_SECS

    return BASE_RETRY_BACKOFF_SECS ** attempt   # 2 → 4 → 8


# ── Shared model builder ──────────────────────────────────────────────────────

def build_model(cfg: Dict[str, Any], temperature: float) -> Any:
    """
    Instantiate and return a ``ChatGoogleGenerativeAI`` model from *cfg*.

    Per-run LLM overrides are injected by the pipeline runner via environment
    variables (set per-subprocess by app.py, never written to disk):

        DN_LLM_MODEL        – overrides cfg["llm"]["model"]
        DN_LLM_TEMPERATURE  – overrides the caller-supplied temperature
        DN_LLM_MAX_TOKENS   – overrides cfg["llm"]["max_tokens"]

    Args:
        cfg:         Resolved configuration dict (must contain ``cfg["llm"]``).
        temperature: Caller-supplied temperature — each step has its own default
                     (BRD schema: 0, MOM: 0.05, generic: 0.1).  Can be
                     further overridden at run-time via DN_LLM_TEMPERATURE.

    Returns:
        A ready-to-use ``ChatGoogleGenerativeAI`` instance.
    """
    from langchain_google_genai import ChatGoogleGenerativeAI   # lazy import

    llm_cfg = cfg["llm"]

    # ── Per-run env-var overrides (injected by app.py per job, never persistent) ─
    model_name = os.environ.get("DN_LLM_MODEL") or llm_cfg["model"]

    temp_env = os.environ.get("DN_LLM_TEMPERATURE")
    if temp_env is not None:
        try:
            temperature = float(temp_env)
        except ValueError:
            pass  # malformed value → keep caller default

    max_tokens_env = os.environ.get("DN_LLM_MAX_TOKENS")
    if max_tokens_env is not None:
        try:
            max_tokens = int(max_tokens_env)
        except ValueError:
            max_tokens = llm_cfg.get("max_tokens", 32768)
    else:
        max_tokens = llm_cfg.get("max_tokens", 32768)

    return ChatGoogleGenerativeAI(
        model              = model_name,
        google_api_key     = llm_cfg["api_key"],
        temperature        = temperature,
        max_output_tokens  = max_tokens,
        response_mime_type = "application/json",
    )


# ── Shared retry wrapper ──────────────────────────────────────────────────────

def invoke_with_retry(
    chain: Any,
    payload: Dict[str, Any],
    required_key: str,
    label: str,
) -> Optional[Dict]:
    """
    Invoke *chain* with *payload*, retrying up to ``MAX_RETRY_ATTEMPTS`` times.

    Args:
        chain:        A LangChain runnable (prompt | model | parser).
        payload:      Input dict passed to ``chain.invoke()``.
        required_key: Top-level key that must be present in the result dict
                      for the invocation to be considered successful.
                      e.g. ``"fields"`` or ``"action_items"``.
        label:        Human-readable label used in log messages.
                      e.g. ``"Core fill"`` or ``"Action items"``.

    Returns:
        The parsed result dict on success, or ``None`` if all attempts fail.
    """
    for attempt in range(1, MAX_RETRY_ATTEMPTS + 1):
        try:
            log.info(">> %s attempt %d/%d…", label, attempt, MAX_RETRY_ATTEMPTS)
            result = chain.invoke(payload)
            if result and isinstance(result, dict) and required_key in result:
                return result
            log.warning("   [WARN]  %s attempt %d: result missing key '%s'",
                        label, attempt, required_key)
        except Exception as exc:
            log.warning("   [WARN]  %s attempt %d: %s", label, attempt, exc)
            if attempt < MAX_RETRY_ATTEMPTS:
                time.sleep(retry_delay(exc, attempt))
    return None


