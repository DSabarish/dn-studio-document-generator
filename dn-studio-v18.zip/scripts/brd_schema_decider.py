"""
brd_schema_decider.py — BRD Pipeline Step 2: Schema Decider

Reads the diarised transcript and asks the LLM to decide:
  - The project domain
  - Which functional modules are in scope
  - Which non-functional requirement (NFR) sections to include

Output: brd-schema.json  (used by brd_requirements_writer.py)
"""
from __future__ import annotations

import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from cfg_utils import resolve_cfg
from llm_utils import (
    build_model,
    extract_json,
    invoke_with_retry,
    load_json,
    save_json,
    to_str,
)

log = logging.getLogger(__name__)


def build_schema_decider_chain(model, prompt_path: str):
    prompt_file = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{prompt_file.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown.",
        ),
        (
            "human",
            "Meeting Transcript:\n{transcript}\n\n"
            "Instructions:\n{instructions}\n\n"
            "Output Format:\n{output_format}\n\n"
            "Return JSON only:",
        ),
    ])

    return (
        {
            "transcript":    RunnableLambda(lambda x: to_str(x["transcript"])),
            "instructions":  RunnableLambda(lambda x: to_str(prompt_file.get("Instructions", {}))),
            "output_format": RunnableLambda(lambda x: to_str(prompt_file.get("Output Format", {}))),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(extract_json)
    )


def run(cfg: dict) -> str:
    chain_cfg = cfg["chains"]["chain1_schema_decider"]

    # Use shared build_model + response_mime_type for JSON mode (same as all other chains)
    model = build_model(cfg, temperature=0)

    transcript  = load_json(chain_cfg["input"]["transcript"])
    prompt_path = chain_cfg["input"]["prompt"]
    output_path = chain_cfg["output"]["schema"]

    log.info(">> Loaded %d utterances", len(transcript))

    chain = build_schema_decider_chain(model, prompt_path)

    schema = invoke_with_retry(
        chain,
        {"transcript": transcript},
        required_key="project_domain",
        label="BRD Schema Decider",
    )

    if not schema:
        raise RuntimeError("BRD Schema Decider failed after all retry attempts")

    save_json(schema, output_path)
    log.info("[OK] Schema saved → %s", output_path)
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg    = resolve_cfg("configuration.yaml")
    path   = run(cfg)
    schema = load_json(path)
    print(
        f"\n>> Schema Decider complete: {path}\n"
        f"   Domain  : {schema.get('project_domain', 'N/A')}\n"
        f"   Modules : {len(schema.get('functional_modules', []))}\n"
        f"   NFRs    : {len(schema.get('nfr_sections', []))}"
    )


