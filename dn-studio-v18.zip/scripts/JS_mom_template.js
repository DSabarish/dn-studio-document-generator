/**
 * JS_mom_template.js — Minutes of Meeting .docx generator
 * DN-Studio by DataNeurus — Executive-grade professional output
 */
"use strict";

const fs   = require("fs");
const path = require("path");

// ── Resolve 'docx' robustly regardless of where this JS file lives ──────────
// Priority:
//   1. NODE_PATH env (set by generic_docx_runner.py → scripts/node_modules)
//   2. scripts/ sibling to this file's directory
//   3. this file's own directory (legacy, when run from scripts/)
function requireDocx() {
  const candidates = [];

  // 1. From NODE_PATH env var (set by runner)
  const nodePath = process.env.NODE_PATH || "";
  nodePath.split(path.delimiter).filter(Boolean).forEach(p => {
    candidates.push(path.join(p, "docx"));
  });

  // 2. scripts/ relative to this file (handles artifacts_library/MOM/ location)
  const thisDir  = path.dirname(path.resolve(__filename));
  const parentDir = path.dirname(thisDir);
  candidates.push(path.join(thisDir, "..", "..", "scripts", "node_modules", "docx"));
  candidates.push(path.join(parentDir, "scripts", "node_modules", "docx"));

  // 3. Same dir as this file (legacy: run directly from scripts/)
  candidates.push(path.join(thisDir, "node_modules", "docx"));

  // 4. Standard Node resolution (global install)
  candidates.push("docx");

  for (const c of candidates) {
    try { return require(c); } catch (_) {}
  }
  throw new Error(
    "Cannot find module 'docx'.\n" +
    "Run: cd scripts && npm install\n" +
    "Tried: " + candidates.join(", ")
  );
}
const docx = requireDocx();

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, HeadingLevel, AlignmentType, BorderStyle, WidthType,
  ShadingType, TabStopType, convertInchesToTwip, LineRuleType, PageNumber,
  VerticalAlign,
} = docx;

const jsonPath   = process.argv[2];
const outputPath = process.argv[3];
if (!jsonPath || !outputPath) { process.exit(1); }
const data = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ── Palette
const C = {
  navy:"0F2044", blue:"1A56DB", blue_l:"EBF5FF", blue_m:"BFDBFE",
  teal:"0E9F6E", teal_l:"F3FAF7",
  amber:"C27803", amber_l:"FDF6B2",
  red:"C81E1E", red_l:"FDF2F2",
  ink:"111928", ink2:"374151", ink3:"6B7280", ink4:"9CA3AF",
  mist:"F9FAFB", mist2:"F3F4F6", mist3:"E5E7EB", mist4:"D1D5DB",
  white:"FFFFFF", accent:"1A56DB",
};
const FONT = "Calibri";

// ── Helpers
function val(o,fb){if(fb===undefined)fb="—";if(!o)return fb;return(o.value!==null&&o.value!==undefined)?o.value:fb;}
function arr(o){const v=val(o,[]);return Array.isArray(v)?v:(v&&v!=="—"?[String(v)]:[]);}
function s(o,fb){const v=val(o,fb!==undefined?fb:"—");return String(v||fb||"—");}
function run(text,opts){opts=opts||{};return new TextRun({text:String(text||""),font:opts.font||FONT,size:opts.size||22,bold:opts.bold||false,italics:opts.italics||false,color:opts.color||C.ink,characterSpacing:opts.spacing||undefined});}
function para(children,opts){opts=opts||{};if(typeof children==="string")children=[run(children,opts)];return new Paragraph({children,alignment:opts.align||AlignmentType.LEFT,spacing:opts.spacing||{before:0,after:100,line:280,lineRule:LineRuleType.AUTO},indent:opts.indent||undefined,border:opts.border||undefined});}
function spacer(pts){return new Paragraph({children:[],spacing:{before:0,after:pts||120}});}

function sectionHeading(label){
  return new Paragraph({
    children:[run(label.toUpperCase(),{size:18,bold:true,color:C.navy,spacing:80})],
    spacing:{before:360,after:160},
    border:{bottom:{style:BorderStyle.SINGLE,size:6,color:C.accent,space:4}},
  });
}
function subsectionLabel(text){
  return new Paragraph({children:[run(text,{size:19,bold:true,color:C.ink2})],spacing:{before:200,after:80}});
}
function bulletPara(text,opts){
  opts=opts||{};
  const txt=typeof text==="object"?JSON.stringify(text):String(text||"");
  return new Paragraph({
    children:[run("\u25B8  ",{bold:true,color:opts.bulletColor||C.blue,size:20}),run(txt,{color:opts.textColor||C.ink,size:opts.size||21})],
    spacing:{before:40,after:80,line:288,lineRule:LineRuleType.AUTO},
    indent:{left:convertInchesToTwip(0.15)},
  });
}

function metaRow(label,value){
  const bord={style:BorderStyle.SINGLE,size:2,color:C.mist3};
  const bL={top:bord,bottom:bord,left:{style:BorderStyle.NONE},right:bord};
  const bV={top:bord,bottom:bord,left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE}};
  return new TableRow({children:[
    new TableCell({width:{size:2520,type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:C.mist2},borders:bL,margins:{top:100,bottom:100,left:180,right:180},
      children:[new Paragraph({children:[run(label,{bold:true,size:20,color:C.ink2})],spacing:{before:0,after:0}})]}),
    new TableCell({borders:bV,margins:{top:100,bottom:100,left:180,right:180},
      children:[new Paragraph({children:[run(String(value||"—"),{size:20,color:C.ink})],spacing:{before:0,after:0}})]}),
  ]});
}
function buildMetaTable(rows){
  return new Table({width:{size:9360,type:WidthType.DXA},columnWidths:[2520,6840],rows,
    borders:{top:{style:BorderStyle.SINGLE,size:4,color:C.mist4},bottom:{style:BorderStyle.SINGLE,size:4,color:C.mist4},
      left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE},
      insideH:{style:BorderStyle.SINGLE,size:2,color:C.mist3},insideV:{style:BorderStyle.NONE}}});
}

function calloutBox(text,type){
  const cfgs={
    decision:{bg:C.teal_l,accent:C.teal,icon:"\u2713  "},
    issue:   {bg:C.amber_l,accent:C.amber,icon:"!  "},
    question:{bg:C.blue_l,accent:C.blue,icon:"?  "},
  };
  const cfg=cfgs[type]||cfgs.decision;
  const txt=typeof text==="object"?JSON.stringify(text):String(text||"");
  const none={style:BorderStyle.NONE};
  return new Table({
    width:{size:9360,type:WidthType.DXA},columnWidths:[120,9240],
    rows:[new TableRow({children:[
      new TableCell({width:{size:120,type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:cfg.accent},
        borders:{top:none,bottom:none,left:none,right:none},margins:{top:0,bottom:0,left:0,right:0},
        children:[new Paragraph({children:[],spacing:{before:0,after:0}})]}),
      new TableCell({shading:{type:ShadingType.CLEAR,fill:cfg.bg},
        borders:{top:none,bottom:none,left:none,right:none},margins:{top:120,bottom:120,left:200,right:160},
        children:[new Paragraph({
          children:[run(cfg.icon,{bold:true,color:cfg.accent,size:21}),run(txt,{color:C.ink,size:21})],
          spacing:{before:0,after:0,line:288,lineRule:LineRuleType.AUTO}})]}),
    ]})],
    borders:{top:none,bottom:none,left:none,right:none,insideH:none,insideV:none}});
}

function actionHeaderRow(){
  const cols=[{text:"#",w:480},{text:"Action Item",w:5520},{text:"Owner",w:1920},{text:"Deadline",w:1440}];
  return new TableRow({tableHeader:true,children:cols.map(c=>new TableCell({
    width:{size:c.w,type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:C.navy},
    margins:{top:100,bottom:100,left:160,right:160},
    children:[new Paragraph({children:[run(c.text,{bold:true,size:19,color:C.white})],alignment:AlignmentType.LEFT,spacing:{before:0,after:0}})]}))});
}
function actionDataRow(action,owner,deadline,idx){
  const bg=idx%2===0?C.white:C.mist;
  const bord={style:BorderStyle.SINGLE,size:2,color:C.mist3};
  const borders={top:bord,bottom:bord,left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE}};
  return new TableRow({children:[
    new TableCell({width:{size:480,type:WidthType.DXA},shading:{type:ShadingType.CLEAR,fill:C.blue_l},borders,margins:{top:100,bottom:100,left:160,right:160},
      children:[new Paragraph({children:[run(String(idx+1),{bold:true,size:20,color:C.blue})],alignment:AlignmentType.CENTER,spacing:{before:0,after:0}})]}),
    new TableCell({shading:{type:ShadingType.CLEAR,fill:bg},borders,margins:{top:100,bottom:100,left:180,right:160},
      children:[new Paragraph({children:[run(String(action||""),{size:20,color:C.ink})],spacing:{before:0,after:0,line:280,lineRule:LineRuleType.AUTO}})]}),
    new TableCell({shading:{type:ShadingType.CLEAR,fill:bg},borders,margins:{top:100,bottom:100,left:160,right:160},
      children:[new Paragraph({children:[run(String(owner||"—"),{size:20,color:C.ink2,bold:true})],spacing:{before:0,after:0}})]}),
    new TableCell({shading:{type:ShadingType.CLEAR,fill:bg},borders,margins:{top:100,bottom:100,left:160,right:160},
      children:[new Paragraph({children:[run(String(deadline||"—"),{size:20,color:C.ink3,italics:!deadline})],spacing:{before:0,after:0}})]}),
  ]});
}
function buildActionTable(items){
  const bord={style:BorderStyle.SINGLE,size:4,color:C.mist4};
  return new Table({width:{size:9360,type:WidthType.DXA},columnWidths:[480,5520,1920,1440],
    rows:[actionHeaderRow(),...items.map((item,i)=>{const a=typeof item==="object"?item:{action:String(item)};return actionDataRow(a.action||String(item),a.owner,a.deadline,i);})],
    borders:{top:bord,bottom:bord,left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE},
      insideH:{style:BorderStyle.SINGLE,size:2,color:C.mist3},insideV:{style:BorderStyle.NONE}}});
}

function makeHeader(title,type){
  const meta=[type,title].filter(Boolean).join("  \u00b7  ");
  return new Header({children:[new Paragraph({
    children:[run(meta,{size:17,color:C.ink3}),new TextRun({text:"\t",font:FONT}),run("DN-Studio",{size:17,color:C.blue,bold:true}),run("  by DataNeurus",{size:17,color:C.ink4})],
    spacing:{before:0,after:0},
    border:{bottom:{style:BorderStyle.SINGLE,size:4,color:C.mist3,space:8}},
    tabStops:[{type:TabStopType.RIGHT,position:convertInchesToTwip(6.3)}],
  })]});
}
function makeFooter(date){
  return new Footer({children:[new Paragraph({
    children:[run("Confidential  \u00b7  "+date,{size:17,color:C.ink4,italics:true}),new TextRun({text:"\t",font:FONT}),
      run("Page ",{size:17,color:C.ink3}),new TextRun({children:[PageNumber.CURRENT],font:FONT,size:17,color:C.ink3}),
      run(" of ",{size:17,color:C.ink3}),new TextRun({children:[PageNumber.TOTAL_PAGES],font:FONT,size:17,color:C.ink3})],
    spacing:{before:0,after:0},
    border:{top:{style:BorderStyle.SINGLE,size:4,color:C.mist3,space:8}},
    tabStops:[{type:TabStopType.RIGHT,position:convertInchesToTwip(6.3)}],
  })]});
}

// ── Extract
const m=data.meta||{},ag=data.agenda||{},di=data.discussion_summary||{};
const ac=data.action_items||{},nx=data.next_steps||{};
const meetingTitle=s(m.meeting_title,"Minutes of Meeting");
const meetingDate=s(m.meeting_date,"");
const meetingType=s(m.meeting_type,"");
const facilitator=s(m.facilitator,"—");
const attendees=arr(m.attendees);
const durationMin=val(m.duration_minutes,null);
const statedAgenda=arr(ag.stated_agenda);
const actualTopics=arr(ag.actual_topics);
const keyPoints=arr(di.key_points);
const decisions=arr(di.decisions_made);
const issues=arr(di.issues_raised);
const openQs=arr(di.open_questions);
const actionItems=arr(ac.items);
const nextMeeting=val(nx.next_meeting,null);
const followUps=arr(nx.follow_up_required_from);
const today=new Date().toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"});
const subLine=[meetingType,meetingDate,durationMin?`${durationMin} min`:null].filter(Boolean).join("   \u00b7   ");

// ── Build document
const ch=[];

// Cover block
ch.push(new Paragraph({children:[],spacing:{before:0,after:0},border:{top:{style:BorderStyle.SINGLE,size:32,color:C.accent,space:0}}}));
ch.push(spacer(160));
ch.push(new Paragraph({children:[run("MINUTES OF MEETING",{size:17,bold:true,color:C.blue,spacing:140})],spacing:{before:0,after:60}}));
ch.push(new Paragraph({children:[run(meetingTitle,{size:52,bold:true,color:C.navy})],spacing:{before:0,after:80}}));
if(subLine) ch.push(new Paragraph({children:[run(subLine,{size:22,color:C.ink3})],spacing:{before:0,after:200}}));
ch.push(new Paragraph({children:[],spacing:{before:0,after:0},border:{bottom:{style:BorderStyle.SINGLE,size:4,color:C.mist3,space:0}}}));
ch.push(spacer(240));

// Meeting Details
ch.push(sectionHeading("Meeting Details"));
ch.push(spacer(80));
ch.push(buildMetaTable([
  metaRow("Date",meetingDate||"—"),
  metaRow("Type",meetingType||"—"),
  metaRow("Facilitator",facilitator),
  metaRow("Duration",durationMin?`${durationMin} minutes`:"—"),
  metaRow("Attendees",attendees.length?attendees.join("   \u00b7   "):"—"),
]));
ch.push(spacer(120));

// Agenda
if(statedAgenda.length||actualTopics.length){
  ch.push(sectionHeading("Agenda"));
  if(statedAgenda.length){ch.push(subsectionLabel("Stated Agenda"));statedAgenda.forEach(i=>ch.push(bulletPara(i)));}
  if(actualTopics.length){ch.push(subsectionLabel("Topics Discussed"));actualTopics.forEach(i=>ch.push(bulletPara(i)));}
}

// Key Discussion Points
if(keyPoints.length){
  ch.push(sectionHeading("Key Discussion Points"));
  keyPoints.forEach(p=>{ch.push(bulletPara(p));ch.push(spacer(20));});
}

// Decisions
if(decisions.length){
  ch.push(sectionHeading("Decisions Made"));
  ch.push(spacer(60));
  decisions.forEach(d=>{ch.push(calloutBox(d,"decision"));ch.push(spacer(60));});
}

// Issues
if(issues.length){
  ch.push(sectionHeading("Issues & Blockers"));
  ch.push(spacer(60));
  issues.forEach(i=>{ch.push(calloutBox(i,"issue"));ch.push(spacer(60));});
}

// Open Questions
if(openQs.length){
  ch.push(sectionHeading("Open Questions"));
  ch.push(spacer(60));
  openQs.forEach(q=>{ch.push(calloutBox(q,"question"));ch.push(spacer(60));});
}

// Action Items
ch.push(sectionHeading("Action Items"));
ch.push(spacer(80));
if(actionItems.length){ch.push(buildActionTable(actionItems));}
else{ch.push(para([run("No action items were recorded.",{italics:true,color:C.ink3,size:21})]));}

// Next Steps
if(nextMeeting||followUps.length){
  ch.push(sectionHeading("Next Steps"));
  if(nextMeeting) ch.push(para([run("Next meeting:   ",{bold:true,size:21,color:C.ink2}),run(nextMeeting,{size:21})],{spacing:{before:100,after:80}}));
  if(followUps.length) ch.push(para([run("Follow-up from:   ",{bold:true,size:21,color:C.ink2}),run(followUps.join(", "),{size:21})],{spacing:{before:40,after:80}}));
}

// Footer
ch.push(spacer(280));
ch.push(new Paragraph({children:[],spacing:{before:0,after:0},border:{top:{style:BorderStyle.SINGLE,size:4,color:C.mist3,space:2}}}));
ch.push(spacer(80));
ch.push(para([run(`Minutes prepared by DN-Studio  \u00b7  ${today}`,{size:17,color:C.ink4,italics:true})],{align:AlignmentType.CENTER}));

const doc=new Document({
  creator:"DN-Studio",title:meetingTitle,description:"Minutes of Meeting \u2014 DN-Studio by DataNeurus",
  styles:{default:{document:{run:{font:FONT,size:22,color:C.ink}}}},
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:convertInchesToTwip(1.0),bottom:convertInchesToTwip(0.9),left:convertInchesToTwip(1.1),right:convertInchesToTwip(1.0),header:convertInchesToTwip(0.5),footer:convertInchesToTwip(0.45)}}},
    headers:{default:makeHeader(meetingTitle,meetingType)},
    footers:{default:makeFooter(today)},
    children:ch,
  }],
});

Packer.toBuffer(doc).then(buf=>{
  fs.writeFileSync(outputPath,buf);
  console.log(`SUCCESS: ${outputPath}`);
}).catch(err=>{console.error("ERROR:",err.message);process.exit(1);});
