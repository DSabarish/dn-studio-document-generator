// valid JS
console.log('hello');