/**
 * JS_example_template.js — DN-Studio Example Document Generator
 * ─────────────────────────────────────────────────────────────
 *
 * HOW THIS FILE WORKS
 * ────────────────────
 * DN-Studio calls this script as:
 *   node JS_template.js <filled_json_path> <output_docx_path>
 *
 * - process.argv[2] = absolute path to the filled JSON (your schema_prompt.json after LLM fill)
 * - process.argv[3] = absolute path to write the output .docx file
 * - The 'docx' npm package is pre-installed in scripts/node_modules/
 * - You MUST log "SUCCESS: <path>" when the file is written (the engine checks for this)
 * - Exit with code 1 and log "ERROR: ..." on failure
 *
 *
 * HOW TO NAVIGATE YOUR FILLED JSON
 * ──────────────────────────────────
 * Your schema_prompt.json becomes the filled JSON after the LLM runs.
 * Every leaf node has this shape after fill:
 *
 *   {
 *     "title": "Meeting Title",
 *     "description": "...",
 *     "format": "String",
 *     "value": "Q1 Strategy Review",          ← LLM fills this
 *     "trace": {                               ← LLM fills this
 *       "utterance_id": [3],
 *       "speaker": "Alice",
 *       "text": "Today we're reviewing Q1"
 *     },
 *     "why_null": "not_mentioned"             ← only present when value is null
 *   }
 *
 * Access pattern:
 *   val(data.section.field_name)              → the value or fallback
 *   arr(data.section.array_field)             → array value or []
 *
 *
 * GENERATING THE DOCX
 * ────────────────────
 * Use the 'docx' npm package (v9.x). Key classes:
 *
 *   Document    — root document, takes { sections: [...] }
 *   Paragraph   — a text block, takes { children: [TextRun], spacing, border, ... }
 *   TextRun     — inline text, takes { text, bold, italics, size, color, font }
 *   Table       — data table, takes { rows: [TableRow], borders, width }
 *   TableRow    — table row, takes { children: [TableCell] }
 *   TableCell   — table cell, takes { children: [Paragraph], shading, width }
 *   Header      — page header, takes { children: [Paragraph] }
 *   Footer      — page footer, takes { children: [Paragraph] }
 *   PageNumber  — enum: PageNumber.CURRENT, PageNumber.TOTAL_PAGES (NOT a constructor)
 *
 * Font sizes are in half-points: size:24 = 12pt, size:22 = 11pt, size:20 = 10pt
 * Colors are 6-digit hex strings without #: "1A1A2E" not "#1A1A2E"
 * Widths use WidthType.PERCENTAGE or WidthType.DXA (twips: 1440 per inch)
 *
 *
 * QUICK-START TEMPLATE
 * ─────────────────────
 * Copy this file, rename to JS_template.js, and adapt the sections below.
 * The helpers val(), arr(), run(), para(), sectionHeading() are ready to use.
 */

"use strict";

const fs   = require("fs");
const path = require("path");

// ── Resolve docx from scripts/node_modules ────────────────────────────────────
const SCRIPTS_DIR = path.dirname(path.resolve(__filename));
const docx = require(path.join(SCRIPTS_DIR, "node_modules", "docx"));

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, BorderStyle, WidthType, ShadingType,
  TabStopType, convertInchesToTwip, LineRuleType, PageNumber,
} = docx;

// ── Args ──────────────────────────────────────────────────────────────────────
const jsonPath   = process.argv[2];
const outputPath = process.argv[3];
if (!jsonPath || !outputPath) {
  console.error("ERROR: Usage: node JS_template.js <json_path> <output_docx_path>");
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ── Design tokens ─────────────────────────────────────────────────────────────
// Adjust these to match your brand
const C = {
  ink:    "0f172a",   // main text
  ink2:   "1e293b",   // secondary text
  ink3:   "64748b",   // muted text
  blue:   "2563eb",   // primary accent
  blue_l: "eff6ff",   // light blue background
  teal:   "0d9488",   // success/positive
  teal_l: "f0fdfa",   // light teal background
  amber:  "d97706",   // warning/caution
  amber_l:"fffbeb",   // light amber background
  mist:   "f8fafc",   // subtle background
  mist2:  "e2e8f0",   // border
  white:  "ffffff",
};
const FONT = "Calibri";

// ── Value helpers ─────────────────────────────────────────────────────────────

/** Safely read a leaf node value with fallback */
function val(obj, fallback) {
  if (fallback === undefined) fallback = "—";
  if (!obj) return fallback;
  return (obj.value !== null && obj.value !== undefined) ? obj.value : fallback;
}

/** Safely read an array leaf node */
function arr(obj) {
  const v = val(obj, []);
  return Array.isArray(v) ? v : (v && v !== "—" ? [String(v)] : []);
}

/** Convert any value to string safely */
function s(obj, fallback) {
  const v = val(obj, fallback !== undefined ? fallback : "—");
  return String(v || fallback || "—");
}

// ── Typography helpers ────────────────────────────────────────────────────────

/** Create a TextRun */
function run(text, opts) {
  opts = opts || {};
  return new TextRun({
    text:    String(text || ""),
    font:    FONT,
    size:    opts.size    || 22,
    bold:    opts.bold    || false,
    italics: opts.italics || false,
    color:   opts.color   || C.ink,
  });
}

/** Create a Paragraph */
function para(children, opts) {
  opts = opts || {};
  if (typeof children === "string") children = [run(children, opts)];
  return new Paragraph({
    children,
    alignment: opts.align   || AlignmentType.LEFT,
    spacing:   opts.spacing || { before: 0, after: 80, line: 276, lineRule: LineRuleType.AUTO },
    border:    opts.border  || undefined,
    indent:    opts.indent  || undefined,
  });
}

/** Section heading with blue underline rule */
function sectionHeading(label) {
  return new Paragraph({
    children: [run(label, { size: 26, bold: true, color: C.ink })],
    spacing: { before: 320, after: 80 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: C.blue, space: 6 } },
  });
}

/** Bullet point */
function bullet(text, color) {
  return new Paragraph({
    children: [
      run("\u2013  ", { bold: true, color: color || C.blue }),
      run(typeof text === "object" ? JSON.stringify(text) : String(text || ""), { color: C.ink }),
    ],
    spacing: { before: 20, after: 60, line: 276, lineRule: LineRuleType.AUTO },
    indent:  { left: convertInchesToTwip(0.2) },
  });
}

/** Two-column key-value table row */
function kvRow(label, value) {
  return new TableRow({ children: [
    new TableCell({
      width: { size: 2800, type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: C.blue_l },
      margins: { top: 80, bottom: 80, left: 120, right: 80 },
      children: [para([run(label, { bold: true, size: 20, color: C.blue })], { spacing: { before: 0, after: 0 } })],
    }),
    new TableCell({
      margins: { top: 80, bottom: 80, left: 120, right: 80 },
      children: [para([run(String(value || "—"), { size: 20 })], { spacing: { before: 0, after: 0 } })],
    }),
  ]});
}

/** Build a 2-column metadata table */
function kvTable(rows) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows,
    borders: {
      top:     { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      bottom:  { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      left:    { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      right:   { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      insideH: { style: BorderStyle.SINGLE, size: 2, color: C.mist2 },
      insideV: { style: BorderStyle.NONE },
    },
  });
}

/** Page header */
function makeHeader(title) {
  return new Header({ children: [new Paragraph({
    children: [
      run(title, { size: 18, color: C.ink3, italics: true }),
      new TextRun({ text: "\t", font: FONT }),
      run("DN-Studio", { size: 18, color: C.blue }),
    ],
    spacing: { before: 0, after: 0 },
    border:  { bottom: { style: BorderStyle.SINGLE, size: 2, color: C.mist2, space: 6 } },
    tabStops: [{ type: TabStopType.RIGHT, position: convertInchesToTwip(6.5) }],
  })]});
}

/** Page footer with page numbers */
function makeFooter(date) {
  return new Footer({ children: [new Paragraph({
    children: [
      run(`Generated ${date}`, { size: 18, color: C.ink3 }),
      new TextRun({ text: "\t", font: FONT }),
      run("Page ", { size: 18, color: C.ink3 }),
      // IMPORTANT: PageNumber is an ENUM in docx v9.x, NOT a constructor
      new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18, color: C.ink3 }),
      run(" of ", { size: 18, color: C.ink3 }),
      new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 18, color: C.ink3 }),
    ],
    spacing: { before: 0, after: 0 },
    border:  { top: { style: BorderStyle.SINGLE, size: 2, color: C.mist2, space: 6 } },
    tabStops: [{ type: TabStopType.RIGHT, position: convertInchesToTwip(6.5) }],
  })]});
}

// ══════════════════════════════════════════════════════════════════════════════
// EXTRACT YOUR DATA
// Replace this section with your own schema fields
// ══════════════════════════════════════════════════════════════════════════════

const m  = data.meta               || {};
const ag = data.agenda             || {};
const di = data.discussion_summary || {};
const ac = data.action_items       || {};
const nx = data.next_steps         || {};

const title      = s(m.meeting_title, "Document");
const date       = s(m.meeting_date,  "");
const today      = new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

// ══════════════════════════════════════════════════════════════════════════════
// BUILD YOUR DOCUMENT BODY
// Add Paragraphs, Tables, etc. to the `children` array
// ══════════════════════════════════════════════════════════════════════════════

const children = [];

// Title
children.push(para([run(title.toUpperCase(), { size: 48, bold: true, color: C.ink })], { spacing: { before: 0, after: 60 } }));
if (date) children.push(para([run(date, { size: 20, color: C.ink3 })], { spacing: { before: 0, after: 200 } }));
children.push(new Paragraph({ text: "", spacing: { before: 0, after: 200 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: C.blue, space: 2 } } }));

// ── Metadata section ──────────────────────────────────────────────────────────
children.push(sectionHeading("Meeting Details"));
children.push(para([], { spacing: { before: 0, after: 80 } }));
children.push(kvTable([
  kvRow("Date",       s(m.meeting_date)),
  kvRow("Type",       s(m.meeting_type)),
  kvRow("Facilitator",s(m.facilitator)),
  kvRow("Duration",   val(m.duration_minutes, null) ? `${val(m.duration_minutes)} minutes` : "—"),
  kvRow("Attendees",  arr(m.attendees).join(", ") || "—"),
]));
children.push(para([], { spacing: { before: 0, after: 120 } }));

// ── Key points ────────────────────────────────────────────────────────────────
const kp = arr(di.key_points);
if (kp.length) {
  children.push(sectionHeading("Key Discussion Points"));
  kp.forEach(p => children.push(bullet(p)));
}

// ── Action items ──────────────────────────────────────────────────────────────
const actions = arr(ac.items);
children.push(sectionHeading("Action Items"));
children.push(para([], { spacing: { before: 0, after: 80 } }));
if (actions.length) {
  const headerRow = new TableRow({ tableHeader: true, children:
    ["#", "Action", "Owner", "Deadline"].map(h => new TableCell({
      shading: { type: ShadingType.CLEAR, fill: C.blue },
      margins: { top: 80, bottom: 80, left: 120, right: 80 },
      children: [para([run(h, { bold: true, size: 20, color: C.white })], { spacing: { before: 0, after: 0 } })],
    }))
  });
  const dataRows = actions.map((item, idx) => {
    const a  = typeof item === "object" ? item : { action: String(item) };
    const bg = idx % 2 === 0 ? C.white : C.mist;
    return new TableRow({ children: [
      new TableCell({ shading: { type: ShadingType.CLEAR, fill: bg }, margins: { top: 80, bottom: 80, left: 120, right: 80 },
        children: [para([run(String(idx + 1), { size: 20, bold: true, color: C.blue })], { spacing: { before: 0, after: 0 }, align: AlignmentType.CENTER })] }),
      new TableCell({ shading: { type: ShadingType.CLEAR, fill: bg }, margins: { top: 80, bottom: 80, left: 120, right: 80 },
        children: [para([run(a.action || "", { size: 20 })], { spacing: { before: 0, after: 0 } })] }),
      new TableCell({ shading: { type: ShadingType.CLEAR, fill: bg }, margins: { top: 80, bottom: 80, left: 120, right: 80 },
        children: [para([run(a.owner || "—", { size: 20, bold: true })], { spacing: { before: 0, after: 0 } })] }),
      new TableCell({ shading: { type: ShadingType.CLEAR, fill: bg }, margins: { top: 80, bottom: 80, left: 120, right: 80 },
        children: [para([run(a.deadline || "—", { size: 20, color: C.ink3 })], { spacing: { before: 0, after: 0 } })] }),
    ]});
  });
  children.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...dataRows],
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      left: { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      right: { style: BorderStyle.SINGLE, size: 4, color: C.mist2 },
      insideH: { style: BorderStyle.SINGLE, size: 2, color: C.mist2 },
      insideV: { style: BorderStyle.SINGLE, size: 2, color: C.mist2 },
    },
  }));
} else {
  children.push(para([run("No action items recorded.", { italics: true, color: C.ink3, size: 21 })]));
}

// Closing rule
children.push(new Paragraph({ text: "", spacing: { before: 360, after: 60 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: C.mist2, space: 2 } } }));
children.push(para([run(`Prepared by DN-Studio  \u00b7  ${today}`, { size: 17, color: C.ink3, italics: true })],
  { align: AlignmentType.CENTER, spacing: { before: 60, after: 0 } }));

// ══════════════════════════════════════════════════════════════════════════════
// ASSEMBLE AND WRITE
// ══════════════════════════════════════════════════════════════════════════════

const doc = new Document({
  creator: "DN-Studio",
  title,
  styles: { default: { document: { run: { font: FONT, size: 22, color: C.ink } } } },
  sections: [{
    properties: { page: { margin: {
      top:    convertInchesToTwip(1.0),
      bottom: convertInchesToTwip(0.9),
      left:   convertInchesToTwip(1.1),
      right:  convertInchesToTwip(1.1),
      header: convertInchesToTwip(0.5),
      footer: convertInchesToTwip(0.5),
    }}},
    headers: { default: makeHeader(title) },
    footers: { default: makeFooter(today) },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outputPath, buf);
  console.log(`SUCCESS: ${outputPath}`);
}).catch(err => {
  console.error("ERROR:", err.message);
  process.exit(1);
});
