# MOM — Minutes of Meeting

## What it generates
A formatted Word document (.docx) summarising a meeting recording, including:
- Meeting metadata (title, date, type, facilitator, attendees, duration)
- Agenda (stated vs. actual topics discussed)
- Key discussion points
- Decisions made
- Issues and blockers raised
- Open questions
- Action items table (action · owner · deadline)
- Next steps and follow-up owners

## Files
| File | Purpose |
|------|---------|
| `schema_prompt.json` | Leaf-node template — defines all 15 fields the LLM will fill |
| `JS_template.js` | Node.js docx generator — reads filled JSON, writes MOM.docx |

## How to register
In Doc Studio → Doc Types → Register New Doc Type:
- **Key:** `mom`
- **Label:** `MOM`
- **Full Name:** Minutes of Meeting
- Upload `schema_prompt.json` and `JS_template.js`

Or it is registered automatically as a built-in type.

## Output filename
`MOM.docx`

## Schema fields
```
meta/
  meeting_title       String
  meeting_date        String
  meeting_type        String (Kickoff | Status Update | Review | Planning | ...)
  facilitator         String
  attendees           Array of strings
  duration_minutes    Integer

agenda/
  stated_agenda       Array of strings
  actual_topics       Array of strings

discussion_summary/
  key_points          Array of strings
  decisions_made      Array of strings
  issues_raised       Array of strings
  open_questions      Array of strings

action_items/
  items               Array of {action, owner, deadline}

next_steps/
  next_meeting        String
  follow_up_required_from  Array of strings
```

## Leaf node contract
Every fillable field follows this shape:
```json
{
  "title": "Field Name",
  "description": "LLM extraction instruction",
  "format": "Expected output type",
  "value": null,
  "trace": null
}
```
The LLM fills `value` and `trace` only. `trace` links to the utterance:
```json
{
  "utterance_id": [12],
  "speaker": "Alice",
  "text": "We agreed to push the deadline to Friday"
}
```


