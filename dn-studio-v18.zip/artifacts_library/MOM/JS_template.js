/**
 * JS_template.js — Minutes of Meeting .docx generator
 * DN-Studio by DataNeurus — Restyled to match BRD visual language
 *
 * CONTRACT (unchanged — runner compatibility guaranteed):
 *   process.argv[2] = absolute path to filled mom_output.json
 *   process.argv[3] = absolute path for output MOM.docx
 *   Logs "SUCCESS: <path>" on completion
 */
"use strict";

const fs   = require("fs");
const path = require("path");

// ── Resolve 'docx' from NODE_PATH (set by generic_docx_runner.py) ───────────
function requireDocx() {
  const candidates = [];
  const nodePath = process.env.NODE_PATH || "";
  nodePath.split(path.delimiter).filter(Boolean).forEach(p => {
    candidates.push(path.join(p, "docx"));
  });
  const thisDir = path.dirname(path.resolve(__filename));
  candidates.push(path.join(thisDir, "..", "..", "scripts", "node_modules", "docx"));
  candidates.push(path.join(thisDir, "node_modules", "docx"));
  candidates.push("docx");
  for (const c of candidates) {
    try { return require(c); } catch (_) {}
  }
  throw new Error("Cannot find module 'docx'. Run: cd scripts && npm install\nTried: " + candidates.join(", "));
}
const docx = requireDocx();

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, HeadingLevel, AlignmentType, BorderStyle, WidthType,
  ShadingType, TabStopType, convertInchesToTwip, LineRuleType,
  PageNumber, VerticalAlign, TableOfContents,
} = docx;

const jsonPath   = process.argv[2];
const outputPath = process.argv[3];
if (!jsonPath || !outputPath) { console.error("Usage: node JS_template.js <json> <output.docx>"); process.exit(1); }
const data = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ── Palette — matches BRD exactly ───────────────────────────────────────────
const C = {
  primary:     "003366",   // BRD deep navy
  accent:      "0070C0",   // BRD corporate blue
  lightBlue:   "D6E4F0",   // BRD light blue table label fill
  dark:        "404040",   // BRD body text
  mid:         "666666",   // BRD secondary / metadata text
  border:      "CCCCCC",   // BRD table borders
  note:        "C7511F",   // BRD null/placeholder warning
  white:       "FFFFFF",
  decision_bg: "EBF5FF",   // soft blue callout
  issue_bg:    "FFF3E0",   // soft amber callout
  question_bg: "F0F4F8",   // neutral cool callout
  mist:        "F9FAFB",   // alternating table row
};

const FONT = "Arial";     // matches BRD font throughout
const PW   = 9360;        // page content width in DXA

// ── Helpers ──────────────────────────────────────────────────────────────────
function val(o, fb) {
  if (fb === undefined) fb = "—";
  if (!o) return fb;
  return (o.value !== null && o.value !== undefined) ? o.value : fb;
}
function arr(o) {
  const v = val(o, []);
  return Array.isArray(v) ? v : (v && v !== "—" ? [String(v)] : []);
}
function s(o, fb) {
  const v = val(o, fb !== undefined ? fb : "—");
  return String(v || fb || "—");
}

function run(text, opts) {
  opts = opts || {};
  return new TextRun({
    text: String(text || ""), font: FONT,
    size:    opts.size    || 22,
    bold:    opts.bold    || false,
    italics: opts.italic  || opts.italics || false,
    color:   opts.color   || C.dark,
    characterSpacing: opts.spacing || undefined,
  });
}

function para(children, opts) {
  opts = opts || {};
  if (typeof children === "string") children = [run(children)];
  return new Paragraph({
    children,
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { before: opts.before || 0, after: opts.after || 100, line: opts.line || 280, lineRule: LineRuleType.AUTO },
    indent:  opts.indent || undefined,
    border:  opts.border || undefined,
  });
}

function spacer(pts) {
  return new Paragraph({ children: [], spacing: { before: 0, after: pts || 120 } });
}

// Thick accent rule — BRD divider() equivalent
function divider(color) {
  return new Paragraph({
    children: [],
    spacing: { before: 0, after: 0 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: color || C.accent, space: 1 } },
  });
}

const bd  = function(c)  { c = c || C.border; return { style: BorderStyle.SINGLE, size: 1, color: c }; };
const bds = function(c)  { var b = bd(c); return { top: b, bottom: b, left: b, right: b }; };

// ── Headings — BRD style ─────────────────────────────────────────────────────
function h1(text, pageBreak) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    pageBreakBefore: pageBreak || false,
    children: [new TextRun({ text: text, bold: true, color: C.primary, font: FONT })],
    spacing: { before: 360, after: 160 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.accent, space: 4 } },
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text: text, bold: true, color: C.accent, font: FONT })],
    spacing: { before: 240, after: 100 },
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [new TextRun({ text: text, bold: true, color: C.dark, size: 22, font: FONT })],
    spacing: { before: 160, after: 80 },
  });
}

function body(text, opts) {
  opts = opts || {};
  return new Paragraph({
    children: [new TextRun({ text: String(text || ""), bold: opts.bold || false, italics: opts.italic || false, color: opts.color || C.dark, size: opts.size || 22, font: FONT })],
    spacing: { before: 0, after: 100, line: 280, lineRule: LineRuleType.AUTO },
  });
}

function bulletPara(text) {
  var txt = typeof text === "object" ? JSON.stringify(text) : String(text || "");
  return new Paragraph({
    children: [
      new TextRun({ text: "\u25A0  ", bold: true, color: C.accent, size: 20, font: FONT }),
      new TextRun({ text: txt, color: C.dark, size: 21, font: FONT }),
    ],
    spacing: { before: 40, after: 80, line: 288, lineRule: LineRuleType.AUTO },
    indent: { left: convertInchesToTwip(0.2) },
  });
}

// ── Meeting Details table — BRD kvRow() style ────────────────────────────────
function metaRow(label, value) {
  return new TableRow({ children: [
    new TableCell({
      borders: bds(), width: { size: 2400, type: WidthType.DXA },
      shading: { fill: C.lightBlue, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ children: [new TextRun({ text: label, bold: true, size: 20, color: C.primary, font: FONT })], spacing: { before: 0, after: 0 } })],
    }),
    new TableCell({
      borders: bds(), width: { size: 6960, type: WidthType.DXA },
      margins: { top: 100, bottom: 100, left: 180, right: 160 },
      children: [new Paragraph({ children: [new TextRun({ text: String(value || "—"), size: 20, color: C.dark, font: FONT })], spacing: { before: 0, after: 0 } })],
    }),
  ]});
}

function buildMetaTable(rows) {
  return new Table({ width: { size: PW, type: WidthType.DXA }, columnWidths: [2400, 6960], rows: rows, borders: bds() });
}

// ── Callout box ───────────────────────────────────────────────────────────────
function calloutBox(text, type) {
  var cfgs = {
    decision: { bg: C.decision_bg, accent: C.accent,  icon: "\u2713  " },
    issue:    { bg: C.issue_bg,    accent: "C27803",   icon: "!  "      },
    question: { bg: C.question_bg, accent: C.mid,      icon: "?  "      },
  };
  var cfg = cfgs[type] || cfgs.decision;
  var txt = typeof text === "object" ? JSON.stringify(text) : String(text || "");
  var none = { style: BorderStyle.NONE };
  return new Table({
    width: { size: PW, type: WidthType.DXA },
    columnWidths: [120, PW - 120],
    rows: [new TableRow({ children: [
      new TableCell({
        width: { size: 120, type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: cfg.accent },
        borders: { top: none, bottom: none, left: none, right: none },
        margins: { top: 0, bottom: 0, left: 0, right: 0 },
        children: [new Paragraph({ children: [], spacing: { before: 0, after: 0 } })],
      }),
      new TableCell({
        shading: { type: ShadingType.CLEAR, fill: cfg.bg },
        borders: { top: none, bottom: none, left: none, right: none },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: [new Paragraph({
          children: [
            new TextRun({ text: cfg.icon, bold: true, color: cfg.accent, size: 21, font: FONT }),
            new TextRun({ text: txt, color: C.dark, size: 21, font: FONT }),
          ],
          spacing: { before: 0, after: 0, line: 288, lineRule: LineRuleType.AUTO },
        })],
      }),
    ]})],
    borders: { top: none, bottom: none, left: none, right: none, insideH: none, insideV: none },
  });
}

// ── Action Items table — BRD table() style ────────────────────────────────────
function buildActionTable(items) {
  var widths = [480, 5520, 1920, 1440];
  var headers = ["#", "Action Item", "Owner", "Deadline"];

  var headerRow = new TableRow({
    tableHeader: true,
    children: headers.map(function(h, i) {
      return new TableCell({
        borders: bds(), width: { size: widths[i], type: WidthType.DXA },
        shading: { fill: C.primary, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 160, right: 160 },
        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 20, color: C.white, font: FONT })], spacing: { before: 0, after: 0 } })],
      });
    }),
  });

  var dataRows = items.map(function(item, i) {
    var a = typeof item === "object" ? item : { action: String(item) };
    var bg = i % 2 === 0 ? C.white : C.mist;
    return new TableRow({ children: [
      new TableCell({
        borders: bds(), width: { size: 480, type: WidthType.DXA },
        shading: { fill: C.lightBlue, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 160, right: 160 },
        children: [new Paragraph({ children: [new TextRun({ text: String(i + 1), bold: true, size: 20, color: C.primary, font: FONT })], alignment: AlignmentType.CENTER, spacing: { before: 0, after: 0 } })],
      }),
      new TableCell({
        borders: bds(), shading: { fill: bg, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 180, right: 160 },
        children: [new Paragraph({ children: [new TextRun({ text: String(a.action || ""), size: 20, color: C.dark, font: FONT })], spacing: { before: 0, after: 0, line: 280, lineRule: LineRuleType.AUTO } })],
      }),
      new TableCell({
        borders: bds(), shading: { fill: bg, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 160, right: 160 },
        children: [new Paragraph({ children: [new TextRun({ text: String(a.owner || "—"), bold: true, size: 20, color: C.dark, font: FONT })], spacing: { before: 0, after: 0 } })],
      }),
      new TableCell({
        borders: bds(), shading: { fill: bg, type: ShadingType.CLEAR },
        margins: { top: 100, bottom: 100, left: 160, right: 160 },
        children: [new Paragraph({ children: [new TextRun({ text: String(a.deadline || "—"), size: 20, color: C.mid, italics: !a.deadline, font: FONT })], spacing: { before: 0, after: 0 } })],
      }),
    ]});
  });

  return new Table({ width: { size: PW, type: WidthType.DXA }, columnWidths: widths, rows: [headerRow].concat(dataRows), borders: bds() });
}

// ── Header / Footer — BRD style ───────────────────────────────────────────────
function makeHeader(title, type) {
  var meta = [type, title].filter(Boolean).join("  \u00b7  ");
  return new Header({ children: [new Paragraph({
    children: [
      new TextRun({ text: meta, size: 16, color: C.mid, font: FONT }),
      new TextRun({ text: "\t", font: FONT }),
      new TextRun({ text: "CONFIDENTIAL DRAFT", size: 16, color: C.mid, font: FONT }),
      new TextRun({ text: " | ", size: 16, color: C.mid, font: FONT }),
      new TextRun({ children: ["Page ", PageNumber.CURRENT, " of ", PageNumber.TOTAL_PAGES], size: 16, color: C.mid, font: FONT }),
    ],
    spacing: { before: 0, after: 0 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: C.accent, space: 4 } },
    tabStops: [{ type: TabStopType.RIGHT, position: convertInchesToTwip(6.3) }],
  })]});
}

function makeFooter(date, version) {
  return new Footer({ children: [new Paragraph({
    children: [new TextRun({ text: "Version " + version + "  |  " + date + "  |  DN-Studio by DataNeurus", size: 16, color: C.mid, font: FONT })],
    spacing: { before: 0, after: 0 },
    border: { top: { style: BorderStyle.SINGLE, size: 4, color: C.accent, space: 4 } },
  })]});
}

// ── Extract ───────────────────────────────────────────────────────────────────
var m  = data.meta               || {};
var ag = data.agenda             || {};
var di = data.discussion_summary || {};
var ac = data.action_items       || {};
var nx = data.next_steps         || {};

var meetingTitle = s(m.meeting_title,  "Minutes of Meeting");
var meetingDate  = s(m.meeting_date,   "");
var meetingType  = s(m.meeting_type,   "");
var facilitator  = s(m.facilitator,    "—");
var attendees    = arr(m.attendees);
var durationMin  = val(m.duration_minutes, null);
var statedAgenda = arr(ag.stated_agenda);
var actualTopics = arr(ag.actual_topics);
var keyPoints    = arr(di.key_points);
var decisions    = arr(di.decisions_made);
var issues       = arr(di.issues_raised);
var openQs       = arr(di.open_questions);
var actionItems  = arr(ac.items);
var nextMeeting  = val(nx.next_meeting, null);
var followUps    = arr(nx.follow_up_required_from);

var today   = new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
var version = "1.0";

// ── Build ─────────────────────────────────────────────────────────────────────
var ch = [];

// Cover
ch.push(divider(C.accent));
ch.push(spacer(200));
ch.push(new Paragraph({
  children: [new TextRun({ text: "MINUTES OF MEETING", bold: true, size: 52, color: C.primary, font: FONT })],
  spacing: { before: 0, after: 80 },
}));
ch.push(new Paragraph({
  children: [new TextRun({ text: meetingTitle, bold: true, size: 40, color: C.accent, font: FONT })],
  spacing: { before: 0, after: 100 },
}));
ch.push(new Paragraph({
  children: [
    new TextRun({ text: "Date: ",           bold: true, size: 22, color: C.mid,  font: FONT }),
    new TextRun({ text: meetingDate || "—",             size: 22, color: C.dark, font: FONT }),
    new TextRun({ text: "    Type: ",       bold: true, size: 22, color: C.mid,  font: FONT }),
    new TextRun({ text: meetingType || "—",             size: 22, color: C.dark, font: FONT }),
    new TextRun({ text: "    Facilitator: ",bold: true, size: 22, color: C.mid,  font: FONT }),
    new TextRun({ text: facilitator,                    size: 22, color: C.dark, font: FONT }),
  ],
  spacing: { before: 0, after: 60 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.accent, space: 1 } },
}));
ch.push(spacer(240));

// Table of Contents
ch.push(new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }));
ch.push(spacer(200));

// 1. Meeting Details
ch.push(h1("1. Meeting Details", true));
ch.push(buildMetaTable([
  metaRow("Date",        meetingDate  || "—"),
  metaRow("Type",        meetingType  || "—"),
  metaRow("Facilitator", facilitator),
  metaRow("Duration",    durationMin ? durationMin + " minutes" : "—"),
  metaRow("Attendees",   attendees.length ? attendees.join("   \u00b7   ") : "—"),
]));
ch.push(spacer(120));

// 2. Agenda
if (statedAgenda.length || actualTopics.length) {
  ch.push(h1("2. Agenda", true));
  if (statedAgenda.length) { ch.push(h2("Stated Agenda")); statedAgenda.forEach(function(i){ ch.push(bulletPara(i)); }); }
  if (actualTopics.length) { ch.push(h2("Topics Discussed")); actualTopics.forEach(function(i){ ch.push(bulletPara(i)); }); }
  ch.push(spacer(80));
}

// 3. Key Discussion Points
if (keyPoints.length) {
  ch.push(h1("3. Key Discussion Points", true));
  keyPoints.forEach(function(p){ ch.push(bulletPara(p)); ch.push(spacer(20)); });
  ch.push(spacer(80));
}

// 4. Decisions Made
if (decisions.length) {
  ch.push(h1("4. Decisions Made", true));
  ch.push(spacer(60));
  decisions.forEach(function(d){ ch.push(calloutBox(d, "decision")); ch.push(spacer(60)); });
}

// 5. Issues & Blockers
if (issues.length) {
  ch.push(h1("5. Issues & Blockers", true));
  ch.push(spacer(60));
  issues.forEach(function(i){ ch.push(calloutBox(i, "issue")); ch.push(spacer(60)); });
}

// 6. Open Questions
if (openQs.length) {
  ch.push(h1("6. Open Questions", true));
  ch.push(spacer(60));
  openQs.forEach(function(q){ ch.push(calloutBox(q, "question")); ch.push(spacer(60)); });
}

// 7. Action Items
ch.push(h1("7. Action Items", true));
ch.push(spacer(80));
if (actionItems.length) {
  ch.push(buildActionTable(actionItems));
} else {
  ch.push(body("No action items were recorded.", { italic: true, color: C.mid }));
}
ch.push(spacer(120));

// 8. Next Steps
if (nextMeeting || followUps.length) {
  ch.push(h1("8. Next Steps", true));
  if (nextMeeting) {
    ch.push(para([run("Next meeting:   ", { bold: true, size: 21, color: C.dark }), run(nextMeeting, { size: 21 })], { before: 100, after: 80 }));
  }
  if (followUps.length) {
    ch.push(para([run("Follow-up from:   ", { bold: true, size: 21, color: C.dark }), run(followUps.join(", "), { size: 21 })], { before: 40, after: 80 }));
  }
  ch.push(spacer(80));
}

// Closing rule
ch.push(spacer(280));
ch.push(divider(C.border));
ch.push(spacer(80));
ch.push(para([run("Minutes prepared by DN-Studio  \u00b7  " + today, { size: 17, color: C.mid, italic: true })], { align: AlignmentType.CENTER }));

// ── Document ──────────────────────────────────────────────────────────────────
var doc = new Document({
  creator: "DN-Studio", title: meetingTitle, description: "Minutes of Meeting \u2014 DN-Studio by DataNeurus",
  styles: {
    default: { document: { run: { font: FONT, size: 22, color: C.dark } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: FONT, color: C.primary },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: FONT, color: C.accent },
        paragraph: { spacing: { before: 240, after: 100 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: FONT, color: C.dark },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
    ],
  },
  sections: [{
    properties: {
      page: {
        size:   { width: 12240, height: 15840 },
        margin: { top: convertInchesToTwip(1.0), bottom: convertInchesToTwip(0.9), left: convertInchesToTwip(1.1), right: convertInchesToTwip(1.0), header: convertInchesToTwip(0.5), footer: convertInchesToTwip(0.45) },
      },
    },
    headers:  { default: makeHeader(meetingTitle, meetingType) },
    footers:  { default: makeFooter(today, version) },
    children: ch,
  }],
});

Packer.toBuffer(doc).then(function(buf) {
  fs.writeFileSync(outputPath, buf);
  console.log("SUCCESS: " + outputPath);
}).catch(function(err) {
  console.error("ERROR:", err.message);
  process.exit(1);
});
