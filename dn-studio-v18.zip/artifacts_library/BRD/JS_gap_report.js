/**
 * JS_gap_report.js — BRD Gap Report .docx generator
 * DN-Studio by DataNeurus
 *
 * CONTRACT:
 *   process.argv[2] = absolute path to gap-report.json
 *   process.argv[3] = absolute path for output gap-report.docx
 *   Logs "SUCCESS: <path>" on completion
 */
"use strict";

const fs   = require("fs");
const path = require("path");

function requireDocx() {
  const candidates = [];
  const nodePath = process.env.NODE_PATH || "";
  nodePath.split(path.delimiter).filter(Boolean).forEach(p => {
    candidates.push(path.join(p, "docx"));
  });
  const thisDir = path.dirname(path.resolve(__filename));
  candidates.push(path.join(thisDir, "..", "..", "scripts", "node_modules", "docx"));
  candidates.push(path.join(thisDir, "node_modules", "docx"));
  candidates.push("docx");
  for (const c of candidates) {
    try { return require(c); } catch (_) {}
  }
  throw new Error("Cannot find module 'docx'. Run: cd scripts && npm install");
}
const docx = requireDocx();

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, HeadingLevel, AlignmentType, BorderStyle, WidthType,
  ShadingType, convertInchesToTwip, VerticalAlign, PageNumber,
} = docx;

const jsonPath   = process.argv[2];
const outputPath = process.argv[3];
if (!jsonPath || !outputPath) {
  console.error("Usage: node JS_gap_report.js <gap-report.json> <output.docx>");
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ── Palette ──────────────────────────────────────────────────────────────────
const C = {
  primary:   "003366",
  accent:    "0070C0",
  lightBlue: "D6E4F0",
  dark:      "1A1A1A",
  mid:       "555555",
  border:    "CCCCCC",
  white:     "FFFFFF",
  critical:  "C00000",   // red
  major:     "E36C09",   // amber
  minor:     "375623",   // green
  critBg:    "FCE4D6",
  majorBg:   "FFF2CC",
  minorBg:   "EBF1DE",
  headBg:    "1F3864",
  altRow:    "F2F7FC",
};
const FONT = "Arial";
const PW   = 9360;

// ── Helpers ───────────────────────────────────────────────────────────────────
function t(text, opts) {
  opts = opts || {};
  return new TextRun({
    text:      String(text || ""),
    font:      FONT,
    size:      opts.size  || 20,
    bold:      opts.bold  || false,
    italics:   opts.italic || false,
    color:     opts.color || C.dark,
    break:     opts.break || 0,
  });
}

function para(runs, opts) {
  opts = opts || {};
  return new Paragraph({
    children:  Array.isArray(runs) ? runs : [runs],
    heading:   opts.heading || undefined,
    alignment: opts.align   || AlignmentType.LEFT,
    spacing:   { before: opts.before || 0, after: opts.after || 120 },
    indent:    opts.indent  ? { left: convertInchesToTwip(opts.indent) } : undefined,
    shading:   opts.shade   ? { type: ShadingType.CLEAR, fill: opts.shade } : undefined,
  });
}

function hRule() {
  return new Paragraph({
    children: [],
    border: { bottom: { color: C.border, size: 6, space: 1, style: BorderStyle.SINGLE } },
    spacing: { before: 80, after: 80 },
  });
}

function spacer(n) {
  return new Paragraph({ children: [new TextRun({ text: "" })], spacing: { before: 0, after: n || 100 } });
}

function severityColor(s) {
  if (!s) return C.mid;
  const l = s.toLowerCase();
  if (l === "critical") return C.critical;
  if (l === "major")    return C.major;
  return C.minor;
}
function severityBg(s) {
  if (!s) return C.white;
  const l = s.toLowerCase();
  if (l === "critical") return C.critBg;
  if (l === "major")    return C.majorBg;
  return C.minorBg;
}

function pill(label, color) {
  return new Paragraph({
    children: [new TextRun({
      text: " " + String(label || "").toUpperCase() + " ",
      font: FONT, size: 16, bold: true, color: C.white,
      shading: { type: ShadingType.CLEAR, fill: color },
    })],
    spacing: { before: 0, after: 0 },
  });
}

function cellShade(paras, bg, width, valign) {
  return new TableCell({
    children: paras,
    shading: { type: ShadingType.CLEAR, fill: bg || C.white },
    width: width ? { size: width, type: WidthType.DXA } : { size: 100, type: WidthType.PERCENTAGE },
    verticalAlign: valign || VerticalAlign.TOP,
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
  });
}

// ── Cover / header block ──────────────────────────────────────────────────────
const summary = data.summary || {};
const gaps    = data.gaps    || [];
const qs      = data.open_questions   || [];
const risks   = data.uncaptured_risks || [];
const conf    = data.confidence_scores || {};

const genDate = new Date().toLocaleDateString("en-GB", { day:"2-digit", month:"long", year:"numeric" });

const coverBlock = [
  new Paragraph({
    children: [t("BRD GAP ANALYSIS REPORT", { size: 48, bold: true, color: C.white })],
    alignment: AlignmentType.LEFT,
    shading: { type: ShadingType.CLEAR, fill: C.headBg },
    spacing: { before: 200, after: 0 },
    indent: { left: convertInchesToTwip(0.2), right: convertInchesToTwip(0.2) },
  }),
  new Paragraph({
    children: [t("DN-Studio  ·  Generated " + genDate, { size: 18, color: "A0B4CC" })],
    shading: { type: ShadingType.CLEAR, fill: C.headBg },
    spacing: { before: 0, after: 200 },
    indent: { left: convertInchesToTwip(0.2) },
  }),
];

// ── Summary scorecard table ───────────────────────────────────────────────────
function scorecardRow(label, val, color) {
  return new TableRow({
    children: [
      cellShade([para([t(label, { size: 18, bold: true, color: C.mid })], { before: 40, after: 40 })], C.altRow, 4600),
      cellShade([para([t(String(val || "—"), { size: 22, bold: true, color: color || C.dark })], { align: AlignmentType.CENTER })], C.white, 4600, VerticalAlign.CENTER),
    ],
  });
}

const confidencePct = typeof summary.overall_confidence === "number"
  ? summary.overall_confidence.toFixed(1) + "%"
  : (summary.overall_confidence || "—");

const scorecardTable = new Table({
  width: { size: PW, type: WidthType.DXA },
  borders: { top:{style:BorderStyle.NONE}, bottom:{style:BorderStyle.NONE}, left:{style:BorderStyle.NONE}, right:{style:BorderStyle.NONE}, insideH:{style:BorderStyle.SINGLE,color:C.border,size:4}, insideV:{style:BorderStyle.NONE} },
  rows: [
    scorecardRow("Total Gaps",            summary.total_gaps   || 0, C.accent),
    scorecardRow("Critical",              summary.critical     || 0, C.critical),
    scorecardRow("Major",                 summary.major        || 0, C.major),
    scorecardRow("Minor",                 summary.minor        || 0, C.minor),
    scorecardRow("Transcript Confidence", confidencePct,            C.minor),
  ],
});

// ── Recommendation banner ─────────────────────────────────────────────────────
const recBanner = summary.recommendation ? [
  new Paragraph({
    children: [
      t("RECOMMENDATION  ", { size: 18, bold: true, color: C.accent }),
      t(summary.recommendation, { size: 20, color: C.dark }),
    ],
    shading: { type: ShadingType.CLEAR, fill: C.lightBlue },
    spacing: { before: 160, after: 160 },
    indent: { left: convertInchesToTwip(0.15), right: convertInchesToTwip(0.15) },
  }),
] : [];

// ── Section heading ───────────────────────────────────────────────────────────
function sectionHeading(title, icon) {
  return new Paragraph({
    children: [t((icon ? icon + "  " : "") + title, { size: 28, bold: true, color: C.primary })],
    spacing: { before: 320, after: 120 },
    border: { bottom: { color: C.accent, size: 12, space: 4, style: BorderStyle.SINGLE } },
  });
}

// ── Gap cards ─────────────────────────────────────────────────────────────────
function gapCard(gap) {
  const sev    = gap.severity || "minor";
  const bg     = severityBg(sev);
  const color  = severityColor(sev);
  const refs   = (gap.transcript_refs || []).join(", ") || "—";
  return [
    new Table({
      width: { size: PW, type: WidthType.DXA },
      borders: {
        top:    { style: BorderStyle.SINGLE, color: color, size: 12 },
        bottom: { style: BorderStyle.SINGLE, color: C.border, size: 4 },
        left:   { style: BorderStyle.SINGLE, color: color, size: 12 },
        right:  { style: BorderStyle.SINGLE, color: C.border, size: 4 },
        insideH:{ style: BorderStyle.NONE },
        insideV:{ style: BorderStyle.NONE },
      },
      rows: [
        // Header row: ID + severity pill + section
        new TableRow({
          children: [
            cellShade([
              para([
                t(gap.id || "", { size: 18, bold: true, color: C.white }),
                t("  " + sev.toUpperCase(), { size: 16, bold: true, color: C.white }),
              ], { before: 60, after: 60 }),
            ], color, Math.round(PW * 0.35)),
            cellShade([
              para([t(gap.section || "", { size: 18, color: C.mid, italic: true })], { before: 60, after: 60 }),
            ], bg, Math.round(PW * 0.65)),
          ],
          tableHeader: true,
        }),
        // Title
        new TableRow({
          children: [
            cellShade([para([t(gap.title || "", { size: 22, bold: true, color: C.dark })], { before: 80, after: 40 })], bg, PW, VerticalAlign.TOP),
          ],
        }),
        // Description
        new TableRow({
          children: [
            cellShade([para([t(gap.description || "", { size: 20, color: C.dark })], { before: 40, after: 80 })], C.white, PW),
          ],
        }),
        // Action row
        new TableRow({
          children: [
            cellShade([
              para([t("ACTION  ", { size: 18, bold: true, color: C.accent }), t(gap.action || "—", { size: 18 })], { before: 60, after: 40 }),
              para([
                t("Owner: ", { size: 17, bold: true, color: C.mid }),
                t(gap.owner || "—", { size: 17 }),
                t("   Deadline: ", { size: 17, bold: true, color: C.mid }),
                t(gap.deadline || "—", { size: 17 }),
                t("   Transcript refs: ", { size: 17, bold: true, color: C.mid }),
                t(refs, { size: 17 }),
              ], { before: 0, after: 60 }),
            ], C.altRow, PW),
          ],
        }),
      ],
    }),
    spacer(120),
  ];
}

// ── Open question rows ────────────────────────────────────────────────────────
function urgencyColor(u) {
  if (!u) return C.mid;
  if (u === "immediate") return C.critical;
  if (u === "soon")      return C.major;
  return C.minor;
}

const qTable = qs.length ? new Table({
  width: { size: PW, type: WidthType.DXA },
  borders: {
    top:    { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    bottom: { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    left:   { style: BorderStyle.NONE },
    right:  { style: BorderStyle.NONE },
    insideH:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
    insideV:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
  },
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        cellShade([para([t("ID",         { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 900),
        cellShade([para([t("Question",   { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 4500),
        cellShade([para([t("Raised by",  { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 1800),
        cellShade([para([t("Urgency",    { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 1800),
      ],
    }),
    ...qs.map((q, i) => new TableRow({
      children: [
        cellShade([para([t(q.id || ("Q-" + String(i+1).padStart(3,"0")), { size: 18, bold: true, color: C.accent })])], i%2===0?C.white:C.altRow, 900),
        cellShade([
          para([t(q.question || "", { size: 19, bold: true })]),
          q.context ? para([t(q.context, { size: 17, color: C.mid, italic: true })]) : null,
        ].filter(Boolean), i%2===0?C.white:C.altRow, 4500),
        cellShade([para([t(q.raised_by || "—", { size: 18 })])], i%2===0?C.white:C.altRow, 1800),
        cellShade([para([t((q.urgency||"—").toUpperCase(), { size: 17, bold: true, color: urgencyColor(q.urgency) })])], i%2===0?C.white:C.altRow, 1800),
      ],
    })),
  ],
}) : null;

// ── Risk rows ─────────────────────────────────────────────────────────────────
const riskTable = risks.length ? new Table({
  width: { size: PW, type: WidthType.DXA },
  borders: {
    top:    { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    bottom: { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    left:   { style: BorderStyle.NONE },
    right:  { style: BorderStyle.NONE },
    insideH:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
    insideV:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
  },
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        cellShade([para([t("ID",          { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 900),
        cellShade([para([t("Risk",        { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 3000),
        cellShade([para([t("Evidence",    { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 2700),
        cellShade([para([t("Mitigation",  { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, 2700),
      ],
    }),
    ...risks.map((r, i) => new TableRow({
      children: [
        cellShade([para([t(r.id || ("R-" + String(i+1).padStart(3,"0")), { size: 18, bold: true, color: C.critical })])], i%2===0?C.white:C.altRow, 900),
        cellShade([para([t(r.risk || "", { size: 18, bold: true })])], i%2===0?C.white:C.altRow, 3000),
        cellShade([para([t(r.evidence || "—", { size: 17, italic: true, color: C.mid })])], i%2===0?C.white:C.altRow, 2700),
        cellShade([para([t(r.suggested_mitigation || "—", { size: 17 })])], i%2===0?C.white:C.altRow, 2700),
      ],
    })),
  ],
}) : null;

// ── Confidence scores table ───────────────────────────────────────────────────
const confEntries = Object.entries(conf);
const confTable = confEntries.length ? new Table({
  width: { size: PW, type: WidthType.DXA },
  borders: {
    top:    { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    bottom: { style: BorderStyle.SINGLE, color: C.border, size: 6 },
    left:   { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE },
    insideH:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
    insideV:{ style: BorderStyle.SINGLE, color: C.border, size: 4 },
  },
  rows: [
    new TableRow({
      tableHeader: true,
      children: [
        cellShade([para([t("Section",    { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, Math.round(PW*0.7)),
        cellShade([para([t("Confidence", { size: 18, bold: true, color: C.white })], { before: 60, after: 60 })], C.headBg, Math.round(PW*0.3)),
      ],
    }),
    ...confEntries.map(([sec, score], i) => {
      const pct = typeof score === "number" ? score.toFixed(1) + "%" : String(score);
      const col = typeof score === "number" ? (score >= 70 ? C.minor : score >= 40 ? C.major : C.critical) : C.mid;
      return new TableRow({
        children: [
          cellShade([para([t(sec, { size: 18 })])], i%2===0?C.white:C.altRow, Math.round(PW*0.7)),
          cellShade([para([t(pct, { size: 18, bold: true, color: col })], { align: AlignmentType.CENTER })], i%2===0?C.white:C.altRow, Math.round(PW*0.3)),
        ],
      });
    }),
  ],
}) : null;

// ── Assemble document ─────────────────────────────────────────────────────────
const children = [
  ...coverBlock,
  spacer(200),

  // Summary scorecard
  sectionHeading("Executive Summary", "📊"),
  scorecardTable,
  spacer(120),
  ...recBanner,
  spacer(200),
];

// Gaps by severity
if (gaps.length) {
  children.push(sectionHeading("Identified Gaps  (" + gaps.length + ")", "🔍"));
  ["critical", "major", "minor"].forEach(sev => {
    const group = gaps.filter(g => (g.severity||"").toLowerCase() === sev);
    if (!group.length) return;
    children.push(para([t(sev.toUpperCase() + " (" + group.length + ")", { size: 22, bold: true, color: severityColor(sev) })], { before: 160, after: 80 }));
    group.forEach(g => gapCard(g).forEach(el => children.push(el)));
  });
  children.push(spacer(200));
}

// Open questions
if (qs.length) {
  children.push(sectionHeading("Open Questions  (" + qs.length + ")", "❓"));
  children.push(qTable);
  children.push(spacer(200));
}

// Uncaptured risks
if (risks.length) {
  children.push(sectionHeading("Uncaptured Risks  (" + risks.length + ")", "⚠️"));
  children.push(riskTable);
  children.push(spacer(200));
}

// Confidence scores
if (confTable) {
  children.push(sectionHeading("Section Confidence Scores", "📈"));
  children.push(confTable);
  children.push(spacer(200));
}

// Footer line
children.push(hRule());
children.push(para([t("Generated by DN-Studio · " + genDate, { size: 16, color: C.mid, italic: true })], { align: AlignmentType.CENTER }));

const doc = new Document({
  creator: "DN-Studio",
  title:   "BRD Gap Analysis Report",
  sections: [{
    properties: {
      page: {
        margin: { top: convertInchesToTwip(0.75), bottom: convertInchesToTwip(0.75), left: convertInchesToTwip(0.9), right: convertInchesToTwip(0.9) },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          children: [
            t("BRD Gap Report  ·  DN-Studio", { size: 16, color: C.mid }),
          ],
          alignment: AlignmentType.RIGHT,
          border: { bottom: { color: C.border, size: 6, space: 4, style: BorderStyle.SINGLE } },
          spacing: { before: 0, after: 80 },
        })],
      }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outputPath, buf);
  console.log("SUCCESS: " + outputPath);
}).catch(err => {
  console.error("ERROR: " + err.message);
  process.exit(1);
});
