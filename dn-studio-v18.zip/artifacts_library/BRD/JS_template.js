/**
 * JS_template.js — Business Requirements Document .docx generator
 * DN-Studio by DataNeurus
 *
 * CONTRACT (generic_docx_runner.py compatible):
 *   process.argv[2] = absolute path to brd-response-trace.json
 *   process.argv[3] = absolute path for output BRD.docx
 *   Logs "SUCCESS: <path>" on completion
 *
 * Replaces generalised_brd_generator.py (v6).
 * Parses the same brd-response-trace.json directly in JS,
 * so no Python pre-processing step is needed.
 */
"use strict";

var fs   = require("fs");
var path = require("path");

function requireDocx() {
  var candidates = [];
  var nodePath = process.env.NODE_PATH || "";
  nodePath.split(path.delimiter).filter(Boolean).forEach(function(p) {
    candidates.push(path.join(p, "docx"));
  });
  var thisDir = path.dirname(path.resolve(__filename));
  candidates.push(path.join(thisDir, "..", "..", "scripts", "node_modules", "docx"));
  candidates.push(path.join(thisDir, "node_modules", "docx"));
  candidates.push("docx");
  for (var i = 0; i < candidates.length; i++) {
    try { return require(candidates[i]); } catch (_) {}
  }
  throw new Error("Cannot find module 'docx'. Run: cd scripts && npm install\nTried: " + candidates.join(", "));
}
var docx = requireDocx();

var Document      = docx.Document;
var Packer        = docx.Packer;
var Paragraph     = docx.Paragraph;
var TextRun       = docx.TextRun;
var Table         = docx.Table;
var TableRow      = docx.TableRow;
var TableCell     = docx.TableCell;
var Header        = docx.Header;
var Footer        = docx.Footer;
var AlignmentType = docx.AlignmentType;
var HeadingLevel  = docx.HeadingLevel;
var BorderStyle   = docx.BorderStyle;
var WidthType     = docx.WidthType;
var ShadingType   = docx.ShadingType;
var PageNumber    = docx.PageNumber;
var PageBreak     = docx.PageBreak;
var LevelFormat   = docx.LevelFormat;
var TableOfContents = docx.TableOfContents;
var TabStopType   = docx.TabStopType;
var TabStopPosition = docx.TabStopPosition;

var jsonPath   = process.argv[2];
var outputPath = process.argv[3];
if (!jsonPath || !outputPath) {
  console.error("Usage: node JS_template.js <brd-response-trace.json> <output.docx>");
  process.exit(1);
}

var rawData = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ── Palette (identical to generalised_brd_generator.py) ─────────────────────
var C = {
  primary:     "003366",
  accent:      "0070C0",
  lightBlue:   "D6E4F0",
  dark:        "404040",
  mid:         "666666",
  border:      "CCCCCC",
  white:       "FFFFFF",
  placeholder: "DDDDDD",
  note:        "888888",
};
var FONT = "Arial";
var PW   = 9360;

// ── why_null messages (must match brd_llm.py / generalised_brd_generator.py) ─
var WHY_NULL = {
  not_mentioned:            "Not discussed in the meeting — to be captured in a future session.",
  deferred_by_participants: "Raised in the meeting but explicitly deferred — participants agreed to decide later.",
  not_yet_agreed:           "Discussed in the meeting but not resolved — consensus was not reached.",
  schema_excluded:          "Not applicable to this project — no evidence found in the transcript for this category.",
  insufficient_detail:      "Mentioned in the meeting but without sufficient detail to document a concrete requirement.",
  not_applicable:           "Not applicable to this project type.",
};
var WHY_NULL_FALLBACK = "Not recorded — to be completed before document review.";

function whyMsg(obj) {
  if (!obj || typeof obj !== "object") return WHY_NULL_FALLBACK;
  var code = obj.why_null;
  return (code && WHY_NULL[code]) ? WHY_NULL[code] : WHY_NULL_FALLBACK;
}

// ── JSON traversal helpers (mirrors Python v/vlist/vdict) ───────────────────
function v(obj) {
  for (var i = 1; i < arguments.length; i++) {
    if (!obj || typeof obj !== "object") return null;
    obj = obj[arguments[i]];
  }
  if (obj && typeof obj === "object" && "value" in obj) return obj.value;
  return (obj !== undefined) ? obj : null;
}
function vObj(obj) {
  for (var i = 1; i < arguments.length; i++) {
    if (!obj || typeof obj !== "object") return {};
    obj = obj[arguments[i]];
  }
  return (obj && typeof obj === "object") ? obj : {};
}
function vList(obj) {
  var result = v.apply(null, arguments);
  if (Array.isArray(result)) return result;
  if (result === null || result === undefined) return [];
  return [String(result)];
}
function vDict(obj) {
  var result = v.apply(null, arguments);
  if (result && typeof result === "object" && !Array.isArray(result)) return result;
  return {};
}
function ss(val) {
  if (val === null || val === undefined) return "—";
  if (Array.isArray(val) && val.length === 0) return "—";
  if (Array.isArray(val)) return val.map(String).join("; ");
  return String(val);
}
function getSection(data, key, fallbackParent) {
  if (data[key]) return data[key];
  if (fallbackParent && data[fallbackParent] && data[fallbackParent][key])
    return data[fallbackParent][key];
  return {};
}

// ── Parse trace JSON into flat D object ─────────────────────────────────────
function parseBrd(data) {
  var H  = data["Header"]                       || {};
  var P  = data["0. Project Details"]           || {};
  var DR = getSection(data, "0. Document Revisions",    "0. Project Details");
  var SA = getSection(data, "0. Stakeholder Approvals", "0. Project Details");
  var I  = data["1. Introduction"]              || {};
  var S  = data["2. Project Scope"]             || {};
  var SP = data["3. System Perspective"]        || {};
  var BP = data["4. Business Process Overview"] || {};
  var KP = data["5. KPI & Success Metrics"]     || {};
  var FR = data["6. Functional Requirements"]   || {};
  var NF = data["7. Non-Functional Requirements"] || {};
  var DG = data["8. Data Governance & Privacy"] || {};
  var TA = data["9. Technology Stack & Architecture"] || {};
  var AP = data["10. Appendices"]               || {};

  var D = {};

  // Header
  D.projectName  = ss(v(H, "Project Name"));
  D.version      = ss(v(H, "Version"));
  D.date         = ss(v(H, "Date"));
  D.businessUnit = ss(v(H, "Business Unit"));
  D.projectType  = ss(v(H, "Project Type"));
  D.deployment   = ss(v(H, "Deployment Model"));
  D.dataStore    = ss(v(H, "Primary Data Store"));
  D.compute      = ss(v(H, "Compute Engine"));
  D.infrastructure = ss(v(H, "Infrastructure"));
  D.docStatus    = ss(v(H, "Document Status"));

  // Project Details
  D.overview          = v(P, "Project Overview");
  D.overviewWhy       = whyMsg(vObj(P, "Project Overview"));
  D.businessNeed      = v(P, "Business Need");
  D.businessNeedWhy   = whyMsg(vObj(P, "Business Need"));
  D.successCriteria   = vList(P, "Success Criteria");
  D.successCriteriaWhy = whyMsg(vObj(P, "Success Criteria"));

  // Revisions
  var rawRevisions = (DR.value || DR.items || []);
  D.revisions = [];
  if (Array.isArray(rawRevisions)) {
    rawRevisions.forEach(function(r) {
      if (r && typeof r === "object") {
        D.revisions.push([ss(v(r,"Version")), ss(v(r,"Date")), ss(v(r,"Author")), ss(v(r,"Description"))]);
      }
    });
  }

  // Approvals
  var rawApprovals = (SA.value || SA.items || []);
  D.approvals = [];
  if (Array.isArray(rawApprovals)) {
    rawApprovals.forEach(function(a) {
      if (a && typeof a === "object") {
        D.approvals.push([ss(v(a,"Name")), ss(v(a,"Role")), ss(v(a,"Status"))]);
      }
    });
  }

  // Introduction
  D.projectSummary    = v(I, "1.1 Project Summary");
  D.projectSummaryWhy = whyMsg(vObj(I, "1.1 Project Summary"));

  var objBlock = I["1.2 Objectives"] || {};
  var objItems = objBlock.value || objBlock.items || {};
  D.objPrimary       = vList(objItems, "Primary");
  D.objPrimaryWhy    = whyMsg(vObj(objItems, "Primary"));
  D.objSecondary     = vList(objItems, "Secondary");
  D.objSecondaryWhy  = whyMsg(vObj(objItems, "Secondary"));

  D.background         = v(I, "1.3 Background & Business Context");
  D.backgroundWhy      = whyMsg(vObj(I, "1.3 Background & Business Context"));
  D.businessDrivers    = vList(I, "1.4 Business Drivers");
  D.businessDriversWhy = whyMsg(vObj(I, "1.4 Business Drivers"));

  // Scope
  D.inScope     = vList(S, "2.1 In-Scope Functionality");
  D.inScopeWhy  = whyMsg(vObj(S, "2.1 In-Scope Functionality"));
  D.outScope    = vList(S, "2.2 Out-of-Scope Functionality");
  D.outScopeWhy = whyMsg(vObj(S, "2.2 Out-of-Scope Functionality"));

  var rawPhases = (S["2.3 Phasing Plan"] || {});
  var phaseVal  = rawPhases.value || rawPhases.items || {};
  D.phases = [];
  Object.keys(phaseVal).sort().forEach(function(pk) {
    var po = phaseVal[pk];
    if (!po || typeof po !== "object") { D.phases.push({label:pk, desc:ss(po), hasValue:!!po}); return; }
    var pv = po.value;
    var hasValue = pv !== null && pv !== undefined && pv !== "";
    D.phases.push({label:pk, desc: hasValue ? ss(pv) : whyMsg(po), hasValue:hasValue});
  });

  // System Perspective
  D.assumptions    = vList(SP, "3.1 Assumptions");
  D.assumptionsWhy = whyMsg(vObj(SP, "3.1 Assumptions"));
  D.constraints    = vList(SP, "3.2 Constraints");
  D.constraintsWhy = whyMsg(vObj(SP, "3.2 Constraints"));

  var risksObj = SP["3.3 Risks"] || {};
  D.risksWhy = whyMsg(risksObj);
  D.risks = [];
  var rawRisks = risksObj.value || risksObj.items || [];
  if (Array.isArray(rawRisks)) {
    rawRisks.forEach(function(r) {
      if (typeof r !== "object") return;
      var rt = r.Risk || r.risk || ""; if (typeof rt === "object") rt = rt.value || "";
      var mt = r.Mitigation || r.mitigation || ""; if (typeof mt === "object") mt = mt.value || "";
      D.risks.push([ss(rt), ss(mt)]);
    });
  } else if (rawRisks && typeof rawRisks === "object") {
    var rt = rawRisks.Risk || rawRisks.risk || ""; if (typeof rt === "object") rt = rt.value || "";
    var mt = rawRisks.Mitigation || rawRisks.mitigation || ""; if (typeof mt === "object") mt = mt.value || "";
    if (rt || mt) D.risks.push([ss(rt), ss(mt)]);
  }

  // Business Process
  D.asIs    = vList(BP, "4.1 Current Process (As-Is)");
  D.asIsWhy = whyMsg(vObj(BP, "4.1 Current Process (As-Is)"));
  D.toBe    = vList(BP, "4.2 Proposed Process (To-Be)");
  D.toBeWhy = whyMsg(vObj(BP, "4.2 Proposed Process (To-Be)"));

  // KPIs
  var kpVal = KP.value || KP.items || [];
  D.kpis    = [];
  D.kpisWhy = whyMsg(KP);
  if (Array.isArray(kpVal)) {
    kpVal.forEach(function(k) {
      if (typeof k !== "object") return;
      var metric = k.Metric || k.metric || ""; if (typeof metric === "object") metric = metric.value || "";
      var target = k.Target || k.target || ""; if (typeof target === "object") target = target.value || "";
      D.kpis.push([ss(metric), ss(target) || "—"]);
    });
  }

  // Functional Requirements (v6 shape: bare list per section)
  D.frSections = [];
  Object.keys(FR).sort().filter(function(fk) { return fk.indexOf("6.") === 0; }).forEach(function(secKey) {
    var secObj = FR[secKey];
    var rawReqs, secWhy;
    if (Array.isArray(secObj)) {
      rawReqs = secObj; secWhy = WHY_NULL_FALLBACK;
    } else if (secObj && typeof secObj === "object") {
      var inner = secObj.value || secObj.items || [];
      rawReqs = Array.isArray(inner) ? inner : [];
      secWhy  = whyMsg(secObj);
    } else {
      rawReqs = []; secWhy = WHY_NULL_FALLBACK;
    }

    var reqs = [];
    if (rawReqs.length) {
      var sub = parseInt((secKey.split(".")[1] || "0"), 10);
      var prefix = "F" + (sub < 10 ? "0"+sub : sub);
      rawReqs.forEach(function(req, idx) {
        var n = idx + 1;
        if (typeof req !== "object") {
          var rs = String(req); var pri = "P1";
          ["P1","P2","P3"].forEach(function(t){ if (rs.indexOf("("+t) >= 0 || rs.indexOf("["+t+"]") >= 0) pri = t; });
          ["P1","P2","P3"].forEach(function(t){ rs = rs.replace("["+t+"]","").replace("("+t+")","").trim(); });
          reqs.push([prefix+"-"+("00"+n).slice(-3), rs.replace(/\.$/,""), pri]);
          return;
        }
        var reqId   = req["Requirement ID"] || req.requirement_id || (prefix+"-"+("00"+n).slice(-3));
        var reqText = req.Description || req.Requirement || req.requirement || req.value || "";
        if (typeof reqText === "object") reqText = reqText.value || "";
        var priority = req.Priority || req.priority || "P1";
        if (typeof priority === "object") priority = priority.value || "P1";
        priority = String(priority).replace(/[\[\]() ]/g,"");
        if (["P1","P2","P3"].indexOf(priority) < 0) priority = "P1";
        reqs.push([String(reqId), String(reqText).replace(/\.$/,""), priority]);
      });
    }
    D.frSections.push({title:secKey, key:secKey, reqs:reqs, why:secWhy});
  });

  // Non-Functional Requirements
  [
    ["nfrPerf",       "7.1 Performance & Scalability"],
    ["nfrAvail",      "7.2 Availability & Reliability"],
    ["nfrUsab",       "7.3 Usability & Accessibility"],
    ["nfrSec",        "7.4 Security & Access Control"],
    ["nfrCompliance", "7.5 Compliance & Regulatory"],
  ].forEach(function(pair) {
    D[pair[0]]          = vList(NF, pair[1]);
    D[pair[0]+"Why"]    = whyMsg(vObj(NF, pair[1]));
  });

  // Data Governance
  var rawDC = vDict(DG, "8.1 Data Classification");
  D.dataClassification    = Object.keys(rawDC).map(function(k){ return [k, ss(rawDC[k])]; });
  D.dataClassificationWhy = whyMsg(vObj(DG, "8.1 Data Classification"));
  D.privacyChecklist      = vList(DG, "8.2 Data Privacy Checklist");
  D.privacyChecklistWhy   = whyMsg(vObj(DG, "8.2 Data Privacy Checklist"));

  // Tech Stack
  var rawTS = vDict(TA, "9.1 Proposed Technology Stack");
  D.techStack    = Object.keys(rawTS).map(function(k){ return [k, ss(rawTS[k])]; });
  D.techStackWhy = whyMsg(vObj(TA, "9.1 Proposed Technology Stack"));

  // Appendices
  var rawGlossary = vDict(AP, "10.1 Glossary of Terms");
  D.glossary     = Object.keys(rawGlossary).sort().map(function(k){ return [k, ss(rawGlossary[k])]; });
  D.glossaryWhy  = whyMsg(vObj(AP, "10.1 Glossary of Terms"));
  D.acronyms     = vList(AP, "10.2 List of Acronyms");
  D.acronymsWhy  = whyMsg(vObj(AP, "10.2 List of Acronyms"));
  D.relatedDocs  = vList(AP, "10.3 Related Documents");
  D.relatedDocsWhy = whyMsg(vObj(AP, "10.3 Related Documents"));

  var rawSignoff = (AP["10.4 Document Sign-Off"] || {}).value || [];
  D.signoff = [];
  if (Array.isArray(rawSignoff)) {
    rawSignoff.forEach(function(s) {
      if (s && typeof s === "object") {
        D.signoff.push([ss(s.Name), ss(s.Role), ss(s.Date||"________________"), ss(s.Signature||"________________")]);
      }
    });
  }

  return D;
}

var D = parseBrd(rawData);

// ── Document helpers ─────────────────────────────────────────────────────────
function bd(c)  { return { style:BorderStyle.SINGLE, size:1, color:c||C.border }; }
function bds(c) { var b=bd(c); return {top:b,bottom:b,left:b,right:b}; }

function sp(n) {
  return new Paragraph({spacing:{before:n||100,after:0}, children:[new TextRun("")]});
}
function divider(color) {
  return new Paragraph({
    border:{bottom:{style:BorderStyle.SINGLE,size:12,color:color||C.accent,space:1}},
    spacing:{before:0,after:200}, children:[new TextRun("")]
  });
}
function h1(text, pageBreak) {
  return new Paragraph({
    heading:HeadingLevel.HEADING_1, pageBreakBefore:pageBreak!==false,
    children:[new TextRun({text:text,bold:true,color:C.primary})],
    spacing:{before:200,after:120}
  });
}
function h2(text) {
  return new Paragraph({
    heading:HeadingLevel.HEADING_2,
    children:[new TextRun({text:text,bold:true,color:C.accent})],
    spacing:{before:280,after:100}
  });
}
function h3(text) {
  return new Paragraph({
    heading:HeadingLevel.HEADING_3,
    children:[new TextRun({text:text,bold:true,color:C.dark,size:22})],
    spacing:{before:200,after:80}
  });
}
function body(text, opts) {
  opts = opts||{};
  return new Paragraph({
    alignment:AlignmentType.JUSTIFIED,
    children:[new TextRun({text:String(text||""),bold:opts.bold||false,italics:opts.italic||false,color:opts.color||C.dark,size:22,font:FONT})],
    spacing:{before:60,after:60}
  });
}
function nullNote(msg) {
  return new Paragraph({
    alignment:AlignmentType.LEFT,
    children:[
      new TextRun({text:"! ",color:C.note,size:20,font:FONT}),
      new TextRun({text:String(msg||WHY_NULL_FALLBACK),italics:true,color:C.note,size:20,font:FONT})
    ],
    spacing:{before:60,after:60}
  });
}
function bullet(text, ref) {
  return new Paragraph({
    numbering:{reference:ref||"b0",level:0},
    alignment:AlignmentType.JUSTIFIED,
    children:[new TextRun({text:String(text||""),size:22,color:C.dark,font:FONT})],
    spacing:{before:40,after:40}
  });
}
function tbl(headers, rows, colWidths) {
  var total = colWidths.reduce(function(a,b){return a+b;},0);
  var hrow = new TableRow({children:headers.map(function(h,i){
    return new TableCell({
      borders:bds(), width:{size:colWidths[i],type:WidthType.DXA},
      shading:{fill:C.primary,type:ShadingType.CLEAR},
      margins:{top:100,bottom:100,left:150,right:150},
      children:[new Paragraph({children:[new TextRun({text:h,bold:true,size:20,color:C.white,font:FONT})]})]
    });
  })});
  var drows = rows.map(function(row){
    return new TableRow({children:row.map(function(cell,i){
      return new TableCell({
        borders:bds(), width:{size:colWidths[i],type:WidthType.DXA},
        margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:AlignmentType.JUSTIFIED,
          children:[new TextRun({text:String(cell||"—"),size:20,color:C.dark,font:FONT})]
        })]
      });
    })});
  });
  return new Table({width:{size:total,type:WidthType.DXA},columnWidths:colWidths,rows:[hrow].concat(drows)});
}
function kvTable(data) {
  var rows = data.map(function(pair){
    return new TableRow({children:[
      new TableCell({borders:bds(),width:{size:2400,type:WidthType.DXA},shading:{fill:C.lightBlue,type:ShadingType.CLEAR},margins:{top:100,bottom:100,left:150,right:150},
        children:[new Paragraph({children:[new TextRun({text:pair[0],bold:true,size:20,color:C.primary,font:FONT})]})]}),
      new TableCell({borders:bds(),width:{size:6960,type:WidthType.DXA},margins:{top:100,bottom:100,left:150,right:150},
        children:[new Paragraph({children:[new TextRun({text:pair[1],size:20,color:C.dark,font:FONT})]})]}),
    ]});
  });
  return new Table({width:{size:PW,type:WidthType.DXA},columnWidths:[2400,6960],rows:rows});
}
function archPlaceholder() {
  var cell = new TableCell({
    borders:bds(C.placeholder), width:{size:PW,type:WidthType.DXA},
    shading:{fill:C.placeholder,type:ShadingType.CLEAR},
    margins:{top:800,bottom:800,left:300,right:300},
    children:[
      new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:0,after:160},
        children:[new TextRun({text:"[ Attach Architecture Data Flow Diagram ]",bold:true,size:24,color:"888888",font:FONT,italics:true})]}),
      new Paragraph({alignment:AlignmentType.CENTER,
        children:[new TextRun({text:"Replace this placeholder with the finalised diagram before distributing.",size:18,color:"999999",font:FONT,italics:true})]})
    ]
  });
  return new Table({width:{size:PW,type:WidthType.DXA},columnWidths:[PW],rows:[new TableRow({children:[cell]})]});
}

// ── Numbering config ─────────────────────────────────────────────────────────
var bulletRefs = [];
for (var bi = 0; bi < 20; bi++) bulletRefs.push("b"+bi);
var numberingConfig = bulletRefs.map(function(ref){
  return {reference:ref,levels:[{level:0,format:LevelFormat.BULLET,text:"\u2022",alignment:AlignmentType.LEFT,
    style:{paragraph:{indent:{left:540,hanging:300}}}}]};
});

// ── Build document ───────────────────────────────────────────────────────────
var ch = [];

// COVER
ch.push(new Paragraph({spacing:{before:1800,after:0},children:[new TextRun("")]}));
ch.push(new Paragraph({alignment:AlignmentType.CENTER,
  children:[new TextRun({text:"BUSINESS REQUIREMENTS DOCUMENT",bold:true,size:52,color:C.primary,font:FONT})]}));
ch.push(sp(200));
ch.push(new Paragraph({alignment:AlignmentType.CENTER,
  children:[new TextRun({text:D.projectName,bold:true,size:40,color:C.accent,font:FONT})]}));
ch.push(sp(300));
ch.push(new Paragraph({alignment:AlignmentType.CENTER,border:{bottom:{style:BorderStyle.SINGLE,size:6,color:C.accent,space:1}},children:[new TextRun("")]}));
ch.push(sp(200));
[["Prepared for",D.businessUnit],["Version",D.version],["Date",D.date],["Document Status",D.docStatus]].forEach(function(pair){
  ch.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:80,after:80},
    children:[new TextRun({text:pair[0]+": ",bold:true,size:22,color:C.mid,font:FONT}),
              new TextRun({text:pair[1],size:22,color:C.dark,font:FONT})]}));
});
ch.push(new Paragraph({children:[new PageBreak()]}));

// TOC
ch.push(h1("Table of Contents", false));
ch.push(divider());
ch.push(new TableOfContents("Table of Contents", {hyperlink:true, headingStyleRange:"1-3"}));
ch.push(new Paragraph({children:[new PageBreak()]}));

// DOCUMENT CONTROL
ch.push(h1("Document Control", false));
ch.push(divider());
ch.push(h3("Document Information"));
ch.push(sp(60));
ch.push(kvTable([
  ["Project Name",D.projectName],["Version",D.version],["Date",D.date],
  ["Business Unit",D.businessUnit],["Project Type",D.projectType],
  ["Deployment",D.deployment],["Data Store",D.dataStore],
  ["Compute Engine",D.compute],["Infrastructure",D.infrastructure],["Document Status",D.docStatus],
]));
ch.push(sp(200));
ch.push(h3("Document Revisions"));
ch.push(sp(60));
D.revisions.length > 0
  ? ch.push(tbl(["Version","Date","Author","Description"],D.revisions,[900,1500,1800,5160]))
  : ch.push(body("No revisions recorded.",{italic:true,color:C.mid}));
ch.push(sp(200));
ch.push(h3("Stakeholder Approvals"));
ch.push(sp(60));
D.approvals.length > 0
  ? ch.push(tbl(["Name","Role","Status"],D.approvals,[2400,4560,2400]))
  : ch.push(body("No stakeholder approvals recorded.",{italic:true,color:C.mid}));

// SECTION 1
ch.push(h1("1. Introduction"));
ch.push(divider());
ch.push(h2("1.1 Project Summary"));
D.projectSummary ? ch.push(body(D.projectSummary)) : ch.push(nullNote(D.projectSummaryWhy));
ch.push(sp(120));
ch.push(h2("1.2 Objectives"));
ch.push(body("Primary Objectives",{bold:true,color:C.primary}));
D.objPrimary.length > 0 ? D.objPrimary.forEach(function(x){ch.push(bullet(x,"b0"));}) : ch.push(nullNote(D.objPrimaryWhy));
ch.push(sp(80));
ch.push(body("Secondary Objectives",{bold:true,color:C.accent}));
D.objSecondary.length > 0 ? D.objSecondary.forEach(function(x){ch.push(bullet(x,"b1"));}) : ch.push(nullNote(D.objSecondaryWhy));
ch.push(sp(120));
ch.push(h2("1.3 Background & Business Context"));
D.background ? ch.push(body(D.background)) : ch.push(nullNote(D.backgroundWhy));
ch.push(sp(120));
ch.push(h2("1.4 Business Drivers"));
D.businessDrivers.length > 0 ? D.businessDrivers.forEach(function(x){ch.push(bullet(x,"b2"));}) : ch.push(nullNote(D.businessDriversWhy));

// SECTION 2
ch.push(h1("2. Project Scope"));
ch.push(divider());
ch.push(h2("2.1 In-Scope Functionality"));
D.inScope.length > 0 ? D.inScope.forEach(function(x){ch.push(bullet(x,"b3"));}) : ch.push(nullNote(D.inScopeWhy));
ch.push(sp(120));
ch.push(h2("2.2 Out-of-Scope Functionality"));
D.outScope.length > 0 ? D.outScope.forEach(function(x){ch.push(bullet(x,"b4"));}) : ch.push(nullNote(D.outScopeWhy));
ch.push(sp(120));
ch.push(h2("2.3 Phasing Plan"));
ch.push(sp(60));
if (D.phases.length > 0) {
  var phHdr = new TableRow({children:["Phase","Scope Description"].map(function(h,i){
    return new TableCell({borders:bds(),width:{size:[1400,7960][i],type:WidthType.DXA},shading:{fill:C.primary,type:ShadingType.CLEAR},margins:{top:100,bottom:100,left:150,right:150},
      children:[new Paragraph({children:[new TextRun({text:h,bold:true,size:20,color:C.white,font:FONT})]})]});
  })});
  var phRows = D.phases.map(function(p){
    return new TableRow({children:[
      new TableCell({borders:bds(),width:{size:1400,type:WidthType.DXA},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({children:[new TextRun({text:p.label,size:20,color:C.dark,font:FONT})]})]}),
      new TableCell({borders:bds(),width:{size:7960,type:WidthType.DXA},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:p.hasValue?AlignmentType.JUSTIFIED:AlignmentType.LEFT,
          children:[p.hasValue ? new TextRun({text:p.desc,size:20,color:C.dark,font:FONT}) : new TextRun({text:"! "+p.desc,size:20,color:C.note,italics:true,font:FONT})]})]}),
    ]});
  });
  ch.push(new Table({width:{size:PW,type:WidthType.DXA},columnWidths:[1400,7960],rows:[phHdr].concat(phRows)}));
} else {
  ch.push(nullNote("Not discussed in the meeting — to be captured in a future session."));
}

// SECTION 3
ch.push(h1("3. System Perspective"));
ch.push(divider());
ch.push(h2("3.1 Assumptions"));
D.assumptions.length>0 ? D.assumptions.forEach(function(x){ch.push(bullet(x,"b5"));}) : ch.push(nullNote(D.assumptionsWhy));
ch.push(sp(120));
ch.push(h2("3.2 Constraints"));
D.constraints.length>0 ? D.constraints.forEach(function(x){ch.push(bullet(x,"b6"));}) : ch.push(nullNote(D.constraintsWhy));
ch.push(sp(120));
ch.push(h2("3.3 Risks & Mitigations"));
ch.push(sp(60));
D.risks.length>0 ? ch.push(tbl(["Risk","Mitigation"],D.risks,[4680,4680])) : ch.push(nullNote(D.risksWhy));

// SECTION 4
ch.push(h1("4. Business Process Overview"));
ch.push(divider());
ch.push(h2("4.1 Current Process (As-Is)"));
D.asIs.length>0 ? D.asIs.forEach(function(x){ch.push(bullet(x,"b7"));}) : ch.push(nullNote(D.asIsWhy));
ch.push(sp(120));
ch.push(h2("4.2 Proposed Process (To-Be)"));
D.toBe.length>0 ? D.toBe.forEach(function(x){ch.push(bullet(x,"b8"));}) : ch.push(nullNote(D.toBeWhy));

// SECTION 5
ch.push(h1("5. KPI & Success Metrics"));
ch.push(divider());
ch.push(body("The following quantitative performance targets will be used to evaluate whether the system is operating successfully in production."));
ch.push(sp(80));
D.kpis.length>0 ? ch.push(tbl(["Metric","Target"],D.kpis,[7200,2160])) : ch.push(nullNote(D.kpisWhy));

// SECTION 6
ch.push(h1("6. Functional Requirements"));
ch.push(divider());
ch.push(h3("Priority Rating Scale"));
ch.push(sp(60));
ch.push(tbl(["Priority","Definition"],[
  ["P1 — Must Have","Project is not complete without this. Blocking requirements — if not delivered, the project fails UAT."],
  ["P2 — Should Have","Strongly desired and planned, but project can launch without it if necessary. Deferral requires explicit stakeholder agreement."],
  ["P3 — Nice to Have","Valuable enhancement but not planned for current phase. Included for visibility and future planning only."],
],[2200,7160]));
ch.push(sp(120));
D.frSections.forEach(function(sec){
  ch.push(h2(sec.title));
  if (sec.reqs && sec.reqs.length > 0) {
    ch.push(sp(60));
    ch.push(tbl(["ID","Requirement","Priority"],sec.reqs,[900,7460,1000]));
  } else {
    ch.push(nullNote(sec.why));
  }
  ch.push(sp(120));
});

// SECTION 7
ch.push(h1("7. Non-Functional Requirements"));
ch.push(divider());
[
  ["7.1 Performance & Scalability", D.nfrPerf,       D.nfrPerfWhy,       "b11"],
  ["7.2 Availability & Reliability",D.nfrAvail,      D.nfrAvailWhy,      "b12"],
  ["7.3 Usability & Accessibility", D.nfrUsab,       D.nfrUsabWhy,       "b13"],
  ["7.4 Security & Access Control", D.nfrSec,        D.nfrSecWhy,        "b14"],
  ["7.5 Compliance & Regulatory",   D.nfrCompliance, D.nfrComplianceWhy, "b15"],
].forEach(function(row,idx,arr){
  ch.push(h2(row[0]));
  row[1] && row[1].length > 0 ? row[1].forEach(function(x){ch.push(bullet(x,row[3]));}) : ch.push(nullNote(row[2]));
  if (idx < arr.length-1) ch.push(sp(80));
});

// SECTION 8
ch.push(h1("8. Data Governance & Privacy"));
ch.push(divider());
ch.push(h2("8.1 Data Classification"));
ch.push(sp(60));
D.dataClassification.length>0 ? ch.push(tbl(["Data Asset","Classification Level"],D.dataClassification,[5760,3600])) : ch.push(nullNote(D.dataClassificationWhy));
ch.push(sp(160));
ch.push(h2("8.2 Data Privacy Checklist"));
D.privacyChecklist.length>0 ? D.privacyChecklist.forEach(function(x){ch.push(bullet(x,"b16"));}) : ch.push(nullNote(D.privacyChecklistWhy));

// SECTION 9
ch.push(h1("9. Technology Stack & Architecture"));
ch.push(divider());
ch.push(h2("9.1 Proposed Technology Stack"));
ch.push(body("The development team has been granted autonomy to select the most feasible technology stack."));
ch.push(sp(60));
D.techStack.length>0 ? ch.push(tbl(["Architectural Layer","Selected Technology"],D.techStack,[3200,6160])) : ch.push(nullNote(D.techStackWhy));
ch.push(sp(200));
ch.push(h2("9.2 Architecture Data Flow"));
ch.push(body("The architecture data flow diagram is to be attached below."));
ch.push(sp(80));
ch.push(archPlaceholder());

// SECTION 10
ch.push(h1("10. Appendices"));
ch.push(divider());
ch.push(h2("10.1 Glossary of Terms"));
ch.push(sp(60));
D.glossary.length>0 ? ch.push(tbl(["Term","Definition"],D.glossary,[1800,7560])) : ch.push(nullNote(D.glossaryWhy));
ch.push(sp(140));
ch.push(h2("10.2 List of Acronyms"));
D.acronyms.length>0 ? D.acronyms.forEach(function(x){ch.push(bullet(x,"b17"));}) : ch.push(nullNote(D.acronymsWhy));
ch.push(sp(120));
ch.push(h2("10.3 Related Documents"));
D.relatedDocs.length>0 ? D.relatedDocs.forEach(function(x){ch.push(bullet(x,"b18"));}) : ch.push(nullNote(D.relatedDocsWhy));
ch.push(sp(140));
ch.push(h2("10.4 Document Sign-Off"));
ch.push(sp(60));
var signoffRows = D.signoff.length ? D.signoff : [["________________","________________","________________","________________"]];
ch.push(tbl(["Name","Role","Date","Signature"],signoffRows,[2200,3500,1800,1860]));

// ── Document assembly ────────────────────────────────────────────────────────
var doc = new Document({
  numbering:{config:numberingConfig},
  styles:{
    default:{document:{run:{font:FONT,size:22,color:C.dark}}},
    paragraphStyles:[
      {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:36,bold:true,font:FONT,color:C.primary},paragraph:{spacing:{before:480,after:160},outlineLevel:0}},
      {id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:28,bold:true,font:FONT,color:C.accent},paragraph:{spacing:{before:320,after:120},outlineLevel:1}},
      {id:"Heading3",name:"Heading 3",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:24,bold:true,font:FONT,color:C.dark},paragraph:{spacing:{before:240,after:80},outlineLevel:2}},
    ]
  },
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1440,right:1440,bottom:1440,left:1440}}},
    headers:{default:new Header({children:[new Paragraph({
      children:[
        new TextRun({text:"CONFIDENTIAL DRAFT | "+D.projectName+" | "+D.businessUnit,size:16,color:C.mid,font:FONT}),
        new TextRun({text:"\t",size:16}),
        new TextRun({children:["Page ",PageNumber.CURRENT," of ",PageNumber.TOTAL_PAGES],size:16,color:C.mid,font:FONT}),
      ],
      tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
      border:{bottom:{style:BorderStyle.SINGLE,size:4,color:C.accent,space:4}}
    })]})},
    footers:{default:new Footer({children:[new Paragraph({
      children:[new TextRun({text:"Version "+D.version+" | "+D.date+" | "+D.businessUnit,size:16,color:C.mid,font:FONT})],
      border:{top:{style:BorderStyle.SINGLE,size:4,color:C.accent,space:4}}
    })]})},
    children:ch
  }]
});

Packer.toBuffer(doc).then(function(buf) {
  fs.writeFileSync(outputPath, buf);
  console.log("SUCCESS: " + outputPath);
}).catch(function(err) {
  console.error("ERROR:", err.message);
  process.exit(1);
});
