# SOP — Standard Operating Procedure

## Status: 🚧 In Progress — schema ready, JS template needed

## What it will generate
A formatted Word document defining a Standard Operating Procedure, including:
- SOP metadata (ID, owner, department, effective date, review frequency)
- Purpose and scope
- Step-by-step procedure
- Roles and responsibilities (RACI)
- Compliance requirements and quality controls
- Exception handling
- Related documents and tools

## Files
| File | Status |
|------|--------|
| `schema_prompt.json` | ✅ Ready — 18 fields across 6 sections |
| `JS_template.js` | ❌ TODO — needs to be written |

## To complete this artifact
1. Write `JS_template.js` following the same pattern as `MOM/JS_template.js`
2. It receives: `argv[2]` = path to filled JSON, `argv[3]` = path to write SOP.docx
3. Use `require('docx')` from `scripts/node_modules/`
4. Log `SUCCESS: <path>` on completion

## Schema sections
```
meta/                      — SOP ID, owner, department, dates
purpose_and_scope/         — Purpose, scope, applicability
procedure/                 — Prerequisites, steps, decision points
roles_and_responsibilities/ — RACI table
controls_and_compliance/   — Compliance, quality checks, exceptions
references/                — Related docs, tools and systems
revision_history/          — Changes from previous version
```


