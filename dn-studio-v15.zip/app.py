"""
app.py — DN-Studio FastAPI backend v5
- Background threading + polling (SSE-free, Colab-safe)
- Multi-doctype pipeline: BRD, MOM, custom studio types
- Diarization analytics: swimlane, scatter, speaker stats
- Upload with real-time progress, transcript JSON import
- Stop/cancel running pipeline jobs
- Job summaries persisted to disk on completion
"""
from __future__ import annotations

import warnings
# Suppress SyntaxWarnings from third-party audio/regex libraries
# (e.g. audioread utils.py uses un-escaped regex tokens like '\(' in older versions)
warnings.filterwarnings("ignore", category=SyntaxWarning)

import base64 as _b64
import glob
import io
import json
import logging
import hashlib
import math
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path

import yaml
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, Response
from pydantic import BaseModel

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "scripts"))

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

app = FastAPI(title="Doc Studio", version="5.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).resolve().parent
CFG_PATH = str(BASE_DIR / "configuration.yaml")

_TRANSPARENT_PIXEL_PNG = _b64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
)

AUDIO_EXTENSIONS = {".mp3", ".mp4", ".wav", ".m4a", ".ogg", ".flac", ".aac", ".webm"}

STEP_LABELS = {
    0: "Convert audio to MP3",
    1: "Transcribe & identify speakers",
    2: "Analyse transcript structure",
    3: "Write requirements",
    4: "Link requirements to transcript",
    5: "Build Word document",
    6: "Find gaps & risks",
}

_BRD_STEP_SCRIPTS = {
    0: "scripts/to_mp3.py",
    1: "scripts/diarize.py",
    2: "scripts/brd_schema_decider.py",
    3: "scripts/brd_requirements_writer.py",
    4: "scripts/brd_traceability_linker.py",
    6: "scripts/brd_gap_analyser.py",
}

DOCTYPES_PATH  = str(BASE_DIR / "prompts" / "doctypes.json")
STUDIO_UPLOADS = str(BASE_DIR / "prompts" / "studio_uploads")

jobs: dict[str, dict] = {}
_MAX_COMPLETED_JOBS   = 50
_upload_progress_lock = threading.Lock()

_cfg_cache: dict | None = None
_cfg_lock = threading.Lock()

_FRONTEND_HTML: str = ""


def _get_frontend_html() -> str:
    global _FRONTEND_HTML
    if not _FRONTEND_HTML:
        _FRONTEND_HTML = (BASE_DIR / "frontend.html").read_text(encoding="utf-8")
    return _FRONTEND_HTML


def _prune_jobs() -> None:
    done = [
        (jid, j["logs"][0]["ts"] if j["logs"] else 0)
        for jid, j in jobs.items()
        if j.get("status") in ("done", "error", "stopped")
    ]
    if len(done) > _MAX_COMPLETED_JOBS:
        for jid, _ in sorted(done, key=lambda x: x[1])[: len(done) - _MAX_COMPLETED_JOBS]:
            jobs.pop(jid, None)


upload_progress: dict[str, dict] = {}
_MAX_UPLOAD_PROGRESS = 100


def load_cfg(force_reload: bool = False) -> dict:
    global _cfg_cache
    with _cfg_lock:
        if _cfg_cache is None or force_reload:
            from cfg_utils import resolve_cfg
            _cfg_cache = resolve_cfg(str(CFG_PATH))
        return _cfg_cache


def save_cfg_raw(raw: dict) -> None:
    try:
        text = Path(CFG_PATH).read_text(encoding="utf-8")
    except FileNotFoundError:
        with open(CFG_PATH, "w", encoding="utf-8") as fh:
            yaml.dump(raw, fh, default_flow_style=False, allow_unicode=True)
        return

    def _replace_scalar(text, key, value):
        pattern = rf"^(\s*{re.escape(key)}\s*:\s*).*$"
        return re.sub(pattern, rf"\g<1>{value}", text, flags=re.MULTILINE)

    exp = raw.get("experiment", "")
    api = raw.get("llm", {}).get("api_key", "")
    mdl = raw.get("llm", {}).get("model", "gemini-2.5-flash")
    spk = raw.get("diarization", {}).get("num_speakers")
    wsp = raw.get("diarization", {}).get("whisper_model", "tiny")

    text = _replace_scalar(text, "experiment", exp)
    text = _replace_scalar(text, "api_key", f'"{api}"')
    text = _replace_scalar(text, "model", mdl)
    text = _replace_scalar(text, "whisper_model", f'"{wsp}"')
    text = _replace_scalar(text, "num_speakers", "null" if spk is None else str(spk))

    Path(CFG_PATH).write_text(text, encoding="utf-8")
    global _cfg_cache
    with _cfg_lock:
        _cfg_cache = None


def get_audio_duration(path: str) -> float:
    try:
        res = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", path],
            capture_output=True, text=True,
        )
        return float(json.loads(res.stdout).get("format", {}).get("duration", 0))
    except Exception:
        return 0.0


def experiment_outputs(exp: str) -> dict:
    base_files = [
        "brd-schema.json", "brd-response.json",
        "brd-response-trace.json", "BRD.docx", "gap-report.json",
    ]
    result = {name: os.path.exists(f"{exp}/output/{name}") for name in base_files}
    out_dir = Path(f"{exp}/output")
    if out_dir.exists():
        for f in out_dir.iterdir():
            if f.name not in result and f.suffix in (".docx", ".json"):
                result[f.name] = True
    return result


def _persist_job_summary(job_id: str, job: dict, cfg: dict) -> None:
    try:
        exp      = cfg.get("experiment", "")
        out_dir  = Path(f"{exp}/output")
        out_dir.mkdir(parents=True, exist_ok=True)
        hist_path = out_dir / "job_history.json"
        summary = {
            "job_id":    job_id,
            "status":    job.get("status"),
            "doc_type":  job.get("doc_type"),
            "steps":     job.get("steps"),
            "completed": time.time(),
            "error":     job.get("error"),
            "outputs":   job.get("outputs", {}),
        }
        history = []
        if hist_path.exists():
            try:
                history = json.loads(hist_path.read_text(encoding="utf-8"))
            except Exception:
                history = []
        history.append(summary)
        history = history[-100:]
        tmp_fd, tmp_path = tempfile.mkstemp(dir=str(out_dir), suffix=".tmp")
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
                json.dump(history, fh, indent=2, ensure_ascii=False)
            os.replace(tmp_path, str(hist_path))
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except Exception as e:
        log.warning("Job persistence failed (non-fatal): %s", e)


def _load_doctypes() -> dict:
    BUILTIN = {
        "brd": {
            "key": "brd", "name": "Business Requirements Document", "label": "BRD",
            "builtin": True,
            "schema_prompt": "artifacts_library/BRD/schema_prompt.json",
            "js_template":   str(BASE_DIR / "artifacts_library" / "BRD" / "JS_template.js"),
            "output_filename": "BRD.docx",
            "step_labels": {
                "2": "Analyse transcript",
                "3": "Write requirements",
                "4": "Link to transcript",
                "5": "Build Word document",
                "6": "Find gaps & risks",
            },
        },
        "mom": {
            "key": "mom", "name": "Minutes of Meeting", "label": "MOM",
            "builtin": True,
            "schema_prompt": str(BASE_DIR / "artifacts_library" / "MOM" / "schema_prompt.json"),
            "js_template":   str(BASE_DIR / "artifacts_library" / "MOM" / "JS_template.js"),
            "output_filename": "MOM.docx",
            "step_labels": {"2": "Document Filler (MOM)", "5": "Word Document (MOM)"},
        },
    }
    custom = {}
    if os.path.exists(DOCTYPES_PATH):
        try:
            on_disk = json.loads(Path(DOCTYPES_PATH).read_text(encoding="utf-8"))
            custom  = {k: v for k, v in on_disk.items() if not v.get("builtin")}
        except Exception:
            pass
    return {**BUILTIN, **custom}


def _save_doctypes(data: dict) -> None:
    custom_only = {k: v for k, v in data.items() if not v.get("builtin")}
    os.makedirs(os.path.dirname(DOCTYPES_PATH), exist_ok=True)
    with open(DOCTYPES_PATH, "w", encoding="utf-8") as fh:
        json.dump(custom_only, fh, indent=2, ensure_ascii=False)


def _push_log(job: dict, step: int, msg: str) -> None:
    job["logs"].append({"step": step, "msg": msg, "ts": time.time()})


def _build_diar_analytics(segs: list[dict]) -> dict:
    speakers = sorted({s["speaker_name"] for s in segs})
    spk_idx  = {s: i for i, s in enumerate(speakers)}
    colors   = ["#3b5bdb", "#0ca678", "#e67700", "#c2255c", "#7048e8", "#1098ad"]
    stats: dict[str, dict] = {spk: {"time": 0.0, "turns": 0, "words": 0} for spk in speakers}
    for seg in segs:
        spk = seg["speaker_name"]
        dur = seg["end"] - seg["start"]
        stats[spk]["time"]  += dur
        stats[spk]["turns"] += 1
        stats[spk]["words"] += len(seg.get("text", "").split())
    swimlanes: dict[str, list] = {spk: [] for spk in speakers}
    for seg in segs:
        swimlanes[seg["speaker_name"]].append({
            "start": round(seg["start"], 3),
            "end":   round(seg["end"], 3),
            "text":  seg.get("text", ""),
            "conf":  round(seg.get("confidence", 1.0), 3),
        })
    _rng = __import__("numpy").random.default_rng(42)
    scatter_pts = []
    for seg in segs:
        spk  = seg["speaker_name"]
        si   = spk_idx[spk]
        dur  = seg["end"] - seg["start"]
        conf = seg.get("confidence", 1.0)
        wpm  = len(seg.get("text", "").split()) / max(dur, 0.1) * 60
        mid  = (seg["start"] + seg["end"]) / 2
        angle  = (si / max(len(speakers), 1)) * 2 * math.pi
        radius = 2.5 + conf * 1.5
        cx = radius * math.cos(angle)
        cy = radius * math.sin(angle)
        jx = (wpm/200-1)*0.8 + (conf-0.8)*0.6 + (_rng.random()-0.5)*0.4
        jy = (dur/5-1)*0.5  + (mid/max(segs[-1]["end"],1)-0.5)*0.6 + (_rng.random()-0.5)*0.4
        scatter_pts.append({
            "x": round(cx+jx,3), "y": round(cy+jy,3),
            "spk": spk, "ci": si,
            "text": seg.get("text","")[:60],
            "conf": round(conf,2), "dur": round(dur,1),
        })
    total_dur = segs[-1]["end"] if segs else 0
    return {
        "speakers":  speakers,
        "colors":    colors[:len(speakers)],
        "stats":     stats,
        "swimlanes": swimlanes,
        "scatter":   scatter_pts,
        "total_dur": round(total_dur,2),
        "total_segs":len(segs),
        "preview":   segs[:12],
    }


def _run_step(job: dict, step: int, cfg: dict, llm_override: dict | None = None) -> bool:
    job["current_step"]       = step
    job["step_status"][step]  = "running"
    job["step_timings"][step] = {"start": time.time(), "end": None}
    _push_log(job, step, f"\u25b6 Starting: {STEP_LABELS[step]}")

    # Build subprocess env: inject per-run LLM overrides as env vars
    # so that llm_utils.build_model() in each script picks them up automatically
    sub_env = {**os.environ, "PYTHONUNBUFFERED": "1"}
    if llm_override:
        if llm_override.get("model"):
            sub_env["DN_LLM_MODEL"] = str(llm_override["model"])
            _push_log(job, step, f"   [LLM override] model={llm_override['model']}")
        if llm_override.get("temperature") is not None:
            sub_env["DN_LLM_TEMPERATURE"] = str(llm_override["temperature"])
            _push_log(job, step, f"   [LLM override] temperature={llm_override['temperature']}")
        if llm_override.get("max_tokens") is not None:
            sub_env["DN_LLM_MAX_TOKENS"] = str(int(llm_override["max_tokens"]))
            _push_log(job, step, f"   [LLM override] max_tokens={llm_override['max_tokens']}")

    if step == 5:
        trace       = cfg["chains"]["chain3_traceability"]["output"]["trace"]
        exp         = cfg["experiment"]
        brd_docx    = f"{exp}/output/BRD.docx"
        brd_js      = str(BASE_DIR / "artifacts_library" / "BRD" / "JS_template.js")
        scripts_dir = str(BASE_DIR / "scripts")
        _push_log(job, step, f"   Input   : {trace}")
        _push_log(job, step, f"   Template: {brd_js}")
        try:
            from generic_docx_runner import run_generic_docx
            run_generic_docx(trace, brd_js, brd_docx, scripts_dir)
            success = True
        except Exception as exc:
            _push_log(job, step, f"\u2715 Exception: {exc}")
            success = False
    else:
        script = _BRD_STEP_SCRIPTS.get(step)
        if not script:
            _push_log(job, step, f"\u2715 No script defined for step {step}")
            job["step_timings"][step]["end"] = time.time()
            job["step_status"][step] = "error"
            return False
        try:
            proc = subprocess.Popen(
                [sys.executable, script],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1,
                env=sub_env,
            )
            try:
                for line in proc.stdout:
                    line = line.rstrip()
                    if line:
                        _push_log(job, step, line)
                proc.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                _push_log(job, step, f"\u2715 Step {step} timed out after 30 min")
                success = False
            else:
                success = proc.returncode == 0
        except Exception as exc:
            _push_log(job, step, f"\u2715 Exception: {exc}")
            success = False

    job["step_timings"][step]["end"] = time.time()
    elapsed = job["step_timings"][step]["end"] - job["step_timings"][step]["start"]
    if success:
        job["step_status"][step] = "done"
        _push_log(job, step, f"\u2713 Done in {elapsed:.1f}s")
    else:
        job["step_status"][step] = "error"
        job["error"] = f"Step {step} ({STEP_LABELS[step]}) failed \u2014 see logs."
        _push_log(job, step, f"\u2715 Step {step} failed")
    return success


def _post_step_data(job: dict, step: int, cfg: dict) -> None:
    if step == 1:
        try:
            path = cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
            segs = json.loads(Path(path).read_text(encoding="utf-8"))
            job["diar_analytics"] = _build_diar_analytics(segs)
        except Exception as e:
            log.warning("diar analytics failed: %s", e)

    if step == 6:
        try:
            path = cfg["chains"]["chain4_gap_analyser"]["output"]["gap_report"]
            gap  = json.loads(Path(path).read_text(encoding="utf-8"))
            job["gap_report"] = {
                "total_gaps":         gap["summary"]["total_gaps"],
                "critical":           gap["summary"]["critical"],
                "major":              gap["summary"]["major"],
                "minor":              gap["summary"]["minor"],
                "overall_confidence": gap["summary"]["overall_confidence"],
                "recommendation":     gap["summary"]["recommendation"],
                "gaps":               gap.get("gaps", []),
                "open_questions":     gap.get("open_questions", []),
                "uncaptured_risks":   gap.get("uncaptured_risks", []),
                "confidence_scores":  gap.get("confidence_scores", {}),
            }
        except Exception as e:
            log.warning("gap preview failed: %s", e)
        try:
            gap_json    = cfg["chains"]["chain4_gap_analyser"]["output"]["gap_report"]
            exp         = cfg["experiment"]
            gap_docx    = f"{exp}/output/gap-report.docx"
            gap_js      = str(BASE_DIR / "artifacts_library" / "BRD" / "JS_gap_report.js")
            scripts_dir = str(BASE_DIR / "scripts")
            from generic_docx_runner import run_generic_docx
            run_generic_docx(gap_json, gap_js, gap_docx, scripts_dir)
        except Exception as e:
            log.warning("gap-report.docx generation failed (non-fatal): %s", e)

    if step == 3:
        try:
            path = cfg["chains"]["chain2_brd_generator"]["output"]["brd"]
            brd  = json.loads(Path(path).read_text(encoding="utf-8"))
            filled = sum(1 for v in brd.values() if isinstance(v,dict) and v.get("value"))
            null   = sum(1 for v in brd.values() if isinstance(v,dict) and v.get("value") is None)
            proj   = brd.get("Header",{}).get("Project Name",{}).get("value","N/A")
            job["brd_preview"] = {"project":proj,"filled":filled,"null":null}
        except Exception:
            pass



# ── Single unified pipeline thread ────────────────────────────────────────────
# Handles BRD, MOM, Quick Run, and all custom studio doc types.
# BRD uses subprocess steps (2,3,4,6); all others use llm_filler.run_fill for
# step 2 and generic_docx_runner for step 5. Steps 0 and 1 are identical for
# all types.

# Steps that only BRD uses (skipped silently for all other doc types)
_BRD_ONLY_STEPS = frozenset({3, 4, 6})


# ── Step-level result caching ──────────────────────────────────────────────────
# Steps 0 (MP3) and 1 (diarization) are experiment-scoped, not doc-type scoped.
# Once produced for any pipeline run they are reused by every subsequent pipeline
# on the same experiment — saving 5+ minutes of Whisper + clustering per re-run.

def _mp3_hash_path(cfg: dict) -> Path:
    """Path of the sentinel file that stores the MD5 of the converted MP3."""
    return Path(f"{cfg['experiment']}/input/.audio_hash")


def _find_experiment_mp3(cfg: dict) -> str | None:
    """Return path to the first non-empty MP3 in the experiment input dir, or None."""
    inp = Path(f"{cfg['experiment']}/input")
    if not inp.exists():
        return None
    for p in inp.glob("*.mp3"):
        if p.stat().st_size > 0:
            return str(p)
    return None


def _checksum_file(path: str) -> str | None:
    """Return MD5 hex-digest of the file at *path*, or None if unreadable."""
    try:
        h = hashlib.md5()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def _step_cache_hit(step: int, cfg: dict) -> bool:
    """
    Return True when the step output already exists and is still valid.

    Step 0 — hit when a non-empty MP3 exists AND its MD5 matches .audio_hash
              (guards against a different recording uploaded under the same name).
    Step 1 — hit when diarization_result.json exists AND the MP3 hash still
              matches (forces re-diarisation whenever new audio is uploaded).
    """
    if step == 0:
        mp3 = _find_experiment_mp3(cfg)
        if not mp3:
            return False
        hash_path = _mp3_hash_path(cfg)
        if not hash_path.exists():
            return False
        return _checksum_file(mp3) == hash_path.read_text(encoding="utf-8").strip()

    if step == 1:
        transcript = cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
        if not os.path.exists(transcript):
            return False
        hash_path = _mp3_hash_path(cfg)
        if not hash_path.exists():
            return True   # transcript imported directly — no MP3 hash, trust it
        mp3 = _find_experiment_mp3(cfg)
        if not mp3:
            return True   # no MP3 means transcript was imported, not generated
        return _checksum_file(mp3) == hash_path.read_text(encoding="utf-8").strip()

    return False


def _write_step_cache(step: int, cfg: dict) -> None:
    """Persist the MD5 sentinel after a successful step 0 run."""
    if step == 0:
        mp3 = _find_experiment_mp3(cfg)
        if not mp3:
            return
        h = _checksum_file(mp3)
        if h:
            try:
                _mp3_hash_path(cfg).write_text(h, encoding="utf-8")
            except OSError as e:
                log.warning("Could not write audio hash: %s", e)


def _pipeline_thread(job_id: str, steps: list[int], doc_type: str, llm_override: dict | None = None) -> None:
    job = jobs[job_id]
    cfg = load_cfg(force_reload=True)

    # Apply in-memory LLM override for in-process steps (llm_filler runs in-process)
    if llm_override:
        import copy
        cfg = copy.deepcopy(cfg)
        if llm_override.get("model"):
            cfg["llm"]["model"] = llm_override["model"]
        if llm_override.get("temperature") is not None:
            cfg["llm"]["temperature"] = float(llm_override["temperature"])
        if llm_override.get("max_tokens") is not None:
            cfg["llm"]["max_tokens"] = int(llm_override["max_tokens"])

    # ── Resolve doctype metadata ───────────────────────────────────────────────
    is_brd = doc_type == "brd"

    if not is_brd:
        doctypes = _load_doctypes()
        dt = doctypes.get(doc_type)
        if not dt:
            job["status"] = "error"
            job["error"]  = f"Unknown doc type: {doc_type}"
            _push_log(job, -1, f"[ERR] Unknown doc type: {doc_type}")
            _persist_job_summary(job_id, job, cfg)
            return
        schema_prompt_path = dt.get("schema_prompt", "")
        js_template_path   = dt.get("js_template", "")
        output_filename    = dt.get("output_filename", f"{doc_type.upper()}.docx")
        exp                = cfg["experiment"]
        output_json_path   = f"{exp}/output/{doc_type}_output.json"
        output_docx_path   = f"{exp}/output/{output_filename}"

    _push_log(job, -1, f"Pipeline started — type={doc_type.upper()}, steps={steps}")

    # ── Step execution loop ────────────────────────────────────────────────────
    for step in steps:

        # Stop requested between steps
        if job.get("_stop_requested"):
            job["status"] = "stopped"
            _push_log(job, -1, "[STOP] Pipeline stopped by user")
            _persist_job_summary(job_id, job, cfg)
            return

        # Skip BRD-only steps for non-BRD doc types
        if not is_brd and step in _BRD_ONLY_STEPS:
            _push_log(job, step, f"[SKIP] Step {step} is BRD-only — skipped for {doc_type.upper()}")
            job["step_status"][step] = "skipped"
            continue

        # Steps 0 and 1: audio conversion and diarisation — cached across all doc types
        if step in (0, 1):
            if _step_cache_hit(step, cfg):
                ts = time.time()
                job["step_status"][step]  = "done"
                job["step_timings"][step] = {"start": ts, "end": ts, "cached": True}
                _push_log(job, step, f"✓ Step {step} ({STEP_LABELS[step]}) — using cached result")
                if step == 1:
                    _post_step_data(job, 1, cfg)
                continue
            ok = _run_step(job, step, cfg, llm_override)
            if ok:
                _post_step_data(job, step, cfg)
                _write_step_cache(step, cfg)
            else:
                job["status"] = "error"
                _persist_job_summary(job_id, job, cfg)
                return
            continue

        # Step 2: schema analysis (BRD) or LLM document fill (all other types)
        if step == 2 and not is_brd:
            job["current_step"]    = 2
            job["step_status"][2]  = "running"
            job["step_timings"][2] = {"start": time.time(), "end": None}
            _push_log(job, 2, f">> Starting: Document Filler ({doc_type.upper()})")
            try:
                import logging as _logging
                class _JobLogHandler(_logging.Handler):
                    def emit(self, r):
                        _push_log(job, 2, r.getMessage())
                _h = _JobLogHandler()
                _logging.getLogger().addHandler(_h)
                try:
                    from llm_filler import run_fill
                    mode = "mom" if doc_type == "mom" else "generic"
                    path = run_fill(
                        cfg=cfg, schema_path=schema_prompt_path,
                        output_path=output_json_path, mode=mode, doc_type=doc_type.upper(),
                    )
                finally:
                    _logging.getLogger().removeHandler(_h)
                job["step_status"][2] = "done"
                elapsed = time.time() - job["step_timings"][2]["start"]
                _push_log(job, 2, f"[OK] Done in {elapsed:.1f}s → {path}")
            except Exception as exc:
                job["step_status"][2] = "error"
                job["error"]          = f"Document Filler failed: {exc}"
                _push_log(job, 2, f"[ERR] Failed: {exc}")
                job["status"]         = "error"
                job["step_timings"][2]["end"] = time.time()
                _persist_job_summary(job_id, job, cfg)
                return
            finally:
                if job["step_timings"][2]["end"] is None:
                    job["step_timings"][2]["end"] = time.time()
            continue

        # Step 5: BRD docx render uses trace file; all others use filled output JSON
        if step == 5 and not is_brd:
            job["current_step"]    = 5
            job["step_status"][5]  = "running"
            job["step_timings"][5] = {"start": time.time(), "end": None}
            _push_log(job, 5, f">> Starting: Word Document ({output_filename})")
            try:
                from generic_docx_runner import run_generic_docx
                run_generic_docx(output_json_path, js_template_path, output_docx_path, str(BASE_DIR / "scripts"))
                job["step_timings"][5]["end"] = time.time()
                elapsed = job["step_timings"][5]["end"] - job["step_timings"][5]["start"]
                job["step_status"][5] = "done"
                _push_log(job, 5, f"[OK] Done in {elapsed:.1f}s → {output_docx_path}")
                job["studio_outputs"] = {
                    "json":      os.path.exists(output_json_path),
                    "docx":      os.path.exists(output_docx_path),
                    "json_path": output_json_path,
                    "docx_path": output_docx_path,
                    "doc_type":  doc_type,
                    "filename":  output_filename,
                }
            except Exception as exc:
                job["step_timings"][5]["end"] = time.time()
                job["step_status"][5] = "error"
                job["error"]          = f"Word Document generation failed: {exc}"
                _push_log(job, 5, f"[ERR] Failed: {exc}")
                job["status"]         = "error"
                _persist_job_summary(job_id, job, cfg)
                return
            continue

        # All remaining steps (BRD steps 2–6): run via subprocess
        ok = _run_step(job, step, cfg, llm_override)
        if ok:
            _post_step_data(job, step, cfg)
        else:
            job["status"] = "error"
            _persist_job_summary(job_id, job, cfg)
            return

    # ── Pipeline complete ──────────────────────────────────────────────────────
    job["status"]       = "done"
    job["current_step"] = -1
    job["outputs"]      = experiment_outputs(cfg["experiment"])
    _push_log(job, -1, ">> Pipeline complete!")
    _persist_job_summary(job_id, job, cfg)
    _prune_jobs()



class ConfigUpdate(BaseModel):
    experiment:    str
    api_key:       str
    num_speakers:  int | None = 2
    whisper_model: str = "tiny"
    gemini_model:  str = "gemini-2.5-flash"


@app.get("/api/config")
def get_config():
    raw      = yaml.safe_load(Path(CFG_PATH).read_text(encoding="utf-8"))
    exp      = raw.get("experiment","")
    full_key = raw.get("llm",{}).get("api_key","")
    masked   = (full_key[:10]+"\u2022"*max(0,len(full_key)-10)) if full_key else ""
    return {
        "experiment":raw.get("experiment",""),"api_key":masked,"api_key_set":bool(full_key),
        "num_speakers":raw.get("diarization",{}).get("num_speakers",2),
        "whisper_model":raw.get("diarization",{}).get("whisper_model","tiny"),
        "gemini_model":raw.get("llm",{}).get("model","gemini-2.5-flash"),
        "temperature":raw.get("llm",{}).get("temperature",0.1),
        "max_tokens":raw.get("llm",{}).get("max_tokens",32768),
        "supported_models":[
            "gemini-2.5-flash","gemini-2.5-pro",
            "gemini-2.0-flash","gemini-2.0-flash-lite",
            "gemini-1.5-pro","gemini-1.5-flash",
        ],
        "outputs":experiment_outputs(exp),
    }


@app.post("/api/config")
def update_config(body: ConfigUpdate):
    try:
        raw = yaml.safe_load(Path(CFG_PATH).read_text(encoding="utf-8"))
        raw["experiment"] = body.experiment
        if body.api_key and not body.api_key.endswith("\u2022"*5):
            raw["llm"]["api_key"] = body.api_key
        raw["llm"]["model"]                 = body.gemini_model
        raw["diarization"]["num_speakers"]  = body.num_speakers
        raw["diarization"]["whisper_model"] = body.whisper_model
        save_cfg_raw(raw)
        load_cfg(force_reload=True)
        return {"ok":True}
    except Exception as e:
        raise HTTPException(500,f"Failed to save config: {e}")


@app.post("/api/upload/start")
def upload_start(filename: str, size: int):
    if size<0: raise HTTPException(400,"size must be non-negative")
    if not filename: raise HTTPException(400,"filename is required")
    uid = str(uuid.uuid4())[:8]
    with _upload_progress_lock:
        upload_progress[uid]={"received":0,"total":max(size,1),"done":False,"filename":filename}
    return {"upload_id":uid}


@app.post("/api/upload")
async def upload_audio(request: Request, file: UploadFile = File(...)):
    ext = Path(file.filename).suffix.lower()
    if ext not in AUDIO_EXTENSIONS:
        raise HTTPException(400,f"Unsupported file type: {ext}")
    cfg=load_cfg(); exp=cfg["experiment"]
    dest_dir=f"{exp}/input"; os.makedirs(dest_dir,exist_ok=True)
    dest=f"{dest_dir}/{file.filename}"
    total=int(request.headers.get("content-length",0)); received=0
    uid=request.headers.get("x-upload-id","")
    if uid and uid not in upload_progress:
        upload_progress[uid]={"received":0,"total":total,"done":False,"filename":file.filename}
    with open(dest,"wb") as fh:
        while True:
            chunk=await file.read(65536)
            if not chunk: break
            fh.write(chunk); received+=len(chunk)
            if uid and uid in upload_progress:
                upload_progress[uid]["received"]=received
                upload_progress[uid]["total"]=max(total,received)
    if uid and uid in upload_progress:
        upload_progress[uid]["done"]=True
    duration=get_audio_duration(dest); size_mb=os.path.getsize(dest)/1e6
    return {
        "ok":True,"filename":file.filename,"size_mb":round(size_mb,1),
        "duration_secs":round(duration,1),"duration_mins":round(duration/60,1),
        "estimated_diarization_mins":max(1,int(duration/60*3)),"is_mp3":ext==".mp3",
    }


@app.get("/api/upload/progress/{uid}")
def upload_progress_check(uid: str):
    with _upload_progress_lock:
        if uid not in upload_progress: raise HTTPException(404,"Unknown upload id")
        p=dict(upload_progress[uid])
    pct=int(p["received"]/p["total"]*100) if p["total"] else 0
    return {"pct":pct,"received":p["received"],"total":p["total"],"done":p["done"],"filename":p["filename"]}


def _safe_experiment(experiment: str) -> str:
    if not re.match(r"^[a-zA-Z0-9][a-zA-Z0-9_\-.]{0,63}$",experiment):
        raise HTTPException(400,"Invalid experiment name")
    return experiment


@app.get("/api/audio/{experiment}")
def stream_audio(experiment: str):
    exp=_safe_experiment(experiment)
    for ext in AUDIO_EXTENSIONS:
        files=glob.glob(f"{exp}/input/*{ext}")
        if files: return FileResponse(files[0],media_type="audio/mpeg")
    raise HTTPException(404,"No audio file found")


class RunRequest(BaseModel):
    steps:        list[int] | None = None
    doc_type:     str = "brd"
    llm_override: dict | None = None   # optional per-run LLM settings: model, temperature, max_tokens


@app.post("/api/run")
def start_pipeline(body: RunRequest | None = None):
    if body is None: body=RunRequest()
    steps=body.steps if body.steps is not None else list(range(7))
    doc_type=(body.doc_type or "brd").lower().strip()
    llm_override = body.llm_override or {}
    invalid=[s for s in steps if s not in range(7)]
    if invalid: raise HTTPException(400,f"Invalid step numbers: {invalid}. Valid range: 0\u20136.")
    job_id=str(uuid.uuid4())[:8]
    jobs[job_id]={
        "status":"running","steps":steps,"current_step":-1,"doc_type":doc_type,
        "step_status":{s:"pending" for s in steps},"step_timings":{},
        "logs":[],"error":None,"diar_analytics":None,"brd_preview":None,
        "gap_report":None,"studio_outputs":None,"outputs":{},
        "llm_override": llm_override,
    }
    threading.Thread(target=_pipeline_thread, args=(job_id, steps, doc_type, llm_override), daemon=True).start()
    return {"job_id":job_id}


@app.get("/api/jobs/{job_id}")
def poll_job(job_id: str, since: int = 0):
    if job_id not in jobs: raise HTTPException(404,"Job not found")
    job=jobs[job_id]
    return {
        "status":job["status"],"current_step":job["current_step"],"step_status":job["step_status"],
        "step_timings":{
            k:{"start":v["start"],"end":v["end"],
               "elapsed":round((v["end"] or time.time())-v["start"],1),
               "cached":v.get("cached",False)}
            for k,v in job["step_timings"].items()
        },
        "logs":job["logs"][since:],"log_total":len(job["logs"]),"error":job["error"],
        "diar_analytics":job["diar_analytics"],"brd_preview":job["brd_preview"],
        "gap_report":job["gap_report"],"studio_outputs":job["studio_outputs"],"outputs":job["outputs"],
    }


@app.post("/api/jobs/{job_id}/stop")
def stop_job(job_id: str):
    if job_id not in jobs: raise HTTPException(404,f"Job {job_id!r} not found")
    job=jobs[job_id]
    if job.get("status")!="running":
        return {"ok":False,"reason":f"Job is not running (status={job.get('status')})"}
    job["_stop_requested"]=True
    log.info("\u26d4 Job %s stop requested by user",job_id)
    return {"ok":True,"job_id":job_id,"status":"stop_requested"}


@app.get("/api/diarization")
def get_diarization():
    try:
        cfg=load_cfg(); path=cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
        if not os.path.exists(path): return {"ok":False}
        segs=json.loads(Path(path).read_text(encoding="utf-8"))
        return {"ok":True,"analytics":_build_diar_analytics(segs)}
    except Exception as e:
        return {"ok":False,"error":str(e)}


@app.get("/api/speakers")
def get_speakers():
    cfg=load_cfg(); path=cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
    if not os.path.exists(path): return {"speakers":[]}
    segs=json.loads(Path(path).read_text(encoding="utf-8"))
    return {"speakers":sorted({s["speaker_name"] for s in segs})}


class SpeakerMap(BaseModel):
    mapping: dict[str,str]


@app.post("/api/speakers/rename")
def rename_speakers(body: SpeakerMap):
    cfg=load_cfg(); path=cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
    if not os.path.exists(path): raise HTTPException(404,"Diarization file not found")
    segs=json.loads(Path(path).read_text(encoding="utf-8"))
    for seg in segs:
        old=seg.get("speaker_name","")
        if old in body.mapping:
            seg["speaker_name"]=body.mapping[old]
            seg["speaker_id"]=body.mapping[old]
    dest_dir=str(Path(path).parent)
    content=json.dumps(segs,indent=2,ensure_ascii=False).encode("utf-8")
    tmp_fd,tmp_path=tempfile.mkstemp(dir=dest_dir,suffix=".tmp")
    try:
        with os.fdopen(tmp_fd,"wb") as fh: fh.write(content)
        os.replace(tmp_path,path)
    except Exception:
        try: os.unlink(tmp_path)
        except OSError: pass
        raise
    return {"ok":True,"renamed":len(body.mapping)}


@app.get("/api/download/{experiment}/{filename}")
def download_file(experiment:str,filename:str):
    exp=_safe_experiment(experiment); safe=Path(filename).name; path=f"{exp}/output/{safe}"
    if not os.path.exists(path): raise HTTPException(404,f"Not found: {path}")
    return FileResponse(path,filename=safe)


@app.get("/api/download/input/{experiment}/{filename}")
def download_input_file(experiment:str,filename:str):
    exp=_safe_experiment(experiment); safe=Path(filename).name; path=f"{exp}/input/{safe}"
    if not os.path.exists(path): raise HTTPException(404,f"Not found: {path}")
    return FileResponse(path,filename=safe)


@app.get("/api/experiments")
def list_experiments():
    exps=[]
    for d in sorted(glob.glob("*/output")):
        exp=d.split("/")[0]
        exps.append({"name":exp,"outputs":experiment_outputs(exp),"has_audio":bool(
            glob.glob(f"{exp}/input/*.mp3")+glob.glob(f"{exp}/input/*.wav"))})
    return {"experiments":exps}


@app.get("/api/gap")
def get_gap_report():
    try:
        cfg=load_cfg(); path=cfg["chains"]["chain4_gap_analyser"]["output"]["gap_report"]
        if not os.path.exists(path): return {"ok":False}
        return {"ok":True,"report":json.loads(Path(path).read_text(encoding="utf-8"))}
    except Exception as e:
        return {"ok":False,"error":str(e)}


@app.get("/api/config/yaml")
def get_config_yaml():
    raw=yaml.safe_load(Path(CFG_PATH).read_text(encoding="utf-8"))
    raw_key=raw.get("llm",{}).get("api_key","")
    safe={"experiment":raw.get("experiment",""),
          "diarization":{"num_speakers":raw.get("diarization",{}).get("num_speakers"),
                         "whisper_model":raw.get("diarization",{}).get("whisper_model","tiny"),
                         "language":raw.get("diarization",{}).get("language","en")},
          "llm":{"model":raw.get("llm",{}).get("model",""),
                 "api_key":(raw_key[:10]+"\u2022"*12) if raw_key else "(not set)"}}
    buf=io.StringIO()
    yaml.dump(safe,buf,default_flow_style=False,allow_unicode=True,sort_keys=False)
    return {"yaml":buf.getvalue()}


@app.get("/api/ping")
def ping():
    return {"ok":True,"ts":time.time()}


@app.get("/logo")
def serve_logo():
    for p in [BASE_DIR/"dataNeurus_logo.png",BASE_DIR/"DataNeurus_logo.png",BASE_DIR/"static"/"logo.png"]:
        if p.exists(): return FileResponse(str(p),media_type="image/png")
    return Response(content=_TRANSPARENT_PIXEL_PNG,media_type="image/png")


@app.get("/api/doctypes")
def list_doctypes():
    dts={k:v for k,v in _load_doctypes().items() if k!="quickrun"}
    return {"doctypes":list(dts.values())}


@app.post("/api/doctypes/register")
async def register_doctype(request: Request):
    form=await request.form()
    key=str(form.get("key","")).strip().lower().replace(" ","_")
    name=str(form.get("name","")).strip(); label=str(form.get("label","")).strip()
    schema_upload=form.get("schema_prompt"); js_upload=form.get("js_template")
    if not key or not name or not label: raise HTTPException(400,"key, name, and label are required")
    if not re.match(r"^[a-z][a-z0-9_]{0,29}$",key):
        raise HTTPException(400,"key must be lowercase alphanumeric/underscore, max 30 chars")
    doctypes=_load_doctypes()
    if key in doctypes and doctypes[key].get("builtin"):
        raise HTTPException(400,f"\'{key}\' is built-in and cannot be overwritten")
    upload_dir=os.path.join(STUDIO_UPLOADS,key); os.makedirs(upload_dir,exist_ok=True)
    schema_dest=os.path.join(upload_dir,"schema_prompt.json")
    js_dest=os.path.join(upload_dir,"JS_template.js")
    sp_data=await schema_upload.read() if hasattr(schema_upload,"read") else b""
    js_data=await js_upload.read()     if hasattr(js_upload,"read")     else b""
    try: json.loads(sp_data)
    except Exception: raise HTTPException(400,"schema_prompt must be valid JSON")
    Path(schema_dest).write_bytes(sp_data); Path(js_dest).write_bytes(js_data)
    doctypes[key]={"key":key,"name":name,"label":label,"builtin":False,
                   "schema_prompt":schema_dest,"js_template":js_dest,
                   "output_filename":f"{label.upper()}.docx",
                   "step_labels":{"2":"Document Filler","5":"Word Document"}}
    _save_doctypes(doctypes)
    log.info("\U0001f4cb Registered doc type: %s (%s)",key,name)
    return {"ok":True,"key":key,"doctype":doctypes[key]}


@app.delete("/api/doctypes/{key}")
def delete_doctype(key: str):
    doctypes=_load_doctypes()
    if key not in doctypes: raise HTTPException(404,f"Doc type \'{key}\' not found")
    if doctypes[key].get("builtin"): raise HTTPException(400,f"\'{key}\' is built-in and cannot be deleted")
    dt=doctypes[key]
    for fk in ("schema_prompt","js_template"):
        fp=dt.get(fk,"")
        if fp and STUDIO_UPLOADS in str(fp) and os.path.exists(fp):
            try: os.remove(fp)
            except Exception: pass
    try:
        d=os.path.join(STUDIO_UPLOADS,key)
        if os.path.isdir(d) and not os.listdir(d): os.rmdir(d)
    except Exception: pass
    del doctypes[key]; _save_doctypes(doctypes)
    log.info("\U0001f5d1\ufe0f  Deleted doc type: %s",key)
    return {"ok":True,"deleted":key}


@app.get("/api/static/{filepath:path}")
def serve_static(filepath: str):
    safe_prefixes=("artifacts_library/","prompts/","scripts/JS_")
    if not any(filepath.startswith(p) for p in safe_prefixes): raise HTTPException(403,"Access denied")
    full=BASE_DIR/filepath
    try: full.resolve().relative_to(BASE_DIR.resolve())
    except ValueError: raise HTTPException(403,"Access denied")
    if not full.exists(): raise HTTPException(404,f"Not found: {filepath}")
    return FileResponse(str(full),filename=full.name)


@app.post("/api/upload/transcript")
async def upload_transcript(request: Request, file: UploadFile = File(...)):
    if not file.filename.endswith(".json"): raise HTTPException(400,"File must be a .json")
    cfg=load_cfg(); exp=cfg["experiment"]
    dest_dir=f"{exp}/input"; os.makedirs(dest_dir,exist_ok=True)
    dest=f"{dest_dir}/diarization_result.json"
    content=await file.read()
    try:
        parsed=json.loads(content)
        if not isinstance(parsed,list): raise ValueError("Expected a JSON array")
        parsed=[i for i in parsed if isinstance(i,dict) and "utterance_id" in i]
        if not parsed: raise ValueError("No valid utterance objects found")
        if not all(k in parsed[0] for k in ("utterance_id","speaker_name","text")):
            raise ValueError("Items must have: utterance_id, speaker_name, text")
    except (json.JSONDecodeError,ValueError) as e:
        raise HTTPException(400,f"Invalid transcript JSON: {e}")
    content=json.dumps(parsed,indent=2,ensure_ascii=False).encode("utf-8")
    tmp_fd,tmp_path=tempfile.mkstemp(dir=dest_dir,suffix=".tmp")
    try:
        with os.fdopen(tmp_fd,"wb") as fh: fh.write(content)
        os.replace(tmp_path,dest)
    except Exception:
        try: os.unlink(tmp_path)
        except OSError: pass
        raise
    return {"ok":True,"utterances":len(parsed),"speakers":sorted({s["speaker_name"] for s in parsed}),"dest":dest,"experiment":exp}


class JsSaveRequest(BaseModel):
    content:  str
    filename: str = "JS_mom_template.js"


@app.post("/api/save-js-template")
def save_js_template(body: JsSaveRequest):
    safe_name=Path(body.filename).name
    if not safe_name.startswith("JS_") or not safe_name.endswith(".js"):
        raise HTTPException(400,"filename must start with JS_ and end with .js")
    dest=BASE_DIR/"artifacts_library"/"MOM"/safe_name
    try:
        dest.write_text(body.content,encoding="utf-8")
        log.info("Saved JS template: %s",dest)
        return {"ok":True,"saved":str(dest)}
    except Exception as e:
        raise HTTPException(500,f"Failed to save: {e}")


@app.get("/api/viewer/data")
def get_viewer_data():
    cfg=load_cfg(); exp=cfg.get("experiment","")
    for dtype,path in [("mom",f"{exp}/output/mom_output.json"),("brd",f"{exp}/output/brd-response-trace.json"),
                       ("brd_schema",f"{exp}/output/brd-response.json"),("brd_schema2",f"{exp}/output/brd-schema-output.json")]:
        if os.path.exists(path):
            try:
                data=json.loads(Path(path).read_text(encoding="utf-8"))
                return {"ok":True,"type":dtype,"experiment":exp,"data":data,"path":path}
            except Exception as e:
                log.warning("viewer data parse error: %s",e)
    return {"ok":False,"experiment":exp,"error":"No output JSON found for this experiment"}


@app.get("/",response_class=HTMLResponse)
def index():
    return HTMLResponse(_get_frontend_html())


if __name__=="__main__":
    import uvicorn
    log.info("\U0001f4c2 Working dir  : %s",os.getcwd())
    log.info("\U0001f4c4 Config path  : %s",CFG_PATH)
    if not Path(CFG_PATH).exists():
        log.error("\u274c configuration.yaml not found at %s",CFG_PATH)
        raise SystemExit(1)
    _get_frontend_html()
    uvicorn.run("app:app",host="0.0.0.0",port=8000,reload=False)


