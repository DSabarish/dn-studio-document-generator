# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/diarisation.py
# SOURCE: DN-Studio v2300 BRD ipynb — diarization_pipeline.py (cell 17)
#         Ported verbatim with repo-specific adaptations noted below.
#
# IPYNB → REPO adaptations:
#   1. GPU auto-detection via torch.cuda (FIX-1 from repo)
#   2. run_pipeline() renamed → run_diarisation() with progress_callback
#   3. ffmpeg convert_to_wav() added (repo handles non-WAV inputs)
#   4. to_json() field "spk_confidence" added (repo enrichment)
#   5. HTML view generated via view_builder.build_view_html()
#   6. speaker_summary() and to_markdown() preserved from ipynb
#   7. All config constants match ipynb exactly (BEAM_SIZE=5, VAD=True, etc.)
# ─────────────────────────────────────────────────────────────────────────────

"""
diarization_pipeline.py  —  DN-Studio Speaker Diarization Core
================================================================
Full end-to-end pipeline: ASR (faster-whisper) → Speaker Embeddings
(resemblyzer d-vectors) → Spectral Clustering → Labelled transcript.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# MODULE-LEVEL DEFAULTS  (exact ipynb values)
# ═══════════════════════════════════════════════════════════════════════════════
import os as _os

SEED              = int(_os.environ.get("DN_SEED",   42))
WHISPER_MODEL     = _os.environ.get("DN_WHISPER",    "base.en")
BEAM_SIZE         = int(_os.environ.get("DN_BEAM",   5))
BEST_OF           = int(_os.environ.get("DN_BESTOF", 5))
VAD_FILTER        = True
VAD_SILENCE_MS    = 500
CONDITION_ON_PREV = True
NO_SPEECH_THRESH  = 0.6
LOG_PROB_THRESH   = -1.0
COMPRESS_THRESH   = 2.4
REMOVE_FILLERS    = True
REMOVE_STUTTERS   = True
REMOVE_REPEATS    = True
NUM_SPEAKERS      = None
MAX_SPEAKERS      = 8
SMOOTH_WINDOW     = 3
MIN_SEG_DUR       = 0.4
PCA_VARIANCE      = 0.99
LINKAGE           = "average"
METRIC            = "cosine"
USE_UTTERANCE_EMBEDDINGS = True

# ─────────────────────────────────────────────────────────────────────────────
# GPU detection (repo FIX-1) — float16 on CUDA, int8 on CPU
# ─────────────────────────────────────────────────────────────────────────────
try:
    import torch as _torch
    if _torch.cuda.is_available():
        DEVICE       = "cuda"
        COMPUTE_TYPE = "float16"
    else:
        DEVICE       = "cpu"
        COMPUTE_TYPE = "int8"
except ImportError:
    DEVICE       = "cpu"
    COMPUTE_TYPE = "int8"

# ─────────────────────────────────────────────────────────────────────────────
# Core imports
# ─────────────────────────────────────────────────────────────────────────────
import logging
import os, sys, json, re, subprocess, tempfile
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Tuple

import numpy as np
import librosa
import soundfile as sf
from sklearn.cluster import SpectralClustering, AgglomerativeClustering
from sklearn.preprocessing import normalize
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
from scipy.ndimage import median_filter
from faster_whisper import WhisperModel

log = logging.getLogger("dn_studio.diarisation")
np.random.seed(SEED)


# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES  (exact ipynb)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ASRSegment:
    """One transcribed utterance with timestamps, optional speaker label, and
    ASR confidence score derived from the average log-probability."""
    start:        float
    end:          float
    text:         str
    speaker:      Optional[str] = None
    utterance_id: Optional[int] = None
    confidence:   float         = 1.0


@dataclass
class SpeakerSegment:
    """A contiguous time range assigned to a single speaker.
    Used in the sliding-window fallback diarization path."""
    start:   float
    end:     float
    speaker: str


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIO CONVERSION  (repo addition — ipynb assumes WAV input)
# ═══════════════════════════════════════════════════════════════════════════════

def convert_to_wav(input_path: str, output_path: str) -> str:
    """Convert any audio/video to 16kHz mono WAV via ffmpeg."""
    log.info("[CONVERT] %s → WAV", Path(input_path).name)
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", input_path, "-ac", "1", "-ar", "16000", "-vn", output_path],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"[CONVERT] ffmpeg failed:\n{result.stderr[-800:]}")
    log.info("[CONVERT] WAV ready  %.1f MB", Path(output_path).stat().st_size / 1024 / 1024)
    return output_path


# ═══════════════════════════════════════════════════════════════════════════════
# TEXT CLEANING  (exact ipynb)
# ═══════════════════════════════════════════════════════════════════════════════

_FILLERS  = re.compile(
    r'\b(um+|uh+|er+|ah+|hmm+|mhm|uh-huh|you know|i mean'
    r'|like,?\s+(?=\w)|sort of|kind of|basically|literally|actually,?\s+)\b',
    re.IGNORECASE,
)
_STUTTER  = re.compile(r'\b(\w+)[–-]\s+\1',  re.IGNORECASE)
_REPEATED = re.compile(r'\b(\w{2,})\s+\1\b', re.IGNORECASE)
_MULTI_SP = re.compile(r'\s{2,}')
_LEAD_PCT = re.compile(r'^[,\.;\s]+')


def clean_text(
    raw:             str,
    remove_fillers:  bool = True,
    remove_stutters: bool = True,
    remove_repeats:  bool = True,
) -> str:
    """Normalise raw ASR output."""
    t = raw.strip()
    if remove_stutters: t = _STUTTER.sub(r'\1', t)
    if remove_repeats:  t = _REPEATED.sub(r'\1', t)
    if remove_fillers:  t = _FILLERS.sub(' ', t)
    t = _LEAD_PCT.sub('', _MULTI_SP.sub(' ', t))
    return (t[0].upper() + t[1:]).strip() if t else t


# ═══════════════════════════════════════════════════════════════════════════════
# ASR — Automatic Speech Recognition  (exact ipynb)
# ═══════════════════════════════════════════════════════════════════════════════

def transcribe(
    audio_path:         str,
    model_size:         str   = WHISPER_MODEL,
    device:             str   = DEVICE,
    compute_type:       str   = COMPUTE_TYPE,
    beam_size:          int   = BEAM_SIZE,
    best_of:            int   = BEST_OF,
    vad_filter:         bool  = VAD_FILTER,
    vad_silence_ms:     int   = VAD_SILENCE_MS,
    condition_on_prev:  bool  = CONDITION_ON_PREV,
    no_speech_thresh:   float = NO_SPEECH_THRESH,
    log_prob_thresh:    float = LOG_PROB_THRESH,
    compression_thresh: float = COMPRESS_THRESH,
    remove_fillers:     bool  = REMOVE_FILLERS,
    remove_stutters:    bool  = REMOVE_STUTTERS,
    remove_repeats:     bool  = REMOVE_REPEATS,
) -> List[ASRSegment]:
    """Transcribe audio with faster-whisper and return cleaned ASR segments."""
    log.info("[ASR] Loading model='%s'  device=%s  compute=%s", model_size, device, compute_type)
    model = WhisperModel(model_size, device=device, compute_type=compute_type)

    segs, info = model.transcribe(
        audio_path,
        language="en",
        beam_size=beam_size,
        best_of=best_of,
        temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
        compression_ratio_threshold=compression_thresh,
        log_prob_threshold=log_prob_thresh,
        no_speech_threshold=no_speech_thresh,
        condition_on_previous_text=condition_on_prev,
        vad_filter=vad_filter,
        vad_parameters=dict(min_silence_duration_ms=vad_silence_ms),
        word_timestamps=False,
    )

    out: List[ASRSegment] = []
    for s in segs:
        t = clean_text(s.text, remove_fillers, remove_stutters, remove_repeats)
        if not t:
            continue
        conf = float(np.clip(np.exp(s.avg_logprob), 0.0, 1.0))
        out.append(ASRSegment(float(s.start), float(s.end), t, confidence=conf))

    log.info("[ASR] %d segments produced.", len(out))
    return out


# ═══════════════════════════════════════════════════════════════════════════════
# SPEAKER EMBEDDINGS — resemblyzer d-vectors  (exact ipynb)
# ═══════════════════════════════════════════════════════════════════════════════

def load_audio_mono(path: str, sr: int = 16_000) -> np.ndarray:
    """Load any audio format as mono float32 at the given sample rate."""
    y, _ = librosa.load(path, sr=sr, mono=True)
    return y


def get_segment_embedding(
    encoder,
    y:       np.ndarray,
    sr:      int,
    start:   float,
    end:     float,
    min_dur: float = 0.5,
) -> Optional[np.ndarray]:
    """Extract a 256-dim d-vector for the audio slice [start, end] seconds.

    Passes numpy array directly to preprocess_wav() — no disk I/O.
    preprocess_wav() accepts Union[str, Path, np.ndarray] with source_sr.
    """
    s, e  = int(start * sr), int(end * sr)
    chunk = y[s:e]

    if len(chunk) < int(min_dur * sr):
        return None

    try:
        from resemblyzer import preprocess_wav
        # Pass numpy array directly — avoids sf.write + disk read overhead entirely
        wav = preprocess_wav(chunk.astype(np.float32), source_sr=sr)
        return encoder.embed_utterance(wav)

    except Exception as ex:
        log.debug("[EMB] Skipping [%.1f–%.1f]s: %s", start, end, ex)
        return None


def extract_embeddings_for_segments(
    audio_path:   str,
    asr_segments: List[ASRSegment],
    sr:           int = 16_000,
) -> Tuple[List[int], np.ndarray]:
    """Embed each ASR utterance with the resemblyzer VoiceEncoder (d-vectors)."""
    from resemblyzer import VoiceEncoder
    log.info("[EMB] Loading VoiceEncoder (resemblyzer d-vector)…")
    encoder = VoiceEncoder("cpu")

    log.info("[EMB] Embedding %d ASR segments…", len(asr_segments))
    y = load_audio_mono(audio_path, sr)

    valid_idx:  List[int]         = []
    embeddings: List[np.ndarray]  = []

    for i, seg in enumerate(asr_segments):
        emb = get_segment_embedding(encoder, y, sr, seg.start, seg.end)
        if emb is not None:
            valid_idx.append(i)
            embeddings.append(emb)

    emb_arr = np.array(embeddings, dtype=np.float32)
    log.info("[EMB] %d embeddings extracted  (dim=%d).", len(valid_idx), emb_arr.shape[1])
    return valid_idx, emb_arr


def extract_sliding_embeddings(
    audio_path: str,
    sr:         int   = 16_000,
    window_sec: float = 1.5,
    hop_sec:    float = 0.5,
) -> Tuple[List[Tuple[float, float]], np.ndarray]:
    """Fallback: compute d-vector embeddings over overlapping sliding windows."""
    from resemblyzer import VoiceEncoder, preprocess_wav  # preprocess_wav accepts numpy
    log.info("[EMB] Sliding-window embeddings (window=%.1fs, hop=%.1fs)…", window_sec, hop_sec)
    encoder  = VoiceEncoder("cpu")
    y        = load_audio_mono(audio_path, sr)
    duration = len(y) / sr

    times:      List[Tuple[float, float]] = []
    embeddings: List[np.ndarray]          = []
    t = 0.0

    while t + window_sec <= duration:
        s, e  = int(t * sr), int((t + window_sec) * sr)
        chunk = y[s:e]
        try:
            # Pass numpy array directly — no tempfile write/read
            wav = preprocess_wav(chunk.astype(np.float32), source_sr=sr)
            emb = encoder.embed_utterance(wav)
            times.append((t, t + window_sec))
            embeddings.append(emb)
        except Exception:
            pass
        t += hop_sec

    emb_arr = np.array(embeddings, dtype=np.float32)
    log.info("[EMB] %d windows  (dim=%d).", len(times), emb_arr.shape[1])
    return times, emb_arr


# ═══════════════════════════════════════════════════════════════════════════════
# SPEAKER COUNT SELECTION — silhouette score  (exact ipynb)
# ═══════════════════════════════════════════════════════════════════════════════

def best_num_speakers(X: np.ndarray, max_n: int = MAX_SPEAKERS) -> int:
    """Auto-select the number of speakers using the cosine silhouette score."""
    Xn = normalize(X)
    best_n, best_score = 2, -1.0
    log.info("[DIAR] Silhouette search for num_speakers (max=%d)…", max_n)

    for n in range(2, min(max_n + 1, len(X))):
        try:
            _Xn  = normalize(Xn)
            _aff = np.clip(_Xn @ _Xn.T, 0.0, 1.0)
            np.fill_diagonal(_aff, 1.0)
            labels = SpectralClustering(
                n_clusters=n, affinity="precomputed", random_state=SEED,
                assign_labels="discretize", n_init=20,
            ).fit_predict(_aff)
            if len(np.unique(labels)) < n:
                raise ValueError("collapsed")

            score = silhouette_score(Xn, labels, metric="cosine")
            log.info("  n=%d  silhouette=%.4f", n, score)

            if score > best_score:
                best_score, best_n = score, n

        except Exception as ex:
            log.warning("  n=%d  failed: %s", n, ex)

    log.info("[DIAR] Best n_speakers=%d  (silhouette=%.4f)", best_n, best_score)
    return best_n


# ═══════════════════════════════════════════════════════════════════════════════
# CLUSTERING  (exact ipynb + repo FIX-3 kmeans retry)
# ═══════════════════════════════════════════════════════════════════════════════

def smooth_labels(labels: np.ndarray, window: int = 5) -> np.ndarray:
    """Apply a 1D median filter over the label sequence."""
    return np.round(median_filter(labels.astype(float), size=window)).astype(int)


def _cluster(Xn: np.ndarray, num_speakers: int) -> np.ndarray:
    """
    Spectral clustering with three fallback levels:
      1. discretize  (primary — exact ipynb)
      2. kmeans retry if discretize collapses  (repo FIX-3)
      3. AgglomerativeClustering ward  (final fallback)
    """
    Xn_norm = normalize(Xn)
    aff     = np.clip(Xn_norm @ Xn_norm.T, 0.0, 1.0)
    np.fill_diagonal(aff, 1.0)

    # Attempt 1: discretize
    try:
        labels = SpectralClustering(
            n_clusters=num_speakers, affinity="precomputed", random_state=SEED,
            assign_labels="discretize", n_init=50,
        ).fit_predict(aff)
        if len(np.unique(labels)) >= num_speakers:
            log.info("[DIAR] Spectral (discretize) → %d clusters ✓", len(np.unique(labels)))
            return labels
        log.warning("[DIAR] Spectral discretize collapsed to %d clusters, retrying kmeans",
                    len(np.unique(labels)))
    except Exception as ex:
        log.warning("[DIAR] Spectral discretize failed: %s", ex)

    # Attempt 2: kmeans
    try:
        labels = SpectralClustering(
            n_clusters=num_speakers, affinity="precomputed", random_state=SEED + 1,
            assign_labels="kmeans", n_init=50,
        ).fit_predict(aff)
        if len(np.unique(labels)) >= num_speakers:
            log.info("[DIAR] Spectral (kmeans) → %d clusters ✓", len(np.unique(labels)))
            return labels
        log.warning("[DIAR] Spectral kmeans also collapsed to %d clusters", len(np.unique(labels)))
    except Exception as ex:
        log.warning("[DIAR] Spectral kmeans failed: %s", ex)

    # Attempt 3: Agglomerative fallback
    log.warning("[DIAR] Falling back to AgglomerativeClustering (ward)")
    labels = AgglomerativeClustering(
        n_clusters=num_speakers, metric="euclidean", linkage="ward",
    ).fit_predict(Xn_norm)
    log.info("[DIAR] Agglomerative → %d clusters", len(np.unique(labels)))
    return labels


def cluster_embeddings(
    times:         List[Tuple[float, float]],
    embeddings:    np.ndarray,
    num_speakers:  Optional[int],
    max_speakers:  int,
    smooth_window: int,
    min_seg_dur:   float,
    pca_variance:  float,
    linkage:       str,
    metric:        str,
) -> List[SpeakerSegment]:
    """Cluster sliding-window embeddings into contiguous speaker segments (ipynb path)."""
    embeddings = np.nan_to_num(embeddings, nan=0.0, posinf=0.0, neginf=0.0)
    _norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = np.where(_norms > 1e-8, embeddings,
                          np.random.default_rng(SEED).normal(0, 1e-4, embeddings.shape))
    Xn = normalize(embeddings)

    if pca_variance < 1.0:
        pca = PCA(n_components=pca_variance, svd_solver="full")
        Xn  = pca.fit_transform(Xn)
        log.info("[DIAR] PCA → %d dims (%.0f%% variance retained)", Xn.shape[1], pca_variance * 100)

    if num_speakers is None:
        num_speakers = best_num_speakers(Xn, max_speakers)
    else:
        log.info("[DIAR] Using num_speakers=%d", num_speakers)

    labels = _cluster(Xn, num_speakers)
    labels = smooth_labels(labels, smooth_window)

    segs: List[SpeakerSegment] = []
    cur  = int(labels[0])
    s0, e0 = times[0]

    for i in range(1, len(labels)):
        lab  = int(labels[i])
        ts, te = times[i]
        if lab == cur:
            e0 = te
        else:
            segs.append(SpeakerSegment(s0, e0, f"SPEAKER_{cur}"))
            cur, s0, e0 = lab, ts, te

    segs.append(SpeakerSegment(s0, e0, f"SPEAKER_{cur}"))
    segs = [s for s in segs if (s.end - s.start) >= min_seg_dur]
    log.info("[DIAR] %d speaker segments produced.", len(segs))
    return segs


def diarize_utterances(
    asr_segments:  List[ASRSegment],
    valid_idx:     List[int],
    embeddings:    np.ndarray,
    num_speakers:  Optional[int] = None,
    max_speakers:  int           = MAX_SPEAKERS,
    smooth_window: int           = SMOOTH_WINDOW,
    pca_variance:  float         = PCA_VARIANCE,
) -> List[ASRSegment]:
    """Cluster utterance-level embeddings and assign a speaker to each ASRSegment."""
    embeddings = np.nan_to_num(embeddings, nan=0.0, posinf=0.0, neginf=0.0)
    _norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = np.where(_norms > 1e-8, embeddings,
                          np.random.default_rng(SEED).normal(0, 1e-4, embeddings.shape))
    Xn = normalize(embeddings)

    if pca_variance < 1.0 and Xn.shape[1] > 10:
        pca = PCA(n_components=pca_variance, svd_solver="full")
        Xn  = pca.fit_transform(Xn)

    if num_speakers is None:
        num_speakers = best_num_speakers(Xn, max_speakers)
    else:
        log.info("[DIAR] Clustering %d utterances → %d speakers…", len(Xn), num_speakers)

    labels = _cluster(Xn, num_speakers)
    labels = smooth_labels(np.array(labels), smooth_window)

    # Compute centroids for spk_confidence (repo enrichment)
    Xn_norm   = normalize(Xn)
    centroids = {}
    for lbl in np.unique(labels):
        mask = labels == lbl
        centroids[lbl] = normalize(Xn_norm[mask].mean(axis=0, keepdims=True))[0]

    # Assign speaker labels back to the original ASR segments
    for rank, seg_idx in enumerate(valid_idx):
        lbl      = int(labels[rank])
        spk_conf = float(np.clip(np.dot(Xn_norm[rank], centroids[lbl]), 0.0, 1.0))
        asr_segments[seg_idx].speaker                    = f"SPEAKER_{lbl}"
        asr_segments[seg_idx].utterance_id               = seg_idx
        asr_segments[seg_idx].__dict__["spk_confidence"] = round(spk_conf, 3)

    # Fill un-embedded segments using nearest-neighbour label
    for i, seg in enumerate(asr_segments):
        if seg.speaker is None:
            nearest     = min(valid_idx, key=lambda j: abs(j - i), default=None)
            seg.speaker = asr_segments[nearest].speaker if nearest else "SPEAKER_UNKNOWN"
            seg.utterance_id               = i
            seg.__dict__["spk_confidence"] = 0.0

    log.info("[DIAR] Labels assigned to %d segments", len(asr_segments))
    return asr_segments


def assign_speakers_from_windows(
    asr_segments: List[ASRSegment],
    times:        List[Tuple[float, float]],
    labels:       np.ndarray,
) -> List[ASRSegment]:
    """Map sliding-window cluster labels back to ASR segments by time overlap."""
    for i, seg in enumerate(asr_segments):
        dur = max(seg.end - seg.start, 1e-6)
        scores: dict = {}
        for j, (ws, we) in enumerate(times):
            ov = max(0.0, min(seg.end, we) - max(seg.start, ws))
            if ov > 0:
                lbl = str(labels[j])
                scores[lbl] = scores.get(lbl, 0.0) + ov / dur
        seg.speaker                    = "SPEAKER_" + max(scores, key=scores.get) if scores else "SPEAKER_UNKNOWN"
        seg.utterance_id               = i
        seg.__dict__["spk_confidence"] = round(max(scores.values()) if scores else 0.0, 3)
    return asr_segments


# ═══════════════════════════════════════════════════════════════════════════════
# OUTPUT HELPERS  (exact ipynb + spk_confidence repo enrichment)
# ═══════════════════════════════════════════════════════════════════════════════

def to_json(asr: List[ASRSegment]) -> List[Dict[str, Any]]:
    """Serialise ASR segments to a JSON-compatible list of dicts.

    speaker_name is initialised to the same value as speaker_id.
    spk_confidence is a repo enrichment — 0.0 for ipynb-only runs.
    """
    return [{
        "start":          round(s.start,      3),
        "end":            round(s.end,        3),
        "utterance_id":   s.utterance_id,
        "speaker_id":     s.speaker,
        "speaker_name":   s.speaker,
        "confidence":     round(s.confidence, 3),
        "spk_confidence": round(s.__dict__.get("spk_confidence", 0.0), 3),
        "text":           s.text,
    } for s in asr]


def speaker_summary(asr: List[ASRSegment]) -> Dict[str, Any]:
    """Aggregate per-speaker statistics (exact ipynb)."""
    spk: Dict[str, Dict] = {}
    for s in asr:
        k = s.speaker or "SPEAKER_UNKNOWN"
        spk.setdefault(k, {
            "speaker_name":   k,
            "total_time_sec": 0.0,
            "utterances":     0,
            "word_count":     0,
        })
        spk[k]["total_time_sec"] += max(0.0, s.end - s.start)
        spk[k]["utterances"]     += 1
        spk[k]["word_count"]     += len(s.text.split())
    return {"total_segments": len(asr), "speakers": spk}


def to_markdown(asr: List[ASRSegment], summary: Dict) -> str:
    """Render the diarised transcript as a human-readable Markdown document (exact ipynb)."""
    lines = ["# Meeting Transcript\n", "## Speaker Summary\n"]
    for spk, st in sorted(summary["speakers"].items()):
        display = st.get("speaker_name", spk)
        lines.append(
            f"- **{display}**: {st['utterances']} utterances | "
            f"{st['total_time_sec']:.0f}s | {st['word_count']} words"
        )
    lines.append("\n## Transcript\n")
    prev = None
    for s in asr:
        if s.speaker != prev:
            display = summary["speakers"].get(s.speaker, {}).get("speaker_name", s.speaker)
            lines.append(f"\n**{display}** _{s.start:.1f}s_")
            prev = s.speaker
        lines.append(f"> {s.text}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — run_diarisation()
# Wraps ipynb run_pipeline() with:
#   - ffmpeg WAV conversion
#   - progress_callback for SSE streaming
#   - HTML view generation via view_builder
# ═══════════════════════════════════════════════════════════════════════════════

def run_diarisation(audio_path: str, config: dict = None,
                    progress_callback=None) -> dict:
    """
    Full diarisation pipeline: convert → ASR → embed → cluster → JSON + MD + HTML.

    Config keys  (all match ipynb defaults):
      whisper_model        str    'base.en'
      num_speakers         int    None = auto (silhouette), int = fixed
      use_utterance_embeddings  bool  True
      max_speakers         int    8
      smooth_window        int    3
      min_seg_dur          float  0.4
      pca_variance         float  0.99
      linkage              str    'average'
      metric               str    'cosine'
      beam_size            int    5
      best_of              int    5
      vad_filter           bool   True
      vad_silence_ms       int    500
      condition_on_prev    bool   True
      no_speech_thresh     float  0.6
      log_prob_thresh      float  -1.0
      compression_thresh   float  2.4
      remove_fillers       bool   True
      remove_stutters      bool   True
      remove_repeats       bool   True
      output_dir           str    'outputs/diarisation'

    Returns:
      {
        "json_path":     path to diarization_response.json   (ipynb: step_0.json)
        "summary_path":  path to diarization_summary.json    (ipynb: step_0_summary.json)
        "markdown_path": path to diarization_transcript.md   (ipynb: step_0_transcript.md)
        "html_path":     path to diarization_view.html       (ipynb: step_0_viz.html)
      }
    """
    def emit(pct: int, msg: str):
        log.info("[DIAR] %d%%  %s", pct, msg)
        if progress_callback:
            progress_callback(pct, msg)

    # ── Defaults (exact ipynb values) ─────────────────────────────────────────
    cfg = {
        "whisper_model":            WHISPER_MODEL,
        "num_speakers":             NUM_SPEAKERS,
        "use_utterance_embeddings": USE_UTTERANCE_EMBEDDINGS,
        "max_speakers":             MAX_SPEAKERS,
        "smooth_window":            SMOOTH_WINDOW,
        "min_seg_dur":              MIN_SEG_DUR,
        "pca_variance":             PCA_VARIANCE,
        "linkage":                  LINKAGE,
        "metric":                   METRIC,
        "beam_size":                BEAM_SIZE,
        "best_of":                  BEST_OF,
        "vad_filter":               VAD_FILTER,
        "vad_silence_ms":           VAD_SILENCE_MS,
        "condition_on_prev":        CONDITION_ON_PREV,
        "no_speech_thresh":         NO_SPEECH_THRESH,
        "log_prob_thresh":          LOG_PROB_THRESH,
        "compression_thresh":       COMPRESS_THRESH,
        "remove_fillers":           REMOVE_FILLERS,
        "remove_stutters":          REMOVE_STUTTERS,
        "remove_repeats":           REMOVE_REPEATS,
        "output_dir":               "outputs/diarisation",
    }
    if config:
        cfg.update(config)

    out_dir = Path(cfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)

    log.info("[DIAR] Starting  audio=%s  device=%s  compute=%s  sliding=%s",
             Path(audio_path).name, DEVICE, COMPUTE_TYPE,
             not cfg["use_utterance_embeddings"])

    # ── Step 1: Convert to WAV ─────────────────────────────────────────────
    emit(5, "Converting audio to WAV...")
    wav_path = str(out_dir / "input_audio.wav")
    convert_to_wav(audio_path, wav_path)

    # ── Step 2: ASR ───────────────────────────────────────────────────────
    emit(15, "Loading transcription model...")
    emit(20, "Transcribing speech...")
    asr_segs = transcribe(
        wav_path,
        model_size        = cfg["whisper_model"],
        device            = DEVICE,
        compute_type      = COMPUTE_TYPE,
        beam_size         = cfg["beam_size"],
        best_of           = cfg["best_of"],
        vad_filter        = cfg["vad_filter"],
        vad_silence_ms    = cfg["vad_silence_ms"],
        condition_on_prev = cfg["condition_on_prev"],
        no_speech_thresh  = cfg["no_speech_thresh"],
        log_prob_thresh   = cfg["log_prob_thresh"],
        compression_thresh= cfg["compression_thresh"],
        remove_fillers    = cfg["remove_fillers"],
        remove_stutters   = cfg["remove_stutters"],
        remove_repeats    = cfg["remove_repeats"],
    )
    if not asr_segs:
        raise ValueError("[DIAR] No speech detected. Check your audio file.")
    emit(40, f"Transcription done — {len(asr_segs)} segments")

    # ── Step 3: Embed + Cluster ───────────────────────────────────────────
    emit(50, "Extracting speaker embeddings...")

    if cfg["use_utterance_embeddings"]:
        # Primary path (ipynb USE_UTTERANCE_EMBEDDINGS=True)
        valid_idx, embeddings = extract_embeddings_for_segments(wav_path, asr_segs)
        emit(65, f"Embeddings extracted — {len(valid_idx)} utterances")
        emit(70, "Running speaker clustering...")
        asr_segs = diarize_utterances(
            asr_segs, valid_idx, embeddings,
            num_speakers  = cfg["num_speakers"],
            max_speakers  = cfg["max_speakers"],
            smooth_window = cfg["smooth_window"],
            pca_variance  = cfg["pca_variance"],
        )
    else:
        # Sliding-window path (ipynb USE_UTTERANCE_EMBEDDINGS=False)
        times, embeddings = extract_sliding_embeddings(wav_path)
        emit(65, f"Embeddings extracted — {len(times)} windows")
        emit(70, "Running speaker clustering...")
        spk_segs = cluster_embeddings(
            times, embeddings,
            num_speakers  = cfg["num_speakers"],
            max_speakers  = cfg["max_speakers"],
            smooth_window = cfg["smooth_window"],
            min_seg_dur   = cfg["min_seg_dur"],
            pca_variance  = cfg["pca_variance"],
            linkage       = cfg["linkage"],
            metric        = cfg["metric"],
        )
        # Map window labels to ASR segments
        labels_arr = np.array([int(s.speaker.replace("SPEAKER_", "")) for s in spk_segs
                                if s.speaker.startswith("SPEAKER_")], dtype=int)
        asr_segs = assign_speakers_from_windows(asr_segs, times,
                                                 np.array([int(s.speaker.replace("SPEAKER_",""))
                                                           for s in spk_segs], dtype=int))

    n_spk = len(set(s.speaker for s in asr_segs if s.speaker))
    emit(80, f"Clustering done — {n_spk} speakers detected")

    # ── Step 4: Write outputs (ipynb: seg_path, sum_path, md_path) ────────
    emit(90, "Writing transcription data...")

    segments_data = to_json(asr_segs)
    summ          = speaker_summary(asr_segs)
    md            = to_markdown(asr_segs, summ)

    json_path    = out_dir / "diarization_response.json"
    summary_path = out_dir / "diarization_summary.json"
    md_path      = out_dir / "diarization_transcript.md"

    json_path.write_text(json.dumps(segments_data, indent=2, ensure_ascii=False), encoding="utf-8")
    summary_path.write_text(json.dumps(summ,         indent=2, ensure_ascii=False), encoding="utf-8")
    md_path.write_text(md, encoding="utf-8")

    log.info("[DIAR] diarization_response.json  — %d utterances", len(segments_data))
    log.info("[DIAR] diarization_summary.json   — %d speakers",   len(summ.get("speakers", {})))
    log.info("[DIAR] diarization_transcript.md  — %d chars",      len(md))

    # ── Step 5: HTML timeline view (ipynb: render_html) ───────────────────
    emit(95, "Building HTML timeline view...")
    html_path = None
    try:
        _root = Path(__file__).resolve().parent.parent
        if str(_root) not in sys.path:
            sys.path.insert(0, str(_root))
        from backend.view_builder import build_view_html
        html_out  = str(out_dir / "diarization_view.html")
        build_view_html(segments_data, html_out)
        html_path = html_out
        log.info("[DIAR] diarization_view.html generated (%d bytes)",
                 Path(html_out).stat().st_size)
    except Exception as ex:
        log.warning("[DIAR] HTML view generation failed (non-fatal): %s", ex)

    emit(100, "Diarisation complete ✓")

    return {
        "json_path":     str(json_path),
        "summary_path":  str(summary_path),
        "markdown_path": str(md_path),
        "html_path":     html_path,
    }
