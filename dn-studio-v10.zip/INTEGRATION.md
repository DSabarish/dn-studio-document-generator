# Integration Guide

This file documents the exact changes made to `app.py` during the Doc Studio upgrade from the original BRD pipeline. For reference if you need to re-apply the patch to a fresh copy.

## Changes to app.py

### 1. App title
```python
# From:
app = FastAPI(title="BRD Pipeline", version="3.0.0")
# To:
app = FastAPI(title="Doc Studio", version="4.0.0")
```

### 2. New constants (add after CFG_PATH)
```python
DOCTYPES_PATH      = str(Path(__file__).resolve().parent / "prompts" / "doctypes.json")
STUDIO_UPLOADS_DIR = str(Path(__file__).resolve().parent / "prompts" / "studio_uploads")
```

### 3. New functions added
- `_load_doctypes()` — reads prompts/doctypes.json
- `_save_doctypes()` — writes prompts/doctypes.json  
- `_studio_pipeline_thread()` — runs Steps 0,1,2,5 for non-BRD types

### 4. Modified: /api/run
Extended to accept `{ steps, doc_type }`. Routes `doc_type="brd"` to existing `_pipeline_thread`, all others to `_studio_pipeline_thread`.

### 5. New API routes
- `GET  /api/doctypes`
- `POST /api/doctypes/register`
- `DELETE /api/doctypes/{key}`
- `GET  /api/download/studio/{experiment}/{filename}`

## The BRD pipeline is completely untouched
All original routes, the `_pipeline_thread` function, and all chain scripts are frozen.
