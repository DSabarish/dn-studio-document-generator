#!/usr/bin/env python3
"""
brd_main.py — End-to-end BRD pipeline runner.

Stages
------
0  Audio → MP3 conversion              (scripts/to_mp3.py)
1  Transcribe & identify speakers      (scripts/diarize.py)
2  Analyse transcript structure        (scripts/chain1_schema_decider.py)
3  Write requirements                  (scripts/chain2_brd_response.py)
4  Link requirements to transcript     (scripts/chain3_brd_trace.py)
5  Build Word document                 (generic_docx_runner + artifacts_library/BRD/JS_template.js)
6  Find gaps & risks                   (scripts/chain4_gap_analyser.py)

Usage
-----
  python brd_main.py [--config configuration.yaml] [--steps 0,1,2,3,4,5]
  python brd_main.py --steps 2,3,4,5   # skip audio processing
  python brd_main.py --steps 5         # regenerate docx only
"""
from __future__ import annotations

import argparse
import logging
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts"))

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

ALL_STEPS = [0, 1, 2, 3, 4, 5, 6]

STEP_LABELS = {
    0: "Convert audio to MP3",
    1: "Transcribe & identify speakers",
    2: "Analyse transcript structure",
    3: "Write requirements",
    4: "Link requirements to transcript",
    5: "Build Word document",
    6: "Find gaps & risks",
}


# ── Utility ───────────────────────────────────────────────────────────────────

def _banner(step: int) -> None:
    label = STEP_LABELS[step]
    log.info(f"\n{'='*60}")
    log.info(f"  Step {step}: {label}")
    log.info(f"{'='*60}")


def _run_subprocess(script: str) -> None:
    """Run a helper script as a subprocess, raising on failure."""
    res = subprocess.run(
        [sys.executable, script],
        capture_output=True,
        text=True,
    )
    if res.stdout:
        log.info(res.stdout.rstrip())
    if res.returncode != 0:
        if res.stderr:
            log.error(res.stderr.rstrip())
        raise RuntimeError(f"Script failed: {script}")


# ── Individual step runners ───────────────────────────────────────────────────

def step0_convert(cfg: dict) -> None:
    from to_mp3 import convert
    convert(cfg)


def step1_diarize(cfg: dict) -> None:
    from diarize import run
    run(cfg)


def step2_chain1(cfg: dict) -> None:
    from chain1_schema_decider import run_chain1
    path = run_chain1(cfg)
    log.info(f"   → {path}")


def step3_chain2(cfg: dict) -> None:
    from chain2_brd_response import run_chain2
    path = run_chain2(cfg)
    log.info(f"   → {path}")


def step4_chain3(cfg: dict) -> None:
    from chain3_brd_trace import run_chain3
    path = run_chain3(cfg)
    log.info(f"   → {path}")


def step5_docx(cfg: dict) -> None:
    base_dir    = os.path.dirname(os.path.abspath(__file__))
    exp         = cfg["experiment"]
    trace_path  = cfg["chains"]["chain3_traceability"]["output"]["trace"]
    docx_path   = f"{exp}/output/BRD.docx"
    js_template = os.path.join(base_dir, "artifacts_library", "BRD", "JS_template.js")
    scripts_dir = os.path.join(base_dir, "scripts")

    from generic_docx_runner import run_generic_docx
    run_generic_docx(trace_path, js_template, docx_path, scripts_dir)
    log.info(f"   -> {docx_path}")


def step6_gap(cfg: dict) -> None:
    from chain4_gap_analyser import run_chain4
    path = run_chain4(cfg)
    log.info(f"   → {path}")


STEP_FNS = {
    0: step0_convert,
    1: step1_diarize,
    2: step2_chain1,
    3: step3_chain2,
    4: step4_chain3,
    5: step5_docx,
    6: step6_gap,
}


# ── Main ──────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="End-to-end BRD pipeline runner.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--config",
        default="configuration.yaml",
        help="Path to configuration YAML (default: configuration.yaml)",
    )
    parser.add_argument(
        "--steps",
        default=",".join(str(s) for s in ALL_STEPS),
        help=(
            "Comma-separated list of steps to run "
            f"(default: {','.join(str(s) for s in ALL_STEPS)}). "
            "Available: " + ", ".join(f"{k}={v}" for k, v in STEP_LABELS.items())
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    try:
        steps = [int(s.strip()) for s in args.steps.split(",")]
    except ValueError:
        log.error("--steps must be a comma-separated list of integers, e.g. 0,1,2,3,4,5")
        sys.exit(1)

    invalid = [s for s in steps if s not in ALL_STEPS]
    if invalid:
        log.error(f"Unknown step(s): {invalid}. Valid steps: {ALL_STEPS}")
        sys.exit(1)

    log.info(f"\n🚀 BRD Pipeline — steps: {steps}")
    cfg = resolve_cfg(args.config)
    log.info(f"   Experiment : {cfg['experiment']}")

    total_start = time.time()
    failed_step = None

    for step in sorted(steps):
        _banner(step)
        t0 = time.time()
        try:
            STEP_FNS[step](cfg)
            elapsed = time.time() - t0
            log.info(f"   ✅ Done in {elapsed:.1f}s")
        except Exception as exc:
            log.error(f"   ❌ Step {step} failed: {exc}")
            failed_step = step
            break

    total_elapsed = time.time() - total_start
    log.info(f"\n{'='*60}")
    if failed_step is not None:
        log.error(f"  Pipeline stopped at step {failed_step}. Total: {total_elapsed:.1f}s")
        sys.exit(1)
    else:
        exp = cfg["experiment"]
        log.info(f"  🎉 Pipeline complete in {total_elapsed:.1f}s")
        log.info(f"  Outputs → {exp}/output/")
        log.info(f"{'='*60}\n")


if __name__ == "__main__":
    main()
