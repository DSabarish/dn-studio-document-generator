@echo off
title Doc Studio
color 0A
cd /d "%~dp0"

echo.
echo  ============================================
echo   Doc Studio v4.0 - Starting
echo  ============================================
echo.
echo  Folder: %~dp0
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 goto NO_PYTHON

node --version >nul 2>&1
if %errorlevel% neq 0 goto NO_NODE

ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 echo  [WARN] ffmpeg not in PATH - audio conversion may fail

python -c "import fastapi" >nul 2>&1
if %errorlevel% neq 0 goto INSTALL_DEPS
goto DEPS_OK

:INSTALL_DEPS
echo  Installing Python dependencies...
pip install -r requirements.txt -q
echo  Done.

:DEPS_OK
if exist "scripts\node_modules\docx" goto NODE_OK
echo  Installing docx npm package (one time)...
cd scripts
npm install docx --silent
cd ..
echo  Done.

:NODE_OK
echo  Starting Doc Studio at http://localhost:8000 ...
echo.
start "Doc Studio Server" cmd /k "cd /d "%~dp0" && python app.py"
timeout /t 5 /nobreak >nul

:PING_LOOP
python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/api/ping')" >nul 2>&1
if %errorlevel% neq 0 goto PING_LOOP

echo  Server ready - opening browser...
start "" http://localhost:8000
echo.
echo  ============================================
echo   Doc Studio running at http://localhost:8000
echo   BRD pipeline + MOM + custom doc types
echo   Close the Server window to stop.
echo  ============================================
echo.
pause
goto END

:NO_PYTHON
echo  [ERROR] Python not found. Install Python and try again.
pause
goto END

:NO_NODE
echo  [ERROR] Node.js not found. Install from https://nodejs.org
pause
goto END

:END
