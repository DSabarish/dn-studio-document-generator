# Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────┐
│                   Browser (frontend.html)                │
│  Setup  │  Upload  │  Run Pipeline  │  Outputs  │  More  │
└─────────────────────────┬───────────────────────────────┘
                          │  HTTP REST + Polling
┌─────────────────────────▼───────────────────────────────┐
│                   FastAPI  (app.py)                      │
│                                                          │
│  GET/POST /api/config          experiment + LLM config  │
│  POST     /api/upload          audio file ingestion      │
│  POST     /api/run             start pipeline job        │
│  GET      /api/jobs/{id}       poll status + live logs   │
│  GET      /api/doctypes        list doc types            │
│  POST     /api/doctypes/register  upload new type        │
│  DELETE   /api/doctypes/{key}  remove custom type        │
│  GET      /api/gap             gap report for experiment │
│  GET      /api/diarization     speaker analytics         │
│                                                          │
│  Background Thread — one per pipeline job               │
└──────────────┬──────────────────────┬──────────────────┘
               │                      │
    ┌──────────▼─────────┐  ┌────────▼────────────┐
    │   BRD Pipeline     │  │   Studio Pipeline    │
    │   Steps 0–6        │  │   Steps 0,1,2,5      │
    └────────────────────┘  └─────────────────────┘
               │                      │
    ┌──────────▼──────────────────────▼──────────┐
    │              Shared Infrastructure          │
    │  File System  │  Gemini API  │  Node.js     │
    └─────────────────────────────────────────────┘
```

## Data Flow

```
Audio File (.mp3 / .wav / .m4a / ...)
  │
  ▼ Step 0  (to_mp3.py)
audio.mp3  ──────────────────────────── {experiment}/input/
  │
  ▼ Step 1  (diarize.py — Whisper + Resemblyzer + SpectralClustering)
diarization_result.json ─────────────── {experiment}/input/
  │
  ├── BRD path ──────────────────────────────────────────────
  │   ▼ Step 2  (chain1_schema_decider.py)
  │   brd-schema.json ───────────────── {experiment}/output/
  │   ▼ Step 3  (chain2_brd_response.py)
  │   brd-response.json ─────────────── {experiment}/output/
  │   ▼ Step 4  (chain3_brd_trace.py)
  │   brd-response-trace.json ──────────{experiment}/output/
  │   ▼ Step 5  (generic_docx_runner.py + artifacts_library/BRD/JS_template.js)
  │   BRD.docx ──────────────────────── {experiment}/output/
  │   ▼ Step 6  (chain4_gap_analyser.py)
  │   gap-report.json ───────────────── {experiment}/output/
  │
  └── Studio path (MOM, custom) ─────────────────────────────
      ▼ Step 2  (generic_chain_fill.py)
      {doctype}_output.json ────────── {experiment}/output/
      ▼ Step 5  (generic_docx_runner.py + JS_template.js)
      {DocType}.docx ──────────────── {experiment}/output/
```

## Key Design Decisions

**Polling over SSE** — Colab's HTTP proxy buffers Server-Sent Events. The pipeline runs in a background thread; the frontend polls `/api/jobs/{id}` every second for log lines and status updates.

**Surgical YAML save** — `yaml.dump()` destroys comments and `{experiment}` placeholders. Config saves use regex surgery to rewrite only changed keys.

**API key never exposed** — The server masks the key to `first10chars••••` before responding. The browser only ever sees the masked version.

**Single-file frontend** — The entire UI is one `frontend.html`. No build step, no bundler, works anywhere Python runs.

**Studio plugin contract** — Any doc type only needs two files: a `schema_prompt.json` (leaf-node template the LLM fills) and a `JS_template.js` (Node.js docx generator). The engine handles everything else.
