# Pipeline Steps

## Overview

The pipeline has 7 steps (0–6). Each step is independent — you can run any subset using `--steps`.

```bash
python brd_main.py --steps 0,1,2,3,4,5,6   # full run
python brd_main.py --steps 2,3,4,5          # skip audio (already diarized)
python brd_main.py --steps 6                # re-run gap analysis only
```

---

## Step 0 — Audio → MP3

**Script:** `scripts/to_mp3.py`  
**Input:** Any audio file in `{experiment}/input/`  
**Output:** `.mp3` file in same folder  

Converts WAV, M4A, MP4, OGG, FLAC, AAC to MP3 using `pydub` (which wraps ffmpeg). Skips files already in MP3 format. This normalises the format for the Whisper model.

---

## Step 1 — Diarization

**Script:** `scripts/diarize.py`  
**Input:** `{experiment}/input/*.mp3`  
**Output:** `{experiment}/input/diarization_result.json`

Three-stage process:
1. **Transcription** — Whisper transcribes audio into text segments with timestamps and confidence scores. VAD filter removes silence.
2. **Embedding** — Resemblyzer encodes each segment into a 256-dim speaker embedding vector.
3. **Clustering** — SpectralClustering groups embeddings by speaker. If `num_speakers: null`, the eigengap heuristic on the normalised Laplacian automatically estimates the cluster count.

Output format per segment:
```json
{
  "utterance_id": 0,
  "speaker_name": "SPEAKER_0",
  "start": 1.234,
  "end": 4.567,
  "text": "We need to ship by Q3.",
  "confidence": 0.94
}
```

---

## Step 2 — Schema Decider (Chain 1)

**Script:** `scripts/chain1_schema_decider.py`  
**Input:** `diarization_result.json` + `prompts/brd-schema-decider-prompt.json`  
**Output:** `{experiment}/output/brd-schema.json`  

Sends the full transcript to Gemini and asks it to decide the BRD structure: which functional modules are relevant, which NFR sections apply, what the project domain is. This schema is used in Step 3 to guide the BRD generation.

---

## Step 3 — BRD Generator (Chain 2)

**Script:** `scripts/chain2_brd_response.py`  
**Input:** `brd-schema.json` + `diarization_result.json` + `prompts/brd-system-prompt.json`  
**Output:** `{experiment}/output/brd-response.json`  

The main LLM chain. Generates the full BRD as a structured JSON document following the template in the prompt. Every field that cannot be filled gets a `why_null` code explaining why (`not_mentioned`, `deferred_by_participants`, `not_yet_agreed`, `schema_excluded`, `insufficient_detail`, `not_applicable`).

Uses `response_mime_type: "application/json"` to force valid JSON output from Gemini. Retries up to 3 times with exponential backoff.

---

## Step 4 — Traceability (Chain 3)

**Script:** `scripts/chain3_brd_trace.py`  
**Input:** `brd-response.json` + `diarization_result.json`  
**Output:** `{experiment}/output/brd-response-trace.json`  

Merges diarization data into the BRD. Every BRD node that has a `trace.utterance_id` list gets that resolved to the full diarization entry — so each requirement is linked to the exact utterance where it was said, including speaker, timestamp, and text.

---

## Step 5 — Word Document

**Script:** `generic_docx_runner.py` + `artifacts_library/BRD/JS_template.js`  
**Input:** `brd-response-trace.json`  
**Output:** `{experiment}/output/BRD.docx`  

Parses the BRD JSON, generates a Node.js script on the fly, and runs it with `node` to produce a formatted `.docx` using the `docx` npm library. The script is self-contained — it installs `docx` automatically on first run if not present.

---

## Step 6 — Gap Analyser (Chain 4)

**Script:** `scripts/chain4_gap_analyser.py`  
**Input:** `brd-response-trace.json` + `diarization_result.json`  
**Output:** `{experiment}/output/gap-report.json`  

Sends the completed BRD + transcript to Gemini with a senior BA prompt. Produces:
- **Gaps** — every null/incomplete section with severity (critical/major/minor), action, owner, and deadline
- **Open questions** — unresolved questions from the meeting
- **Uncaptured risks** — risks discussed verbally but missing from Section 3.3
- **Confidence scores** — per-section 0–100 score of how well the transcript supports the content

See [gap_analyser.md](gap_analyser.md) for the full output schema.
