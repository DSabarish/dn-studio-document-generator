# BRD Studio — Technical Documentation

## Overview

BRD Studio converts meeting audio recordings into structured Business Requirements Documents (BRDs) using a 6-step AI pipeline. It runs as a local web application served by FastAPI, with a pure HTML/CSS/JS frontend.

## Documentation Index

| File | Contents |
|------|----------|
| [architecture.md](architecture.md) | System architecture, data flow, component diagram |
| [pipeline.md](pipeline.md) | Each pipeline step explained in detail |
| [diarization.md](diarization.md) | How speaker detection and clustering works |
| [api.md](api.md) | All REST API endpoints |
| [frontend.md](frontend.md) | Frontend architecture and key interactions |
| [gap_analyser.md](gap_analyser.md) | Gap analysis chain and output schema |

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt
apt-get install -y ffmpeg nodejs npm

# Start the web app
python app.py

# OR run from command line
python brd_main.py --steps 0,1,2,3,4,5,6
```

## Project Structure

```
brd-app/
├── app.py                    # FastAPI backend + REST API
├── brd_main.py               # CLI pipeline runner
├── frontend.html             # Single-file web UI
├── configuration.yaml        # User configuration
├── requirements.txt          # Python dependencies
├── prompts/
│   ├── brd-schema-decider-prompt.json   # Chain 1 prompt
│   └── brd-system-prompt.json           # Chain 2 prompt
├── scripts/
│   ├── cfg_utils.py                     # Config loader
│   ├── to_mp3.py                        # Audio converter
│   ├── diarize.py                       # Speaker diarization
│   ├── chain1_schema_decider.py         # LLM Chain 1
│   ├── chain2_brd_response.py           # LLM Chain 2
│   ├── chain3_brd_trace.py              # Traceability merger
│   ├── chain4_gap_analyser.py           # Gap analysis
│   └── generalised_brd_generator.py    # Legacy — superseded by artifacts_library/BRD/JS_template.js
└── docs/                                # This documentation
```
