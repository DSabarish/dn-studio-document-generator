# REST API Reference

Base URL: `http://localhost:8000`

---

## Config

### `GET /api/config`
Returns current project configuration. API key is **masked** — only first 10 characters shown.

```json
{
  "experiment":    "my_project",
  "api_key":       "AIzaSyA5a3••••••••••••••••",
  "api_key_set":   true,
  "num_speakers":  null,
  "whisper_model": "tiny",
  "gemini_model":  "gemini-2.5-flash",
  "outputs": {
    "brd-schema.json":        false,
    "brd-response.json":      false,
    "brd-response-trace.json":false,
    "BRD.docx":               false,
    "gap-report.json":        false
  }
}
```

### `POST /api/config`
Save configuration. Only updates `api_key` if the submitted value is a real key (not the masked display value).

**Body:**
```json
{
  "experiment":    "my_project",
  "api_key":       "AIzaSy...",
  "gemini_model":  "gemini-2.5-flash",
  "whisper_model": "tiny",
  "num_speakers":  null
}
```

### `GET /api/config/yaml`
Returns user-facing config as YAML text (no backend paths, API key masked).

```json
{ "yaml": "experiment: my_project\ndiarization:\n  ..." }
```

---

## Upload

### `POST /api/upload`
Upload an audio file. Send as `multipart/form-data`. Include `x-upload-id` header to enable progress tracking.

**Headers:**
- `x-upload-id: <uid>` — optional, enables `/api/upload/progress/{uid}`

**Response:**
```json
{
  "ok": true,
  "filename": "meeting.mp3",
  "size_mb": 14.2,
  "duration_secs": 1112.4,
  "duration_mins": 18.5,
  "estimated_diarization_mins": 3,
  "is_mp3": true
}
```

### `GET /api/upload/progress/{uid}`
Poll upload progress. Returns 0–100 percentage.

```json
{ "pct": 67, "received": 9437184, "total": 14090240, "done": false }
```

### `GET /api/audio/{experiment}`
Stream the uploaded audio file for the given experiment. Used by the swimlane player.

---

## Pipeline

### `POST /api/run`
Start a pipeline job. Body is a JSON array of step numbers.

**Body:** `[0, 1, 2, 3, 4, 5, 6]`

**Response:** `{ "job_id": "a3f7c2b1" }`

### `GET /api/jobs/{job_id}?since=N`
Poll job status. `since=N` returns only log entries after index N — avoids re-sending the full log on every poll.

**Response:**
```json
{
  "status":       "running",
  "current_step": 1,
  "step_status":  { "0": "done", "1": "running", "2": "pending" },
  "step_timings": { "0": { "start": 1700000000, "end": 1700000003, "elapsed": 3.2 } },
  "logs":         [{ "step": 1, "msg": "🎤 Processing: meeting.mp3", "ts": 1700000004.1 }],
  "log_total":    47,
  "error":        null,
  "diar_analytics": { ... },
  "brd_preview":  { "project": "Customer Portal", "filled": 24, "null": 8 },
  "gap_report":   null,
  "outputs":      {}
}
```

`status` values: `"running"` | `"done"` | `"error"`

---

## Analysis

### `GET /api/diarization`
Returns diarization analytics for the current experiment (speakers, swimlane data, scatter points, stats).

### `GET /api/speakers`
Returns list of detected speaker names.

```json
{ "speakers": ["SPEAKER_0", "SPEAKER_1"] }
```

### `POST /api/speakers/rename`
Rename detected speakers. Updates `diarization_result.json` in place.

**Body:** `{ "mapping": { "SPEAKER_0": "Alice", "SPEAKER_1": "Bob" } }`

---

## Results

### `GET /api/gap`
Returns the gap report for the current experiment.

### `GET /api/download/{experiment}/{filename}`
Download an output file. Valid filenames: `brd-schema.json`, `brd-response.json`, `brd-response-trace.json`, `BRD.docx`, `gap-report.json`.

### `GET /api/experiments`
List all experiment folders and their output file status.

---

## Health

### `GET /api/ping`
Server health check. Returns `{ "ok": true, "ts": 1700000000.0 }`.
