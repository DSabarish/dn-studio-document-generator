# Frontend Architecture

## Overview

The entire UI is a single `frontend.html` file — no build step, no bundler, no npm. It runs in the browser and communicates with the FastAPI backend via HTTP fetch calls and polling.

## Technology Choices

- **DM Sans + DM Mono** — clean, professional typefaces via Google Fonts
- **Canvas API** — swimlane player and scatter plot drawn directly on `<canvas>` elements
- **XHR for upload** — `XMLHttpRequest` used instead of `fetch` specifically to get `upload.onprogress` events (fetch doesn't support this)
- **Polling** — `setInterval` every 1s polls `/api/jobs/{id}?since=N` for pipeline status. No SSE/WebSocket — Colab's proxy buffers those.

## Page Structure

```
.app
├── .sidebar           ← fixed left nav, step pills during run, exp badge
└── .main
    ├── .topbar        ← page title + breadcrumb
    └── .content
        ├── #view-setup       ← experiment name, API key, model config
        ├── #view-upload      ← drag-drop + XHR progress + audio preview
        ├── #view-run         ← step selector + live log panel
        ├── #view-diarization ← speaker stats, swimlane, scatter, transcript
        ├── #view-speakers    ← rename SPEAKER_0 → real names
        ├── #view-outputs     ← download generated files
        ├── #view-gap         ← gap report with filters
        └── #view-experiments ← history of all experiments
```

## Key Interactions

### Upload Flow
1. User drops/selects file
2. XHR fires with `x-upload-id` header
3. `xhr.upload.onprogress` updates the progress bar width
4. On success, `audio-player` src is set for preview

### Pipeline Polling
1. `POST /api/run` with step array → gets `job_id`
2. `setInterval` every 1s calls `GET /api/jobs/{job_id}?since={cursor}`
3. New log lines appended to terminal, step cards updated by status changes
4. When `status === "done"` — interval cleared, outputs refreshed

### Swimlane Player
- Dedicated `<audio id="swim-audio">` element inside the swimlane component
- `timeupdate` event drives both the canvas playhead needle and transcript row highlight
- Canvas click seeks audio via `_swimAudio.currentTime`
- `play()` returns a Promise — rejection caught and toasted (autoplay policy)

### YAML Config Panel
- Clicking the experiment badge in the sidebar bottom slides up a panel
- Fetches `/api/config/yaml` which returns user-friendly YAML (no backend paths, masked key)
- Syntax-highlighted with CSS classes for keys, values, and comments

## State Variables

| Variable | Purpose |
|----------|---------|
| `EXP` | Current experiment name |
| `selected` | Set of step numbers selected to run |
| `_pollTimer` | setInterval handle for pipeline polling |
| `_pollJobId` | Current job ID being polled |
| `_logCursor` | How many log entries already consumed |
| `_lastStates` | Previous step_status snapshot for change detection |
| `_diarData` | Cached diarization analytics |
| `_gapData` | Cached gap report |
| `_swimAudio` | Audio element inside swimlane component |
| `_swimData` | Diarization data bound to swimlane |
| `_swimWrap` | Root element of swimlane component |
| `_txSegs` | Transcript rows registered for audio sync |
| `_yamlOpen` | Whether the YAML config panel is open |

## Security

- API key **never** sent to frontend in full — server masks to `first10••••••`
- `esc()` helper sanitises all user-supplied text before innerHTML insertion
- `saveConfig()` skips updating the key if the submitted value contains bullet chars (the masked display value)
