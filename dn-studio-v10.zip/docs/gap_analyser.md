# Gap Analyser — Chain 4

## Purpose

After the BRD is generated, Chain 4 reads the completed BRD + transcript and produces a structured gap analysis report. It thinks like a senior Business Analyst doing a post-meeting BRD review.

## Inputs

| Input | Path |
|-------|------|
| BRD with traceability | `{experiment}/output/brd-response-trace.json` |
| Original transcript | `{experiment}/input/diarization_result.json` |

## Output Schema

```json
{
  "summary": {
    "total_gaps":          12,
    "critical":            3,
    "major":               6,
    "minor":               3,
    "overall_confidence":  68.5,
    "recommendation":      "The BRD is well-supported in sections 1–3 but..."
  },
  "gaps": [
    {
      "id":            "GAP-001",
      "severity":      "critical",
      "section":       "2.1 In-Scope Functionality",
      "title":         "Payment gateway integration not defined",
      "description":   "The team mentioned payment processing but never agreed on a provider.",
      "why_null_code": "not_yet_agreed",
      "action":        "Schedule a follow-up meeting to decide between Stripe and Razorpay.",
      "owner":         "Product Owner",
      "transcript_refs": [14, 15, 23],
      "deadline":      "Before sign-off"
    }
  ],
  "open_questions": [
    {
      "id":        "Q-001",
      "question":  "Who owns the data migration from the legacy system?",
      "context":   "Mentioned at utterance 47 but deferred.",
      "raised_by": "SPEAKER_1",
      "urgency":   "immediate"
    }
  ],
  "uncaptured_risks": [
    {
      "id":                   "R-001",
      "risk":                 "Third-party API dependency could cause downtime.",
      "evidence":             "Speaker_0 said 'we depend entirely on their uptime'",
      "suggested_mitigation": "Add SLA requirement and fallback mechanism to Section 3.3"
    }
  ],
  "confidence_scores": {
    "1. Introduction":              85,
    "2. Project Scope":             72,
    "6. Functional Requirements":   61,
    "7. Non-Functional Requirements": 45
  }
}
```

## Severity Guide

| Severity | Meaning |
|----------|---------|
| **critical** | Cannot proceed to development. Affects scope, budget, or delivery. |
| **major** | Will cause problems in UAT or delivery if not resolved. |
| **minor** | Nice to have, or can be deferred without risk. |

## why_null Codes

| Code | Meaning |
|------|---------|
| `not_mentioned` | Not discussed in the meeting at all |
| `deferred_by_participants` | Raised but explicitly deferred to a later session |
| `not_yet_agreed` | Discussed but no consensus reached |
| `schema_excluded` | Not applicable to this project type |
| `insufficient_detail` | Mentioned but too vague to document |
| `not_applicable` | Not relevant to this project |

## Confidence Score Interpretation

| Score | Meaning |
|-------|---------|
| 80–100 | Well-supported by multiple utterances |
| 60–79 | Reasonably supported |
| 40–59 | Partially inferred — needs verification |
| 0–39 | Largely inferred, not discussed — high risk |

## LLM Prompt Strategy

The chain uses a focused prompt that instructs Gemini to act as a senior BA. Key elements:
- Pre-populates null sections detected automatically via `extract_null_sections()` before sending to the LLM
- Uses `response_mime_type: "application/json"` to force structured output
- Retries up to 3 times with exponential backoff
- Falls back to a minimal valid report if JSON parsing fails
