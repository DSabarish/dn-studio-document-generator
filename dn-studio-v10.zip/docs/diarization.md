# Diarization — How Speaker Detection Works

## The Three Stages

### Stage 1: Transcription (Whisper)

`faster-whisper` runs the Whisper model on the audio file. VAD (Voice Activity Detection) is enabled to skip silence. Each segment gets:
- `start` / `end` timestamps
- `text` — cleaned (fillers removed, capitalised)  
- `avg_logprob` → converted to a confidence score 0–1

**Model sizes vs quality:**

| Model | Speed (CPU) | Accuracy | Use when |
|-------|-------------|----------|----------|
| `tiny` | ~3× realtime | Basic | Quick test |
| `base` | ~6× realtime | Good | Default |
| `small` | ~15× realtime | Better | Good audio |
| `large-v2` | very slow | Best | GPU only |

### Stage 2: Speaker Embeddings (Resemblyzer)

Each transcribed segment is encoded into a 256-dimensional vector that represents the speaker's voice characteristics. Segments shorter than 0.3 seconds are skipped (too short to embed reliably).

The `VoiceEncoder` from Resemblyzer is a pretrained GE2E model trained to cluster same-speaker audio together in embedding space.

### Stage 3: Clustering (Spectral)

The embeddings are clustered using `SpectralClustering` with a precomputed cosine affinity matrix.

**Auto-detect mode (num_speakers: null):**

The eigengap heuristic is applied to the normalised Laplacian of the affinity matrix:

```python
# Normalised Laplacian
L_sym = I - D^{-1/2} A D^{-1/2}

# Eigenvalues of L_sym
eigvals = sorted(eigenvalues(L_sym))

# Largest gap between consecutive eigenvalues = number of clusters
k = argmax(diff(eigvals[1:])) + 2
```

This is theoretically grounded: the multiplicity of the zero eigenvalue of the Laplacian equals the number of connected components (speakers) in the graph.

**Manual mode (num_speakers: 2):**

Uses exactly `k` clusters. More reliable when you know the number of speakers.

**Post-processing:**

A median filter (window size 3–7, scaled to recording length) smooths the cluster labels to prevent single-segment speaker switches that are usually errors.

## Known Limitations

- Speakers with very similar voices (same gender, similar accent) may be merged
- Overlapping speech assigns one label per segment — the dominant voice wins
- Very short turns (<1 sec) are harder to embed accurately
- Cross-talk / background noise degrades accuracy significantly
- The auto-detect max is capped at 6 speakers

## Improving Accuracy

1. Use `whisper_model: small` or `large-v2` with a GPU
2. Set `num_speakers` manually if you know the count
3. Use clean audio — single room, no echo
4. After diarization, use the Speakers page to rename and correct labels before running the AI chains
