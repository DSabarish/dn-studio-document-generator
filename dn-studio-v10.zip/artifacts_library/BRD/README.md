# BRD — Business Requirements Document

## Purpose
Generates a fully-formatted `BRD.docx` from the pipeline trace JSON
(`brd-response-trace.json`) via `generic_docx_runner.py`.

## Files
| File | Role |
|---|---|
| `JS_template.js` | Node.js docx generator — reads trace JSON, renders all 10 BRD sections |

## Replaces
`scripts/generalised_brd_generator.py` (v6) — that script parsed the JSON in
Python, baked the data into a generated JS string, wrote a temp file, and ran
Node on it. This template eliminates the Python intermediary: Node reads the
JSON directly at runtime, same output, fewer moving parts.

## Input
`brd-response-trace.json` — produced by Step 4 (`chain3_brd_trace.py`).
Structure: nested dict keyed by BRD section (`Header`, `0. Project Details`,
`1. Introduction` … `10. Appendices`), each leaf has `{ value, trace, why_null }`.

## Output
`BRD.docx` — 10-section Word document, identical layout to the legacy generator:
cover page, TOC, document control, introduction, scope, system perspective,
business process, KPIs, functional requirements, NFRs, data governance,
tech stack, appendices, sign-off.

## Registration
BRD is a **built-in** doc type — it is registered automatically in `_load_doctypes()`
and does not appear in `prompts/doctypes.json`. The `js_template` path is set to
this file. The `schema_prompt` remains `prompts/brd-system-prompt.json`.
