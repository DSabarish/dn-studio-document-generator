# QRM — Quality Review Meeting

## Status: 🚧 In Progress — schema ready, JS template needed

## What it will generate
A structured Quality Review Meeting document including:
- Review metadata (product/process, type, reviewers, date)
- Overall quality status and score
- Key metrics reviewed
- Findings: critical / major / minor issues + positives
- Root cause analysis
- Corrective and preventive actions
- Approval decision and conditions

## Files
| File | Status |
|------|--------|
| `schema_prompt.json` | ✅ Ready — 18 fields across 6 sections |
| `JS_template.js` | ❌ TODO — needs to be written |

## Schema sections
```
meta/                  — Review title, date, product, type, reviewers
quality_status/        — Overall status, score, key metrics
findings/              — Critical / major / minor issues, positives
root_cause_analysis/   — Root causes, contributing factors
corrective_actions/    — Immediate actions, preventive actions
decisions/             — Approval decision, conditions, next review date
```
