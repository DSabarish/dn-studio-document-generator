# Artifacts Library

A collection of ready-made schema + JS template pairs for Doc Studio.
Each folder is a self-contained, plug-and-play document type.

## Library Index

| Folder | Doc Type | Full Name | Status |
|--------|----------|-----------|--------|
| `MOM/` | MOM | Minutes of Meeting | ✅ **Complete** — schema + JS template ready |
| `SOP/` | SOP | Standard Operating Procedure | 🚧 Schema ready — JS template needed |
| `QRM/` | QRM | Quality Review Meeting | 🚧 Schema ready — JS template needed |
| `BPIP/` | BPIP | Business Process Improvement Plan | 🚧 Schema ready — JS template needed |

---

## What each folder contains

```
artifacts_library/
└── <TYPE>/
    ├── README.md           ← What the doc type produces, fields, how to register
    ├── schema_prompt.json  ← Leaf-node template (LLM reads this + fills value + trace)
    └── JS_template.js      ← Node.js docx generator (reads filled JSON → writes .docx)
```

---

## How to add a new doc type

### Step 1 — Create the folder
```
artifacts_library/
└── MYTYPE/
    ├── README.md
    ├── schema_prompt.json
    └── JS_template.js
```

### Step 2 — Write `schema_prompt.json`
Every fillable field must be a **leaf node** with EXACTLY these keys:
```json
{
  "title": "Field Name",
  "description": "Instruction to the LLM — what to extract from the transcript",
  "format": "Expected output type (String, Array of strings, Integer, etc.)",
  "value": null,
  "trace": null
}
```
You can nest leaf nodes as deep as you like — the engine walks the full tree.

### Step 3 — Write `JS_template.js`
```js
// Minimal contract:
const fs   = require("fs");
const path = require("path");
const docx = require(path.join(path.dirname(path.resolve(__filename)), "node_modules", "docx"));

const jsonPath   = process.argv[2];   // filled JSON path (absolute)
const outputPath = process.argv[3];   // output .docx path (absolute)

const data = JSON.parse(fs.readFileSync(jsonPath, "utf-8"));

// ... build your Document using the 'docx' package ...

docx.Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync(outputPath, buffer);
  console.log(`SUCCESS: ${outputPath}`);  // ← required
});
```
The `docx` npm package is pre-installed in `scripts/node_modules/`.

### Step 4 — Register in Doc Studio
Either:
- Copy both files to `prompts/studio_uploads/<key>/` and update `prompts/doctypes.json`
- Or use the **Doc Studio → Register New Doc Type** form in the UI

---

## Leaf node trace format
When the LLM finds evidence in the transcript:
```json
{
  "value": "Alice will prepare the report by Friday",
  "trace": {
    "utterance_id": [42],
    "speaker": "Bob",
    "text": "Alice, can you have that ready by Friday?"
  }
}
```
When no evidence exists:
```json
{
  "value": null,
  "trace": null,
  "why_null": "not_mentioned"
}
```
`why_null` codes: `not_mentioned` | `deferred_by_participants` | `insufficient_detail`

---

## Planned additions
- `PAR/` — Project Acceptance Report
- `KT/`  — Knowledge Transfer Document
- `RAR/` — Risk Assessment Report
- `DRR/` — Design Review Record
- `PDD/` — Project Definition Document
