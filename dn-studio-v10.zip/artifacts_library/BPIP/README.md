# BPIP — Business Process Improvement Plan

## Status: 🚧 In Progress — schema ready, JS template needed

## What it will generate
A structured Business Process Improvement Plan document including:
- Initiative metadata (sponsor, lead, target dates)
- Problem statement and current-state pain points
- Business impact of the problem
- Desired state: goals, success metrics, expected benefits
- Improvement plan: proposed changes, methodology, phases
- Risks, dependencies, and change management considerations
- Immediate next actions

## Files
| File | Status |
|------|--------|
| `schema_prompt.json` | ✅ Ready — 20 fields across 6 sections |
| `JS_template.js` | ❌ TODO — needs to be written |

## Schema sections
```
meta/                      — Title, process, sponsor, lead, timeline
problem_statement/         — Current state, pain points, business impact
desired_state/             — Goals, KPIs, expected benefits
improvement_plan/          — Proposed changes, methodology, phases
risks_and_dependencies/    — Risks, dependencies, change management
action_items/              — Next actions with owners and deadlines
```
