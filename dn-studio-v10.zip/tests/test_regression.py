"""
tests/test_regression.py
========================
Regression test suite for DN-Studio — all 10 original fixes + Fix 11.

Each test class maps to a specific fix.  Run with:
    pytest tests/test_regression.py -v

Fix map
-------
Fix  1  chain2_brd_response imports shared helpers from llm_utils
Fix  2  invoke_with_retry — shared retry wrapper with backoff
Fix  3  Atomic write in upload_transcript (os.replace / mkstemp)
Fix  3b Atomic write in rename_speakers
Fix  4  Local numpy RNG — no global random.seed(42) side-effect
Fix  5  Step-number validation before spawning pipeline thread
Fix  6  MOM core fill failure is fatal (raises RuntimeError)
Fix  7  Warning logged when LLM silently drops fields
Fix  8  stop_job only sets _stop_requested flag; thread owns final status
Fix  9  (intentionally skipped — no code change was required)
Fix 10  extract_json logs raw LLM response preview on failure
Fix 11  retryDelay regex corrected — \\d in raw string now matches digits
"""

from __future__ import annotations

import copy
import json
import logging
import os
import re
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Dict
from unittest.mock import MagicMock, patch, call

import pytest

# ── Path setup ────────────────────────────────────────────────────────────────
REPO_ROOT   = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = REPO_ROOT / "scripts"
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(SCRIPTS_DIR))

# ── Minimal config used by app tests ─────────────────────────────────────────
_TEST_TMP  = tempfile.mkdtemp(prefix="dn_regtest_")
_TEST_CFG  = Path(_TEST_TMP) / "configuration.yaml"
_CFG_YAML  = """\
experiment: reg_test_exp

paths:
  upload_dir: uploads
  mp3_dir: "{experiment}/input"
  input_dir: "{experiment}/input"

diarization:
  output_file: "{experiment}/input/diarization_result.json"
  num_speakers: 2
  whisper_model: "tiny"
  language: "en"
  HF_TOKEN:

llm:
  provider: gemini
  model: gemini-2.5-flash
  api_key: "TEST_KEY_NOT_REAL"
  temperature: 0.1
  max_tokens: 32768

prompts:
  schema_decider: prompts/brd-schema-decider-prompt.json
  brd_generator:  prompts/brd-system-prompt.json

chains:
  chain1_schema_decider:
    input:
      transcript: "{experiment}/input/diarization_result.json"
      prompt: prompts/brd-schema-decider-prompt.json
    output:
      schema: "{experiment}/output/brd-schema.json"
  chain2_brd_generator:
    input:
      schema: "{experiment}/output/brd-schema.json"
      transcript: "{experiment}/input/diarization_result.json"
      prompt: prompts/brd-system-prompt.json
    output:
      brd: "{experiment}/output/brd-response.json"
  chain3_traceability:
    input:
      brd: "{experiment}/output/brd-response.json"
      transcript: "{experiment}/input/diarization_result.json"
    output:
      trace: "{experiment}/output/brd-response-trace.json"
  chain4_gap_analyser:
    input:
      brd:        "{experiment}/output/brd-response-trace.json"
      transcript: "{experiment}/input/diarization_result.json"
    output:
      gap_report: "{experiment}/output/gap-report.json"
"""

_TEST_CFG.write_text(_CFG_YAML, encoding="utf-8")

# Patch CFG_PATH before importing app
os.chdir(str(REPO_ROOT))
import app as _app_module  # noqa: E402
_app_module.CFG_PATH = str(_TEST_CFG)

from app import app  # noqa: E402

try:
    from fastapi.testclient import TestClient
    _HAS_TESTCLIENT = True
except ImportError:
    _HAS_TESTCLIENT = False

# ── Shared sample data ────────────────────────────────────────────────────────
SAMPLE_TRANSCRIPT = [
    {
        "utterance_id": 0,
        "speaker_name": "Alice",
        "text": "The deployment target is end of month.",
        "start": 0.0,
        "end": 3.5,
    },
    {
        "utterance_id": 1,
        "speaker_name": "Bob",
        "text": "I will update the API documentation by Friday.",
        "start": 3.6,
        "end": 7.2,
    },
]

SAMPLE_SCHEMA = {
    "_GUIDE": {"_comment": "regression test schema"},
    "meta": {
        "meeting_title": {
            "title": "Meeting Title",
            "description": "The title of this meeting.",
            "format": "String",
            "value": None,
            "trace": None,
        },
        "date": {
            "title": "Meeting Date",
            "description": "Date when meeting took place.",
            "format": "String",
            "value": None,
            "trace": None,
        },
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# FIX 1 — chain2 imports shared helpers from llm_utils
# ══════════════════════════════════════════════════════════════════════════════

class TestFix1SharedImports:
    """chain2_brd_response must use shared llm_utils helpers, not local copies."""

    def test_chain2_imports_llm_utils(self):
        """Confirm chain2 imports load_json, save_json, extract_json from llm_utils."""
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert "from llm_utils import" in src, "chain2 must import from llm_utils"

    def test_chain2_imports_invoke_with_retry(self):
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert "invoke_with_retry" in src, "chain2 must use invoke_with_retry"

    def test_chain2_imports_extract_json(self):
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert "extract_json" in src

    def test_chain2_imports_load_save_json(self):
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert "load_json" in src
        assert "save_json" in src

    def test_chain2_no_local_duplicate_extract_json(self):
        """chain2 must not define its own extract_json function."""
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        # chain2 may define safe_extract_json (its recovery wrapper) but not extract_json itself
        matches = re.findall(r"^def (extract_json)\s*\(", src, re.MULTILINE)
        assert matches == [], f"chain2 defines its own extract_json: {matches}"

    def test_chain2_no_local_duplicate_load_json(self):
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert not re.search(r"^def load_json\s*\(", src, re.MULTILINE)

    def test_chain2_no_local_duplicate_save_json(self):
        src = (SCRIPTS_DIR / "chain2_brd_response.py").read_text(encoding="utf-8")
        assert not re.search(r"^def save_json\s*\(", src, re.MULTILINE)


# ══════════════════════════════════════════════════════════════════════════════
# FIX 2 — invoke_with_retry retry wrapper
# ══════════════════════════════════════════════════════════════════════════════

class TestFix2InvokeWithRetry:
    """invoke_with_retry must retry on failure and back off correctly."""

    def test_invoke_with_retry_exists(self):
        from llm_utils import invoke_with_retry
        assert callable(invoke_with_retry)

    def test_invoke_with_retry_success_first_attempt(self):
        from llm_utils import invoke_with_retry
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"fields": [{"path": "a", "value": "v"}]}
        result = invoke_with_retry(mock_chain, {"x": 1}, required_key="fields", label="test")
        assert result is not None
        assert "fields" in result
        assert mock_chain.invoke.call_count == 1

    def test_invoke_with_retry_retries_on_exception(self):
        from llm_utils import invoke_with_retry, MAX_RETRY_ATTEMPTS
        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = [
            Exception("rate limited"),
            Exception("rate limited"),
            {"fields": [{"value": "ok"}]},
        ]
        with patch("llm_utils.time.sleep"):
            result = invoke_with_retry(mock_chain, {}, required_key="fields", label="t")
        assert result is not None
        assert mock_chain.invoke.call_count == 3

    def test_invoke_with_retry_returns_none_after_all_failures(self):
        from llm_utils import invoke_with_retry, MAX_RETRY_ATTEMPTS
        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = Exception("always fails")
        with patch("llm_utils.time.sleep"):
            result = invoke_with_retry(mock_chain, {}, required_key="fields", label="t")
        assert result is None
        assert mock_chain.invoke.call_count == MAX_RETRY_ATTEMPTS

    def test_invoke_with_retry_returns_none_missing_required_key(self):
        from llm_utils import invoke_with_retry
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = {"wrong_key": []}
        with patch("llm_utils.time.sleep"):
            result = invoke_with_retry(mock_chain, {}, required_key="fields", label="t")
        assert result is None

    def test_invoke_with_retry_sleeps_between_attempts(self):
        from llm_utils import invoke_with_retry
        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = [Exception("fail"), {"fields": []}]
        sleep_calls = []
        with patch("llm_utils.time.sleep", side_effect=lambda s: sleep_calls.append(s)):
            invoke_with_retry(mock_chain, {}, required_key="fields", label="t")
        assert len(sleep_calls) == 1
        assert sleep_calls[0] > 0

    def test_max_retry_attempts_is_3(self):
        from llm_utils import MAX_RETRY_ATTEMPTS
        assert MAX_RETRY_ATTEMPTS == 3


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3 — Atomic write in upload_transcript
# ══════════════════════════════════════════════════════════════════════════════

class TestFix3AtomicWrite:
    """upload_transcript must write via tempfile → os.replace (atomic)."""

    def test_upload_transcript_source_uses_os_replace(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        # Should have both mkstemp and os.replace in the upload_transcript context
        assert "os.replace" in src, "app.py must use os.replace for atomic writes"
        assert "mkstemp" in src, "app.py must use mkstemp for temp file"

    def test_upload_transcript_no_direct_open_write(self):
        """upload_transcript must NOT write directly to destination (non-atomic)."""
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        # Find the upload_transcript function body
        fn_match = re.search(
            r"async def upload_transcript.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL
        )
        assert fn_match, "upload_transcript function not found"
        body = fn_match.group()
        # Must use os.replace
        assert "os.replace" in body
        # Must NOT do open(dest, 'wb') directly to dest as primary write path
        # (it's okay to fdopen a temp fd, but not open(dest, ...) for writing)
        direct_writes = re.findall(r'open\(dest\s*,\s*["\']wb?["\']', body)
        assert not direct_writes, f"Direct write to dest detected: {direct_writes}"

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_upload_transcript_atomic_via_api(self):
        """End-to-end: transcript upload writes atomically."""
        client = TestClient(app, raise_server_exceptions=False)
        data = json.dumps(SAMPLE_TRANSCRIPT).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("diarization_result.json", data, "application/json")},
        )
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_upload_transcript_invalid_json_returns_400(self):
        """Bad JSON must be rejected before any file write."""
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("bad.json", b"NOT JSON!!!", "application/json")},
        )
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_upload_transcript_not_array_returns_400(self):
        client = TestClient(app, raise_server_exceptions=False)
        data = json.dumps({"not": "an array"}).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("t.json", data, "application/json")},
        )
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_upload_transcript_empty_array_returns_400(self):
        client = TestClient(app, raise_server_exceptions=False)
        data = json.dumps([]).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("t.json", data, "application/json")},
        )
        assert r.status_code == 400

    def test_atomic_write_leaves_no_tmp_on_success(self):
        """Verify a direct atomic write leaves no .tmp file behind."""
        with tempfile.TemporaryDirectory() as d:
            dest = os.path.join(d, "output.json")
            content = b'{"ok": true}'
            tmp_fd, tmp_path = tempfile.mkstemp(dir=d, suffix=".tmp")
            try:
                with os.fdopen(tmp_fd, "wb") as fh:
                    fh.write(content)
                os.replace(tmp_path, dest)
            except Exception:
                os.unlink(tmp_path)
                raise
            assert os.path.exists(dest)
            assert not os.path.exists(tmp_path)
            assert open(dest, "rb").read() == content


# ══════════════════════════════════════════════════════════════════════════════
# FIX 3b — Atomic write in rename_speakers
# ══════════════════════════════════════════════════════════════════════════════

class TestFix3bAtomicRename:
    """rename_speakers must also use atomic write."""

    def test_rename_speakers_source_uses_os_replace(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        fn_match = re.search(
            r"def rename_speakers.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL
        )
        assert fn_match, "rename_speakers function not found"
        body = fn_match.group()
        assert "os.replace" in body
        assert "mkstemp" in body

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_rename_speakers_atomic_via_api(self):
        """Plant a transcript, rename speakers, verify result."""
        client = TestClient(app, raise_server_exceptions=False)
        # Plant the transcript
        data = json.dumps(SAMPLE_TRANSCRIPT).encode()
        client.post(
            "/api/upload/transcript",
            files={"file": ("diarization_result.json", data, "application/json")},
        )
        r = client.post(
            "/api/speakers/rename",
            json={"mapping": {"Alice": "Dr. Smith", "Bob": "Mr. Jones"}},
        )
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert body["renamed"] == 2

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_rename_speakers_no_transcript_returns_404(self):
        """rename_speakers with no transcript must return 404."""
        client = TestClient(app, raise_server_exceptions=False)
        from app import load_cfg
        cfg = load_cfg()
        p = Path(cfg["chains"]["chain1_schema_decider"]["input"]["transcript"])
        p.unlink(missing_ok=True)
        r = client.post(
            "/api/speakers/rename",
            json={"mapping": {"Alice": "X"}},
        )
        assert r.status_code == 404


# ══════════════════════════════════════════════════════════════════════════════
# FIX 4 — Local numpy RNG, no global random.seed
# ══════════════════════════════════════════════════════════════════════════════

class TestFix4LocalRng:
    """_build_diar_analytics must use a local numpy RNG, not global random.seed."""

    def test_no_random_seed_call_in_source(self):
        """random.seed(42) must not appear as a live call (only allowed in comments)."""
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        for line in src.splitlines():
            stripped = line.strip()
            if "random.seed" in stripped and not stripped.startswith("#"):
                pytest.fail(f"Live random.seed() call detected: {stripped!r}")

    def test_uses_numpy_default_rng(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        assert "default_rng(42)" in src, "Must use numpy default_rng(42)"

    def test_uses_rng_local_variable(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        assert "_rng.random()" in src, "Must call _rng.random() not random.random()"

    def test_diar_analytics_does_not_mutate_global_random_state(self):
        """Calling _build_diar_analytics should not affect Python's global random state."""
        import random as _random
        from app import _build_diar_analytics
        _random.seed(99)
        state_before = _random.getstate()
        _build_diar_analytics(SAMPLE_TRANSCRIPT)
        state_after = _random.getstate()
        assert state_before == state_after, (
            "_build_diar_analytics mutated global random state"
        )

    def test_diar_analytics_scatter_is_deterministic(self):
        """Same input must always produce the same scatter coordinates."""
        from app import _build_diar_analytics
        r1 = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        r2 = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        assert r1["scatter"] == r2["scatter"], "Scatter points are not deterministic"

    def test_diar_analytics_empty_transcript(self):
        from app import _build_diar_analytics
        result = _build_diar_analytics([])
        assert result["speakers"] == []
        assert result["scatter"] == []
        assert result["total_dur"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# FIX 5 — Step-number validation in /api/run
# ══════════════════════════════════════════════════════════════════════════════

class TestFix5StepValidation:
    """POST /api/run must reject out-of-range step numbers before spawning a thread."""

    def test_step_validation_in_source(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        assert "_VALID_STEPS" in src
        # Must raise HTTP 400 for invalid steps
        assert "HTTPException" in src

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_invalid_step_returns_400(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [99], "doc_type": "brd"})
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_negative_step_returns_400(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [-1], "doc_type": "brd"})
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_mixed_valid_invalid_steps_returns_400(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [0, 1, 100], "doc_type": "brd"})
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_valid_steps_create_job(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [5], "doc_type": "brd"})
        assert r.status_code == 200
        assert "job_id" in r.json()

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_boundary_step_6_valid(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [6], "doc_type": "brd"})
        assert r.status_code == 200

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_boundary_step_7_invalid(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [7], "doc_type": "brd"})
        assert r.status_code == 400


# ══════════════════════════════════════════════════════════════════════════════
# FIX 6 — MOM core fill failure is fatal
# ══════════════════════════════════════════════════════════════════════════════

class TestFix6MomFatalFail:
    """When MOM core fill returns None, _run_mom_passes must raise RuntimeError."""

    def test_mom_core_fail_raises_runtime_error(self):
        """Simulate invoke_with_retry returning None for core fill."""
        from llm_filler import _run_mom_passes
        import copy

        filled = copy.deepcopy(SAMPLE_SCHEMA)
        model  = MagicMock()

        with patch("llm_filler.invoke_with_retry", return_value=None):
            with pytest.raises(RuntimeError, match="MOM core fill failed"):
                _run_mom_passes(model, SAMPLE_TRANSCRIPT, SAMPLE_SCHEMA, filled)

    def test_mom_core_fail_error_message_helpful(self):
        from llm_filler import _run_mom_passes
        import copy

        with patch("llm_filler.invoke_with_retry", return_value=None):
            try:
                _run_mom_passes(MagicMock(), SAMPLE_TRANSCRIPT, SAMPLE_SCHEMA, copy.deepcopy(SAMPLE_SCHEMA))
            except RuntimeError as e:
                assert "retry" in str(e).lower() or "attempt" in str(e).lower(), (
                    "RuntimeError message should mention retry attempts"
                )

    def test_mom_core_success_no_raise(self):
        """If core fill succeeds, _run_mom_passes must NOT raise."""
        from llm_filler import _run_mom_passes
        import copy

        core_result    = {"fields": [{"path": "meta.meeting_title", "value": "Test", "trace": None}]}
        action_result  = {"action_items": []}

        with patch("llm_filler.invoke_with_retry", side_effect=[core_result, action_result]):
            # Should not raise
            _run_mom_passes(MagicMock(), SAMPLE_TRANSCRIPT, SAMPLE_SCHEMA, copy.deepcopy(SAMPLE_SCHEMA))

    def test_run_fill_mom_raises_on_core_fail(self):
        """run_fill(mode='mom') must propagate the RuntimeError to the caller."""
        import copy, json, tempfile as tf
        from llm_filler import run_fill

        with tf.TemporaryDirectory() as tmpdir:
            schema_path = os.path.join(tmpdir, "schema.json")
            output_path = os.path.join(tmpdir, "out.json")
            tx_path     = os.path.join(tmpdir, "tx.json")
            json.dump(SAMPLE_SCHEMA,    open(schema_path, "w"))
            json.dump(SAMPLE_TRANSCRIPT, open(tx_path, "w"))

            cfg = {"llm": {"model": "x", "api_key": "y", "temperature": 0.05, "max_tokens": 1000},
                   "chains": {"chain1_schema_decider": {"input": {"transcript": tx_path}}}}

            with patch("llm_filler.build_model", return_value=MagicMock()):
                with patch("llm_filler.invoke_with_retry", return_value=None):
                    with pytest.raises(RuntimeError):
                        run_fill(cfg, schema_path, output_path, mode="mom")


# ══════════════════════════════════════════════════════════════════════════════
# FIX 7 — Warning logged when LLM drops fields
# ══════════════════════════════════════════════════════════════════════════════

class TestFix7DroppedFieldsWarning:
    """When the LLM returns fewer fields than expected, a warning must be logged."""

    def test_generic_pass_warns_on_dropped_fields(self, caplog):
        from llm_filler import _run_generic_pass
        import copy

        schema = {
            "f1": {"title": "F1", "description": "desc", "value": None},
            "f2": {"title": "F2", "description": "desc", "value": None},
            "f3": {"title": "F3", "description": "desc", "value": None},
        }
        filled = copy.deepcopy(schema)

        # LLM returns only 1 of 3 fields
        partial_result = {"fields": [{"path": "f1", "value": "yes", "trace": None}]}

        with patch("llm_filler.invoke_with_retry", return_value=partial_result):
            with caplog.at_level(logging.WARNING, logger="llm_filler"):
                _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled, "test_doc")

        assert any("dropped" in r.message.lower() for r in caplog.records), (
            "No 'dropped' warning emitted when LLM returned fewer fields"
        )

    def test_mom_core_warns_on_dropped_fields(self, caplog):
        from llm_filler import _run_mom_passes
        import copy

        schema = {
            "f1": {"title": "F1", "description": "d", "value": None},
            "f2": {"title": "F2", "description": "d", "value": None},
        }
        filled = copy.deepcopy(schema)

        core_result   = {"fields": [{"path": "f1", "value": "v", "trace": None}]}
        action_result = {"action_items": []}

        with patch("llm_filler.invoke_with_retry", side_effect=[core_result, action_result]):
            with caplog.at_level(logging.WARNING, logger="llm_filler"):
                _run_mom_passes(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled)

        assert any("dropped" in r.message.lower() for r in caplog.records)

    def test_no_warning_when_all_fields_returned(self, caplog):
        from llm_filler import _run_generic_pass
        import copy

        schema = {"f1": {"title": "F1", "description": "d", "value": None}}
        filled = copy.deepcopy(schema)
        full_result = {"fields": [{"path": "f1", "value": "ok", "trace": None}]}

        with patch("llm_filler.invoke_with_retry", return_value=full_result):
            with caplog.at_level(logging.WARNING, logger="llm_filler"):
                _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled, "test")

        drop_warns = [r for r in caplog.records if "dropped" in r.message.lower()]
        assert drop_warns == [], "Should not warn when all fields are returned"

    def test_warning_contains_counts(self, caplog):
        """The warning must include expected and actual field counts."""
        from llm_filler import _run_generic_pass
        import copy

        schema = {f"f{i}": {"title": f"F{i}", "description": "d", "value": None} for i in range(4)}
        filled = copy.deepcopy(schema)
        partial = {"fields": [{"path": "f0", "value": "v", "trace": None}]}

        with patch("llm_filler.invoke_with_retry", return_value=partial):
            with caplog.at_level(logging.WARNING, logger="llm_filler"):
                _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled, "t")

        warn_msg = next((r.message for r in caplog.records if "dropped" in r.message.lower()), "")
        # Should mention a number (expected or dropped count)
        assert re.search(r"\d+", warn_msg), f"Warning has no numeric count: {warn_msg}"


# ══════════════════════════════════════════════════════════════════════════════
# FIX 8 — stop_job only sets flag; thread owns final status
# ══════════════════════════════════════════════════════════════════════════════

class TestFix8StopJobFlag:
    """POST /api/jobs/{id}/stop must only set _stop_requested, not set status='stopped'."""

    def test_stop_job_source_sets_only_flag(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        fn_match = re.search(r"def stop_job.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL)
        assert fn_match, "stop_job function not found"
        body = fn_match.group()
        assert "_stop_requested" in body, "Must set _stop_requested flag"
        # The endpoint must NOT set job['status'] = 'stopped'
        assert not re.search(r'job\["status"\]\s*=\s*"stopped"', body), (
            "stop_job endpoint must not set status='stopped' — thread owns this"
        )
        assert not re.search(r"job\['status'\]\s*=\s*'stopped'", body), (
            "stop_job endpoint must not set status='stopped'"
        )

    def test_stop_job_response_is_stop_requested(self):
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        fn_match = re.search(r"def stop_job.*?(?=\n@app|\nclass |\Z)", src, re.DOTALL)
        body = fn_match.group()
        assert "stop_requested" in body, "Response should say stop_requested, not stopped"

    def test_pipeline_thread_sets_stopped_on_flag(self):
        """Thread must check _stop_requested and set status='stopped' itself."""
        src = (REPO_ROOT / "app.py").read_text(encoding="utf-8")
        # The pipeline thread must check the flag
        assert "_stop_requested" in src
        # The thread function must set status='stopped'
        fn_match = re.search(r"def _pipeline_thread.*?(?=\ndef [a-z]|\Z)", src, re.DOTALL)
        assert fn_match
        thread_body = fn_match.group()
        assert '"stopped"' in thread_body, "Pipeline thread must set status='stopped'"

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_stop_running_job_returns_ok(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [5], "doc_type": "brd"})
        job_id = r.json()["job_id"]
        time.sleep(0.05)  # let thread start
        stop_r = client.post(f"/api/jobs/{job_id}/stop")
        assert stop_r.status_code == 200
        body = stop_r.json()
        assert body["ok"] is True

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_stop_unknown_job_returns_404(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/jobs/nonexistent_job_xyz/stop")
        assert r.status_code == 404

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_stop_sets_flag_not_status(self):
        """Immediately after stop, the job dict has _stop_requested=True but
        status may still be 'running' (thread hasn't reacted yet)."""
        from app import jobs
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [5], "doc_type": "brd"})
        job_id = r.json()["job_id"]
        time.sleep(0.05)
        client.post(f"/api/jobs/{job_id}/stop")
        if job_id in jobs:
            assert jobs[job_id].get("_stop_requested") is True


# ══════════════════════════════════════════════════════════════════════════════
# FIX 10 — extract_json logs raw LLM response preview on failure
# ══════════════════════════════════════════════════════════════════════════════

class TestFix10ExtractJsonLogging:
    """extract_json must log the raw LLM text preview when parsing fails."""

    def test_extract_json_logs_on_no_opening_brace(self, caplog):
        from llm_utils import extract_json
        with caplog.at_level(logging.DEBUG, logger="llm_utils"):
            result = extract_json("no json here at all")
        assert result is None
        assert any("Raw preview" in r.message or "raw" in r.message.lower()
                   for r in caplog.records), (
            "extract_json should log raw preview when no opening brace found"
        )

    def test_extract_json_logs_on_unmatched_braces(self, caplog):
        from llm_utils import extract_json
        with caplog.at_level(logging.DEBUG, logger="llm_utils"):
            result = extract_json('{"unclosed": "object"')
        assert result is None
        assert any("raw" in r.message.lower() or "preview" in r.message.lower()
                   for r in caplog.records)

    def test_extract_json_logs_on_decode_error(self, caplog):
        from llm_utils import extract_json
        # Syntactically looks like JSON but is actually invalid
        with caplog.at_level(logging.DEBUG, logger="llm_utils"):
            result = extract_json('{"key": invalid_value_no_quotes }')
        # result may or may not be None depending on cleanup; just confirm no crash
        assert True  # extract_json must not raise

    def test_extract_json_success_no_debug_log(self, caplog):
        from llm_utils import extract_json
        with caplog.at_level(logging.DEBUG, logger="llm_utils"):
            result = extract_json('{"key": "value"}')
        assert result == {"key": "value"}
        # On success, no error-level logs should be emitted
        error_logs = [r for r in caplog.records if r.levelno >= logging.WARNING]
        assert error_logs == []

    def test_extract_json_preview_truncated_to_200_chars(self, caplog):
        """Preview must be limited (not dump entire multi-KB response)."""
        from llm_utils import extract_json
        long_garbage = "x" * 5000
        with caplog.at_level(logging.DEBUG, logger="llm_utils"):
            extract_json(long_garbage)
        for r in caplog.records:
            # No single log message should embed the full 5000-char string
            assert len(r.message) < 1000, (
                f"Log message too long — preview not truncated: {len(r.message)} chars"
            )

    # Verify Fix 10 comment is present in source
    def test_fix10_comment_in_source(self):
        src = (SCRIPTS_DIR / "llm_utils.py").read_text(encoding="utf-8")
        assert "Fix 10" in src


# ══════════════════════════════════════════════════════════════════════════════
# FIX 11 — retryDelay regex correctly parses digit sequences
# ══════════════════════════════════════════════════════════════════════════════

class TestFix11RetryDelayRegex:
    """retry_delay must correctly parse retryDelay values from Gemini 429 errors."""

    def test_parses_quoted_integer_delay(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS
        exc = Exception("retryDelay: '5s'")
        assert retry_delay(exc, 1) == 5.0 + RETRY_BUFFER_SECS

    def test_parses_double_quoted_delay(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS
        exc = Exception('retryDelay: "10s"')
        assert retry_delay(exc, 1) == 10.0 + RETRY_BUFFER_SECS

    def test_parses_float_delay(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS
        exc = Exception("retryDelay: '2.5s'")
        assert abs(retry_delay(exc, 1) - (2.5 + RETRY_BUFFER_SECS)) < 0.001

    def test_parses_dict_style_delay(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS
        exc = Exception("{'retryDelay': '30s', 'code': 429}")
        assert retry_delay(exc, 1) == 30.0 + RETRY_BUFFER_SECS

    def test_parses_large_delay(self):
        from llm_utils import retry_delay, RETRY_BUFFER_SECS
        exc = Exception("message: 'Rate limit', retryDelay: '60s'")
        assert retry_delay(exc, 1) == 60.0 + RETRY_BUFFER_SECS

    def test_fallback_when_no_retry_delay(self):
        from llm_utils import retry_delay, BASE_RETRY_BACKOFF_SECS
        exc = Exception("generic server error 500")
        assert retry_delay(exc, 1) == BASE_RETRY_BACKOFF_SECS ** 1
        assert retry_delay(exc, 2) == BASE_RETRY_BACKOFF_SECS ** 2
        assert retry_delay(exc, 3) == BASE_RETRY_BACKOFF_SECS ** 3

    def test_exponential_fallback_values(self):
        from llm_utils import retry_delay
        exc = Exception("no hint")
        # 2^1=2, 2^2=4, 2^3=8
        assert retry_delay(exc, 1) == 2
        assert retry_delay(exc, 2) == 4
        assert retry_delay(exc, 3) == 8

    def test_broken_regex_did_not_match_old_format(self):
        """Prove the old broken regex returned None for the standard format."""
        import re
        broken = r"['\"]retryDelay['\"]:\s*['\"](\\ d+(?:\\.\\ d+)?)s?['\"]"
        test   = "retryDelay: '5s'"
        assert re.search(broken, test) is None, (
            "Old broken pattern must not match — confirms Fix 11 was necessary"
        )

    def test_new_regex_matches_all_standard_formats(self):
        import re
        pattern = r"retryDelay['\"]?\s*[:\s]+['\"]?(\d+(?:\.\d+)?)s?['\"]?"
        cases = [
            ("retryDelay: '5s'",              "5"),
            ('retryDelay: "10s"',             "10"),
            ("{'retryDelay': '5s'}",          "5"),
            ("message: x, retryDelay: '30s'", "30"),
            ('retryDelay: "2.5s"',            "2.5"),
        ]
        for text, expected in cases:
            m = re.search(pattern, text)
            assert m and m.group(1) == expected, f"Pattern failed for {text!r}"


# ══════════════════════════════════════════════════════════════════════════════
# llm_utils core functionality (shared by all fixes)
# ══════════════════════════════════════════════════════════════════════════════

class TestLlmUtilsCore:
    """Core llm_utils helpers used across all pipelines."""

    # extract_json
    def test_extract_json_simple(self):
        from llm_utils import extract_json
        assert extract_json('{"a": 1}') == {"a": 1}

    def test_extract_json_markdown_fences(self):
        from llm_utils import extract_json
        result = extract_json('```json\n{"b": 2}\n```')
        assert result == {"b": 2}

    def test_extract_json_trailing_comma(self):
        from llm_utils import extract_json
        assert extract_json('{"a": 1,}') == {"a": 1}

    def test_extract_json_nested(self):
        from llm_utils import extract_json
        r = extract_json('{"outer": {"inner": [1, 2, 3]}}')
        assert r == {"outer": {"inner": [1, 2, 3]}}

    def test_extract_json_empty_string(self):
        from llm_utils import extract_json
        assert extract_json("") is None

    def test_extract_json_plain_text(self):
        from llm_utils import extract_json
        assert extract_json("no json here") is None

    def test_extract_json_array_not_matched(self):
        """extract_json looks for objects {}, not bare arrays."""
        from llm_utils import extract_json
        assert extract_json("[1, 2, 3]") is None

    # collect_leaves
    def test_collect_leaves_flat(self):
        from llm_utils import collect_leaves
        schema = {
            "f1": {"title": "F1", "description": "d", "value": None},
            "f2": {"title": "F2", "description": "d", "value": None},
        }
        leaves = collect_leaves(schema)
        paths = [p for p, _ in leaves]
        assert "f1" in paths
        assert "f2" in paths

    def test_collect_leaves_nested(self):
        from llm_utils import collect_leaves
        schema = {"meta": {"title": {"title": "T", "description": "D", "value": None}}}
        leaves = collect_leaves(schema)
        assert leaves[0][0] == "meta.title"

    def test_collect_leaves_list(self):
        from llm_utils import collect_leaves
        schema = {"items": [{"name": {"title": "N", "description": "D", "value": None}}]}
        leaves = collect_leaves(schema)
        assert leaves[0][0] == "items[0].name"

    def test_collect_leaves_empty_schema(self):
        from llm_utils import collect_leaves
        assert collect_leaves({}) == []

    # is_leaf
    def test_is_leaf_valid(self):
        from llm_utils import is_leaf
        assert is_leaf({"title": "T", "description": "D", "value": None})

    def test_is_leaf_missing_value_key(self):
        from llm_utils import is_leaf
        assert not is_leaf({"title": "T", "description": "D"})

    def test_is_leaf_not_dict(self):
        from llm_utils import is_leaf
        assert not is_leaf("string")
        assert not is_leaf(42)
        assert not is_leaf(None)

    # write_back
    def test_write_back_flat(self):
        from llm_utils import write_back
        filled = {"f1": {"title": "T", "description": "D", "value": None, "trace": None}}
        write_back(filled, "f1", "hello", {"utterance_id": [0]})
        assert filled["f1"]["value"] == "hello"
        assert filled["f1"]["trace"] == {"utterance_id": [0]}

    def test_write_back_nested(self):
        from llm_utils import write_back
        filled = {"meta": {"title": {"title": "T", "description": "D", "value": None, "trace": None}}}
        write_back(filled, "meta.title", "My Meeting", None)
        assert filled["meta"]["title"]["value"] == "My Meeting"

    def test_write_back_why_null(self):
        from llm_utils import write_back
        filled = {"f1": {"title": "T", "description": "D", "value": None, "trace": None}}
        write_back(filled, "f1", None, None, why_null="not_mentioned")
        assert filled["f1"]["why_null"] == "not_mentioned"

    # save_json / load_json
    def test_save_load_json_roundtrip(self, tmp_path):
        from llm_utils import save_json, load_json
        data = {"key": "value", "nums": [1, 2, 3]}
        path = str(tmp_path / "test.json")
        save_json(data, path)
        loaded = load_json(path)
        assert loaded == data

    def test_save_json_creates_parent_dirs(self, tmp_path):
        from llm_utils import save_json
        nested = str(tmp_path / "a" / "b" / "c" / "out.json")
        save_json({"x": 1}, nested)
        assert os.path.exists(nested)

    # to_str
    def test_to_str_dict(self):
        from llm_utils import to_str
        result = to_str({"a": 1})
        parsed = json.loads(result)
        assert parsed == {"a": 1}

    def test_to_str_scalar(self):
        from llm_utils import to_str
        assert to_str(42) == "42"
        assert to_str("hello") == "hello"


# ══════════════════════════════════════════════════════════════════════════════
# Edge case / integration tests
# ══════════════════════════════════════════════════════════════════════════════

class TestEdgeCases:
    """Edge cases: empty transcripts, invalid schemas, concurrent safety."""

    def test_collect_leaves_skips_non_leaf_dicts(self):
        from llm_utils import collect_leaves
        # A dict without title/description/value should not be treated as a leaf
        schema = {"group": {"nested": {"title": "T", "description": "D", "value": None}}}
        leaves = collect_leaves(schema)
        assert len(leaves) == 1
        assert leaves[0][0] == "group.nested"

    def test_llm_filler_rejects_unsupported_mode(self, tmp_path):
        """run_fill must raise ValueError for unknown modes immediately."""
        from llm_filler import run_fill
        cfg = {"llm": {"model": "x", "api_key": "y", "temperature": 0.1, "max_tokens": 1000},
               "chains": {"chain1_schema_decider": {"input": {"transcript": "/tmp/tx.json"}}}}
        with pytest.raises(ValueError, match="unsupported mode"):
            run_fill(cfg, "schema.json", "out.json", mode="invalid_mode")

    def test_generic_fill_raises_on_all_retry_failures(self, tmp_path):
        """_run_generic_pass raises RuntimeError if invoke_with_retry returns None."""
        from llm_filler import _run_generic_pass
        import copy
        schema = {"f1": {"title": "F1", "description": "d", "value": None}}
        with patch("llm_filler.invoke_with_retry", return_value=None):
            with pytest.raises(RuntimeError):
                _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, copy.deepcopy(schema), "test")

    def test_extract_json_handles_escape_sequences(self):
        from llm_utils import extract_json
        r = extract_json('{"msg": "line1\\nline2"}')
        assert r is not None
        assert "msg" in r

    def test_extract_json_text_before_json(self):
        from llm_utils import extract_json
        r = extract_json('Sure, here is the JSON: {"answer": 42}')
        assert r == {"answer": 42}

    def test_collect_leaves_preserves_leaf_content(self):
        from llm_utils import collect_leaves
        schema = {"f": {"title": "T", "description": "D", "value": "existing", "format": "String"}}
        leaves = collect_leaves(schema)
        assert leaves[0][1]["value"] == "existing"
        assert leaves[0][1]["format"] == "String"

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_concurrent_playground_jobs(self):
        """Multiple concurrent playground run requests must each get a unique job_id."""
        client  = TestClient(app, raise_server_exceptions=False)
        payload = {
            "schema_data":  SAMPLE_SCHEMA,
            "js_template":  "// test",
            "transcript":   SAMPLE_TRANSCRIPT,
        }
        results = []

        def run_one():
            r = client.post("/api/playground/run", json=payload)
            if r.status_code == 200:
                results.append(r.json()["job_id"])

        threads = [threading.Thread(target=run_one) for _ in range(4)]
        for t in threads: t.start()
        for t in threads: t.join()

        assert len(results) == 4
        assert len(set(results)) == 4, "All job IDs must be unique"

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_upload_start_negative_size_rejected(self):
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/upload/start?filename=test.mp3&size=-1")
        assert r.status_code == 400

    @pytest.mark.skipif(not _HAS_TESTCLIENT, reason="fastapi[testclient] not installed")
    def test_run_empty_steps_list_creates_job(self):
        """An empty steps list is valid — it creates a done job immediately."""
        client = TestClient(app, raise_server_exceptions=False)
        r = client.post("/api/run", json={"steps": [], "doc_type": "brd"})
        assert r.status_code == 200

    def test_mom_action_items_empty_on_action_fail(self):
        """If action items extraction fails, items.value should be [] not crash."""
        from llm_filler import _run_mom_passes
        import copy

        schema = {
            "meta": {"title": {"title": "T", "description": "d", "value": None}},
            "action_items": {"items": {"title": "AI", "description": "d", "value": None}},
        }
        filled = copy.deepcopy(schema)

        core_result = {"fields": [{"path": "meta.title", "value": "v", "trace": None}]}
        # Action items returns None (failure)
        with patch("llm_filler.invoke_with_retry", side_effect=[core_result, None]):
            _run_mom_passes(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled)

        assert filled["action_items"]["items"]["value"] == []


# ══════════════════════════════════════════════════════════════════════════════
# Output formatting — structural preservation checks
# ══════════════════════════════════════════════════════════════════════════════

class TestOutputFormatting:
    """Verify output structures are preserved after fixes."""

    def test_generic_fill_output_preserves_schema_structure(self, tmp_path):
        """Filled schema must have same top-level keys as input schema."""
        from llm_filler import _run_generic_pass
        import copy

        schema = {
            "meta": {
                "title": {"title": "T", "description": "d", "value": None},
            }
        }
        filled = copy.deepcopy(schema)
        result = {"fields": [{"path": "meta.title", "value": "Test Meeting", "trace": None}]}

        with patch("llm_filler.invoke_with_retry", return_value=result):
            _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled, "test")

        assert "meta" in filled
        assert filled["meta"]["title"]["value"] == "Test Meeting"

    def test_write_back_does_not_add_spurious_keys(self):
        """write_back must not add keys not present in the leaf."""
        from llm_utils import write_back
        leaf = {"title": "T", "description": "D", "value": None, "trace": None}
        filled = {"f1": leaf.copy()}
        write_back(filled, "f1", "val", "trace_obj")
        allowed = {"title", "description", "value", "trace", "why_null", "format"}
        extra = set(filled["f1"].keys()) - allowed
        assert not extra, f"write_back added unexpected keys: {extra}"

    def test_apply_action_items_normalises_fields(self):
        """_apply_action_items must produce action items with action/owner/deadline."""
        from llm_filler import _apply_action_items
        import copy

        filled = {
            "action_items": {"items": {"title": "AI", "description": "d", "value": None, "trace": None}},
            "next_steps":   {"follow_up_required_from": {"title": "FU", "description": "d", "value": None}},
        }
        action_result = {
            "action_items": [
                {"action": "Update docs", "owner": "Bob", "deadline": "Friday",
                 "utterance_ids": [1], "speaker": "Alice", "quote": "Bob will update docs"},
            ]
        }
        count = _apply_action_items(filled, action_result)
        assert count == 1
        items = filled["action_items"]["items"]["value"]
        assert len(items) == 1
        assert items[0]["action"] == "Update docs"
        assert items[0]["owner"] == "Bob"
        assert items[0]["deadline"] == "Friday"

    def test_save_json_produces_valid_json(self, tmp_path):
        from llm_utils import save_json, load_json
        data = {
            "meta": {"title": {"value": "Test", "trace": None}},
            "items": [{"action": "do something", "owner": "Alice"}],
        }
        path = str(tmp_path / "output.json")
        save_json(data, path)
        reloaded = load_json(path)
        assert reloaded == data

    def test_filled_schema_retains_non_leaf_structure(self):
        """Sections, headers, guides in schema must be untouched by fill."""
        from llm_filler import _run_generic_pass
        import copy

        schema = {
            "_GUIDE": {"_comment": "do not modify"},
            "section": {
                "field": {"title": "F", "description": "d", "value": None},
            }
        }
        filled = copy.deepcopy(schema)
        result = {"fields": [{"path": "section.field", "value": "v", "trace": None}]}

        with patch("llm_filler.invoke_with_retry", return_value=result):
            _run_generic_pass(MagicMock(), SAMPLE_TRANSCRIPT, schema, filled, "t")

        assert filled["_GUIDE"]["_comment"] == "do not modify"
