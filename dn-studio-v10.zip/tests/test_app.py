"""
tests/test_app.py
=================
Full pytest suite for DN-Studio app.py

Coverage:
  - GET  /api/ping
  - GET  /api/config
  - POST /api/config
  - GET  /api/config/yaml
  - GET  /api/experiments
  - GET  /api/doctypes
  - POST /api/doctypes/register
  - DELETE /api/doctypes/{key}
  - POST /api/upload/start
  - POST /api/upload/transcript
  - GET  /api/speakers
  - POST /api/speakers/rename
  - GET  /api/diarization
  - GET  /api/gap
  - GET  /api/viewer/data
  - POST /api/run  (job creation only, not execution)
  - GET  /api/jobs/{job_id}
  - GET  /api/static/{filepath}
  - POST /api/save-js-template
  - POST /api/playground/run
  - GET  /api/playground/result/{job_id}
  - GET  /
  - Error / edge-case paths
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

# ── Make sure the repo root is importable ────────────────────────────────────
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "scripts"))

# ── Write a minimal config so the app can boot without a real config.yaml ───
_TEST_DIR = tempfile.mkdtemp(prefix="dn_studio_test_")
_TEST_CFG  = Path(_TEST_DIR) / "configuration.yaml"
_TEST_CFG.write_text(
    """
experiment: test_exp

paths:
  upload_dir: uploads
  mp3_dir: "{experiment}/input"
  input_dir: "{experiment}/input"

diarization:
  output_file: "{experiment}/input/diarization_result.json"
  num_speakers: 2
  whisper_model: "tiny"
  language: "en"
  HF_TOKEN:

llm:
  provider: gemini
  model: gemini-2.5-flash
  api_key: "TEST_KEY_NOT_REAL"
  temperature: 0.1
  max_tokens: 32768

prompts:
  schema_decider: prompts/brd-schema-decider-prompt.json
  brd_generator:  prompts/brd-system-prompt.json

chains:
  chain1_schema_decider:
    input:
      transcript: "{experiment}/input/diarization_result.json"
      prompt: prompts/brd-schema-decider-prompt.json
    output:
      schema: "{experiment}/output/brd-schema.json"
  chain2_brd_generator:
    input:
      schema: "{experiment}/output/brd-schema.json"
      transcript: "{experiment}/input/diarization_result.json"
      prompt: prompts/brd-system-prompt.json
    output:
      brd: "{experiment}/output/brd-response.json"
  chain3_traceability:
    input:
      brd: "{experiment}/output/brd-response.json"
      transcript: "{experiment}/input/diarization_result.json"
    output:
      trace: "{experiment}/output/brd-response-trace.json"
  chain4_gap_analyser:
    input:
      brd:        "{experiment}/output/brd-response-trace.json"
      transcript: "{experiment}/input/diarization_result.json"
    output:
      gap_report: "{experiment}/output/gap-report.json"
""",
    encoding="utf-8",
)

# Patch CFG_PATH before importing app
os.chdir(str(REPO_ROOT))
import app as _app_module  # noqa: E402

_app_module.CFG_PATH = str(_TEST_CFG)

from app import app  # noqa: E402

# ── Sample data ───────────────────────────────────────────────────────────────
SAMPLE_TRANSCRIPT = [
    {
        "utterance_id": 1,
        "speaker_name": "SPEAKER_0",
        "text": "Good morning. Today we are reviewing the retention dashboard.",
        "start": 0.0,
        "end": 4.2,
    },
    {
        "utterance_id": 2,
        "speaker_name": "SPEAKER_1",
        "text": "Agreed. The Q-way deployment target is end of month.",
        "start": 4.3,
        "end": 8.1,
    },
]

SAMPLE_SCHEMA = {
    "_GUIDE": {"_comment": "test schema"},
    "meta": {
        "meeting_title": {
            "title": "Meeting Title",
            "description": "Extract the title.",
            "format": "String",
            "value": None,
            "trace": None,
        }
    },
}


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def client():
    """TestClient with the patched config."""
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


@pytest.fixture(autouse=True)
def clean_doctypes():
    """Reset doctypes.json to only BRD builtin between tests."""
    from app import DOCTYPES_PATH, _save_doctypes, STUDIO_UPLOADS_DIR  # noqa: PLC0415
    os.makedirs(STUDIO_UPLOADS_DIR, exist_ok=True)
    builtin = {
        "brd": {
            "key": "brd",
            "name": "Business Requirements Document",
            "label": "BRD",
            "builtin": True,
            "schema_prompt": "prompts/brd-system-prompt.json",
            "js_template": None,
            "output_filename": "BRD.docx",
            "step_labels": {
                "2": "Schema Decider",
                "3": "BRD Generator",
                "4": "Traceability",
                "5": "Word Document",
                "6": "Gap Analyser",
            },
        }
    }
    _save_doctypes(builtin)
    yield
    _save_doctypes(builtin)


@pytest.fixture()
def transcript_file(tmp_path):
    """Write sample transcript JSON to a temp file, returns Path."""
    p = tmp_path / "diarization_result.json"
    p.write_text(json.dumps(SAMPLE_TRANSCRIPT), encoding="utf-8")
    return p


@pytest.fixture()
def seeded_transcript(transcript_file):
    """Plant transcript in the experiment input directory."""
    from app import load_cfg  # noqa: PLC0415
    cfg = load_cfg()
    exp = cfg["experiment"]
    dest = Path(f"{exp}/input/diarization_result.json")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(str(transcript_file), str(dest))
    yield dest
    dest.unlink(missing_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 1: Health & Config
# ══════════════════════════════════════════════════════════════════════════════

class TestPing:
    def test_ping_returns_ok(self, client):
        r = client.get("/api/ping")
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert "ts" in body

    def test_ping_ts_is_float(self, client):
        r = client.get("/api/ping")
        assert isinstance(r.json()["ts"], float)


class TestConfig:
    def test_get_config_returns_200(self, client):
        r = client.get("/api/config")
        assert r.status_code == 200

    def test_get_config_has_required_keys(self, client):
        body = client.get("/api/config").json()
        for key in ("experiment", "api_key", "api_key_set",
                    "num_speakers", "whisper_model", "gemini_model", "outputs"):
            assert key in body, f"Missing key: {key}"

    def test_get_config_experiment_is_string(self, client):
        body = client.get("/api/config").json()
        assert isinstance(body["experiment"], str)

    def test_post_config_updates_experiment(self, client):
        r = client.post("/api/config", json={
            "experiment": "test_update",
            "api_key":    "",
            "num_speakers": 2,
            "whisper_model": "tiny",
            "gemini_model": "gemini-2.5-flash",
        })
        assert r.status_code == 200
        assert r.json()["ok"] is True
        # verify it stuck
        body = client.get("/api/config").json()
        assert body["experiment"] == "test_update"
        # restore
        client.post("/api/config", json={
            "experiment": "test_exp", "api_key": "",
            "num_speakers": 2, "whisper_model": "tiny",
            "gemini_model": "gemini-2.5-flash",
        })

    def test_post_config_masked_key_not_saved(self, client):
        """A key that ends in many bullets should not overwrite the real key."""
        r = client.post("/api/config", json={
            "experiment": "test_exp",
            "api_key": "AIza123456••••••••••",
            "num_speakers": 2,
            "whisper_model": "tiny",
            "gemini_model": "gemini-2.5-flash",
        })
        assert r.status_code == 200

    def test_get_config_yaml_returns_yaml_text(self, client):
        r = client.get("/api/config/yaml")
        assert r.status_code == 200
        body = r.json()
        assert "yaml" in body
        assert isinstance(body["yaml"], str)
        assert "experiment" in body["yaml"]
        # API key must be masked
        assert "TEST_KEY_NOT_REAL" not in body["yaml"]


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 2: Experiments
# ══════════════════════════════════════════════════════════════════════════════

class TestExperiments:
    def test_list_experiments_returns_list(self, client):
        r = client.get("/api/experiments")
        assert r.status_code == 200
        body = r.json()
        assert "experiments" in body
        assert isinstance(body["experiments"], list)

    def test_experiment_shape(self, client):
        """Each entry must have name, outputs, has_audio."""
        r = client.get("/api/experiments")
        for exp in r.json()["experiments"]:
            assert "name" in exp
            assert "outputs" in exp
            assert "has_audio" in exp


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 3: Doc Types (registry)
# ══════════════════════════════════════════════════════════════════════════════

class TestDocTypes:
    def test_list_doctypes_has_brd(self, client):
        r = client.get("/api/doctypes")
        assert r.status_code == 200
        keys = [dt["key"] for dt in r.json()["doctypes"]]
        assert "brd" in keys

    def test_register_new_doctype(self, client, tmp_path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_test.js"
        js_file.write_bytes(b"// test template\n")

        r = client.post(
            "/api/doctypes/register",
            data={"key": "test_dt", "name": "Test DocType", "label": "TEST"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_test.js",  js_file.read_bytes(),  "text/javascript"),
            },
        )
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert body["key"] == "test_dt"

    def test_register_then_list_contains_new(self, client, tmp_path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_x.js"
        js_file.write_bytes(b"// x\n")
        client.post(
            "/api/doctypes/register",
            data={"key": "reglist_dt", "name": "RegList", "label": "RL"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_x.js",    js_file.read_bytes(),  "text/javascript"),
            },
        )
        keys = [dt["key"] for dt in client.get("/api/doctypes").json()["doctypes"]]
        assert "reglist_dt" in keys

    def test_register_invalid_key_rejected(self, client, tmp_path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_bad.js"
        js_file.write_bytes(b"//\n")
        r = client.post(
            "/api/doctypes/register",
            data={"key": "INVALID KEY!", "name": "Bad", "label": "BAD"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_bad.js",   js_file.read_bytes(),  "text/javascript"),
            },
        )
        assert r.status_code == 400

    def test_register_invalid_json_schema_rejected(self, client, tmp_path):
        js_file = tmp_path / "JS_bad2.js"
        js_file.write_bytes(b"//\n")
        r = client.post(
            "/api/doctypes/register",
            data={"key": "badjson", "name": "Bad JSON", "label": "BJ"},
            files={
                "schema_prompt": ("schema.json", b"NOT VALID JSON!!!", "application/json"),
                "js_template":   ("JS_bad2.js",  js_file.read_bytes(), "text/javascript"),
            },
        )
        assert r.status_code == 400

    def test_delete_custom_doctype(self, client, tmp_path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_del.js"
        js_file.write_bytes(b"//\n")
        client.post(
            "/api/doctypes/register",
            data={"key": "del_dt", "name": "Delete Me", "label": "DEL"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_del.js",  js_file.read_bytes(),  "text/javascript"),
            },
        )
        r = client.delete("/api/doctypes/del_dt")
        assert r.status_code == 200
        assert r.json()["deleted"] == "del_dt"

    def test_delete_builtin_doctype_rejected(self, client):
        r = client.delete("/api/doctypes/brd")
        assert r.status_code == 400

    def test_delete_nonexistent_doctype_404(self, client):
        r = client.delete("/api/doctypes/does_not_exist_xyz")
        assert r.status_code == 404

    def test_cannot_overwrite_builtin(self, client, tmp_path):
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_o.js"
        js_file.write_bytes(b"//\n")
        r = client.post(
            "/api/doctypes/register",
            data={"key": "brd", "name": "Override BRD", "label": "BRD"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_o.js",     js_file.read_bytes(),  "text/javascript"),
            },
        )
        assert r.status_code == 400


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 4: Upload
# ══════════════════════════════════════════════════════════════════════════════

class TestUpload:
    def test_upload_start_returns_upload_id(self, client):
        r = client.post("/api/upload/start?filename=test.mp3&size=1000")
        assert r.status_code == 200
        assert "upload_id" in r.json()

    def test_upload_start_stores_progress(self, client):
        r = client.post("/api/upload/start?filename=myfile.mp3&size=5000")
        uid = r.json()["upload_id"]
        prog = client.get(f"/api/upload/progress/{uid}")
        assert prog.status_code == 200
        body = prog.json()
        assert body["total"] == 5000
        assert body["filename"] == "myfile.mp3"

    def test_upload_progress_unknown_id_404(self, client):
        r = client.get("/api/upload/progress/nonexistent123")
        assert r.status_code == 404

    def test_upload_transcript_valid(self, client):
        data = json.dumps(SAMPLE_TRANSCRIPT).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("diarization_result.json", data, "application/json")},
        )
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert body["utterances"] == 2
        assert "SPEAKER_0" in body["speakers"]
        assert "SPEAKER_1" in body["speakers"]

    def test_upload_transcript_wrong_extension_rejected(self, client):
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("transcript.txt", b"not json", "text/plain")},
        )
        assert r.status_code == 400

    def test_upload_transcript_not_array_rejected(self, client):
        data = json.dumps({"not": "an array"}).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("transcript.json", data, "application/json")},
        )
        assert r.status_code == 400

    def test_upload_transcript_missing_fields_rejected(self, client):
        data = json.dumps([{"bad": "data", "no_utterance_id": True}]).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("transcript.json", data, "application/json")},
        )
        assert r.status_code == 400

    def test_upload_transcript_strips_comment_objects(self, client):
        """Objects without utterance_id should be stripped, not cause failure."""
        mixed = [
            {"_comment": "this is a comment"},
            {
                "utterance_id": 1,
                "speaker_name": "SPEAKER_0",
                "text": "Hello",
                "start": 0.0,
                "end": 1.0,
            },
        ]
        data = json.dumps(mixed).encode()
        r = client.post(
            "/api/upload/transcript",
            files={"file": ("transcript.json", data, "application/json")},
        )
        assert r.status_code == 200
        assert r.json()["utterances"] == 1


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 5: Speakers
# ══════════════════════════════════════════════════════════════════════════════

class TestSpeakers:
    def test_get_speakers_no_transcript_returns_empty(self, client):
        r = client.get("/api/speakers")
        assert r.status_code == 200
        assert "speakers" in r.json()
        assert isinstance(r.json()["speakers"], list)

    def test_get_speakers_with_transcript(self, client, seeded_transcript):
        r = client.get("/api/speakers")
        assert r.status_code == 200
        spks = r.json()["speakers"]
        assert "SPEAKER_0" in spks
        assert "SPEAKER_1" in spks

    def test_rename_speakers(self, client, seeded_transcript):
        r = client.post(
            "/api/speakers/rename",
            json={"mapping": {"SPEAKER_0": "Alice", "SPEAKER_1": "Bob"}},
        )
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert body["renamed"] == 2
        # Verify rename stuck
        spks = client.get("/api/speakers").json()["speakers"]
        assert "Alice" in spks
        assert "Bob" in spks

    def test_rename_speakers_no_transcript_404(self, client):
        # Remove transcript first
        from app import load_cfg  # noqa: PLC0415
        cfg = load_cfg()
        p = Path(cfg["chains"]["chain1_schema_decider"]["input"]["transcript"])
        p.unlink(missing_ok=True)
        r = client.post(
            "/api/speakers/rename",
            json={"mapping": {"SPEAKER_0": "Alice"}},
        )
        assert r.status_code == 404


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 6: Diarization analytics
# ══════════════════════════════════════════════════════════════════════════════

class TestDiarization:
    def test_diarization_no_transcript_returns_not_ok(self, client):
        from app import load_cfg  # noqa: PLC0415
        cfg = load_cfg()
        p = Path(cfg["chains"]["chain1_schema_decider"]["input"]["transcript"])
        p.unlink(missing_ok=True)
        r = client.get("/api/diarization")
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_diarization_with_transcript(self, client, seeded_transcript):
        r = client.get("/api/diarization")
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        analytics = body["analytics"]
        assert "speakers" in analytics
        assert "swimlanes" in analytics
        assert "scatter" in analytics
        assert "stats" in analytics
        assert "SPEAKER_0" in analytics["speakers"]

    def test_diarization_analytics_speaker_stats(self, client, seeded_transcript):
        r = client.get("/api/diarization")
        stats = r.json()["analytics"]["stats"]
        for spk in ("SPEAKER_0", "SPEAKER_1"):
            assert spk in stats
            assert "time" in stats[spk]
            assert "turns" in stats[spk]
            assert "words" in stats[spk]


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 7: Gap report
# ══════════════════════════════════════════════════════════════════════════════

class TestGapReport:
    def test_gap_no_file_returns_not_ok(self, client):
        r = client.get("/api/gap")
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_gap_with_file(self, client, tmp_path):
        """Seed a fake gap report and verify it's returned."""
        from app import load_cfg  # noqa: PLC0415
        cfg = load_cfg()
        gap_path = Path(
            cfg["chains"]["chain4_gap_analyser"]["output"]["gap_report"]
        )
        gap_path.parent.mkdir(parents=True, exist_ok=True)
        gap_data = {
            "summary": {
                "total_gaps": 2,
                "critical": 1,
                "major": 1,
                "minor": 0,
                "overall_confidence": 0.8,
                "recommendation": "Review blockers.",
            },
            "gaps": [],
            "open_questions": [],
            "uncaptured_risks": [],
            "confidence_scores": {},
        }
        gap_path.write_text(json.dumps(gap_data), encoding="utf-8")
        r = client.get("/api/gap")
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert "report" in body
        gap_path.unlink(missing_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 8: Viewer data
# ══════════════════════════════════════════════════════════════════════════════

class TestViewerData:
    def test_viewer_data_no_output_returns_not_ok(self, client):
        r = client.get("/api/viewer/data")
        assert r.status_code == 200
        assert r.json()["ok"] is False

    def test_viewer_data_with_mom_output(self, client):
        from app import load_cfg  # noqa: PLC0415
        cfg = load_cfg()
        exp = cfg["experiment"]
        out_path = Path(f"{exp}/output/mom_output.json")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps({"meta": {"meeting_title": {"value": "Test Meeting", "trace": None}}}))
        r = client.get("/api/viewer/data")
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is True
        assert body["type"] == "mom"
        assert "data" in body
        out_path.unlink(missing_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 9: Run / Jobs
# ══════════════════════════════════════════════════════════════════════════════

class TestRunJobs:
    def test_run_creates_job(self, client):
        r = client.post("/api/run", json={"steps": [5], "doc_type": "brd"})
        assert r.status_code == 200
        assert "job_id" in r.json()

    def test_run_job_pollable(self, client):
        r = client.post("/api/run", json={"steps": [5], "doc_type": "brd"})
        job_id = r.json()["job_id"]
        poll = client.get(f"/api/jobs/{job_id}")
        assert poll.status_code == 200
        body = poll.json()
        assert "status" in body
        assert "step_status" in body
        assert "logs" in body

    def test_run_unknown_job_404(self, client):
        r = client.get("/api/jobs/nonexistent_job_id")
        assert r.status_code == 404

    def test_run_non_brd_doctype_creates_job(self, client, tmp_path):
        """Register a doc type then start a studio pipeline job."""
        schema_file = tmp_path / "schema.json"
        schema_file.write_bytes(json.dumps(SAMPLE_SCHEMA).encode())
        js_file = tmp_path / "JS_run_test.js"
        js_file.write_bytes(b"// test\n")
        client.post(
            "/api/doctypes/register",
            data={"key": "run_test_dt", "name": "Run Test", "label": "RT"},
            files={
                "schema_prompt": ("schema.json", schema_file.read_bytes(), "application/json"),
                "js_template":   ("JS_run_test.js", js_file.read_bytes(), "text/javascript"),
            },
        )
        r = client.post("/api/run", json={"steps": [2], "doc_type": "run_test_dt"})
        assert r.status_code == 200
        assert "job_id" in r.json()

    def test_run_empty_body_defaults_to_brd(self, client):
        r = client.post("/api/run")
        assert r.status_code == 200
        assert "job_id" in r.json()

    def test_job_log_total_is_int(self, client):
        r = client.post("/api/run", json={"steps": [], "doc_type": "brd"})
        job_id = r.json()["job_id"]
        import time; time.sleep(0.1)
        poll = client.get(f"/api/jobs/{job_id}")
        assert isinstance(poll.json()["log_total"], int)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 10: Download
# ══════════════════════════════════════════════════════════════════════════════

class TestDownload:
    def test_download_existing_file(self, client, tmp_path):
        from app import load_cfg  # noqa: PLC0415
        cfg = load_cfg()
        exp = cfg["experiment"]
        out = Path(f"{exp}/output/test_output.json")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text('{"test": true}')
        r = client.get(f"/api/download/{exp}/test_output.json")
        assert r.status_code == 200
        out.unlink(missing_ok=True)

    def test_download_missing_file_404(self, client):
        r = client.get("/api/download/test_exp/file_that_does_not_exist.docx")
        assert r.status_code == 404


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 11: Static files
# ══════════════════════════════════════════════════════════════════════════════

class TestStaticFiles:
    def test_serve_schema_prompt(self, client):
        r = client.get("/api/static/artifacts_library/MOM/schema_prompt.json")
        assert r.status_code == 200

    def test_serve_js_template(self, client):
        r = client.get("/api/static/artifacts_library/MOM/JS_template.js")
        assert r.status_code in (200, 404)  # file may or may not exist in test env

    def test_serve_example_transcript(self, client):
        r = client.get("/api/static/artifacts_library/MOM/example_transcript.json")
        assert r.status_code in (200, 404)

    def test_blocked_path_returns_403(self, client):
        r = client.get("/api/static/configuration.yaml")
        assert r.status_code == 403

    def test_path_traversal_blocked(self, client):
        r = client.get("/api/static/artifacts_library/../../configuration.yaml")
        assert r.status_code in (403, 404)

    def test_scripts_js_path_allowed(self, client):
        """JS_ prefix under scripts/ is now whitelisted."""
        r = client.get("/api/static/scripts/JS_mom_template.js")
        assert r.status_code in (200, 404)  # route allowed, file may not exist


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 12: Save JS template
# ══════════════════════════════════════════════════════════════════════════════

class TestSaveJsTemplate:
    def test_save_valid_js(self, client, tmp_path):
        r = client.post(
            "/api/save-js-template",
            json={"content": "// valid JS\nconsole.log('hello');", "filename": "JS_test_save.js"},
        )
        # Should succeed (200) or fail gracefully if dir doesn't exist
        assert r.status_code in (200, 500)
        if r.status_code == 200:
            assert r.json()["ok"] is True

    def test_save_invalid_filename_rejected(self, client):
        r = client.post(
            "/api/save-js-template",
            json={"content": "// code", "filename": "malicious.js"},
        )
        assert r.status_code == 400

    def test_save_non_js_extension_rejected(self, client):
        r = client.post(
            "/api/save-js-template",
            json={"content": "evil", "filename": "JS_bad.txt"},
        )
        assert r.status_code == 400


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 13: Playground
# ══════════════════════════════════════════════════════════════════════════════

class TestPlayground:
    def test_playground_run_creates_job(self, client):
        r = client.post(
            "/api/playground/run",
            json={
                "schema_data": SAMPLE_SCHEMA,
                "js_template": "// test template\n",
                "transcript": SAMPLE_TRANSCRIPT,
            },
        )
        assert r.status_code == 200
        body = r.json()
        assert "job_id" in body
        assert body["job_id"].startswith("pg_")

    def test_playground_result_pollable(self, client):
        r = client.post(
            "/api/playground/run",
            json={
                "schema_data": SAMPLE_SCHEMA,
                "js_template": "// test template\n",
                "transcript": SAMPLE_TRANSCRIPT,
            },
        )
        job_id = r.json()["job_id"]
        poll = client.get(f"/api/playground/result/{job_id}")
        assert poll.status_code == 200
        body = poll.json()
        assert "status" in body
        assert body["status"] in ("running", "done", "error")

    def test_playground_unknown_job_404(self, client):
        r = client.get("/api/playground/result/pg_notexist")
        assert r.status_code == 404

    def test_playground_download_no_docx_404(self, client):
        """Job exists but no docx generated yet — should 404."""
        r = client.post(
            "/api/playground/run",
            json={
                "schema_data": SAMPLE_SCHEMA,
                "js_template": "// no docx\n",
                "transcript": SAMPLE_TRANSCRIPT,
            },
        )
        job_id = r.json()["job_id"]
        dl = client.get(f"/api/playground/download/{job_id}")
        # Either 404 (no docx yet) or 200 if somehow completed fast
        assert dl.status_code in (200, 404)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 14: Frontend HTML
# ══════════════════════════════════════════════════════════════════════════════

class TestFrontend:
    def test_root_returns_html(self, client):
        r = client.get("/")
        assert r.status_code == 200
        assert "text/html" in r.headers["content-type"]

    def test_root_contains_dn_studio(self, client):
        r = client.get("/")
        assert "DN-Studio" in r.text or "DataNeurus" in r.text

    def test_root_contains_view_setup(self, client):
        r = client.get("/")
        assert 'id="view-setup"' in r.text

    def test_root_contains_view_run(self, client):
        r = client.get("/")
        assert 'id="view-run"' in r.text

    def test_root_no_duplicate_transcriptimported(self, client):
        r = client.get("/")
        html = r.text
        count = html.count("let _transcriptImported")
        assert count == 1, f"_transcriptImported declared {count} times (must be exactly 1)"

    def test_root_all_nav_views_present(self, client):
        r = client.get("/")
        html = r.text
        required_views = [
            "view-setup", "view-upload", "view-run", "view-outputs",
            "view-diarization", "view-gap", "view-speakers",
            "view-experiments", "view-studio", "view-viewer", "view-playground",
        ]
        for view_id in required_views:
            assert f'id="{view_id}"' in html, f"Missing view: {view_id}"

    def test_root_nav_buttons_present(self, client):
        r = client.get("/")
        html = r.text
        required_nav = [
            "nb-setup", "nb-upload", "nb-run", "nb-outputs",
            "nb-diarization", "nb-gap", "nb-speakers",
            "nb-experiments", "nb-studio", "nb-viewer", "nb-playground",
        ]
        for nav_id in required_nav:
            assert f'id="{nav_id}"' in html, f"Missing nav button: {nav_id}"

    def test_root_no_syntax_errors_duplicate_vars(self, client):
        """Critical: duplicate let declarations break all JS."""
        r = client.get("/")
        html = r.text
        import re
        all_lets = re.findall(r'\blet (\w+)\b', html)
        from collections import Counter
        dupes = [v for v, c in Counter(all_lets).items() if c > 1]
        # These are known-OK variables that appear in multiple <script> or template contexts
        allowed_dupes = {"i", "r", "e", "v", "k", "s", "d", "p", "c", "a", "t", "n", "m", "f"}
        bad_dupes = [v for v in dupes if v not in allowed_dupes and len(v) > 3]
        assert bad_dupes == [], f"Duplicate let declarations: {bad_dupes}"


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 15: Internal helpers (_build_diar_analytics)
# ══════════════════════════════════════════════════════════════════════════════

class TestDiarAnalytics:
    def test_build_analytics_structure(self):
        from app import _build_diar_analytics  # noqa: PLC0415
        result = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        assert "speakers" in result
        assert "swimlanes" in result
        assert "scatter" in result
        assert "stats" in result
        assert "total_dur" in result

    def test_build_analytics_speaker_count(self):
        from app import _build_diar_analytics  # noqa: PLC0415
        result = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        assert len(result["speakers"]) == 2

    def test_build_analytics_swimlane_keys(self):
        from app import _build_diar_analytics  # noqa: PLC0415
        result = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        assert "SPEAKER_0" in result["swimlanes"]
        assert "SPEAKER_1" in result["swimlanes"]

    def test_build_analytics_scatter_length(self):
        from app import _build_diar_analytics  # noqa: PLC0415
        result = _build_diar_analytics(SAMPLE_TRANSCRIPT)
        assert len(result["scatter"]) == len(SAMPLE_TRANSCRIPT)

    def test_build_analytics_empty_input(self):
        from app import _build_diar_analytics  # noqa: PLC0415
        result = _build_diar_analytics([])
        assert result["speakers"] == []
        assert result["total_dur"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 16: Config YAML save/load round-trip
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigRoundTrip:
    def test_save_load_roundtrip(self, client):
        client.post("/api/config", json={
            "experiment": "roundtrip_exp",
            "api_key": "",
            "num_speakers": 3,
            "whisper_model": "base",
            "gemini_model": "gemini-1.5-pro",
        })
        body = client.get("/api/config").json()
        assert body["experiment"] == "roundtrip_exp"
        assert body["num_speakers"] == 3
        assert body["whisper_model"] == "base"
        assert body["gemini_model"] == "gemini-1.5-pro"
        # restore
        client.post("/api/config", json={
            "experiment": "test_exp", "api_key": "",
            "num_speakers": 2, "whisper_model": "tiny",
            "gemini_model": "gemini-2.5-flash",
        })

    def test_num_speakers_null(self, client):
        client.post("/api/config", json={
            "experiment": "test_exp",
            "api_key": "",
            "num_speakers": None,
            "whisper_model": "tiny",
            "gemini_model": "gemini-2.5-flash",
        })
        body = client.get("/api/config").json()
        assert body["num_speakers"] is None
