@echo off

REM Create virtual environment with Python 3.12
py -3.12 -m venv venv

REM Activate the virtual environment
call venv\Scripts\activate

REM Upgrade pip (optional but recommended)
python -m pip install --upgrade pip

REM Install requirements
pip install -r requirements.txt

echo.
echo Setup complete!
pause