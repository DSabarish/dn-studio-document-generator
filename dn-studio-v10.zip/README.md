# DN-Studio by DataNeurus

**Audio recording → Speaker-diarized transcript → AI-generated Word documents**

DN-Studio is a self-hosted document generation platform. Upload any meeting recording, select a document type, and receive a professionally formatted Word document — with every field traced back to the exact moment it was spoken in the transcript.

---

## Quick Start

### Windows
```
Double-click start.bat
```

### Linux / macOS / Google Colab
```bash
pip install -r requirements.txt
python app.py
```
Then open `http://localhost:8000`.

---

## Workflow

```
1. Configure  →  Set project name, Gemini API key, audio settings
2. Prepare    →  Upload audio, rename detected speakers
3. Generate   →  Run the pipeline — AI transcribes, analyses, and writes
4. Download   →  Get your Word document from the Outputs page
```

---

## Document Types

| Type | Full Name | Pipeline |
|------|-----------|----------|
| BRD  | Business Requirements Document | Full 7-step pipeline with traceability and gap analysis |
| MOM  | Minutes of Meeting | Studio 4-step pipeline |
| Custom | Any document type | Register your own schema + JS template via the Studio tab |

---

## Pipeline Architecture

```
Audio File
  ↓ Step 0 — Convert to MP3          (to_mp3.py)
  ↓ Step 1 — Diarize                 (diarize.py — Whisper + SpectralClustering)

  ── BRD ─────────────────────────────────────────────────────────
  ↓ Step 2 — Schema Decider          (chain1_schema_decider.py)
  ↓ Step 3 — BRD Generator           (chain2_brd_response.py)
  ↓ Step 4 — Traceability            (chain3_brd_trace.py)
  ↓ Step 5 — Build Word document     (generic_docx_runner.py + BRD/JS_template.js)
  ↓ Step 6 — Gap Analyser            (chain4_gap_analyser.py)

  ── Studio (MOM / custom) ───────────────────────────────────────
  ↓ Step 2 — Document Filler         (generic_chain_fill.py — single-pass Gemini)
  ↓ Step 5 — Word Document           (generic_docx_runner.py + JS_template.js)
```

---

## Requirements

- Python 3.10+
- Node.js 16+
- ffmpeg (for audio conversion)
- Gemini API key — free at [aistudio.google.com](https://aistudio.google.com)

---

## Configuration

Edit `configuration.yaml` or use the Setup tab:

```yaml
experiment: my-project-name

llm:
  provider: gemini
  model: gemini-2.5-flash
  api_key: "YOUR_KEY_HERE"

diarization:
  num_speakers: 2        # or null for auto-detect
  whisper_model: tiny    # tiny | base | small | large-v2
```

---

## Project Structure

```
app.py                          FastAPI backend — BRD pipeline + Studio API
brd_main.py                     CLI runner for the BRD pipeline
configuration.yaml              All settings
frontend.html                   Single-file web UI
requirements.txt                Python dependencies
start.bat                       Windows one-click launcher

scripts/
  cfg_utils.py                  Config resolver
  to_mp3.py                     Audio format conversion
  diarize.py                    Whisper transcription + speaker clustering
  chain1_schema_decider.py      BRD: decide which sections to generate
  chain2_brd_response.py        BRD: generate full document JSON
  chain3_brd_trace.py           BRD: link fields to transcript utterances
  chain4_gap_analyser.py        BRD: gap analysis and open questions
  artifacts_library/BRD/JS_template.js  BRD: Word document template (replaces generalised_brd_generator.py)
  generic_chain_fill.py         Studio: single-pass LLM field fill
  generic_docx_runner.py        Studio: run any JS_template.js → .docx
  JS_mom_template.js            MOM: Word document generator
  node_modules/                 Pre-installed: docx npm package

prompts/
  brd-system-prompt.json        BRD generator prompt and output template
  brd-schema-decider-prompt.json  BRD schema decision prompt
  mom-schema-prompt.json        MOM leaf-node schema (15 fields)
  doctypes.json                 Doc type registry (BRD + MOM built-in)

artifacts_library/
  README.md                     Full contract for adding new doc types
  MOM/                          Complete MOM example (schema + JS template)
  SOP/                          Standard Operating Procedure (schema ready)
  QRM/                          Quality Review Meeting (schema ready)
  BPIP/                         Business Process Improvement Plan (schema ready)

docs/
  architecture.md               System architecture and data flow
  api.md                        API endpoint reference
  pipeline.md                   Pipeline step details
  diarization.md                Diarization technical notes
  gap_analyser.md               Gap analysis output schema
```

---

## Running on Google Colab

```python
import nest_asyncio
nest_asyncio.apply()

import os, sys, uvicorn
from google.colab.output import eval_js

os.chdir("/content/repo")
sys.path.insert(0, "/content/repo/scripts")

print(f"URL: {eval_js('google.colab.kernel.proxyPort(8000)')}")

config = uvicorn.Config("app:app", host="0.0.0.0", port=8000, reload=False)
server = uvicorn.Server(config)
await server.serve()
```

---

## Adding Custom Document Types

See `artifacts_library/README.md` for the complete guide.

In short: create a `schema_prompt.json` (leaf-node template) and a `JS_template.js` (Node.js docx generator), then register them via the Studio tab in the UI.
