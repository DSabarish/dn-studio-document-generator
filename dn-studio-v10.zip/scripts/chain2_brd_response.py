"""BRD Pipeline — Chain 2: BRD Generator (JSON Mode + Retry)"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import logging
from typing import Any, Dict, Optional

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI

from cfg_utils import resolve_cfg

# Fix 1: import shared helpers — removes the four locally-defined duplicates
# Fix 2: use invoke_with_retry — gains Gemini retryDelay parsing + shared backoff
# Fix 10: extract_json now logs raw response on failure (handled inside llm_utils)
from llm_utils import (
    load_json, save_json, to_str,
    extract_json, invoke_with_retry,
    MAX_RETRY_ATTEMPTS,
)

log = logging.getLogger(__name__)


# ── safe_extract_json — chain2-specific recovery wrapper ─────────────────────
# Kept here because chain2 has unique recovery strategies (brace-padding, line
# trimming) that are not part of the generic extract_json in llm_utils.

def safe_extract_json(text: str, max_retries: int = 2) -> Dict:
    for attempt in range(max_retries + 1):
        result = extract_json(text)
        if result:
            return result
        if attempt == 0:
            text += "}" * max(0, text.count("{") - text.count("}"))
        elif attempt == 1:
            lines = text.split("\n")
            while lines and lines[-1].strip().rstrip(",").rstrip() not in ("}", "]"):
                lines.pop()
            text = "\n".join(lines) + "}"
    raise ValueError(f"Failed to parse JSON after {max_retries} retries. Preview: {text[:300]}...")


# ── Chain Builder ─────────────────────────────────────────────────────────────

def build_chain2(model, prompt_path: str, brd_template: Dict[str, Any]):
    p = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{p.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown. No trailing commas. Close all braces.",
        ),
        (
            "human",
            "Meeting Transcript (utterance_id range: 0 to {max_utid}):\n{transcript}\n\n"
            "Schema Decision (MUST follow for Section 6 & 7):\n{schema}\n\n"
            "BRD Template Structure:\n{brd_template}\n\n"
            "Rules:\n"
            "- Utterance IDs must be in range [0, {max_utid}]\n"
            "- Use why_null codes: not_mentioned, deferred_by_participants, not_yet_agreed, "
            "schema_excluded, insufficient_detail, not_applicable\n"
            "- Every non-null value needs a trace with valid utterance_id\n"
            "- Output valid, complete JSON only — no truncation\n\n"
            "Generate complete BRD JSON:",
        ),
    ])

    chain = (
        {
            "transcript":   RunnableLambda(lambda x: to_str(x["transcript"])),
            "schema":       RunnableLambda(lambda x: to_str(x["schema"])),
            "brd_template": RunnableLambda(lambda x: to_str(x["template"])),
            "max_utid":     RunnableLambda(
                lambda x: len(x["transcript"]) - 1 if isinstance(x["transcript"], list) else 0
            ),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(safe_extract_json)
    )
    return chain


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain2(cfg: Dict[str, Any]) -> str:
    llm_cfg   = cfg["llm"]
    chain_cfg = cfg["chains"]["chain2_brd_generator"]

    model = ChatGoogleGenerativeAI(
        model              = llm_cfg["model"],
        google_api_key     = llm_cfg["api_key"],
        temperature        = llm_cfg.get("temperature", 0),
        max_output_tokens  = llm_cfg.get("max_tokens", 32768),
        response_mime_type = "application/json",
    )

    transcript   = load_json(chain_cfg["input"]["transcript"])
    schema       = load_json(chain_cfg["input"]["schema"])
    prompt_path  = chain_cfg["input"]["prompt"]
    brd_template = load_json(prompt_path).get("BRD_Template", {})
    output_path  = chain_cfg["output"]["brd"]

    log.info(
        "📄 Transcript: %d utterances | Schema modules: %d",
        len(transcript), len(schema.get("functional_modules", [])),
    )

    chain2 = build_chain2(model, prompt_path, brd_template)

    # Fix 2: use shared invoke_with_retry — gains Gemini retryDelay hint parsing
    # and consistent backoff behaviour with all other chains.
    # "Header" is always present in a valid BRD response.
    brd = invoke_with_retry(
        chain2,
        {"transcript": transcript, "schema": schema, "template": brd_template},
        required_key="Header",
        label="BRD Generator (chain2)",
    )

    if not brd:
        raise RuntimeError(f"Chain 2 failed after {MAX_RETRY_ATTEMPTS} attempts")

    save_json(brd, output_path)
    log.info("✅ BRD saved → %s", output_path)
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg         = resolve_cfg("configuration.yaml")
    output_path = run_chain2(cfg)
    brd         = load_json(output_path)
    print(
        f"\n🎯 Chain 2 Complete: {output_path}\n"
        f"   Project  : {brd.get('Header', {}).get('Project Name', {}).get('value', 'N/A')}\n"
        f"   Sections : {sum(1 for v in brd.values() if isinstance(v, dict) and v.get('value'))}"
    )
