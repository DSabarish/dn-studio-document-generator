"""BRD Pipeline — Chain 1: Schema Decider"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import logging
from typing import Any, Dict

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI

from cfg_utils import resolve_cfg

# Fix 1+9: import shared helpers from llm_utils — removes duplicate definitions
# and uses the robust brace-depth extract_json instead of the simple regex version
from llm_utils import load_json, save_json, to_str, extract_json

log = logging.getLogger(__name__)


# ── Chain Builder ─────────────────────────────────────────────────────────────

def build_chain1(model, prompt_path: str):
    prompt_file = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{prompt_file.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown.",
        ),
        (
            "human",
            "Meeting Transcript:\n{transcript}\n\n"
            "Instructions:\n{instructions}\n\n"
            "Output Format:\n{output_format}\n\n"
            "Return JSON only:",
        ),
    ])

    chain = (
        {
            "transcript":    RunnableLambda(lambda x: to_str(x["transcript"])),
            "instructions":  RunnableLambda(lambda x: to_str(prompt_file.get("Instructions", {}))),
            "output_format": RunnableLambda(lambda x: to_str(prompt_file.get("Output Format", {}))),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(extract_json)
    )
    return chain


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain1(cfg: Dict[str, Any]) -> str:
    llm_cfg   = cfg["llm"]
    chain_cfg = cfg["chains"]["chain1_schema_decider"]

    model = ChatGoogleGenerativeAI(
        model              = llm_cfg["model"],
        google_api_key     = llm_cfg["api_key"],
        temperature        = llm_cfg.get("temperature", 0),
        max_output_tokens  = llm_cfg.get("max_tokens", 4096),
    )

    transcript = load_json(chain_cfg["input"]["transcript"])
    log.info(f"📄 Loaded {len(transcript)} utterances")

    schema = build_chain1(model, chain_cfg["input"]["prompt"]).invoke(
        {"transcript": transcript}
    )

    output_path = chain_cfg["output"]["schema"]
    save_json(schema, output_path)
    log.info(f"✅ Schema saved → {output_path}")
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    path   = run_chain1(resolve_cfg("configuration.yaml"))
    schema = load_json(path)
    print(
        f"\n🎯 Chain 1 Complete: {path}\n"
        f"   Domain  : {schema.get('project_domain', 'N/A')}\n"
        f"   Modules : {len(schema.get('functional_modules', []))}\n"
        f"   NFRs    : {len(schema.get('nfr_sections', []))}"
    )
