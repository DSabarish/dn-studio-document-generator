"""
generic_chain_fill.py — Generic single-pass LLM fill for any doc type.
DN-Studio by DataNeurus

Thin wrapper around llm_filler.run_fill(mode="generic").

The generic system prompt and single-pass logic now live in llm_filler.py.
This file preserves the original public signature so app.py needs no changes.
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cfg_utils import resolve_cfg
from llm_filler import run_fill

log = logging.getLogger(__name__)


def run_generic_fill(
    cfg: Dict[str, Any],
    schema_prompt_path: str,
    output_path: str,
    doc_type: str = "doc",
    transcript_override: Optional[str] = None,
) -> str:
    """
    Fill all leaf nodes in *schema_prompt_path* using the transcript from cfg.

    Delegates to llm_filler.run_fill(mode="generic").
    Signature is preserved for backward compatibility with app.py.

    Args:
        cfg:                 Resolved configuration dict.
        schema_prompt_path:  Path to the schema/prompt JSON template.
        output_path:         Destination path for the filled JSON.
        doc_type:            Label for log messages (e.g. ``"SOP"``, ``"BPIP"``).
        transcript_override: Optional explicit transcript path (Playground use).

    Returns:
        *output_path* on success.
    """
    return run_fill(
        cfg                 = cfg,
        schema_path         = schema_prompt_path,
        output_path         = output_path,
        mode                = "generic",
        doc_type            = doc_type,
        transcript_override = transcript_override,
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generic doc type chain fill")
    parser.add_argument("schema_prompt", help="Path to schema_prompt.json")
    parser.add_argument("output",        help="Path to write filled JSON")
    parser.add_argument("--doc-type",    default="doc")
    parser.add_argument("--config",      default="configuration.yaml")
    args = parser.parse_args()
    _cfg  = resolve_cfg(args.config)
    _path = run_generic_fill(_cfg, args.schema_prompt, args.output, args.doc_type)
    print(f"\n🎯 Fill complete: {_path}")
