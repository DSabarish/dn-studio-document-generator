"""BRD Pipeline — Chain 3: Traceability (merge diarization into BRD)"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import copy
import json
import logging
from typing import Any, Dict

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_json(data: Any, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


# ── Trace resolution ──────────────────────────────────────────────────────────

def _resolve_traces(node: Any, utterance_map: Dict[int, Dict]) -> None:
    """Walk the document tree and replace every trace node with the full
    diarization entry keyed by the first utterance_id in the list."""
    if isinstance(node, dict):
        if "trace" in node and isinstance(node["trace"], dict):
            uid_list = node["trace"].get("utterance_id")
            if isinstance(uid_list, list) and uid_list:
                node["trace"] = utterance_map.get(uid_list[0])
            else:
                node["trace"] = None
        for v in node.values():
            _resolve_traces(v, utterance_map)
    elif isinstance(node, list):
        for item in node:
            _resolve_traces(item, utterance_map)


def _inject_value_in_list_items(node: Any) -> None:
    """Ensure every functional-requirement list item has a `value` key
    mirroring its `Description` field, keeping the schema consistent."""
    if isinstance(node, dict):
        for v in node.values():
            if isinstance(v, list):
                for item in v:
                    if isinstance(item, dict) and "Description" in item and "value" not in item:
                        new_item: Dict = {}
                        for k, val in item.items():
                            new_item[k] = val
                            if k == "Description":
                                new_item["value"] = val
                        item.clear()
                        item.update(new_item)
            _inject_value_in_list_items(v)
    elif isinstance(node, list):
        for item in node:
            _inject_value_in_list_items(item)


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain3(cfg: Dict[str, Any]) -> str:
    chain_cfg = cfg["chains"]["chain3_traceability"]

    diarization_path = chain_cfg["input"]["transcript"]
    brd_path = chain_cfg["input"]["brd"]
    output_path = chain_cfg["output"]["trace"]

    diarization_list: list = load_json(diarization_path)
    brd: dict = load_json(brd_path)

    utterance_map: Dict[int, Dict] = {
        entry["utterance_id"]: entry for entry in diarization_list
    }

    trace_doc = copy.deepcopy(brd)
    _resolve_traces(trace_doc, utterance_map)
    _inject_value_in_list_items(trace_doc)

    save_json(trace_doc, output_path)
    log.info(f"✅ Trace document written → {output_path}")
    return output_path


if __name__ == "__main__":
    cfg = resolve_cfg("configuration.yaml")
    path = run_chain3(cfg)
    print(f"\n🎯 Chain 3 Complete: {path}")
