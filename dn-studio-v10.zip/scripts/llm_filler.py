"""
llm_filler.py — Mode-based unified LLM fill entry point.
DN-Studio by DataNeurus

Exposes a single function:

    run_fill(cfg, schema_path, output_path, mode, ...)

Supported modes
---------------
"generic"
    Single-pass fill.  Uses the generic document extraction prompt.
    All leaf fields in the schema are sent to the LLM in one call.
    Temperature: 0.1 (from cfg, fallback 0.1)

"mom"
    Two-pass fill.  Uses specialist meeting-analyst prompts.
    Pass 1 — core fields (everything except action_items)
    Pass 2 — action items only (dedicated extraction prompt)
    Temperature: 0.05  (fixed — MOM requires higher precision)

Architecture
------------
This module owns:
  - mode routing
  - system prompt selection
  - pass strategy (1-pass vs 2-pass)
  - calling invoke_with_retry from llm_utils
  - writing results back into the filled schema

This module does NOT own:
  - model instantiation    → llm_utils.build_model()
  - retry timing / backoff → llm_utils.invoke_with_retry()
  - schema leaf traversal  → llm_utils.collect_leaves() / write_back()
  - JSON I/O               → llm_utils.load_json() / save_json()

BRD chain2 (chain2_brd_response.py) remains separate — it has a
fundamentally different schema structure and traversal model.
"""
from __future__ import annotations

import copy
import logging
from typing import Any, Dict, List, Optional

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from llm_utils import (
    MAX_RETRY_ATTEMPTS,
    build_model,
    collect_leaves,
    extract_json,
    invoke_with_retry,
    load_json,
    save_json,
    to_str,
    write_back,
)

log = logging.getLogger(__name__)

# ── Supported modes ───────────────────────────────────────────────────────────

SUPPORTED_MODES = {"generic", "mom"}

# ── Temperatures per mode — preserved exactly from original callers ───────────
# generic_chain_fill used: llm_cfg.get("temperature", 0.1)
# chain_mom        used:   0.05  (fixed — not from config)

_TEMPERATURES: Dict[str, Any] = {
    "generic": None,    # None = read from cfg["llm"]["temperature"], fallback 0.1
    "mom":     0.05,    # fixed — do not change without testing MOM output quality
}


# ── System prompts — copied verbatim from original callers ───────────────────
# generic: from generic_chain_fill._SYSTEM_PROMPT
# mom core: from chain_mom._SYSTEM_CORE
# mom actions: from chain_mom._SYSTEM_ACTIONS

_PROMPT_GENERIC = (
    "You are a precise document extraction assistant.\n\n"
    "You will receive:\n"
    "1. A meeting transcript (utterances with utterance_id, speaker_name, text)\n"
    "2. Fields to fill - each with path, title, description, format\n\n"
    "Fill EVERY field from the transcript. Output ONLY valid JSON, no markdown.\n\n"
    'Schema: {{ "fields": [ {{ "path":"", "value":null, "trace":null, "why_null":"..." }} ] }}\n\n'
    "Rules:\n"
    "- Match format exactly (String, Array of strings, Integer, etc.)\n"
    "- trace must reference a real utterance_id from the transcript\n"
    "- If not in transcript: value=null, add why_null\n"
    "- Never invent information"
)

_PROMPT_MOM_CORE = """\
You are an expert meeting analyst extracting structured Minutes of Meeting from a transcript.

You will receive:
1. A meeting transcript with utterance_id, speaker_name, start/end times, and text
2. Fields to fill — each with path, title, description, and expected format

Rules:
- Extract ONLY from the transcript — never invent or infer beyond what was said
- For every field, provide a trace: {{ "utterance_id": [<int>], "speaker": "<n>", "text": "<exact quote>" }}
- If a field is not in the transcript: value=null, why_null = "not_mentioned" | "deferred" | "insufficient_detail"
- Arrays: capture ALL relevant items, not just the first one
- Attendees: list every unique speaker_name from the transcript

Output ONLY valid JSON matching:
{{"fields": [{{"path":"..","value":..,"trace":{{"utterance_id":[],"speaker":"","text":""}},"why_null":null}}]}}\
"""

_PROMPT_MOM_ACTIONS = """\
You are extracting ACTION ITEMS from a meeting transcript with high precision.

An action item is any commitment, task, or follow-up that a named person agreed to do.

Signals to look for:
- Direct commitments: "I will...", "I'll...", "I can do that"
- Assignments: "Can you...", "Please...", "Action on [name]"
- Deadlines: "by end of week", "before next push", "by [date]"
- Implicit commitments: anything phrased as future work assigned to someone

For EACH action item extract:
- action: specific task description
- owner: the person's name from the transcript (not a role)
- deadline: explicit deadline or null

Output ONLY valid JSON:
{{"action_items": [{{"action":"..","owner":"..","deadline":null,"utterance_ids":[1,2],"speaker":"..","quote":".."}}]}}\
"""


# ── Chain builders ────────────────────────────────────────────────────────────

def _build_generic_chain(model: Any) -> Any:
    """Single-pass chain — identical to generic_chain_fill._build_fill_chain."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", _PROMPT_GENERIC),
        ("human",
         "Meeting Transcript (utterance_id range: 0 to {max_utid}):\n{transcript}\n\n"
         "Fields to fill:\n{fields}\n\nReturn JSON only:"),
    ])
    return (
        {
            "transcript": RunnableLambda(lambda x: to_str(x["transcript"])),
            "fields":     RunnableLambda(lambda x: to_str(x["fields"])),
            "max_utid":   RunnableLambda(
                lambda x: len(x["transcript"]) - 1
                if isinstance(x["transcript"], list) else 0
            ),
        }
        | prompt | model | StrOutputParser()
        | RunnableLambda(extract_json)
    )


def _build_mom_core_chain(model: Any) -> Any:
    """MOM pass-1 chain — identical to chain_mom._build_core_chain."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", _PROMPT_MOM_CORE),
        ("human",
         "Transcript ({n_utts} utterances, speakers: {speakers}):\n{transcript}\n\n"
         "Fields to fill:\n{fields}\n\nReturn JSON only:"),
    ])
    return (
        {
            "transcript": RunnableLambda(lambda x: to_str(x["transcript"])),
            "fields":     RunnableLambda(lambda x: to_str(x["fields"])),
            "n_utts":     RunnableLambda(lambda x: len(x["transcript"])),
            "speakers":   RunnableLambda(
                lambda x: ", ".join(sorted({u["speaker_name"] for u in x["transcript"]}))
            ),
        }
        | prompt | model | StrOutputParser()
        | RunnableLambda(extract_json)
    )


def _build_mom_action_chain(model: Any) -> Any:
    """MOM pass-2 chain — identical to chain_mom._build_action_chain."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", _PROMPT_MOM_ACTIONS),
        ("human",
         "Meeting transcript ({n} utterances):\n{transcript}\n\n"
         "Extract ALL action items. Return JSON only:"),
    ])
    return (
        {
            "transcript": RunnableLambda(lambda x: to_str(x["transcript"])),
            "n":          RunnableLambda(lambda x: len(x["transcript"])),
        }
        | prompt | model | StrOutputParser()
        | RunnableLambda(extract_json)
    )


# ── Write-back helpers ────────────────────────────────────────────────────────

def _apply_fields_result(
    filled: Dict,
    leaves: List,
    result: Dict,
    label: str,
) -> tuple[int, int]:
    """
    Write a 'fields' result dict back into *filled*.
    Returns (filled_count, null_count).
    """
    path_map = {item["path"]: item for item in result.get("fields", [])}
    filled_count = null_count = 0
    for path, leaf in leaves:
        item = path_map.get(path)
        if not item:
            log.warning("   ⚠️  %s: no result for field: %s", label, path)
            continue
        write_back(
            filled, path,
            item.get("value"),
            item.get("trace"),
            item.get("why_null") or None,
        )
        if item.get("value") is not None:
            filled_count += 1
        else:
            null_count += 1
    return filled_count, null_count


def _apply_action_items(filled: Dict, action_result: Dict) -> int:
    """
    Write action-items result back into *filled*.
    Also derives follow_up_required_from from unique owners.
    Returns the number of action items extracted.
    Identical logic to chain_mom.run_mom_fill action-items write-back.
    """
    raw_items = action_result.get("action_items", [])
    normalised = [
        {
            "action":   item.get("action", ""),
            "owner":    item.get("owner", "—"),
            "deadline": item.get("deadline"),
        }
        for item in raw_items
    ]
    trace: Optional[Dict] = None
    if raw_items:
        first = raw_items[0]
        trace = {
            "utterance_id": first.get("utterance_ids", []),
            "speaker":      first.get("speaker", ""),
            "text":         first.get("quote", ""),
        }
    try:
        filled["action_items"]["items"]["value"] = normalised
        filled["action_items"]["items"]["trace"] = trace
    except (KeyError, TypeError):
        pass

    # Derive follow-up owners
    try:
        owners = sorted({
            i["owner"] for i in normalised
            if i.get("owner") and i["owner"] != "—"
        })
        if owners:
            filled["next_steps"]["follow_up_required_from"]["value"] = owners
    except (KeyError, TypeError, AttributeError):
        pass

    return len(normalised)


# ── Pass runners ──────────────────────────────────────────────────────────────

def _run_generic_pass(
    model: Any,
    transcript: List[Dict],
    schema: Dict,
    filled: Dict,
    doc_type: str,
) -> None:
    """Execute a single generic fill pass."""
    leaves = collect_leaves(schema)
    field_descriptors = [
        {
            "path":        path,
            "title":       leaf["title"],
            "description": leaf["description"],
            "format":      leaf.get("format", "String"),
        }
        for path, leaf in leaves
    ]
    log.info("🌿 Fields to fill: %d", len(leaves))

    chain  = _build_generic_chain(model)
    result = invoke_with_retry(
        chain,
        {"transcript": transcript, "fields": field_descriptors},
        required_key="fields",
        label=f"Generic fill ({doc_type})",
    )

    if not result:
        raise RuntimeError(
            f"llm_filler: generic fill failed after {MAX_RETRY_ATTEMPTS} attempts "
            f"for doc_type='{doc_type}'"
        )

    filled_count, null_count = _apply_fields_result(
        filled, leaves, result, label=doc_type
    )
    log.info("✅ Filled: %d fields | Null: %d fields", filled_count, null_count)
    # Fix 7: warn if the LLM silently dropped fields
    returned = filled_count + null_count
    if returned < len(leaves):
        log.warning(
            "⚠️  LLM dropped %d fields (expected %d, got %d back) — "
            "remaining fields left as null.",
            len(leaves) - returned, len(leaves), returned,
        )


def _run_mom_passes(
    model: Any,
    transcript: List[Dict],
    schema: Dict,
    filled: Dict,
) -> None:
    """Execute MOM two-pass fill (core fields then action items)."""
    all_leaves    = collect_leaves(schema)
    core_leaves   = [(p, l) for p, l in all_leaves if not p.startswith("action_items")]
    action_leaves = [(p, l) for p, l in all_leaves if     p.startswith("action_items")]

    core_fields = [
        {
            "path":        p,
            "title":       leaf["title"],
            "description": leaf["description"],
            "format":      leaf.get("format", "String"),
        }
        for p, leaf in core_leaves
    ]
    log.info("🌿 Core fields: %d  |  Action fields: %d",
             len(core_fields), len(action_leaves))

    # Pass 1 — core fields
    core_chain  = _build_mom_core_chain(model)
    core_result = invoke_with_retry(
        core_chain,
        {"transcript": transcript, "fields": core_fields},
        required_key="fields",
        label="Core fill",
    )

    if not core_result:
        # Fix 6: core fill failure is fatal — a document with all null core fields
        # is worse than a clean error (user sees empty output with no indication of failure)
        raise RuntimeError(
            "MOM core fill failed after all retry attempts — aborting. "
            "Check API key, model availability, and transcript quality."
        )

    fc, nc = _apply_fields_result(filled, core_leaves, core_result, label="MOM core")
    log.info("✅ Core: %d filled, %d null", fc, nc)
    # Fix 7: warn if LLM dropped MOM core fields
    if (fc + nc) < len(core_leaves):
        log.warning(
            "⚠️  MOM core: LLM dropped %d fields (expected %d, got %d back).",
            len(core_leaves) - (fc + nc), len(core_leaves), fc + nc,
        )

    # Pass 2 — action items
    action_chain  = _build_mom_action_chain(model)
    action_result = invoke_with_retry(
        action_chain,
        {"transcript": transcript},
        required_key="action_items",
        label="Action items",
    )

    if action_result:
        n = _apply_action_items(filled, action_result)
        log.info("✅ Action items: %d extracted", n)
    else:
        log.warning("⚠️  Action items extraction failed")
        try:
            filled["action_items"]["items"]["value"]    = []
            filled["action_items"]["items"]["why_null"] = "not_mentioned"
        except (KeyError, TypeError):
            pass


# ── Public entry point ────────────────────────────────────────────────────────

def run_fill(
    cfg: Dict[str, Any],
    schema_path: str,
    output_path: str,
    mode: str,
    doc_type: str = "doc",
    transcript_override: Optional[str] = None,
) -> str:
    """
    Fill all leaf nodes in *schema_path* using the transcript from *cfg*.

    Args:
        cfg:                 Resolved configuration dict.
        schema_path:         Path to the schema/prompt JSON template.
        output_path:         Destination path for the filled JSON.
        mode:                Fill strategy — ``"generic"`` or ``"mom"``.
        doc_type:            Label for log messages (e.g. ``"MOM"``, ``"SOP"``).
        transcript_override: Optional explicit transcript path (Playground use).

    Returns:
        *output_path* on success.

    Raises:
        ValueError:       if *mode* is not supported.
        RuntimeError:     if the LLM fill fails after all retry attempts.
        FileNotFoundError: if transcript or schema files are missing.
    """
    if mode not in SUPPORTED_MODES:
        raise ValueError(
            f"llm_filler: unsupported mode '{mode}'. "
            f"Supported modes: {sorted(SUPPORTED_MODES)}"
        )

    transcript_path = (
        transcript_override
        or cfg["chains"]["chain1_schema_decider"]["input"]["transcript"]
    )

    # Temperature: MOM is fixed; generic reads from cfg with fallback 0.1
    temp_setting = _TEMPERATURES[mode]
    temperature  = temp_setting if temp_setting is not None else cfg["llm"].get("temperature", 0.1)

    model      = build_model(cfg, temperature=temperature)
    transcript = load_json(transcript_path)
    schema     = load_json(schema_path)
    filled     = copy.deepcopy(schema)

    log.info("📄 %s fill [mode=%s]: %d utterances", doc_type, mode, len(transcript))

    if mode == "generic":
        _run_generic_pass(model, transcript, schema, filled, doc_type)
    elif mode == "mom":
        _run_mom_passes(model, transcript, schema, filled)

    save_json(filled, output_path)
    log.info("✅ Output saved → %s", output_path)
    return output_path
