"""
generic_docx_runner.py — Studio: Run a JS template to generate a .docx file.

Takes:
  - filled_json_path: path to the filled {doctype}_output.json
  - js_template_path: path to the JS file (uses 'docx' npm package)
  - output_docx_path: where to write the resulting .docx

The JS template contract:
  - process.argv[2] = absolute path to filled JSON
  - process.argv[3] = absolute path to write the output .docx
  - Must require('docx') — pre-installed in scripts/node_modules/
  - Must log "SUCCESS: <path>" on completion

This script resolves node_modules from the scripts/ directory so the
JS template can require('docx') without any local install.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


def run_generic_docx(
    filled_json_path: str,
    js_template_path: str,
    output_docx_path: str,
    scripts_dir: Optional[str] = None,
) -> str:
    """
    Run node <js_template_path> <filled_json_path> <output_docx_path>.

    Args:
        filled_json_path: Absolute path to the LLM-filled JSON
        js_template_path: Absolute path to the JS template
        output_docx_path: Absolute path for the output .docx
        scripts_dir: Directory containing node_modules (default: next to this script)

    Returns:
        output_docx_path on success

    Raises:
        RuntimeError on failure
    """
    filled_json_path  = str(Path(filled_json_path).resolve())
    js_template_path  = str(Path(js_template_path).resolve())
    output_docx_path  = str(Path(output_docx_path).resolve())

    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_docx_path) or ".", exist_ok=True)

    if not os.path.exists(filled_json_path):
        raise RuntimeError(f"Filled JSON not found: {filled_json_path}")
    if not os.path.exists(js_template_path):
        raise RuntimeError(f"JS template not found: {js_template_path}")

    # Resolve scripts dir (where node_modules lives)
    if scripts_dir is None:
        scripts_dir = str(Path(__file__).resolve().parent)
    scripts_dir = str(Path(scripts_dir).resolve())

    # ── Auto-install docx if node_modules is missing ─────────────────────────
    node_modules = Path(scripts_dir) / "node_modules"
    package_json = Path(scripts_dir) / "package.json"
    if not (node_modules / "docx").exists() and package_json.exists():
        log.info("📦 node_modules/docx not found — running npm install...")
        try:
            npm_result = subprocess.run(
                ["npm", "install", "--prefer-offline"],
                cwd=scripts_dir,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if npm_result.returncode == 0:
                log.info("✅ npm install completed")
            else:
                log.warning(f"⚠️  npm install failed (exit {npm_result.returncode})")
                log.warning(npm_result.stderr[:500] if npm_result.stderr else "")
                raise RuntimeError(
                    f"npm install failed. Please run manually:\n"
                    f"  cd {scripts_dir} && npm install\n"
                    f"stderr: {npm_result.stderr[:300]}"
                )
        except FileNotFoundError:
            raise RuntimeError(
                "npm not found — ensure Node.js is installed.\n"
                f"Then run: cd {scripts_dir} && npm install"
            )
    # ─────────────────────────────────────────────────────────────────────────

    log.info(f"📝 Running JS template: {Path(js_template_path).name}")
    log.info(f"   Input  : {filled_json_path}")
    log.info(f"   Output : {output_docx_path}")

    # Set NODE_PATH so require('docx') resolves from scripts/node_modules
    env = {
        **os.environ,
        "NODE_PATH": os.path.join(scripts_dir, "node_modules"),
    }

    try:
        result = subprocess.run(
            ["node", js_template_path, filled_json_path, output_docx_path],
            capture_output=True,
            text=True,
            env=env,
            cwd=scripts_dir,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "node not found — ensure Node.js is installed and in PATH"
        )

    stdout = result.stdout.strip()
    stderr = result.stderr.strip()

    if stdout:
        for line in stdout.splitlines():
            log.info(f"   {line}")
    if stderr:
        for line in stderr.splitlines():
            log.warning(f"   [stderr] {line}")

    if result.returncode != 0:
        raise RuntimeError(
            f"JS template failed (exit {result.returncode}).\n"
            f"stdout: {stdout}\nstderr: {stderr}"
        )

    if not os.path.exists(output_docx_path):
        raise RuntimeError(
            f"JS template exited 0 but did not produce: {output_docx_path}\n"
            f"stdout: {stdout}"
        )

    size_kb = os.path.getsize(output_docx_path) / 1024
    log.info(f"✅ Document generated: {output_docx_path} ({size_kb:.1f} KB)")
    return output_docx_path


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generic .docx runner via Node.js template")
    parser.add_argument("filled_json",  help="Path to filled output JSON")
    parser.add_argument("js_template",  help="Path to JS template file")
    parser.add_argument("output_docx",  help="Path for output .docx")
    parser.add_argument("--scripts-dir", default=None,
                        help="Directory containing node_modules (default: script's own directory)")
    args = parser.parse_args()

    path = run_generic_docx(args.filled_json, args.js_template, args.output_docx, args.scripts_dir)
    print(f"\n🎯 Docx complete: {path}")
