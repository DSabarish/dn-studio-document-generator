"""BRD Pipeline — Chain 4: Gap Analyser

Reads the completed BRD trace and original transcript, then asks the LLM to:
  1. Identify every null/incomplete section and explain WHY it matters
  2. Surface open questions that must be answered before sign-off
  3. Flag risks that were discussed but not captured as requirements
  4. Score each section for transcript confidence (well-supported vs inferred)
  5. Produce a prioritised action list the team can act on immediately

Output schema (gap-report.json):
{
  "summary": {
    "total_gaps": int,
    "critical": int,       # must fix before BRD sign-off
    "major": int,          # should fix
    "minor": int,          # nice to have
    "overall_confidence": float,   # 0-100
    "recommendation": str
  },
  "gaps": [
    {
      "id": "GAP-001",
      "severity": "critical" | "major" | "minor",
      "section": "2.1 In-Scope Functionality",
      "title": "Short gap title",
      "description": "What is missing and why it matters",
      "why_null_code": "not_mentioned" | "deferred_by_participants" | ...,
      "action": "Specific action the team must take",
      "owner": "Who should resolve this",
      "transcript_refs": [utterance_id, ...],
      "deadline": "Before sign-off" | "Next meeting" | "Phase 2"
    }
  ],
  "open_questions": [
    {
      "id": "Q-001",
      "question": str,
      "context": str,
      "raised_by": str,
      "urgency": "immediate" | "soon" | "later"
    }
  ],
  "uncaptured_risks": [
    {
      "id": "R-001",
      "risk": str,
      "evidence": str,
      "suggested_mitigation": str
    }
  ],
  "confidence_scores": {
    "section_name": float   # 0-100 per section
  }
}
"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json
import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, Optional

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

# ── Helpers ───────────────────────────────────────────────────────────────────

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)

def save_json(data: Any, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)

def to_str(obj: Any) -> str:
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)

def extract_json(text: str) -> Optional[Dict]:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    start = text.find("{")
    if start == -1:
        return None
    depth, end, in_string, escape = 0, -1, False, False
    for i, ch in enumerate(text[start:], start):
        if escape: escape = False; continue
        if ch == "\\": escape = True; continue
        if ch == '"' and not escape: in_string = not in_string; continue
        if in_string: continue
        if ch == "{": depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0: end = i + 1; break
    if end == -1: return None
    try:
        return json.loads(re.sub(r",\s*([}\]])", r"\1", text[start:end]))
    except Exception:
        return None


# ── BRD null section extractor ────────────────────────────────────────────────

def extract_null_sections(brd: dict) -> list[dict]:
    """Walk the BRD and collect every field that is null with its why_null code."""
    nulls = []

    def walk(node, path=""):
        if isinstance(node, dict):
            val     = node.get("value")
            why     = node.get("why_null")
            section = node.get("section_name", path)
            if val is None and why:
                nulls.append({"path": path, "why_null": why})
            for k, v in node.items():
                if k not in ("value", "why_null", "trace"):
                    walk(v, path=f"{path}.{k}" if path else k)
        elif isinstance(node, list):
            for item in node:
                walk(item, path)

    walk(brd)
    return nulls


# ── Chain 4 ───────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are a senior Business Analyst reviewing a BRD (Business Requirements Document).
Your job is to produce a structured Gap Analysis report.

You will receive:
1. The complete BRD JSON (with null sections marked with why_null codes)
2. The original meeting transcript
3. A list of null/incomplete sections detected automatically

Your tasks:
A. For every null section — assess severity (critical/major/minor) and what specific action fixes it
B. Surface open questions the team never resolved
C. Find risks discussed in the transcript that are NOT captured in the BRD
D. Score each major BRD section 0-100 for transcript confidence
   (100 = well-supported by multiple utterances, 0 = entirely inferred/missing)
E. Write a one-paragraph executive recommendation

Severity guide:
- critical: Project cannot proceed to development without this. Affects scope, budget, or delivery date.
- major: Significant gap that will cause problems in UAT or delivery if not resolved.
- minor: Nice to have, or can be deferred to a later phase without risk.

Output ONLY valid JSON matching this exact schema:
{{
  "summary": {{
    "total_gaps": <int>,
    "critical": <int>,
    "major": <int>,
    "minor": <int>,
    "overall_confidence": <0-100 float>,
    "recommendation": "<paragraph>"
  }},
  "gaps": [
    {{
      "id": "GAP-001",
      "severity": "critical|major|minor",
      "section": "<section name>",
      "title": "<10 word title>",
      "description": "<what is missing and why it matters>",
      "why_null_code": "<code>",
      "action": "<specific action the team must take>",
      "owner": "<role who should own this>",
      "transcript_refs": [<utterance_ids>],
      "deadline": "Before sign-off|Next meeting|Phase 2"
    }}
  ],
  "open_questions": [
    {{
      "id": "Q-001",
      "question": "<full question>",
      "context": "<what was said / what led to this>",
      "raised_by": "<speaker if known>",
      "urgency": "immediate|soon|later"
    }}
  ],
  "uncaptured_risks": [
    {{
      "id": "R-001",
      "risk": "<risk description>",
      "evidence": "<quote or reference from transcript>",
      "suggested_mitigation": "<concrete suggestion>"
    }}
  ],
  "confidence_scores": {{
    "<section name>": <0-100>
  }}
}}"""


def build_chain4(model):
    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human",
         "BRD JSON:\n{brd}\n\n"
         "Original Transcript (first 80 utterances):\n{transcript}\n\n"
         "Automatically detected null sections:\n{nulls}\n\n"
         "Produce the Gap Analysis JSON now:"),
    ])
    chain = (
        {
            "brd":        RunnableLambda(lambda x: to_str(x["brd"])),
            "transcript": RunnableLambda(lambda x: to_str(x["transcript"][:80])),
            "nulls":      RunnableLambda(lambda x: to_str(x["nulls"])),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(lambda t: extract_json(t) or _fallback_report(t))
    )
    return chain


def _fallback_report(raw_text: str) -> dict:
    """Return a minimal valid report if JSON parsing fails, preserving the raw text."""
    log.warning("Gap analyser: JSON parse failed, returning fallback report")
    return {
        "summary": {
            "total_gaps": 1,
            "critical": 0, "major": 1, "minor": 0,
            "overall_confidence": 50.0,
            "recommendation": "Gap analysis could not be fully parsed. Raw output preserved.",
        },
        "gaps": [{
            "id": "GAP-001", "severity": "major",
            "section": "General",
            "title": "Gap analysis output could not be parsed",
            "description": raw_text[:500],
            "why_null_code": "insufficient_detail",
            "action": "Re-run gap analysis",
            "owner": "Business Analyst",
            "transcript_refs": [],
            "deadline": "Before sign-off",
        }],
        "open_questions": [],
        "uncaptured_risks": [],
        "confidence_scores": {},
    }


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain4(cfg: Dict[str, Any]) -> str:
    llm_cfg   = cfg["llm"]
    chain_cfg = cfg["chains"]["chain4_gap_analyser"]

    model = ChatGoogleGenerativeAI(
        model=llm_cfg["model"],
        google_api_key=llm_cfg["api_key"],
        temperature=0.1,
        max_output_tokens=llm_cfg.get("max_tokens", 16384),
        response_mime_type="application/json",
    )

    brd_path        = chain_cfg["input"]["brd"]
    transcript_path = chain_cfg["input"]["transcript"]
    output_path     = chain_cfg["output"]["gap_report"]

    brd        = load_json(brd_path)
    transcript = load_json(transcript_path)
    nulls      = extract_null_sections(brd)

    log.info(f"📋 BRD sections: {len(brd)} | Null fields detected: {len(nulls)} | Transcript utterances: {len(transcript)}")

    chain4 = build_chain4(model)

    report = None
    for attempt in range(1, 4):
        try:
            log.info(f"🔄 Gap analyser attempt {attempt}/3…")
            result = chain4.invoke({"brd": brd, "transcript": transcript, "nulls": nulls})
            if result and isinstance(result, dict) and "summary" in result:
                report = result
                break
        except Exception as exc:
            log.warning(f"⚠️  Attempt {attempt} failed: {exc}")
            if attempt < 3:
                time.sleep(2 ** (attempt - 1))

    if not report:
        raise RuntimeError("Chain 4 (Gap Analyser) failed after 3 attempts")

    save_json(report, output_path)

    s = report["summary"]
    log.info(
        f"✅ Gap report saved → {output_path}\n"
        f"   Critical: {s['critical']} | Major: {s['major']} | Minor: {s['minor']}\n"
        f"   Confidence: {s['overall_confidence']:.0f}/100"
    )
    return output_path


if __name__ == "__main__":
    cfg  = resolve_cfg("configuration.yaml")
    path = run_chain4(cfg)
    report = load_json(path)
    s = report["summary"]
    print(
        f"\n🎯 Chain 4 Complete: {path}\n"
        f"   Total gaps : {s['total_gaps']}\n"
        f"   Critical   : {s['critical']}\n"
        f"   Major      : {s['major']}\n"
        f"   Minor      : {s['minor']}\n"
        f"   Confidence : {s['overall_confidence']:.0f}/100\n"
        f"\n📝 Recommendation:\n   {s['recommendation']}"
    )
