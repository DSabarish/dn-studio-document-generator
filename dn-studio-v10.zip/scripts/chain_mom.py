"""
chain_mom.py — Minutes of Meeting AI fill.
DN-Studio by DataNeurus

Thin wrapper around llm_filler.run_fill(mode="mom").

The MOM-specific prompts and two-pass logic now live in llm_filler.py.
This file preserves the original public signature so app.py needs no changes.
"""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cfg_utils import resolve_cfg
from llm_filler import run_fill

log = logging.getLogger(__name__)

MOM_ARTIFACTS = Path(__file__).resolve().parent.parent / "artifacts_library" / "MOM"


def run_mom_fill(
    cfg: Dict[str, Any],
    schema_path: str,
    output_path: str,
    transcript_override: Optional[str] = None,
) -> str:
    """
    Fill all MOM schema fields from the diarised transcript.

    Delegates to llm_filler.run_fill(mode="mom").
    Signature is preserved for backward compatibility with app.py.

    Args:
        cfg:                 Resolved configuration dict.
        schema_path:         Path to MOM schema_prompt.json.
        output_path:         Destination path for the filled JSON.
        transcript_override: Optional explicit transcript path (Playground use).

    Returns:
        *output_path* on success.
    """
    return run_fill(
        cfg                 = cfg,
        schema_path         = schema_path,
        output_path         = output_path,
        mode                = "mom",
        doc_type            = "MOM",
        transcript_override = transcript_override,
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Run MOM fill chain")
    parser.add_argument("output",   help="Path to write filled MOM JSON")
    parser.add_argument("--config", default="configuration.yaml")
    args = parser.parse_args()
    _cfg = resolve_cfg(args.config)
    run_mom_fill(_cfg, str(MOM_ARTIFACTS / "schema_prompt.json"), args.output)
    print(f"Done → {args.output}")
