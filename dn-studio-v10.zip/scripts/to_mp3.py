"""Convert audio files in experiment/input to MP3 format."""
import sys
import os
import glob
import logging

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pydub import AudioSegment
from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)

AUDIO_EXTENSIONS = {".mp4", ".wav", ".m4a", ".ogg", ".flac", ".aac", ".wma", ".webm"}


def convert(cfg: dict) -> int:
    paths = cfg.get("paths", {})
    input_dir = paths.get("input_dir", paths.get("mp3_dir", "mp3_output"))
    os.makedirs(input_dir, exist_ok=True)

    converted = 0
    for f in glob.glob(f"{input_dir}/*"):
        ext = os.path.splitext(f)[1].lower()
        if ext == ".mp3" or ext not in AUDIO_EXTENSIONS:
            continue
        out_name = f"{input_dir}/{os.path.splitext(os.path.basename(f))[0]}.mp3"
        log.info(f"  Converting: {os.path.basename(f)} → {os.path.basename(out_name)}")
        AudioSegment.from_file(f).export(out_name, format="mp3")
        converted += 1

    log.info(f"  Done: {converted} file(s) converted.")
    return converted


if __name__ == "__main__":
    convert(resolve_cfg("configuration.yaml"))
