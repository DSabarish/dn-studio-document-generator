"""
diarize.py — Speaker-labelled transcript from MP3 audio.
DN-Studio by DataNeurus — v2

Improvements:
  - AgglomerativeClustering (average cosine) as primary — better for uneven speakers
  - Dual speaker-count estimation: eigengap + linkage elbow, combined vote
  - Temporal connectivity: adjacent segments within 2s get a clustering pull
  - Orphan segment merging: short isolated segments reassigned to surrounding speaker  
  - Per-segment speaker confidence score
  - Spectral fallback for small n
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glob, json, logging, re, tempfile
from typing import Any, Dict, List, Optional, Tuple
import librosa, numpy as np, soundfile as sf
from faster_whisper import WhisperModel
from resemblyzer import VoiceEncoder, preprocess_wav
from scipy.ndimage import median_filter
from sklearn.cluster import AgglomerativeClustering, SpectralClustering
from sklearn.preprocessing import normalize
from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)
logging.getLogger("faster_whisper").setLevel(logging.WARNING)

_FILLERS   = re.compile(r"\b(um+|uh+|er+|ah+|like,?\s+|you know|i mean|sort of|kind of)\b", re.I)
_MIN_CHUNK = 0.4
_SAMPLE_RATE = 16_000


def clean_text(text):
    text = _FILLERS.sub(" ", text.strip())
    return re.sub(r"\s+", " ", text).strip().capitalize()


def transcribe(path, model_size, lang):
    device       = "cuda" if os.path.exists("/usr/local/cuda") else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"
    mdl          = WhisperModel(model_size, device=device, compute_type=compute_type)
    segs, _      = mdl.transcribe(path, language=lang, vad_filter=True)
    return [{"start":s.start,"end":s.end,"text":clean_text(s.text),
             "conf":float(np.clip(np.exp(s.avg_logprob),0,1))}
            for s in segs if clean_text(s.text)]


def extract_embeddings(path, segs):
    encoder  = VoiceEncoder("cpu")
    audio, _ = librosa.load(path, sr=_SAMPLE_RATE, mono=True)
    valid_idx, embeddings = [], []
    for i, seg in enumerate(segs):
        chunk = audio[int(seg["start"]*_SAMPLE_RATE):int(seg["end"]*_SAMPLE_RATE)]
        if len(chunk) < _SAMPLE_RATE * _MIN_CHUNK:
            continue
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            sf.write(tmp.name, chunk, _SAMPLE_RATE)
            try:
                wav = preprocess_wav(tmp.name)
                embeddings.append(encoder.embed_utterance(wav))
                valid_idx.append(i)
            except Exception as exc:
                log.debug(f"Skip seg {i}: {exc}")
            finally:
                os.unlink(tmp.name)
    return valid_idx, (np.array(embeddings,dtype=np.float32) if embeddings else np.empty((0,256)))


def estimate_n_speakers(X_norm, max_k=8, min_k=2):
    """Dual method: eigengap + agglomerative linkage elbow, vote on result."""
    n = len(X_norm)
    if n < 4:
        return min(min_k, n)

    # Method 1: eigengap on cosine affinity Laplacian
    eigengap_k = min_k
    try:
        A = np.clip(X_norm @ X_norm.T, 0, 1)
        np.fill_diagonal(A, 1.0)
        D_inv = np.diag(1.0/np.sqrt(np.maximum(A.sum(1),1e-10)))
        L = np.eye(n) - D_inv @ A @ D_inv
        eigvals = np.sort(np.abs(np.linalg.eigvalsh(L)))[:min(max_k+2,n)]
        gaps = np.diff(eigvals[1:])
        if len(gaps):
            norm_gaps = gaps / (gaps.mean()+1e-10)
            eigengap_k = max(min_k, min(max_k, int(np.argmax(norm_gaps))+2))
    except Exception as e:
        log.debug(f"Eigengap err: {e}")

    # Method 2: Ward linkage distance elbow
    linkage_k = min_k
    try:
        from scipy.cluster.hierarchy import linkage as sc_linkage
        dist = 1.0 - np.clip(X_norm @ X_norm.T, -1, 1)
        np.fill_diagonal(dist, 0)
        tri = dist[np.triu_indices(n, k=1)]
        Z = sc_linkage(tri, method="ward")
        merge_dists = Z[:, 2]
        if len(merge_dists) >= max_k:
            last = merge_dists[-(max_k+1):]
            mg = np.diff(last[::-1])
            if len(mg):
                linkage_k = max(min_k, min(max_k, int(np.argmax(mg))+2))
    except Exception as e:
        log.debug(f"Linkage err: {e}")

    # Vote
    if eigengap_k == linkage_k:
        k = eigengap_k
    elif abs(eigengap_k - linkage_k) == 1:
        k = min(eigengap_k, linkage_k)
    else:
        k = eigengap_k

    k = max(min_k, min(max_k, k))
    log.info(f"  🔍 Auto-detected {k} speakers (eigengap={eigengap_k}, linkage={linkage_k})")
    return k


def cluster_speakers(embs, n_speakers, timestamps=None):
    n = len(embs)
    if n < 2:
        return np.zeros(n, dtype=int)

    X = normalize(np.nan_to_num(embs, nan=0.0))
    k = estimate_n_speakers(X) if n_speakers is None else max(2, min(int(n_speakers), n))
    k = min(k, n)

    # Build temporal connectivity: adjacent segs within 2s get a pull
    connectivity = None
    if timestamps and len(timestamps) == n:
        try:
            from scipy.sparse import lil_matrix
            conn = lil_matrix((n, n))
            for i in range(n-1):
                gap = timestamps[i+1][0] - timestamps[i][1]
                if gap < 2.0:
                    conn[i, i+1] = 1
                    conn[i+1, i] = 1
            if conn.nnz > 0:
                connectivity = conn.tocsr()
        except Exception:
            connectivity = None

    labels = None
    # Primary: Agglomerative (average cosine)
    try:
        model = AgglomerativeClustering(
            n_clusters=k, metric="cosine", linkage="average",
            connectivity=connectivity)
        labels = model.fit_predict(X)
        log.info(f"  ✅ Clustered {n} segments → {k} speakers (agglomerative)")
    except Exception as exc:
        log.warning(f"  Agglomerative failed ({exc}), trying spectral")

    # Fallback: Spectral
    if labels is None:
        try:
            A = np.clip(X @ X.T, 0, 1)
            np.fill_diagonal(A, 1.0)
            labels = SpectralClustering(n_clusters=k, affinity="precomputed",
                assign_labels="kmeans", random_state=42, n_init=15).fit_predict(A)
            log.info(f"  ✅ Clustered {n} segments → {k} speakers (spectral)")
        except Exception as exc:
            log.error(f"  Clustering failed: {exc}")
            return np.zeros(n, dtype=int)

    # Smooth: median filter
    fs = max(3, min(9, n//15))
    labels = np.round(median_filter(labels.astype(float), size=fs)).astype(int)

    # Smooth: orphan merge (single seg sandwiched between same speaker, dur < 1.5s)
    if timestamps and len(timestamps) == n:
        for i in range(1, n-1):
            if labels[i-1] == labels[i+1] and labels[i] != labels[i-1]:
                dur = timestamps[i][1] - timestamps[i][0]
                if dur < 1.5:
                    labels[i] = labels[i-1]

    # Re-index in order of first appearance
    remap, counter = {}, 0
    out = np.zeros_like(labels)
    for i, lbl in enumerate(labels):
        if lbl not in remap:
            remap[lbl] = counter; counter += 1
        out[i] = remap[lbl]
    return out


def speaker_confidence(embs, labels):
    """Per-segment confidence: cosine similarity to speaker centroid."""
    X = normalize(np.nan_to_num(embs, nan=0.0))
    confs = np.ones(len(embs))
    for spk in np.unique(labels):
        mask = labels == spk
        centroid = normalize(X[mask].mean(axis=0, keepdims=True))[0]
        confs[mask] = np.clip(X[mask] @ centroid, 0, 1)
        mean_c = confs[mask].mean()
        log.info(f"    SPEAKER_{spk}: {mask.sum()} segs, conf={mean_c:.3f}")
    return confs


def run(cfg):
    paths  = cfg.get("paths", {})
    diar   = cfg.get("diarization", {})
    input_dir     = paths.get("input_dir", paths.get("mp3_dir", "mp3_output"))
    output_file   = diar.get("output_file", "diarization_result.json")
    whisper_model = diar.get("whisper_model", "tiny")
    language      = diar.get("language", "en")
    num_speakers  = diar.get("num_speakers")

    if num_speakers is None:
        log.info("🔍 Speaker count: AUTO-DETECT (eigengap + linkage dual method)")
    else:
        log.info(f"👥 Speaker count: {num_speakers} (manual)")

    mp3s = glob.glob(f"{input_dir}/*.mp3")
    if not mp3s:
        raise FileNotFoundError(f"No MP3 files found in: {input_dir}")

    results = []
    for audio_path in mp3s:
        log.info(f"🎤 Processing: {os.path.basename(audio_path)}")
        segs = transcribe(audio_path, whisper_model, language)
        if not segs:
            log.warning("No speech segments detected."); continue

        log.info(f"  📝 {len(segs)} segments transcribed")
        valid_idx, embs = extract_embeddings(audio_path, segs)
        log.info(f"  🎵 {len(embs)} embeddings extracted")

        if len(embs) >= 2:
            timestamps = [(segs[i]["start"], segs[i]["end"]) for i in valid_idx]
            labels     = cluster_speakers(embs, num_speakers, timestamps)
            confs      = speaker_confidence(embs, labels)
            for rank, seg_i in enumerate(valid_idx):
                spk = f"SPEAKER_{labels[rank]}"
                segs[seg_i].update({"speaker_id":spk,"speaker_name":spk,
                                    "spk_conf":round(float(confs[rank]),3)})

        for uid, seg in enumerate(segs):
            seg.setdefault("speaker_id",   "SPEAKER_0")
            seg.setdefault("speaker_name", seg["speaker_id"])
            seg.setdefault("spk_conf",     1.0)
            results.append({"start":round(seg["start"],3),"end":round(seg["end"],3),
                "utterance_id":uid,"speaker_id":seg["speaker_id"],
                "speaker_name":seg["speaker_name"],"confidence":round(seg["conf"],3),
                "spk_confidence":round(seg["spk_conf"],3),"text":seg["text"]})

    out_dir = os.path.dirname(output_file)
    if out_dir: os.makedirs(out_dir, exist_ok=True)
    with open(output_file,"w",encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    n_spk = len({r["speaker_id"] for r in results})
    log.info(f"✅ Saved {len(results)} segments, {n_spk} speakers → {output_file}")
    return results


if __name__ == "__main__":
    run(resolve_cfg("configuration.yaml"))
