# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/server.py
# PURPOSE: FastAPI server — all endpoints the React frontend calls.
# RUN:     uvicorn backend.server:app --host 0.0.0.0 --port 8000 --reload
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import asyncio
import logging
import tempfile
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional, AsyncIterator

import yaml
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

log = logging.getLogger("dn_studio.server")
logging.basicConfig(
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S", level=logging.INFO,
)

app = FastAPI(title="DN-Studio API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    # allow_credentials cannot be True when allow_origins=["*"] — browsers reject it.
    # We don't use cookies/session auth so credentials=False is correct.
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

CONFIG_PATH = Path("config/document_types.yaml")

# ─────────────────────────────────────────────────────────────────────────────
# PYDANTIC MODELS
# ─────────────────────────────────────────────────────────────────────────────

class GenerateRequest(BaseModel):
    doc_type: str
    diarisation_json: list
    business_context: str = ""
    h1_sections: str = ""
    gemini_api_key: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# IN-MEMORY STATE
# ─────────────────────────────────────────────────────────────────────────────

# Diarisation job progress  { job_id: { "logs": [...], "pct": 0-100, "done": bool, "result": {} } }
_diar_jobs: dict = {}

# Document generation jobs  { job_id: { "logs": [...], "result": {}, "done": bool } }
_gen_jobs: dict = {}


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _load_doc_types() -> dict:
    with open(CONFIG_PATH, "r") as f:
        return yaml.safe_load(f)


def _set_api_key(key: Optional[str]):
    if key:
        os.environ["GOOGLE_API_KEY"] = key


def _sse(data: dict) -> str:
    return "data: " + json.dumps(data) + "\n\n"


# ─────────────────────────────────────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# JOB STORE CLEANUP — keep only last 20 completed jobs to prevent memory leak
# ─────────────────────────────────────────────────────────────────────────────
MAX_STORED_JOBS = 20

def _cleanup_jobs(store: dict):
    """Remove oldest completed jobs when store exceeds MAX_STORED_JOBS."""
    done_ids = [jid for jid, j in store.items()
                if (j.get("done") or j.get("result", {}).get("status") in ("complete", "error", "success"))]
    if len(done_ids) > MAX_STORED_JOBS:
        for jid in done_ids[:len(done_ids) - MAX_STORED_JOBS]:
            store.pop(jid, None)
        log.debug("[SERVER] Cleaned up %d old jobs", len(done_ids) - MAX_STORED_JOBS)


@app.get("/health")
async def health():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}


# ─────────────────────────────────────────────────────────────────────────────
# DOCUMENT TYPES
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/document-types")
async def get_document_types():
    log.info("[SERVER] GET /document-types")
    try:
        cfg    = _load_doc_types()
        result = []
        for key, val in cfg.items():
            result.append({
                "id":              key,
                "label":           val.get("label", key),
                "description":     val.get("description", ""),
                "llm_calls":       val.get("llm_calls", 1),
                "output_filename": val.get("output_filename", "output.docx"),
            })
        return {"document_types": result}
    except Exception as e:
        log.error("[SERVER] Failed to load doc types: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — DIARISATION  (with SSE progress stream)
# ─────────────────────────────────────────────────────────────────────────────

DIAR_STEPS = [
    (5,  "Converting audio to WAV…"),
    (15, "Loading Whisper model…"),
    (35, "Transcribing speech…"),
    (55, "Extracting speaker embeddings…"),
    (70, "Running speaker clustering…"),
    (82, "Computing t-SNE…"),
    (90, "Writing diarization_response.json…"),
    (95, "Building HTML view…"),
    (100,"Diarisation complete ✓"),
]


def _run_diarisation_job(job_id: str, audio_path: str, config: dict):
    """Background task — calls run_diarisation() with progress_callback."""
    job = _diar_jobs[job_id]

    def progress(pct: int, msg: str):
        job["logs"].append(msg)
        job["pct"]  = pct

    try:
        from backend.diarisation import run_diarisation

        result = run_diarisation(
            audio_path        = audio_path,
            config            = config,
            progress_callback = progress,
        )

        json_path = result["json_path"]
        html_path = result["html_path"]
        segments  = json.loads(Path(json_path).read_text(encoding="utf-8"))
        speakers  = list(set(s["speaker_id"] for s in segments))
        duration  = max(s["end"] for s in segments) if segments else 0

        job["result"] = {
            "status":       "success",
            "filename":     Path(audio_path).name,
            "n_utterances": len(segments),
            "n_speakers":   len(speakers),
            "duration_sec": round(duration),
            "model":        config.get("whisper_model", "base.en"),
            "segments":     segments,
            "json_path":    json_path,
            "html_path":    html_path,
        }

    except Exception as e:
        log.error("[DIAR][%s] Failed: %s", job_id, e)
        job["logs"].append("ERROR: " + str(e))
        job["pct"]    = -1
        job["result"] = {"status": "error", "error": str(e)}

    finally:
        job["done"] = True
        try:
            os.unlink(audio_path)
        except Exception:
            pass


@app.post("/diarise")
async def diarise(
    background_tasks: BackgroundTasks,
    audio_file:      UploadFile        = File(...),
    whisper_model:   str               = Form("base.en"),
    num_speakers:    Optional[str]     = Form(None),
    remove_fillers:  bool              = Form(True),
    remove_stutters: bool              = Form(True),
):
    """
    Upload audio/video → start diarisation job.
    Returns job_id immediately. Stream progress via /diarise/stream/{job_id}.
    """
    log.info("[SERVER] POST /diarise  file=%s  model=%s", audio_file.filename, whisper_model)

    suffix   = Path(audio_file.filename).suffix if audio_file.filename else ".mp3"
    tmp      = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
    content  = await audio_file.read()
    tmp.write(content)
    tmp.close()

    log.info("[SERVER] Audio saved  %.1f MB", len(content) / 1024 / 1024)

    num_spk = None
    if num_speakers and num_speakers.strip().isdigit():
        num_spk = int(num_speakers)

    job_id = datetime.now().strftime("%Y%m%d_%H%M%S_") + "diar_" + __import__("uuid").uuid4().hex[:6]
    _cleanup_jobs(_diar_jobs)
    _diar_jobs[job_id] = {"logs": [], "pct": 0, "done": False, "result": {}}

    config = {
        "whisper_model":   whisper_model,
        "num_speakers":    num_spk,
        "remove_fillers":  remove_fillers,
        "remove_stutters": remove_stutters,
        "output_dir":      "outputs/diarisation",
        "roster":          [],
        "max_speakers":    8,
        "smooth_window":   3,
        "pca_variance":    0.99,
    }

    background_tasks.add_task(_run_diarisation_job, job_id, tmp.name, config)

    return {"job_id": job_id, "status": "started"}


@app.get("/diarise/stream/{job_id}")
async def stream_diarisation(job_id: str):
    """
    SSE stream — emits { pct, log, done, result } events.
    Frontend listens with EventSource to show real progress bar.
    """
    if job_id not in _diar_jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    async def _gen() -> AsyncIterator[str]:
        sent_logs  = 0
        last_pct   = -1
        last_ping  = asyncio.get_event_loop().time()
        PING_EVERY = 15   # seconds — keeps localtunnel connection alive

        while True:
            job  = _diar_jobs[job_id]
            logs = job["logs"]
            pct  = job["pct"]
            now  = asyncio.get_event_loop().time()

            # Emit new log lines
            while sent_logs < len(logs):
                yield _sse({"log": logs[sent_logs], "pct": pct})
                sent_logs += 1
                last_ping = now

            # Emit pct update even if no new log
            if pct != last_pct:
                yield _sse({"pct": pct})
                last_pct  = pct
                last_ping = now

            # Keepalive ping — empty comment line so localtunnel doesn't close
            if now - last_ping >= PING_EVERY:
                yield ": keepalive\n\n"
                last_ping = now

            # Check done BEFORE sleeping — fast jobs (< 0.4s) must not be missed
            if job["done"]:
                yield _sse({"done": True, "pct": 100, "result": job["result"]})
                break

            await asyncio.sleep(0.25)

    return StreamingResponse(
        _gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/diarise/status/{job_id}")
async def diarise_status(job_id: str):
    if job_id not in _diar_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = _diar_jobs[job_id]
    return {"job_id": job_id, "pct": job["pct"], "done": job["done"],
            "logs": job["logs"], "result": job["result"]}


# ─────────────────────────────────────────────────────────────────────────────
# UPLOAD EXISTING JSON  — chunked read to handle large files
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/upload-json")
async def upload_json(request: Request):
    """
    Accept a raw JSON body (multipart or raw).
    Reads in chunks to avoid localtunnel 1 MB body limit timeout.
    Also accepts multipart/form-data with a json_file field.
    """
    log.info("[SERVER] POST /upload-json")

    content_type = request.headers.get("content-type", "")

    if "multipart/form-data" in content_type:
        # Multipart upload
        form     = await request.form()
        file_obj = form.get("json_file")
        if file_obj is None:
            raise HTTPException(status_code=400, detail="No json_file field in form")
        raw = await file_obj.read()
        filename = getattr(file_obj, "filename", "upload.json")
    else:
        # Raw body — read chunked
        chunks   = []
        async for chunk in request.stream():
            chunks.append(chunk)
        raw      = b"".join(chunks)
        filename = "diarization_response.json"

    log.info("[SERVER] JSON body received  %.1f KB", len(raw) / 1024)

    try:
        segments = json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail="Invalid JSON: " + str(e))

    speakers = list(set(s["speaker_id"] for s in segments))
    duration = max(s["end"] for s in segments) if segments else 0

    out_path = Path("outputs/diarisation/diarization_response.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(segments, indent=2, ensure_ascii=False))

    log.info("[SERVER] JSON saved  %d utterances  %d speakers", len(segments), len(speakers))

    return {
        "status":       "success",
        "filename":     filename,
        "n_utterances": len(segments),
        "n_speakers":   len(speakers),
        "duration_sec": round(duration),
        "model":        "uploaded",
        "segments":     segments,
        "json_path":    str(out_path),
        "html_path":    None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# DOWNLOADS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/download/diarisation-json")
async def download_diarisation_json():
    p = Path("outputs/diarisation/diarization_response.json")
    if not p.exists():
        raise HTTPException(status_code=404, detail="No diarisation JSON found")
    return FileResponse(str(p), filename="diarization_response.json",
                        media_type="application/json")


@app.get("/download/diarisation-html")
async def download_diarisation_html():
    p = Path("outputs/diarisation/diarization_view.html")
    if not p.exists():
        raise HTTPException(status_code=404, detail="No HTML view found")
    return FileResponse(str(p), filename="diarization_view.html",
                        media_type="text/html")


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2 — DOCUMENT GENERATION  (SSE streaming logs)
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/generate")
async def generate_document(req: GenerateRequest, background_tasks: BackgroundTasks):
    log.info("[SERVER] POST /generate  doc_type=%s", req.doc_type)
    _set_api_key(req.gemini_api_key)

    job_id = datetime.now().strftime("%Y%m%d_%H%M%S_") + req.doc_type + "_" + __import__("uuid").uuid4().hex[:6]
    _cleanup_jobs(_gen_jobs)
    _gen_jobs[job_id] = {"logs": [], "result": {"status": "running"}, "done": False, "metrics": {}}

    background_tasks.add_task(_run_generation_job, job_id, req)
    return {"job_id": job_id, "status": "started"}


async def _run_generation_job(job_id: str, req: GenerateRequest):
    job = _gen_jobs[job_id]

    def emit(msg):
        """
        Accept either a plain string log line OR a dict (structured SSE event).
        Plain strings go into job["logs"].
        Dicts with type=="metrics_update" go into job["metrics"].
        """
        if isinstance(msg, dict):
            if msg.get("type") == "metrics_update":
                job["metrics"] = msg["metrics"]
                log.info("[SERVER] Metrics update: tokens=%d cost=$%.4f",
                         msg["metrics"].get("total_tokens", 0),
                         msg["metrics"].get("total_cost_usd", 0))
        else:
            ts = "[" + datetime.now().strftime("%H:%M:%S") + "]  "
            job["logs"].append(ts + str(msg))
            log.info(str(msg))

    try:
        from backend.document_generator import generate_document as _gen
        result = _gen(
            doc_type         = req.doc_type,
            diarisation_json = req.diarisation_json,
            business_context = req.business_context,
            h1_sections      = req.h1_sections,
            log_callback     = emit,
        )
        # Merge metrics into result
        job["result"] = {**result, "status": "complete"}
        if "metrics" not in job["result"] and job.get("metrics"):
            job["result"]["metrics"] = job["metrics"]
    except Exception as e:
        job["result"] = {"status": "error", "error": str(e)}
        emit("ERROR  " + str(e))
        log.error("[SERVER] Job %s failed: %s", job_id, e)
    finally:
        job["done"] = True


@app.get("/generate/status/{job_id}")
async def get_job_status(job_id: str):
    if job_id not in _gen_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = _gen_jobs[job_id]
    return {"job_id": job_id, "result": job["result"], "logs": job["logs"]}


@app.get("/generate/stream/{job_id}")
async def stream_job_logs(job_id: str):
    # FIX: validate job exists before creating the generator
    if job_id not in _gen_jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    async def _gen() -> AsyncIterator[str]:
        sent         = 0
        last_ping    = asyncio.get_event_loop().time()
        last_metrics = None
        PING_EVERY   = 15

        while True:
            job     = _gen_jobs.get(job_id, {})
            logs    = job.get("logs", [])
            metrics = job.get("metrics")
            now     = asyncio.get_event_loop().time()

            while sent < len(logs):
                yield _sse({"log": logs[sent]})
                sent      += 1
                last_ping  = now

            # Push metrics update whenever they change
            if metrics and metrics != last_metrics:
                yield _sse({"type": "metrics_update", "metrics": metrics})
                last_metrics = metrics
                last_ping    = now

            if now - last_ping >= PING_EVERY:
                yield ": keepalive\n\n"
                last_ping = now

            # Check done BEFORE sleeping — fast jobs must not be missed
            if job.get("done"):
                yield _sse({"done": True, "result": job["result"]})
                break

            await asyncio.sleep(0.25)

    return StreamingResponse(
        _gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# DOWNLOAD OUTPUTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/download/schema/{job_id}")
async def download_schema(job_id: str):
    p = (_gen_jobs.get(job_id) or {}).get("result", {}).get("schema_path")
    if not p or not Path(p).exists():
        raise HTTPException(status_code=404, detail="Schema not found")
    return FileResponse(str(p), filename="a_schema.json", media_type="application/json")


@app.get("/download/response/{job_id}")
async def download_response(job_id: str):
    p = (_gen_jobs.get(job_id) or {}).get("result", {}).get("response_path")
    if not p or not Path(p).exists():
        raise HTTPException(status_code=404, detail="Response not found")
    return FileResponse(str(p), filename="b_response.json", media_type="application/json")


@app.get("/download/docx/{job_id}")
async def download_docx(job_id: str):
    result   = (_gen_jobs.get(job_id) or {}).get("result", {})
    p        = result.get("docx_path")
    doc_type = result.get("doc_type", "output")
    if not p or not Path(p).exists():
        raise HTTPException(status_code=404, detail="DOCX not found")
    return FileResponse(
        str(p), filename=doc_type + "_output.docx",
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )


# ─────────────────────────────────────────────────────────────────────────────
# SERVE BUILT FRONTEND
# ─────────────────────────────────────────────────────────────────────────────

frontend_dist = Path("frontend/dist")
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="frontend")
    log.info("[SERVER] Serving built frontend from %s", frontend_dist)
