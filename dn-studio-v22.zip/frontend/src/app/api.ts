// ─────────────────────────────────────────────────────────────────────────────
// FILE: frontend/src/app/api.ts
// ─────────────────────────────────────────────────────────────────────────────

export const API_BASE_URL =
  (import.meta.env.VITE_API_URL as string) ||
  (typeof window !== 'undefined' && window.location.hostname !== 'localhost'
    ? ''
    : 'http://localhost:8000');

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Segment {
  start: number;
  end: number;
  utterance_id: number;
  speaker_id: string;
  speaker_name: string;
  confidence: number;
  spk_confidence: number;
  text: string;
}

export interface DiarisationResult {
  status: string;
  filename: string;
  n_utterances: number;
  n_speakers: number;
  duration_sec: number;
  model: string;
  segments: Segment[];
  json_path: string;
  html_path: string | null;
}

export interface DiarProgress {
  pct: number;
  log?: string;
  done?: boolean;
  result?: DiarisationResult;
}

export interface DocumentType {
  id: string;
  label: string;
  description: string;
  llm_calls: number;
  output_filename: string;
}

export interface GenerateRequest {
  doc_type: string;
  diarisation_json: Segment[];
  business_context: string;
  h1_sections: string;
  gemini_api_key?: string;
}

export interface PhaseMetric {
  name: string;
  elapsed_sec: number;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  cost_usd: number;
}

export interface GenerationMetrics {
  phases: PhaseMetric[];
  total_tokens: number;
  total_cost_usd: number;
  total_elapsed_sec: number;
}

export interface JobStatus {
  job_id: string;
  result: {
    status: 'running' | 'complete' | 'error';
    doc_type: string;
    schema_path?: string;
    response_path?: string;
    docx_path?: string;
    error?: string;
    metrics?: GenerationMetrics;
  };
  logs: string[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Fetch with AbortController support — returns null if aborted. */
async function fetchJSON<T>(
  url: string,
  options: RequestInit = {},
  signal?: AbortSignal
): Promise<T> {
  const r = await fetch(url, { ...options, signal });
  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error((err as any).detail || r.statusText);
  }
  return r.json() as Promise<T>;
}

// ─── Health ──────────────────────────────────────────────────────────────────

export async function checkHealth(): Promise<boolean> {
  try {
    const r = await fetch(API_BASE_URL + '/health');
    return r.ok;
  } catch {
    return false;
  }
}

// ─── Document types ───────────────────────────────────────────────────────────

export async function getDocumentTypes(signal?: AbortSignal): Promise<DocumentType[]> {
  const data = await fetchJSON<{ document_types: DocumentType[] }>(
    API_BASE_URL + '/document-types',
    {},
    signal
  );
  return data.document_types;
}

// ─── Diarisation ─────────────────────────────────────────────────────────────

export async function startDiarisation(
  audioFile: File,
  config: {
    whisperModel: string;
    numSpeakers: number | null;
    removeFillers: boolean;
    removeStutters: boolean;
  },
  onUploadProgress?: (loaded: number, total: number) => void
): Promise<string> {
  const form = new FormData();
  form.append('audio_file', audioFile);
  form.append('whisper_model', config.whisperModel);
  if (config.numSpeakers !== null) form.append('num_speakers', String(config.numSpeakers));
  form.append('remove_fillers',  String(config.removeFillers));
  form.append('remove_stutters', String(config.removeStutters));

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE_URL + '/diarise');

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onUploadProgress) {
        onUploadProgress(e.loaded, e.total);
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText).job_id);
        } catch {
          reject(new Error('Invalid response from server'));
        }
      } else {
        try {
          reject(new Error(JSON.parse(xhr.responseText).detail || 'Upload failed'));
        } catch {
          reject(new Error('Upload failed: ' + xhr.statusText));
        }
      }
    };

    xhr.timeout   = 300_000; // 5 min — large audio files can take time
    xhr.onerror   = () => reject(new Error('Network error during upload'));
    xhr.ontimeout = () => reject(new Error('Upload timed out — file may be too large for the tunnel'));
    xhr.send(form);
  });
}

export function streamDiarisation(
  jobId: string,
  onProgress: (p: DiarProgress) => void,
  onDone: (result: DiarisationResult) => void,
  onError: (msg: string) => void
): () => void {
  let es: EventSource;
  let closed  = false;
  let retries = 0;
  const MAX_RETRY = 10;

  function connect() {
    es = new EventSource(API_BASE_URL + '/diarise/stream/' + jobId);

    es.onmessage = (e) => {
      if (!e.data || e.data.startsWith(':')) return;
      try {
        const data: DiarProgress = JSON.parse(e.data);
        retries = 0;
        onProgress(data);

        // FIX api.ts L1: fire onDone when done=true regardless of result presence
        if (data.done) {
          closed = true;
          es.close();
          if (data.result && data.result.status !== 'error') {
            onDone(data.result);
          } else if (data.result?.status === 'error') {
            onError((data.result as any).error || 'Diarisation failed on server');
          } else {
            onError('Diarisation completed but no result returned');
          }
        }
      } catch { /* ignore malformed SSE frames */ }
    };

    es.onerror = () => {
      es.close();
      if (closed) return;
      retries++;
      if (retries > MAX_RETRY) {
        onError('Connection lost after ' + MAX_RETRY + ' retries. Check server logs.');
        return;
      }
      setTimeout(connect, Math.min(1000 * retries, 5000));
    };
  }

  connect();
  return () => { closed = true; es?.close(); };
}

// ─── Upload existing JSON ─────────────────────────────────────────────────────

export async function uploadDiarisationJson(
  file: File,
  signal?: AbortSignal
): Promise<DiarisationResult> {
  const raw = await file.arrayBuffer();
  return fetchJSON<DiarisationResult>(
    API_BASE_URL + '/upload-json',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: raw,
    },
    signal
  );
}

// ─── Download URLs (no fetch — direct anchor href) ────────────────────────────

export function getDiarisationJsonUrl(): string {
  return API_BASE_URL + '/download/diarisation-json';
}
export function getDiarisationHtmlUrl(): string {
  return API_BASE_URL + '/download/diarisation-html';
}

// ─── Document generation ─────────────────────────────────────────────────────

export async function startGeneration(
  req: GenerateRequest,
  signal?: AbortSignal
): Promise<string> {
  const data = await fetchJSON<{ job_id: string }>(
    API_BASE_URL + '/generate',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req),
    },
    signal
  );
  return data.job_id;
}

export function streamJobLogs(
  jobId: string,
  onLog: (line: string) => void,
  onDone: (result: JobStatus['result']) => void,
  onError: (err: string) => void,
  onMetrics?: (metrics: GenerationMetrics) => void
): () => void {
  let es: EventSource;
  let closed  = false;
  let retries = 0;
  const MAX_RETRY = 10;

  function connect() {
    es = new EventSource(API_BASE_URL + '/generate/stream/' + jobId);
    es.onmessage = (e) => {
      if (!e.data || e.data.startsWith(':')) return;
      try {
        const data = JSON.parse(e.data);
        retries = 0;
        if (data.log) onLog(data.log);
        if (data.type === 'metrics_update' && data.metrics && onMetrics) {
          onMetrics(data.metrics);
        }
        if (data.done) {
          closed = true;
          es.close();
          onDone(data.result);
        }
      } catch { /* ignore */ }
    };
    es.onerror = () => {
      es.close();
      if (closed) return;
      retries++;
      if (retries > MAX_RETRY) { onError('Connection lost. Check server logs.'); return; }
      setTimeout(connect, Math.min(1000 * retries, 5000));
    };
  }

  connect();
  return () => { closed = true; es?.close(); };
}

export function getDownloadUrl(
  type: 'schema' | 'response' | 'docx',
  jobId: string
): string {
  return API_BASE_URL + '/download/' + type + '/' + jobId;
}
