// FILE: frontend/src/app/components/Sidebar.tsx
import { useState } from 'react';
import type { DiarisationResult } from '../api';

interface SidebarProps {
  currentStage: number;
  onStageChange: (stage: number) => void;
  hasDiarisation: boolean;
  hasDocument: boolean;
  diarisationData?: DiarisationResult | null;
  documentData?: any;
  geminiApiKey: string;
  onApiKeyChange: (key: string) => void;
}

export function Sidebar({
  currentStage, onStageChange,
  hasDiarisation, hasDocument,
  diarisationData, documentData,
  geminiApiKey, onApiKeyChange,
}: SidebarProps) {
  const [showKey, setShowKey] = useState(false);

  return (
    <div className="w-52 bg-[#1a1a1a] border-r border-[#2a2a2a] flex flex-col h-screen flex-shrink-0">

      {/* Logo */}
      <div className="p-4 border-b border-[#2a2a2a]">
        <div className="text-white font-semibold tracking-tight">DN-Studio</div>
        <div className="text-[#666] text-xs mt-0.5">v1.0 - Colab backend</div>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* Session nav */}
        <div className="p-4">
          <div className="text-[#555] text-[10px] uppercase tracking-widest mb-3">Session</div>
          {([
            { stage: 1, label: 'Diarisation', ready: hasDiarisation, locked: false },
            { stage: 2, label: 'Documents',   ready: hasDocument,    locked: !hasDiarisation },
          ] as const).map(({ stage, label, ready, locked }) => (
            <button key={stage}
              onClick={() => !locked && onStageChange(stage)}
              disabled={locked}
              title={locked ? 'Run diarisation first' : undefined}
              className={`w-full text-left px-3 py-2 rounded-lg mb-1.5 flex items-center gap-2.5 transition-all text-sm ${
                locked
                  ? 'text-[#444] cursor-not-allowed'
                  : currentStage === stage
                    ? 'bg-[#2a2a2a] text-white'
                    : 'text-[#999] hover:bg-[#222] hover:text-white'
              }`}>
              <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 transition-colors ${
                ready ? 'bg-green-500' : 'bg-[#3a3a3a]'
              }`} />
              <span>Stage {stage} - {label}</span>
            </button>
          ))}
        </div>

        {/* CTA: proceed to Stage 2 when diarisation ready but still on Stage 1 */}
        {hasDiarisation && currentStage === 1 && (
          <div className="px-4 pb-4">
            <button
              onClick={() => onStageChange(2)}
              className="w-full px-3 py-2 bg-white text-black rounded-lg text-xs font-semibold hover:bg-gray-100 transition">
              Generate document
            </button>
          </div>
        )}

        {/* State summary */}
        <div className="px-4 pb-4 border-t border-[#2a2a2a] pt-4">
          <div className="text-[#555] text-[10px] uppercase tracking-widest mb-3">State</div>

          <div className="mb-4">
            <div className="text-[#888] text-xs mb-1.5">Diarisation JSON</div>
            {hasDiarisation ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">
                  <span>loaded</span>
                </div>
                <div className="text-[#666] text-[10px] truncate" title={diarisationData?.filename}>
                  {diarisationData?.filename}
                </div>
                <div className="text-[#555] text-[10px]">
                  {diarisationData?.n_utterances} utt | {diarisationData?.n_speakers} spk
                </div>
              </div>
            ) : (
              <div className="text-[#555] text-[10px] px-2 py-1 bg-[#1e1e1e] rounded border border-[#2a2a2a]">
                none yet
              </div>
            )}
          </div>

          <div>
            <div className="text-[#888] text-xs mb-1.5">Last document</div>
            {hasDocument ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">
                  <span>{documentData?.type} ready</span>
                </div>
                <div className="text-[#555] text-[10px]">{documentData?.type}_output.docx</div>
              </div>
            ) : (
              <div className="text-[#555] text-[10px] px-2 py-1 bg-[#1e1e1e] rounded border border-[#2a2a2a]">
                none yet
              </div>
            )}
          </div>
        </div>

        {/* API key */}
        <div className="px-4 pb-4 border-t border-[#2a2a2a] pt-4">
          <div className="text-[#555] text-[10px] uppercase tracking-widest mb-2">Gemini API Key</div>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={geminiApiKey}
              onChange={e => onApiKeyChange(e.target.value)}
              placeholder="AIzaSy..."
              aria-label="Gemini API key"
              className="w-full bg-[#111] text-white text-xs border border-[#2a2a2a] rounded-lg px-2.5 py-1.5 pr-8 focus:outline-none focus:border-[#444] transition-colors placeholder:text-[#444]"
            />
            <button
              onClick={() => setShowKey(v => !v)}
              aria-label={showKey ? 'Hide API key' : 'Show API key'}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[#555] hover:text-[#888] transition text-xs">
              {showKey ? 'hide' : 'show'}
            </button>
          </div>
          {geminiApiKey && (
            <div className="mt-1.5 flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
              <span className="text-[#555] text-[10px]">key set</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-[#2a2a2a]">
        <div className="text-[#555] text-[10px] leading-relaxed">
          Gemini 2.5 Flash<br />
          <span className="inline-flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
            Colab runtime active
          </span>
        </div>
      </div>
    </div>
  );
}
