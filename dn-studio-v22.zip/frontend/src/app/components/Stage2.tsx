// FILE: frontend/src/app/components/Stage2.tsx

import { useState, useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';
import {
  getDocumentTypes,
  startGeneration,
  streamJobLogs,
  getDownloadUrl,
  type DocumentType,
  type DiarisationResult,
  type JobStatus,
  type GenerationMetrics,
} from '../api';

interface Stage2Props {
  onDocumentGenerate: (data: any) => void;
  diarisationData?: DiarisationResult | null;
  geminiApiKey?: string;
}

type PhaseStatus = 'pending' | 'running' | 'done' | 'error';

interface Phase {
  num: number;
  title: string;
  desc: string;
  status: PhaseStatus;
  elapsed_sec?: number;
  tokens?: number;
  cost_usd?: number;
}

// Estimated values per doc type for the cards (before generation)
const DOC_ESTIMATES: Record<string, { time: string; cost: string; pages: string; desc: string }> = {
  BPD: { time: '3-6 min', cost: '~$0.04', pages: '15-25 pages', desc: 'SAP process flows, AS-IS/TO-BE, business rules' },
  BRD: { time: '4-7 min', cost: '~$0.05', pages: '20-35 pages', desc: 'Functional requirements, scope, sign-off tables' },
  MOM: { time: '1-2 min', cost: '~$0.01', pages:  '4-8 pages',  desc: 'Action items, decisions, attendee summary' },
};

function fmtCost(usd: number): string {
  if (usd === 0) return '$0.00';
  if (usd < 0.001) return '$0.00';
  if (usd < 0.01)  return '$' + usd.toFixed(4);
  return '$' + usd.toFixed(3);
}

function fmtTokens(n: number): string {
  if (n === 0) return '-';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return String(n);
}

function fmtSec(s: number): string {
  const n = Math.max(0, s);
  if (n < 60) return n.toFixed(1) + 's';
  return Math.floor(n / 60) + 'm ' + String(Math.round(n % 60)).padStart(2, '0') + 's';
}

export function Stage2({ onDocumentGenerate, diarisationData, geminiApiKey }: Stage2Props) {
  const [docTypes,      setDocTypes]      = useState<DocumentType[]>([]);
  const [selectedType,  setSelectedType]  = useState('BPD');
  const [bizContext,    setBizContext]     = useState('');
  const [h1Sections,   setH1Sections]    = useState('Business Process Overview, Business Process Design, Business Process Flow');
  const [phases,        setPhases]        = useState<Phase[]>([]);
  const [logs,          setLogs]          = useState<string[]>([]);
  const [isGenerating,  setIsGenerating]  = useState(false);
  const [jobId,         setJobId]         = useState<string | null>(null);
  const [jobResult,     setJobResult]     = useState<JobStatus['result'] | null>(null);
  const [metrics,       setMetrics]       = useState<GenerationMetrics | null>(null);
  const [error,         setError]         = useState('');
  const [elapsedSec,    setElapsedSec]    = useState(0);

  const logEndRef   = useRef<HTMLDivElement>(null);
  const stopStream  = useRef<(() => void) | null>(null);
  const timerRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    getDocumentTypes()
      .then(types => { setDocTypes(types); if (types.length > 0) setSelectedType(types[0].id); })
      .catch(() => setDocTypes([
        { id: 'BPD', label: 'BPD', description: 'Business Process Document', llm_calls: 2, output_filename: 'BPD_output.docx' },
        { id: 'BRD', label: 'BRD', description: 'Business Requirement Document', llm_calls: 2, output_filename: 'BRD_output.docx' },
        { id: 'MOM', label: 'MOM', description: 'Minutes of Meeting', llm_calls: 1, output_filename: 'MOM_output.docx' },
      ]));
  }, []);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logs]);
  useEffect(() => () => { stopStream.current?.(); clearInterval(timerRef.current!); }, []);

  const selectedCfg = docTypes.find(d => d.id === selectedType);

  function buildInitialPhases(cfg: DocumentType): Phase[] {
    const p: Phase[] = [{
      num: 1,
      title: cfg.llm_calls >= 2 ? 'Schema design' : 'Document generation',
      desc: cfg.llm_calls >= 2 ? 'Analysing transcript - designing structure' : 'Analysing transcript - writing content',
      status: 'pending',
    }];
    if (cfg.llm_calls >= 2) {
      p.push({ num: 2, title: 'Content population', desc: 'Writing all sections from transcript', status: 'pending' });
    }
    p.push({ num: cfg.llm_calls >= 2 ? 3 : 2, title: 'DOCX render', desc: 'Assembling Word document', status: 'pending' });
    return p;
  }

  function applyMetricsToPhases(prev: Phase[], m: GenerationMetrics): Phase[] {
    const updated = [...prev];
    m.phases.forEach((pm, idx) => {
      if (idx < updated.length) {
        updated[idx] = {
          ...updated[idx],
          status:      'done',
          elapsed_sec: pm.elapsed_sec,
          tokens:      pm.total_tokens,
          cost_usd:    pm.cost_usd,
        };
        // FIX Stage2 L2: only advance next phase to running if it is still pending
        // (never downgrade done->running if metrics arrive out of order)
        const next = updated[idx + 1];
        if (next && next.status === 'pending') {
          updated[idx + 1] = { ...next, status: 'running' };
        }
      }
    });
    return updated;
  }

  function updatePhaseFromLog(line: string, prev: Phase[]): Phase[] {
    const updated = [...prev];
    if ((line.includes('Phase 1') || line.includes('Schema design') || line.includes('designing')) && !line.includes('complete')) {
      if (updated[0]?.status === 'pending') updated[0] = { ...updated[0], status: 'running' };
    } else if ((line.includes('Phase 2') || line.includes('Content population') || line.includes('writing')) && !line.includes('complete')) {
      const idx = updated.findIndex(p => p.title.includes('Content') || p.title.includes('generation'));
      if (idx >= 0 && updated[idx].status === 'pending') updated[idx] = { ...updated[idx], status: 'running' };
    } else if (line.includes('DOCX render') || line.includes('rendering Word')) {
      const last = updated.length - 1;
      if (updated[last]?.status === 'pending') updated[last] = { ...updated[last], status: 'running' };
    }
    return updated;
  }

  async function handleGenerate() {
    if (!diarisationData) { setError('No diarisation data. Go to Stage 1 first.'); return; }
    if (!selectedCfg) return;

    // FIX Stage2 L3: cancel any in-flight SSE stream before starting new generation
    stopStream.current?.();
    stopStream.current = null;
    clearInterval(timerRef.current!);

    setIsGenerating(true);
    setError('');
    setLogs([]);
    setJobResult(null);
    setMetrics(null);
    setElapsedSec(0);

    const initialPhases = buildInitialPhases(selectedCfg);
    setPhases(initialPhases.map((p, i) => i === 0 ? { ...p, status: 'running' } : p));

    try {
      const jid = await startGeneration({
        doc_type:         selectedType,
        diarisation_json: diarisationData.segments,
        business_context: bizContext,
        h1_sections:      h1Sections,
        gemini_api_key:   geminiApiKey,
      });
      setJobId(jid);

      // Timer starts after successful POST. 250ms interval for smooth display.
      startTimeRef.current = performance.now();
      timerRef.current = setInterval(() => {
        setElapsedSec((performance.now() - startTimeRef.current) / 1000);
      }, 250);

      stopStream.current = streamJobLogs(
        jid,
        (line) => {
          setLogs(prev => [...prev, line]);
          setPhases(prev => updatePhaseFromLog(line, prev));
        },
        (result) => {
          clearInterval(timerRef.current!);
          setIsGenerating(false);
          setJobResult(result);
          if (result.status === 'complete') {
            setPhases(prev => prev.map(p => ({ ...p, status: 'done' })));
            if (result.metrics) setMetrics(result.metrics);
            onDocumentGenerate({ type: selectedType, jobId: jid, ...result });
          } else if (result.status === 'error') {
            setError(result.error || 'Generation failed');
            setPhases(prev => {
              const u = [...prev];
              const ri = u.findIndex(p => p.status === 'running');
              if (ri >= 0) u[ri] = { ...u[ri], status: 'error' };
              return u;
            });
          }
        },
        (err) => { clearInterval(timerRef.current!); setError(err); setIsGenerating(false); },
        (m) => {
          setMetrics(m);
          setPhases(prev => applyMetricsToPhases(prev, m));
        }
      );
    } catch (e: any) {
      clearInterval(timerRef.current!);
      setError(e.message || 'Failed to start generation');
      setIsGenerating(false);
    }
  }

  function logColor(line: string): string {
    if (line.includes('ERROR') || line.includes('failed'))                         return '#f87171';
    if (line.includes('complete') || line.includes('Pipeline complete') || line.includes('done')) return '#6ee7b7';
    if (line.includes('tokens') || line.includes('$'))                             return '#a78bfa';
    if (line.includes('Phase') || line.includes('schema') || line.includes('content') || line.includes('render')) return '#60a5fa';
    return '#64748b';
  }

  const isComplete = jobResult?.status === 'complete';

  return (
    <div className="flex-1 bg-[#111] text-white overflow-auto">
      <div className="p-6 max-w-5xl">

        <h1 className="text-2xl font-bold mb-1">Stage 2 - Document generation</h1>
        <p className="text-[#888] text-sm mb-6">Using session JSON - no re-diarisation needed</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-lg text-red-400 text-sm">{error}</div>
        )}
        {!diarisationData && (
          <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded-lg text-yellow-400 text-sm">
            No diarisation data in session. Go to Stage 1 first.
          </div>
        )}

        {/* ── Document type selector ─────────────────────────────────────── */}
        <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a] mb-5">
          <h3 className="font-semibold mb-1">Document type</h3>
          <p className="text-[#888] text-xs mb-4">Select the document to generate from this transcript</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {docTypes.map(dt => {
              const e = DOC_ESTIMATES[dt.id] || { time: '3-5 min', cost: '~$0.04', pages: '~20 pages', desc: '' };
              return (
                <button key={dt.id} onClick={() => !isGenerating && setSelectedType(dt.id)}
                  className={`p-4 rounded-xl border-2 transition-all text-left ${
                    selectedType === dt.id ? 'border-white bg-[#2a2a2a]' : 'border-[#2a2a2a] hover:border-[#444]'
                  } ${isGenerating ? 'cursor-not-allowed opacity-60' : ''}`}>
                  <div className="font-bold text-base mb-1">{dt.label}</div>
                  <div className="text-[#888] text-[11px] leading-relaxed">
                    <div>{e.desc}</div>
                    <div className="mt-1.5 flex gap-2 flex-wrap">
                      <span className="text-[#60a5fa]">{e.time}</span>
                      <span className="text-[#a78bfa]">{e.cost}</span>
                      <span className="text-[#666]">{e.pages}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── Config ─────────────────────────────────────────────────────── */}
        {selectedCfg && (
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a] mb-5">
            <h3 className="font-semibold mb-1">{selectedType} config</h3>
            <p className="text-[#888] text-xs mb-4">Business context is injected into all prompts</p>
            <div className="mb-4">
              <label className="text-[#888] text-xs block mb-2">Business context</label>
              <textarea value={bizContext} onChange={e => setBizContext(e.target.value)}
                className="w-full bg-[#0f0f0f] text-white border border-[#2a2a2a] rounded-lg px-3 py-2 text-sm min-h-[80px] resize-none focus:outline-none focus:border-[#444]"
                placeholder="e.g. Refund automation for utility customers with eligibility rules and batch processing in SAP..." />
            </div>
            {selectedCfg.llm_calls >= 2 && (
              <div>
                <label className="text-[#888] text-xs block mb-2">H1 section names (comma-separated)</label>
                <input value={h1Sections} onChange={e => setH1Sections(e.target.value)}
                  className="w-full bg-[#0f0f0f] text-white border border-[#2a2a2a] rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#444]" />
              </div>
            )}
          </div>
        )}

        {/* ── Generation panel ───────────────────────────────────────────── */}
        <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden mb-5">

          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#2a2a2a]">
            <div>
              <h3 className="font-semibold">Generation log</h3>
              {isGenerating && (
                <p className="text-[#888] text-xs mt-0.5">Running for {fmtSec(elapsedSec)}</p>
              )}
            </div>
            <button onClick={handleGenerate} disabled={isGenerating || !diarisationData}
              className={`px-5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 text-sm ${
                isGenerating || !diarisationData
                  ? 'bg-[#2a2a2a] text-[#555] cursor-not-allowed'
                  : 'bg-white text-black hover:bg-gray-100'
              }`}>
              {isGenerating && <Loader2 size={14} className="animate-spin" />}
              {isGenerating ? 'Generating...' : 'Generate ' + selectedType}
            </button>
          </div>

          {phases.length > 0 && (
            <div className="p-6">

              {/* ── Live metrics bar ────────────────────────────────────── */}
              {(isGenerating || metrics) && (
                <div className="grid grid-cols-4 gap-3 mb-6">
                  {[
                    { label: 'Elapsed',    value: fmtSec(metrics?.total_elapsed_sec ?? elapsedSec), sub: 'wall-clock time' },
                    { label: 'Tokens in',  value: fmtTokens((metrics?.phases ?? []).reduce((s,p) => s + p.input_tokens, 0)), sub: 'input tokens' },
                    { label: 'Tokens out', value: fmtTokens((metrics?.phases ?? []).reduce((s,p) => s + p.output_tokens, 0)), sub: 'output tokens' },
                    { label: 'Cost',       value: metrics ? fmtCost(metrics.total_cost_usd) : '-', sub: 'USD - Gemini 2.5 Flash' },
                  ].map(({ label, value, sub }) => (
                    <div key={label} className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-lg p-3 text-center">
                      <div className="text-[#888] text-[10px] uppercase tracking-wider mb-1">{label}</div>
                      <div className={`text-lg font-bold font-mono ${
                        label === 'Cost' ? 'text-[#a78bfa]' :
                        label === 'Elapsed' ? 'text-[#60a5fa]' :
                        'text-white'
                      }`}>
                        {isGenerating && value === '-' ? (
                          <span className="inline-block w-4 h-4 border-2 border-[#333] border-t-white rounded-full animate-spin" />
                        ) : value}
                      </div>
                      <div className="text-[#555] text-[10px] mt-0.5">{sub}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* ── Phase steps ─────────────────────────────────────────── */}
              <div className="space-y-3 mb-5">
                {phases.map(p => (
                  <div key={p.num} className="flex items-start gap-4">
                    {/* Status dot */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0 font-bold border ${
                      p.status === 'done'    ? 'bg-green-900/30 text-green-400 border-green-800' :
                      p.status === 'running' ? 'bg-blue-900/30 text-blue-400 border-blue-800 animate-pulse' :
                      p.status === 'error'   ? 'bg-red-900/30 text-red-400 border-red-800' :
                                               'bg-[#111] text-[#555] border-[#2a2a2a]'
                    }`}>
                      {p.status === 'running' ? <Loader2 size={14} className="animate-spin" /> :
                       p.status === 'done'    ? 'OK' : p.num}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <p className={`font-semibold text-sm ${
                            p.status === 'done' ? 'text-white' :
                            p.status === 'running' ? 'text-blue-300' : 'text-[#555]'
                          }`}>{p.title}</p>
                          <p className="text-[#555] text-xs mt-0.5">{p.desc}</p>
                        </div>

                        {/* Per-phase metrics badge */}
                        {p.status === 'done' && p.elapsed_sec !== undefined && (
                          <div className="flex items-center gap-2 flex-shrink-0">
                            {p.tokens !== undefined && p.tokens > 0 && (
                              <span className="text-[#666] text-xs font-mono">{fmtTokens(p.tokens)} tok</span>
                            )}
                            {p.cost_usd !== undefined && p.cost_usd > 0 && (
                              <span className="text-[#a78bfa] text-xs font-mono">{fmtCost(p.cost_usd)}</span>
                            )}
                            <span className="bg-green-900/30 text-green-400 text-xs px-2 py-0.5 rounded font-mono border border-green-900">
                              {fmtSec(p.elapsed_sec)}
                            </span>
                          </div>
                        )}
                        {p.status === 'running' && (
                          <span className="bg-blue-900/30 text-blue-400 text-xs px-2 py-0.5 rounded border border-blue-900 animate-pulse">
                            running...
                          </span>
                        )}
                        {p.status === 'pending' && (
                          <span className="text-[#333] text-xs px-2 py-0.5 rounded border border-[#2a2a2a]">pending</span>
                        )}
                        {p.status === 'error' && (
                          <span className="bg-red-900/30 text-red-400 text-xs px-2 py-0.5 rounded border border-red-900">error</span>
                        )}
                      </div>

                      {p.status === 'running' && (
                        <div className="mt-2 h-0.5 bg-[#2a2a2a] rounded overflow-hidden">
                          <div className="h-full bg-blue-500 rounded animate-pulse" style={{ width: '65%' }} />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* ── Log terminal ────────────────────────────────────────── */}
              <div className="bg-[#080808] rounded-lg p-4 font-mono text-[11px] max-h-40 overflow-y-auto border border-[#1e1e1e]">
                {logs.length === 0
                  ? <div className="text-[#333]">Waiting for logs...</div>
                  : logs.map((line, i) => (
                    <div key={i} style={{ color: logColor(line) }} className="leading-relaxed">{line}</div>
                  ))
                }
                <div ref={logEndRef} />
              </div>
            </div>
          )}

          {phases.length === 0 && (
            <div className="p-12 text-center text-[#444] text-sm">
              Click "Generate {selectedType}" to start.
            </div>
          )}
        </div>

        {/* ── Completion summary card ─────────────────────────────────────── */}
        {isComplete && metrics && jobId && (
          <div className="bg-[#0c1a0c] border border-green-900/50 rounded-xl p-6 mb-5">
            <div className="flex items-start justify-between mb-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-green-400 text-lg">Done</span>
                  <h3 className="font-bold text-white text-lg">{selectedType} generated successfully</h3>
                </div>
                <p className="text-[#888] text-sm">Ready to download - All sections populated from transcript</p>
              </div>
            </div>

            {/* Summary metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
              {[
                { label: 'Total time',    value: fmtSec(metrics.total_elapsed_sec),         color: 'text-[#60a5fa]' },
                { label: 'Total tokens',  value: metrics.total_tokens.toLocaleString(),      color: 'text-white' },
                { label: 'Total cost',    value: fmtCost(metrics.total_cost_usd),            color: 'text-[#a78bfa]' },
                { label: 'LLM calls',     value: String(metrics.phases.filter(p => p.cost_usd > 0).length), color: 'text-white' },
              ].map(({ label, value, color }) => (
                <div key={label} className="bg-[#111] border border-green-900/30 rounded-lg p-3 text-center">
                  <div className="text-[#666] text-[10px] uppercase tracking-wider mb-1">{label}</div>
                  <div className={`text-xl font-bold font-mono ${color}`}>{value}</div>
                </div>
              ))}
            </div>

            {/* Phase breakdown */}
            <div className="bg-[#0a0a0a] rounded-lg p-4 mb-5 border border-[#1a2a1a]">
              <div className="text-[#666] text-xs uppercase tracking-wider mb-3">Phase breakdown</div>
              <div className="space-y-2">
                {metrics.phases.map((p, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-[#888]">{p.name}</span>
                    <div className="flex items-center gap-4 font-mono text-xs">
                      {p.total_tokens > 0 && <span className="text-[#666]">{fmtTokens(p.total_tokens)} tokens</span>}
                      {p.cost_usd > 0     && <span className="text-[#a78bfa]">{fmtCost(p.cost_usd)}</span>}
                      <span className="text-[#60a5fa]">{fmtSec(p.elapsed_sec)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Value framing - the "money slide" */}
            <div className="bg-[#111] rounded-lg p-4 mb-5 border border-[#2a2a2a]">
              <div className="text-[#555] text-xs uppercase tracking-wider mb-2">Value delivered</div>
              <p className="text-[#aaa] text-sm">
                A senior Business Analyst would typically spend <strong className="text-white">2-3 days</strong> researching,
                structuring and writing this document manually.
                DN-Studio produced it from your meeting recording in{' '}
                <strong className="text-[#60a5fa]">{fmtSec(metrics.total_elapsed_sec)}</strong> for{' '}
                <strong className="text-[#a78bfa]">{fmtCost(metrics.total_cost_usd)}</strong> in AI compute cost.
              </p>
            </div>

            {/* Download button - large and prominent */}
            <div className="flex gap-3">
              {jobResult?.docx_path && (
                <a href={getDownloadUrl('docx', jobId)} download={selectedType + '_output.docx'}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-white text-black rounded-xl font-bold text-base hover:bg-gray-100 transition">
                  Download {selectedType}.docx
                </a>
              )}
              {jobResult?.schema_path && (
                <a href={getDownloadUrl('schema', jobId)} download="a_schema.json"
                  className="px-5 py-4 bg-[#1a1a1a] text-[#888] border border-[#2a2a2a] rounded-xl text-sm hover:text-white transition">
                  a_schema.json
                </a>
              )}
              {jobResult?.response_path && (
                <a href={getDownloadUrl('response', jobId)} download="b_response.json"
                  className="px-5 py-4 bg-[#1a1a1a] text-[#888] border border-[#2a2a2a] rounded-xl text-sm hover:text-white transition">
                  b_response.json
                </a>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
