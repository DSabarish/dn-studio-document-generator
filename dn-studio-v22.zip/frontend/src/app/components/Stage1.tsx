// FILE: frontend/src/app/components/Stage1.tsx

import { useState, useRef, useEffect } from 'react';
import { Upload, ChevronDown } from 'lucide-react';
import {
  startDiarisation,
  streamDiarisation,
  uploadDiarisationJson,
  getDiarisationJsonUrl,
  getDiarisationHtmlUrl,
  type DiarisationResult,
  type Segment,
} from '../api';

interface Stage1Props {
  onDiarisationComplete: (data: DiarisationResult) => void;
  onClearSession: () => void;
  existingResult?: DiarisationResult | null;
}

// These map exactly to the pct values emitted by backend/diarisation.py run_diarisation()
const PIPELINE_STEPS = [
  { pct: 5,   label: 'Converting audio to WAV' },
  { pct: 15,  label: 'Loading Whisper model' },
  { pct: 20,  label: 'Transcribing speech' },
  { pct: 50,  label: 'Extracting speaker embeddings' },
  { pct: 70,  label: 'Running speaker clustering' },
  { pct: 82,  label: 'Computing t-SNE' },
  { pct: 90,  label: 'Writing diarization JSON' },
  { pct: 95,  label: 'Building HTML view' },
  { pct: 100, label: 'Complete' },
];

const SPK_COLORS = ['#8b5cf6','#10b981','#f97316','#eab308','#3b82f6','#ec4899','#06b6d4','#84cc16'];

type ProcessPhase = 'idle' | 'uploading' | 'processing' | 'done';
type ActiveTab    = 'preview' | 'utterances' | 'json';

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}
function fmtDur(sec: number): string {
  const n = Math.max(0, sec);
  if (n >= 60) return Math.floor(n / 60) + 'm ' + String(Math.round(n % 60)).padStart(2,'0') + 's';
  return Math.round(n) + 's';
}
function confColor(c: number): string {
  if (c >= 0.85) return '#22c55e';
  if (c >= 0.65) return '#f59e0b';
  return '#ef4444';
}
function confLabel(c: number): string {
  if (c >= 0.85) return 'high';
  if (c >= 0.65) return 'med';
  return 'low';
}

export function Stage1({ onDiarisationComplete, onClearSession, existingResult }: Stage1Props) {

  // ── Processing state ──────────────────────────────────────────────────────
  const [isDragging,    setIsDragging]    = useState(false);
  const [phase,         setPhase]         = useState<ProcessPhase>('idle');
  const [uploadPct,     setUploadPct]     = useState(0);
  const [pipelinePct,   setPipelinePct]   = useState(0);   // 0-100 from SSE (pipeline only)
  const [uploadStatus,  setUploadStatus]  = useState('');  // top status msg during upload
  const [pipelineMsg,   setPipelineMsg]   = useState('');  // current pipeline step label
  const [logLines,      setLogLines]      = useState<string[]>([]);
  const [error,         setError]         = useState('');
  const [processingSec, setProcessingSec] = useState(0);

  // ── Config state ──────────────────────────────────────────────────────────
  const [whisperModel,   setWhisperModel]   = useState('base.en');
  const [speakerCount,   setSpeakerCount]   = useState('auto');
  const [removeFillers,  setRemoveFillers]  = useState(true);
  const [removeStutters, setRemoveStutters] = useState(true);

  // ── Output state ──────────────────────────────────────────────────────────
  const [activeTab,   setActiveTab]   = useState<ActiveTab>('preview');
  const [audioSrc,    setAudioSrc]    = useState<string | null>(null);
  const [audioDur,    setAudioDur]    = useState(0);
  const [audioTime,   setAudioTime]   = useState(0);
  const [activeUttId, setActiveUttId] = useState<number | null>(null);

  // ── Speaker renaming ──────────────────────────────────────────────────────
  const [nameMap,     setNameMap]     = useState<Record<string, string>>({});
  const [editingSp,   setEditingSp]   = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  // ── Refs ──────────────────────────────────────────────────────────────────
  const audioRef      = useRef<HTMLAudioElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef  = useRef<HTMLInputElement>(null);
  const jsonInputRef  = useRef<HTMLInputElement>(null);
  const stopStream    = useRef<(() => void) | null>(null);
  const logEndRef     = useRef<HTMLDivElement>(null);
  const uttRefs       = useRef<Record<number, HTMLDivElement | null>>({});
  const timerRef      = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef      = useRef<number>(0);
  // Used to avoid redundant setState on every 16ms audio tick
  const audioTimeRef   = useRef(0);
  const activeUttIdRef = useRef<number | null>(null);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logLines]);

  useEffect(() => () => {
    stopStream.current?.();
    clearInterval(timerRef.current!);
    if (audioSrc) URL.revokeObjectURL(audioSrc);
  }, []);

  useEffect(() => {
    if (editingSp) setTimeout(() => editInputRef.current?.select(), 30);
  }, [editingSp]);

  // Clear stale refs and init name map on new result
  useEffect(() => {
    uttRefs.current = {};
    if (!existingResult) { setNameMap({}); return; }
    const speakers = [...new Set(existingResult.segments.map(s => s.speaker_id))].sort();
    setNameMap(prev => {
      const next: Record<string, string> = {};
      speakers.forEach(sp => { next[sp] = prev[sp] || sp; });
      return next;
    });
  }, [existingResult]);

  // Audio time -> active utterance -> auto-scroll (only when segment actually changes)
  useEffect(() => {
    audioTimeRef.current = audioTime;
    if (!existingResult) return;
    const seg = existingResult.segments.find(s => audioTime >= s.start && audioTime < s.end);
    const id  = seg?.utterance_id ?? null;
    if (id !== activeUttIdRef.current) {
      activeUttIdRef.current = id;
      setActiveUttId(id);
      if (id !== null && uttRefs.current[id]) {
        uttRefs.current[id]?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [audioTime, existingResult]);

  // ── Derived data ──────────────────────────────────────────────────────────
  const res      = existingResult;
  const speakers = res ? [...new Set(res.segments.map(s => s.speaker_id))].sort() : [];
  const colorMap: Record<string, string> = {};
  speakers.forEach((sp, i) => { colorMap[sp] = SPK_COLORS[i % SPK_COLORS.length]; });
  const totalDur = res ? Math.max(...res.segments.map(s => s.end), 1) : 1;
  const talkTime: Record<string, number> = {};
  if (res) speakers.forEach(sp => {
    talkTime[sp] = res.segments.filter(s => s.speaker_id === sp)
      .reduce((a, s) => a + (s.end - s.start), 0);
  });
  const wordCount = res
    ? res.segments.reduce((a, s) => a + s.text.trim().split(/\s+/).filter(Boolean).length, 0)
    : 0;
  const avgConf = res && res.segments.length > 0
    ? Math.round(res.segments.reduce((a, s) => a + s.confidence, 0) / res.segments.length * 100)
    : 0;
  const durStr = res ? fmtDur(res.duration_sec) : '';

  // ── Progress: step checklist driven by pipelinePct (SSE) only ─────────────
  // During upload phase the pipeline steps show as pending - not partially done.
  // Active step = the step whose pct window contains pipelinePct.
  function pipelineStepStatus(step: typeof PIPELINE_STEPS[0], idx: number) {
    if (phase !== 'processing' && phase !== 'done') return 'pending';
    const prevPct = idx === 0 ? 0 : PIPELINE_STEPS[idx - 1].pct;
    if (pipelinePct >= step.pct) return 'done';
    if (pipelinePct > prevPct)   return 'active';
    return 'pending';
  }

  // ── Speaker rename handlers ───────────────────────────────────────────────
  function startEdit(sp: string) { setEditingSp(sp); setEditingName(nameMap[sp] || sp); }
  function commitEdit() {
    if (!editingSp) return;
    const t = editingName.trim();
    if (t) setNameMap(prev => ({ ...prev, [editingSp]: t }));
    setEditingSp(null);
  }
  function cancelEdit() { setEditingSp(null); }
  function handleEditKey(e: React.KeyboardEvent) {
    if (e.key === 'Enter')  { e.preventDefault(); commitEdit(); }
    if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
  }
  function displayName(spId: string) { return nameMap[spId] || spId; }
  function buildRenamedJson() {
    if (!res) return '[]';
    return JSON.stringify(res.segments.map(s => ({ ...s, speaker_name: displayName(s.speaker_id) })), null, 2);
  }
  const hasRenames = res && speakers.some(sp => nameMap[sp] && nameMap[sp] !== sp);

  // ── Audio handlers ────────────────────────────────────────────────────────
  function handleAudioFileLoad(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (audioSrc) URL.revokeObjectURL(audioSrc);
    setAudioSrc(URL.createObjectURL(f));
    setAudioTime(0);
  }
  function seekTo(sec: number) {
    if (audioRef.current) { audioRef.current.currentTime = sec; audioRef.current.play().catch(() => {}); }
  }
  function handleLaneSegClick(e: React.MouseEvent, seg: Segment) { e.stopPropagation(); seekTo(seg.start); }
  function handleLaneBarClick(e: React.MouseEvent<HTMLDivElement>) {
    if (!res) return;
    const rect = e.currentTarget.getBoundingClientRect();
    seekTo((e.clientX - rect.left) / rect.width * totalDur);
  }
  const playheadPct = audioDur > 0 ? (audioTime / audioDur) * 100 : 0;

  // ── Pipeline handlers ─────────────────────────────────────────────────────
  async function doAudio(file: File) {
    setPhase('uploading');
    setError('');
    setUploadPct(0);
    setPipelinePct(0);
    setPipelineMsg('');
    setLogLines([]);
    setProcessingSec(0);
    setUploadStatus('Uploading ' + file.name + ' (' + (file.size / 1024 / 1024).toFixed(1) + ' MB)');
    startRef.current = Date.now();

    try {
      const n     = speakerCount === 'auto' ? null : parseInt(speakerCount);
      const jobId = await startDiarisation(
        file,
        { whisperModel, numSpeakers: n, removeFillers, removeStutters },
        (loaded, total) => {
          const pct = Math.round((loaded / total) * 100);
          setUploadPct(pct);
          setUploadStatus(
            'Uploading ' + (loaded / 1024 / 1024).toFixed(1) +
            ' / ' + (total / 1024 / 1024).toFixed(1) + ' MB  (' + pct + '%)'
          );
        }
      );

      // Upload done - switch to processing phase
      setPhase('processing');
      setPipelineMsg('Starting pipeline...');
      timerRef.current = setInterval(() => {
        setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      }, 1000);

      stopStream.current = streamDiarisation(
        jobId,
        (p) => {
          // pct comes from backend emit(pct, msg) - drives step checklist
          if (p.pct != null && p.pct >= 0) setPipelinePct(p.pct);
          // log drives the step label text shown in the progress area
          if (p.log) {
            setLogLines(prev => [...prev, p.log!]);
            // Show the current pipeline step as the main status message
            setPipelineMsg(p.log!);
          }
        },
        (result) => {
          clearInterval(timerRef.current!);
          setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
          if (result.status === 'error') {
            setError((result as any).error || 'Diarisation failed');
            setPhase('idle');
          } else {
            setPhase('done');
            setPipelinePct(100);
            onDiarisationComplete(result as DiarisationResult);
          }
        },
        (err) => { clearInterval(timerRef.current!); setError(err); setPhase('idle'); }
      );
    } catch (e: any) {
      clearInterval(timerRef.current!);
      setPhase('idle');
      setError(e.message || 'Failed to start diarisation');
    }
  }

  async function doJson(file: File) {
    setPhase('uploading');
    setError('');
    setUploadStatus('Uploading JSON...');
    setProcessingSec(0);
    startRef.current = Date.now();
    try {
      const r = await uploadDiarisationJson(file);
      setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      setPhase('done');
      onDiarisationComplete(r);
    } catch (e: any) { setError(e.message || 'Upload failed'); setPhase('idle'); }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) f.name.endsWith('.json') ? doJson(f) : doAudio(f);
  }

  const isProcessing = phase === 'uploading' || phase === 'processing';

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="flex-1 bg-[#111] text-white overflow-auto">
      <div className="p-6">

        {/* Title */}
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl font-bold">Stage 1 - Diarisation</h1>
          <div className="flex gap-3">
            {res && (
              <span className="px-5 py-2 bg-white text-black rounded-full text-sm font-semibold">
                JSON ready
              </span>
            )}
            <button onClick={onClearSession}
              className="px-5 py-2 bg-[#2a2a2a] text-white rounded-full hover:bg-[#333] transition text-sm">
              Clear session
            </button>
          </div>
        </div>
        <p className="text-[#888] text-sm mb-6">Run once - reuse the JSON for every document</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-lg text-red-400 text-sm">{error}</div>
        )}

        {/* Input + Config grid */}
        <div className="grid grid-cols-2 gap-6 mb-6">

          {/* Input card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Input</h3>
            <p className="text-[#888] text-xs mb-4">Upload audio/video - or skip if you already have a JSON</p>

            <div
              onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={onDrop}
              onClick={() => !isProcessing && fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center transition-all duration-200 mb-4 ${
                isProcessing ? 'cursor-default border-[#444]' :
                isDragging   ? 'cursor-pointer border-white bg-white/5' :
                               'cursor-pointer border-[#444] hover:border-[#666]'
              }`}
            >
              {isProcessing ? (
                <div className="space-y-3">

                  {/* ── UPLOAD PHASE ─────────────────────────────────────── */}
                  {phase === 'uploading' && (
                    <>
                      <div className="text-sm font-semibold text-white">Uploading</div>
                      <div className="text-[#888] text-xs">{uploadStatus}</div>
                      <div className="w-full bg-[#2a2a2a] rounded-full h-2.5 overflow-hidden">
                        <div className="h-2.5 rounded-full bg-blue-500 transition-all duration-300"
                          style={{ width: uploadPct + '%' }} />
                      </div>
                      <div className="text-[#888] text-xs font-mono">{uploadPct}% uploaded</div>
                      {/* Steps all pending during upload */}
                      <div className="space-y-0.5 text-left mt-2">
                        {PIPELINE_STEPS.map(s => (
                          <div key={s.pct} className="flex items-center gap-2 text-xs text-[#444]">
                            <span className="w-3 text-center flex-shrink-0">.</span>
                            <span>{s.label}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  {/* ── PROCESSING PHASE ─────────────────────────────────── */}
                  {phase === 'processing' && (
                    <>
                      <div className="text-sm font-semibold text-white">Processing</div>
                      {/* Active step label - derived from pipelinePct so it always matches the checklist */}
                      <div className="text-[#888] text-xs truncate px-1">
                        {PIPELINE_STEPS.find((s, idx) => {
                          const prev = idx === 0 ? 0 : PIPELINE_STEPS[idx - 1].pct;
                          return pipelinePct < s.pct && pipelinePct >= prev;
                        })?.label ?? (pipelinePct >= 100 ? 'Complete' : 'Starting...')}
                      </div>
                      <div className="w-full bg-[#2a2a2a] rounded-full h-2.5 overflow-hidden">
                        <div className="h-2.5 rounded-full transition-all duration-500"
                          style={{
                            width: pipelinePct + '%',
                            background: 'linear-gradient(90deg,#6366f1,#8b5cf6)',
                          }} />
                      </div>
                      <div className="text-[#888] text-xs font-mono">
                        {pipelinePct}% - {fmtDur(processingSec)} elapsed
                      </div>
                      {/* Steps driven by pipelinePct from SSE */}
                      <div className="space-y-0.5 text-left mt-2">
                        {PIPELINE_STEPS.map((s, idx) => {
                          const st = pipelineStepStatus(s, idx);
                          return (
                            <div key={s.pct} className={`flex items-center gap-2 text-xs transition-colors ${
                              st === 'done'   ? 'text-green-400' :
                              st === 'active' ? 'text-purple-300 font-semibold' :
                                               'text-[#444]'
                            }`}>
                              <span className="w-3 text-center flex-shrink-0">
                                {st === 'done' ? '+' : st === 'active' ? '>' : '.'}
                              </span>
                              <span>{s.label}</span>
                            </div>
                          );
                        })}
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <>
                  <Upload className={`mx-auto mb-3 ${isDragging ? 'text-white' : 'text-[#666]'}`} size={32} />
                  <div className="font-medium mb-1">Drop audio / video here</div>
                  <div className="text-[#666] text-xs">mp3, mp4, m4a, wav, mkv - any format</div>
                </>
              )}
            </div>

            <input ref={fileInputRef} type="file"
              accept="audio/*,video/*,.mp3,.mp4,.m4a,.wav,.mkv,.ogg,.flac,.webm"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doAudio(f); e.target.value = ''; }} />

            {/* Log lines during processing */}
            {phase === 'processing' && logLines.length > 0 && (
              <div className="bg-[#0a0a0a] rounded-lg p-3 font-mono text-[10px] text-[#666] max-h-24 overflow-y-auto mb-3">
                {logLines.slice(-20).map((l, i) => <div key={i}>{l}</div>)}
                <div ref={logEndRef} />
              </div>
            )}

            <div className="text-center text-[#666] text-xs my-3">or</div>

            <button onClick={() => jsonInputRef.current?.click()} disabled={isProcessing}
              className="w-full px-4 py-3 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium disabled:opacity-50">
              Upload existing diarization_response.json
            </button>
            <input ref={jsonInputRef} type="file" accept=".json" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doJson(f); e.target.value = ''; }} />
          </div>

          {/* Config card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Pipeline config</h3>
            <p className="text-[#888] text-xs mb-4">Adjust before running</p>
            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs block mb-2">Whisper model</label>
                <div className="relative">
                  <select value={whisperModel} onChange={e => setWhisperModel(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="tiny.en">tiny.en  (fastest)</option>
                    <option value="base.en">base.en</option>
                    <option value="small.en">small.en</option>
                    <option value="medium.en">medium.en  (best accuracy)</option>
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>
              <div>
                <label className="text-[#888] text-xs block mb-2">Speaker count</label>
                <div className="relative">
                  <select value={speakerCount} onChange={e => setSpeakerCount(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="auto">Auto-detect (silhouette)</option>
                    {[2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} speakers</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeFillers} onChange={e => setRemoveFillers(e.target.checked)} className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove fillers</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeStutters} onChange={e => setRemoveStutters(e.target.checked)} className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove stutters</span>
              </label>
              <button onClick={() => fileInputRef.current?.click()} disabled={isProcessing}
                className="w-full px-4 py-3 bg-white text-black rounded-lg hover:bg-gray-200 transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed">
                {phase === 'uploading'  ? 'Uploading ' + uploadPct + '%' :
                 phase === 'processing' ? 'Processing ' + pipelinePct + '%' :
                 'Run diarisation'}
              </button>
            </div>
          </div>
        </div>

        {/* ── OUTPUT SECTION ─────────────────────────────────────────────── */}
        {res && (
          <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">

            {/* Stats row */}
            <div className="grid grid-cols-3 sm:grid-cols-6 border-b border-[#2a2a2a]">
              {[
                { label: 'Speakers',   value: String(res.n_speakers) },
                { label: 'Utterances', value: String(res.n_utterances) },
                { label: 'Duration',   value: durStr },
                { label: 'Words',      value: wordCount.toLocaleString() },
                { label: 'Processed',  value: processingSec > 0 ? fmtDur(processingSec) : '-' },
                { label: 'Confidence', value: avgConf + '%' },
              ].map(({ label, value }, i) => (
                <div key={label} className={`p-4 text-center ${i < 5 ? 'border-r border-[#2a2a2a]' : ''}`}>
                  <div className="text-[#666] text-[10px] uppercase tracking-wider mb-1">{label}</div>
                  <div className={`text-xl font-bold ${
                    label === 'Confidence'
                      ? avgConf >= 85 ? 'text-green-400' : avgConf >= 65 ? 'text-yellow-400' : 'text-red-400'
                      : 'text-white'
                  }`}>{value}</div>
                </div>
              ))}
            </div>

            {/* Tab bar + audio loader */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-[#2a2a2a]">
              <div className="flex gap-1 bg-[#111] rounded-lg p-1">
                {(['preview','utterances','json'] as ActiveTab[]).map(t => (
                  <button key={t} onClick={() => setActiveTab(t)}
                    className={`px-3 py-1.5 text-xs rounded-md transition-all ${
                      activeTab === t ? 'bg-[#2a2a2a] text-white' : 'text-[#888] hover:text-white'
                    }`}>
                    {t === 'utterances' ? 'Utterances' : t.charAt(0).toUpperCase() + t.slice(1)}
                  </button>
                ))}
              </div>
              <button onClick={() => audioInputRef.current?.click()}
                className="px-3 py-1.5 bg-[#2a2a2a] text-[#888] hover:text-white rounded-lg text-xs transition border border-[#333] hover:border-[#555]">
                {audioSrc ? 'Change audio file' : 'Load audio to play'}
              </button>
              <input ref={audioInputRef} type="file" accept="audio/*,video/*" className="hidden"
                onChange={handleAudioFileLoad} />
            </div>

            {/* Audio player */}
            {audioSrc && (
              <div className="px-5 py-3 border-b border-[#2a2a2a] bg-[#0d0d0d] flex items-center gap-4">
                <audio ref={audioRef} src={audioSrc}
                  onTimeUpdate={() => { if (audioRef.current) setAudioTime(audioRef.current.currentTime); }}
                  onLoadedMetadata={() => { if (audioRef.current) setAudioDur(audioRef.current.duration); }}
                  className="flex-1 h-8" controls style={{ accentColor: '#8b5cf6' }} />
                <span className="text-[#666] text-xs font-mono whitespace-nowrap">
                  {fmtTime(audioTime)} / {fmtTime(audioDur || totalDur)}
                </span>
              </div>
            )}

            {/* TAB: Preview - swimlane */}
            {activeTab === 'preview' && (
              <div className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="text-[#666] text-[10px] uppercase tracking-wider">
                    Speaker lanes - click a name to rename
                  </div>
                  {hasRenames && (
                    <span className="text-[#555] text-[10px]">names edited - download JSON to save</span>
                  )}
                </div>

                <div className="space-y-3">
                  {speakers.map(sp => {
                    const segs     = res.segments.filter(s => s.speaker_id === sp);
                    const color    = colorMap[sp];
                    const pct      = Math.round((talkTime[sp] / totalDur) * 100);
                    const isActive = segs.some(s => audioTime >= s.start && audioTime < s.end);
                    const name     = displayName(sp);
                    const isEditing = editingSp === sp;

                    return (
                      <div key={sp} className="flex items-center gap-3">
                        <div className="w-28 flex-shrink-0 text-right">
                          {isEditing ? (
                            <input ref={editInputRef} value={editingName}
                              onChange={e => setEditingName(e.target.value)}
                              onKeyDown={handleEditKey} onBlur={commitEdit}
                              className="w-full bg-[#0f0f0f] text-white text-xs border rounded px-1.5 py-0.5 text-right focus:outline-none"
                              style={{ borderColor: color }} />
                          ) : (
                            <button onClick={() => startEdit(sp)} title="Click to rename"
                              className={`w-full text-right text-xs font-medium truncate hover:underline cursor-text transition-colors ${
                                isActive ? 'text-white' : 'text-[#888] hover:text-white'
                              }`}>
                              {name}
                              {name !== sp && <span className="text-[#444] ml-1">*</span>}
                            </button>
                          )}
                          <div className="text-[#444] text-[10px] mt-0.5">{pct}% talk</div>
                        </div>

                        <div className="flex-1 h-7 bg-[#0a0a0a] rounded-lg relative overflow-hidden cursor-pointer border border-[#1e1e1e]"
                          onClick={handleLaneBarClick}>
                          {segs.map(seg => {
                            const left        = (seg.start / totalDur) * 100;
                            const width       = Math.max(0.3, ((seg.end - seg.start) / totalDur) * 100);
                            const isActiveSeg = audioTime >= seg.start && audioTime < seg.end;
                            return (
                              <div key={seg.utterance_id}
                                className="absolute top-1 rounded-sm cursor-pointer"
                                style={{
                                  left: left + '%', width: width + '%', height: '20px',
                                  backgroundColor: color,
                                  opacity: isActiveSeg ? 1 : 0.72,
                                  boxShadow: isActiveSeg ? '0 0 0 1.5px ' + color : 'none',
                                  borderBottom: '2px solid ' + confColor(seg.confidence),
                                }}
                                title={fmtTime(seg.start) + ' | ' + name + ' | ' + Math.round(seg.confidence * 100) + '% conf | ' + seg.text.slice(0, 80)}
                                onClick={e => handleLaneSegClick(e, seg)} />
                            );
                          })}

                          {audioSrc && playheadPct > 0 && (
                            <div className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
                              style={{ left: playheadPct + '%' }} />
                          )}
                          {Array.from({ length: Math.floor(totalDur / 30) }, (_, i) => (
                            <div key={i} className="absolute top-0 bottom-0 w-px bg-[#1a1a1a] pointer-events-none"
                              style={{ left: ((i + 1) * 30 / totalDur * 100) + '%' }} />
                          ))}
                        </div>
                      </div>
                    );
                  })}

                  {/* Time axis */}
                  <div className="flex items-center gap-3">
                    <div className="w-28 flex-shrink-0" />
                    <div className="flex-1 flex justify-between text-[#333] text-[10px] font-mono px-0.5">
                      <span>0:00</span>
                      <span>{fmtTime(totalDur / 4)}</span>
                      <span>{fmtTime(totalDur / 2)}</span>
                      <span>{fmtTime(totalDur * 3 / 4)}</span>
                      <span>{fmtTime(totalDur)}</span>
                    </div>
                  </div>

                  {/* Confidence legend */}
                  <div className="flex items-center gap-3 mt-1">
                    <div className="w-28 flex-shrink-0" />
                    <div className="flex items-center gap-4 text-[10px] text-[#555]">
                      <span>Confidence stripe:</span>
                      {[['#22c55e','high (85%+)'],['#f59e0b','medium (65-84%)'],['#ef4444','low (<65%)']].map(([c,l]) => (
                        <span key={l} className="flex items-center gap-1">
                          <span className="inline-block w-4 h-1 rounded-full" style={{ backgroundColor: c as string }} />
                          {l}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: Utterances */}
            {activeTab === 'utterances' && (
              <div className="overflow-hidden">
                <div className="flex items-center gap-4 px-5 py-2 border-b border-[#1e1e1e] bg-[#111]">
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-12 flex-shrink-0">Time</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-24 flex-shrink-0">Speaker</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider flex-1">Transcript</span>
                  <span className="text-[#555] text-[10px] uppercase tracking-wider w-12 text-right flex-shrink-0">Conf.</span>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {res.segments.map(seg => {
                    const isActive = seg.utterance_id === activeUttId;
                    const color    = colorMap[seg.speaker_id] || '#888';
                    const conf     = seg.confidence;
                    return (
                      <div key={seg.utterance_id}
                        ref={el => { uttRefs.current[seg.utterance_id ?? 0] = el; }}
                        onClick={() => seekTo(seg.start)}
                        className={`flex items-start gap-4 px-5 py-2.5 cursor-pointer border-b border-[#161616] transition-colors ${
                          isActive ? 'bg-[#1a1630]' : 'hover:bg-[#1a1a1a]'
                        }`}>
                        <span className="text-[#555] text-xs font-mono w-12 flex-shrink-0 pt-0.5">{fmtTime(seg.start)}</span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0 mt-0.5 w-24 text-center truncate"
                          style={{ backgroundColor: color + '20', color, border: '1px solid ' + color + '44' }}
                          title={displayName(seg.speaker_id) !== seg.speaker_id ? 'Originally: ' + seg.speaker_id : undefined}>
                          {displayName(seg.speaker_id)}
                        </span>
                        <span className={`text-sm leading-relaxed flex-1 ${isActive ? 'text-white' : 'text-[#bbb]'}`}>
                          {seg.text}
                          {isActive && audioSrc && (
                            <span className="text-red-400 text-xs ml-2 animate-pulse" style={{ fontSize: '10px' }}>[playing]</span>
                          )}
                        </span>
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded w-12 text-right flex-shrink-0 font-mono"
                          style={{ color: confColor(conf) }}
                          title={'ASR confidence: ' + Math.round(conf * 100) + '%'}>
                          {Math.round(conf * 100)}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB: JSON */}
            {activeTab === 'json' && (
              <div className="p-5">
                <pre className="bg-[#0a0a0a] rounded-lg p-4 text-xs text-[#888] overflow-auto max-h-64 font-mono border border-[#1e1e1e]">
                  {JSON.stringify(res.segments.slice(0, 5), null, 2)}
                </pre>
                <p className="text-[#555] text-xs mt-2">First 5 of {res.n_utterances} utterances. Download for full data.</p>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-3 p-5 border-t border-[#2a2a2a]">
              {hasRenames ? (
                <button
                  onClick={() => {
                    const blob = new Blob([buildRenamedJson()], { type: 'application/json' });
                    const url  = URL.createObjectURL(blob);
                    const a    = document.createElement('a');
                    a.href = url; a.download = 'diarization_response.json';
                    a.click(); URL.revokeObjectURL(url);
                  }}
                  className="px-5 py-2.5 bg-white text-black rounded-lg hover:bg-gray-100 transition text-sm font-semibold">
                  Download JSON (with renamed speakers)
                </button>
              ) : (
                <a href={getDiarisationJsonUrl()} download="diarization_response.json"
                  className="px-5 py-2.5 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium">
                  Download JSON
                </a>
              )}
              {res.html_path && (
                <a href={getDiarisationHtmlUrl()} download="diarization_view.html"
                  className="px-5 py-2.5 bg-[#2a2a2a] text-[#888] rounded-lg hover:bg-[#333] hover:text-white transition text-sm">
                  Open full HTML view
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
