# DN-Studio — by DataNeurus

**Audio recording → Speaker-diarised transcript → AI-generated Word document**

DN-Studio is a self-hosted document generation platform. Upload any meeting recording, pick a document type, and receive a professionally formatted Word document — every field traced back to the exact spoken moment.

---

## Quick Start

**Windows**
```
Double-click start.bat
```

**Linux / macOS / Google Colab**
```bash
pip install -r requirements.txt
python app.py
```

Open `http://localhost:8000`.

---

## Workflow

```
1. Configure   →  API key, project name, model
2. Input       →  Upload audio or import transcript JSON
3. Pipeline    →  Run — AI transcribes, analyses, writes
4. Outputs     →  Download your Word document
```

---

## Document Types

| Type     | Full Name                        | Steps         |
|----------|----------------------------------|---------------|
| BRD      | Business Requirements Document   | 0 1 2 3 4 5 6 |
| MOM      | Minutes of Meeting               | 0 1 2 5       |
| Custom   | Any type you register            | 0 1 2 5       |
| Quick Run| One-off schema + JS template     | 0 1 2 5       |

---

## Pipeline Architecture

```
Audio File
  |
  | Step 0 — Convert to MP3          scripts/to_mp3.py
  | Step 1 — Diarise + transcribe    scripts/diarize.py
  |
  |-- BRD pipeline -----------------------------------------------
  |   Step 2 — Schema decision       scripts/brd_schema_decider.py
  |   Step 3 — Write requirements    scripts/brd_requirements_writer.py
  |   Step 4 — Link to transcript    scripts/brd_traceability_linker.py
  |   Step 5 — Build Word document   scripts/generic_docx_runner.py
  |   Step 6 — Gap analysis          scripts/brd_gap_analyser.py
  |
  |-- MOM / Custom / Quick Run pipeline --------------------------
      Step 2 — Fill document fields  scripts/llm_filler.py
      Step 5 — Build Word document   scripts/generic_docx_runner.py
```

All three variants run through the same `_pipeline_thread` in `app.py`.
BRD-only steps (3, 4, 6) are skipped automatically for other types.

---

## Requirements

- Python 3.10+
- Node.js 16+
- ffmpeg (for audio conversion)
- Gemini API key — free at [aistudio.google.com](https://aistudio.google.com)

---

## Configuration

Edit `configuration.yaml` or use the Configure tab in the UI:

```yaml
experiment: my-project-name

llm:
  model: gemini-2.5-flash   # see Configure tab for all model options
  api_key: "YOUR_KEY_HERE"

diarization:
  num_speakers: 2            # or null for auto-detect
  whisper_model: tiny        # tiny | base | small | large-v2
```

---

## Project Structure

```
app.py                        FastAPI backend (all pipelines)
configuration.yaml            Settings (auto-resolved by cfg_utils.py)
frontend.html                 Single-file web UI
requirements.txt              Python dependencies
start.bat                     Windows one-click launcher

scripts/
  cfg_utils.py                Config resolver — expands {experiment} paths
  llm_utils.py                Shared LLM helpers: build_model, invoke_with_retry,
                              extract_json, collect_leaves, write_back
  llm_filler.py               Generic document fill — MOM + all custom types
  to_mp3.py                   Audio format conversion (Step 0)
  diarize.py                  Whisper transcription + speaker clustering (Step 1)
  brd_schema_decider.py       BRD Step 2: decide document structure
  brd_requirements_writer.py  BRD Step 3: generate all requirement fields
  brd_traceability_linker.py  BRD Step 4: link fields to transcript utterances
  brd_gap_analyser.py         BRD Step 6: identify gaps, open questions, risks
  generic_docx_runner.py      Step 5 for all types: run JS_template.js → .docx
  package.json                Node.js manifest (docx package)

artifacts_library/
  README.md                   How to create a new document type
  BRD/
    schema_prompt.json        BRD field definitions and generation prompt
    schema_decider_prompt.json  BRD structure decision prompt
    JS_template.js            BRD Word document template
    JS_gap_report.js          Gap report Word document template
  MOM/
    schema_prompt.json        MOM field definitions
    JS_template.js            MOM Word document template
    example_transcript.json   Example diarised transcript for testing
  SOP/                        Standard Operating Procedure (schema ready)
  QRM/                        Quality Review Meeting (schema ready)
  BPIP/                       Business Process Improvement Plan (schema ready)

prompts/
  doctypes.json               Custom doc type registry (runtime — do not edit)
  studio_uploads/             Quick Run uploaded schema + JS files (runtime)

docs/
  architecture.md             System design and data flow
  api.md                      API endpoint reference
  pipeline.md                 Pipeline step details
  diarization.md              Diarisation technical notes
  gap_analyser.md             Gap analysis output schema
```

---

## Adding Custom Document Types

See `artifacts_library/README.md` for the complete guide.

In short: create a `schema_prompt.json` and a `JS_template.js` in a new folder under `artifacts_library/`, then register via the Studio tab.

---

## Running on Google Colab

```python
import nest_asyncio
nest_asyncio.apply()

import os, sys, uvicorn
from google.colab.output import eval_js

os.chdir("/content/dn-studio")
sys.path.insert(0, "/content/dn-studio/scripts")

print(f"Open: {eval_js('google.colab.kernel.proxyPort(8000)')}")

config = uvicorn.Config("app:app", host="0.0.0.0", port=8000, reload=False)
await uvicorn.Server(config).serve()
```

