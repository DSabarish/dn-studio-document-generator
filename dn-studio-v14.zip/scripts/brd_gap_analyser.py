"""
brd_gap_analyser.py — BRD Pipeline Step 6: Gap Analyser

Reads the completed BRD trace + original transcript, then asks the LLM to:
  1. Identify every null/incomplete section and explain WHY it matters
  2. Surface open questions that must be answered before sign-off
  3. Flag risks discussed but not captured as requirements
  4. Score each section for transcript confidence (well-supported vs inferred)
  5. Produce a prioritised action list the team can act on immediately

Output: gap-report.json
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from cfg_utils import resolve_cfg
from llm_utils import (
    MAX_RETRY_ATTEMPTS,
    build_model,
    extract_json,
    invoke_with_retry,
    load_json,
    save_json,
    to_str,
)

log = logging.getLogger(__name__)


_SYSTEM_PROMPT = """\
You are a senior Business Analyst reviewing a BRD (Business Requirements Document).
Your job is to produce a structured Gap Analysis report.

You will receive:
1. The complete BRD JSON (with null sections marked with why_null codes)
2. The original meeting transcript
3. A list of null/incomplete sections detected automatically

Your tasks:
A. For every null section — assess severity (critical/major/minor) and what specific action fixes it
B. Surface open questions the team never resolved
C. Find risks discussed in the transcript that are NOT captured in the BRD
D. Score each major BRD section 0-100 for transcript confidence
   (100 = well-supported by multiple utterances, 0 = entirely inferred/missing)
E. Write a one-paragraph executive recommendation

Severity guide:
- critical: Project cannot proceed to development without this. Affects scope, budget, or delivery date.
- major: Significant gap that will cause problems in UAT or delivery if not resolved.
- minor: Nice to have, or can be deferred to a later phase without risk.

Output ONLY valid JSON matching this exact schema:
{{
  "summary": {{
    "total_gaps": <int>,
    "critical": <int>,
    "major": <int>,
    "minor": <int>,
    "overall_confidence": <0-100 float>,
    "recommendation": "<paragraph>"
  }},
  "gaps": [
    {{
      "id": "GAP-001",
      "severity": "critical|major|minor",
      "section": "<section name>",
      "title": "<10 word title>",
      "description": "<what is missing and why it matters>",
      "why_null_code": "<code>",
      "action": "<specific action the team must take>",
      "owner": "<role who should own this>",
      "transcript_refs": [<utterance_ids>],
      "deadline": "Before sign-off|Next meeting|Phase 2"
    }}
  ],
  "open_questions": [
    {{
      "id": "Q-001",
      "question": "<full question>",
      "context": "<what was said / what led to this>",
      "raised_by": "<speaker if known>",
      "urgency": "immediate|soon|later"
    }}
  ],
  "uncaptured_risks": [
    {{
      "id": "R-001",
      "risk": "<risk description>",
      "evidence": "<quote or reference from transcript>",
      "suggested_mitigation": "<concrete suggestion>"
    }}
  ],
  "confidence_scores": {{
    "<section name>": <0-100>
  }}
}}\
"""


def _extract_null_sections(brd: dict) -> list[dict]:
    """Walk the BRD and collect every field that is null with its why_null code."""
    nulls = []

    def walk(node, path=""):
        if isinstance(node, dict):
            if node.get("value") is None and node.get("why_null"):
                nulls.append({"path": path, "why_null": node["why_null"]})
            for k, v in node.items():
                if k not in ("value", "why_null", "trace"):
                    walk(v, path=f"{path}.{k}" if path else k)
        elif isinstance(node, list):
            for item in node:
                walk(item, path)

    walk(brd)
    return nulls


def _fallback_report(raw_text: str) -> dict:
    """Return a minimal valid report if JSON parsing fails."""
    log.warning("Gap analyser: JSON parse failed, returning fallback report")
    return {
        "summary": {
            "total_gaps": 1,
            "critical": 0, "major": 1, "minor": 0,
            "overall_confidence": 50.0,
            "recommendation": "Gap analysis could not be fully parsed. Raw output preserved.",
        },
        "gaps": [{
            "id": "GAP-001", "severity": "major",
            "section": "General",
            "title": "Gap analysis output could not be parsed",
            "description": raw_text[:500],
            "why_null_code": "insufficient_detail",
            "action": "Re-run gap analysis",
            "owner": "Business Analyst",
            "transcript_refs": [],
            "deadline": "Before sign-off",
        }],
        "open_questions": [],
        "uncaptured_risks": [],
        "confidence_scores": {},
    }


def build_gap_analyser_chain(model):
    prompt = ChatPromptTemplate.from_messages([
        ("system", _SYSTEM_PROMPT),
        ("human",
         "BRD JSON:\n{brd}\n\n"
         "Original Transcript (first 80 utterances):\n{transcript}\n\n"
         "Automatically detected null sections:\n{nulls}\n\n"
         "Produce the Gap Analysis JSON now:"),
    ])
    return (
        {
            "brd":        RunnableLambda(lambda x: to_str(x["brd"])),
            "transcript": RunnableLambda(lambda x: to_str(x["transcript"][:80])),
            "nulls":      RunnableLambda(lambda x: to_str(x["nulls"])),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(lambda t: extract_json(t) or _fallback_report(t))
    )


def run(cfg: dict) -> str:
    chain_cfg = cfg["chains"]["chain4_gap_analyser"]

    # Gap analysis needs slightly more creativity than pure extraction
    model = build_model(cfg, temperature=0.1)

    brd_path        = chain_cfg["input"]["brd"]
    transcript_path = chain_cfg["input"]["transcript"]
    output_path     = chain_cfg["output"]["gap_report"]

    brd        = load_json(brd_path)
    transcript = load_json(transcript_path)
    nulls      = _extract_null_sections(brd)

    log.info(
        ">> BRD sections: %d | Null fields: %d | Transcript utterances: %d",
        len(brd), len(nulls), len(transcript),
    )

    chain = build_gap_analyser_chain(model)

    report = invoke_with_retry(
        chain,
        {"brd": brd, "transcript": transcript, "nulls": nulls},
        required_key="summary",
        label="Gap Analyser",
    )

    if not report:
        raise RuntimeError(f"Gap Analyser failed after {MAX_RETRY_ATTEMPTS} attempts")

    save_json(report, output_path)

    s = report["summary"]
    log.info(
        "[OK] Gap report saved → %s\n"
        "   Critical: %d | Major: %d | Minor: %d\n"
        "   Confidence: %.0f/100",
        output_path, s["critical"], s["major"], s["minor"], s["overall_confidence"],
    )
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg    = resolve_cfg("configuration.yaml")
    path   = run(cfg)
    report = load_json(path)
    s      = report["summary"]
    print(
        f"\n>> Gap Analyser complete: {path}\n"
        f"   Total gaps : {s['total_gaps']}\n"
        f"   Critical   : {s['critical']}\n"
        f"   Major      : {s['major']}\n"
        f"   Minor      : {s['minor']}\n"
        f"   Confidence : {s['overall_confidence']:.0f}/100\n"
        f"\n>> Recommendation:\n   {s['recommendation']}"
    )

