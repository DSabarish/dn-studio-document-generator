"""Shared utility: resolve {experiment} placeholders in configuration.yaml"""
import json
import os
import yaml
from pathlib import Path


def resolve_cfg(path: str = "configuration.yaml") -> dict:
    """Load config and expand all {experiment} placeholders.
    Auto-creates experiment/input and experiment/output directories.
    """
    cfg_path = Path(path)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path.resolve()}")

    raw: dict = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    exp: str = raw.get("experiment", "default")

    def _resolve(obj):
        if isinstance(obj, str):
            return obj.replace("{experiment}", exp)
        if isinstance(obj, dict):
            return {k: _resolve(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_resolve(i) for i in obj]
        return obj

    cfg = _resolve(raw)

    for d in [f"{exp}/input", f"{exp}/output"]:
        os.makedirs(d, exist_ok=True)

    return cfg


if __name__ == "__main__":
    cfg = resolve_cfg()
    print(f"Experiment: {cfg['experiment']}")
    print(json.dumps(cfg, indent=2))

