"""
diarize.py — Speaker-labelled transcript from MP3 audio.
DN-Studio by DataNeurus — v3

Changes from v2:
  - Segment pre-merging before embedding: short consecutive segments
    merged to give Resemblyzer more audio context per embedding
  - Three-method speaker count vote: eigengap + Ward elbow + silhouette sweep
  - Ward/Euclidean primary (more balanced clusters than average/cosine)
  - Post-correction pass: segments reassigned if closer to another centroid
  - Orphan threshold raised 1.5s -> 2.5s
  - Min segment raised 0.4s -> 0.6s
  - UMAP/PCA dimensionality reduction (when available) improves separation
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glob, json, logging, re, tempfile
from typing import Optional
import librosa, numpy as np, soundfile as sf
from faster_whisper import WhisperModel
from resemblyzer import VoiceEncoder, preprocess_wav
from scipy.ndimage import median_filter
from sklearn.cluster import AgglomerativeClustering, SpectralClustering
from sklearn.preprocessing import normalize
from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)
logging.getLogger("faster_whisper").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("huggingface_hub").setLevel(logging.WARNING)

_FILLERS     = re.compile(r"\b(um+|uh+|er+|ah+|like,?\s+|you know|i mean|sort of|kind of)\b", re.I)
_MIN_CHUNK   = 0.6
_SAMPLE_RATE = 16_000


def clean_text(text: str) -> str:
    text = _FILLERS.sub(" ", text.strip())
    return re.sub(r"\s+", " ", text).strip().capitalize()


def transcribe(path: str, model_size: str, lang: str) -> list[dict]:
    device       = "cuda" if os.path.exists("/usr/local/cuda") else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"
    mdl          = WhisperModel(model_size, device=device, compute_type=compute_type)
    segs, _      = mdl.transcribe(path, language=lang, vad_filter=True)
    return [
        {"start": s.start, "end": s.end, "text": clean_text(s.text),
         "conf": float(np.clip(np.exp(s.avg_logprob), 0, 1))}
        for s in segs if clean_text(s.text)
    ]


def merge_short_segments(segs: list[dict], gap_threshold: float = 0.8) -> list[dict]:
    """Merge consecutive segments with a short gap for better embedding quality."""
    if not segs:
        return segs
    merged = [dict(segs[0])]
    for seg in segs[1:]:
        prev = merged[-1]
        gap  = seg["start"] - prev["end"]
        if gap <= gap_threshold and (seg["end"] - prev["start"]) <= 4.0:
            prev["end"]  = seg["end"]
            prev["text"] = (prev["text"] + " " + seg["text"]).strip()
            prev["conf"] = (prev["conf"] + seg["conf"]) / 2
        else:
            merged.append(dict(seg))
    return merged


def extract_embeddings(path: str, segs: list[dict]) -> tuple[list[int], np.ndarray]:
    encoder  = VoiceEncoder("cpu")
    audio, _ = librosa.load(path, sr=_SAMPLE_RATE, mono=True)
    valid_idx, embeddings = [], []
    for i, seg in enumerate(segs):
        chunk = audio[int(seg["start"] * _SAMPLE_RATE):int(seg["end"] * _SAMPLE_RATE)]
        if len(chunk) < _SAMPLE_RATE * _MIN_CHUNK:
            continue
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            sf.write(tmp.name, chunk, _SAMPLE_RATE)
            try:
                wav = preprocess_wav(tmp.name)
                embeddings.append(encoder.embed_utterance(wav))
                valid_idx.append(i)
            except Exception as exc:
                log.debug("Skip seg %d: %s", i, exc)
            finally:
                os.unlink(tmp.name)
    return valid_idx, (np.array(embeddings, dtype=np.float32) if embeddings else np.empty((0, 256)))


def _reduce_dimensions(X: np.ndarray) -> np.ndarray:
    """Reduce embeddings to ~16D. UMAP preferred, PCA fallback."""
    n, d = X.shape
    target = min(16, n - 1, d)
    if target < 4:
        return X
    try:
        import umap  # type: ignore
        Xr = umap.UMAP(n_components=target, n_neighbors=min(15, n - 1),
                       metric="cosine", random_state=42, low_memory=True).fit_transform(X)
        log.info("  >> Dim reduction: UMAP %dD -> %dD", d, target)
        return normalize(Xr.astype(np.float32))
    except Exception:
        pass
    try:
        from sklearn.decomposition import PCA
        Xr = PCA(n_components=target, random_state=42).fit_transform(X)
        log.info("  >> Dim reduction: PCA %dD -> %dD (install umap-learn for better results)", d, target)
        return normalize(Xr.astype(np.float32))
    except Exception:
        return X


def estimate_n_speakers(X_norm: np.ndarray, max_k: int = 8, min_k: int = 2) -> int:
    """Three-method majority vote: eigengap + Ward elbow + silhouette sweep."""
    n = len(X_norm)
    if n < 4:
        return min(min_k, n)
    votes = []

    # Method 1: eigengap on cosine affinity Laplacian
    try:
        A      = np.clip(X_norm @ X_norm.T, 0, 1)
        np.fill_diagonal(A, 1.0)
        D_inv  = np.diag(1.0 / np.sqrt(np.maximum(A.sum(1), 1e-10)))
        L      = np.eye(n) - D_inv @ A @ D_inv
        eigv   = np.sort(np.abs(np.linalg.eigvalsh(L)))[:min(max_k + 2, n)]
        gaps   = np.diff(eigv[1:])
        if len(gaps):
            ng  = gaps / (gaps.mean() + 1e-10)
            votes.append(max(min_k, min(max_k, int(np.argmax(ng)) + 2)))
    except Exception as e:
        log.debug("Eigengap err: %s", e)

    # Method 2: Ward linkage distance elbow
    try:
        from scipy.cluster.hierarchy import linkage as sc_linkage
        dist = 1.0 - np.clip(X_norm @ X_norm.T, -1, 1)
        np.fill_diagonal(dist, 0)
        Z    = sc_linkage(dist[np.triu_indices(n, k=1)], method="ward")
        md   = Z[:, 2]
        if len(md) >= max_k:
            mg = np.diff(md[-(max_k + 1):][::-1])
            if len(mg):
                votes.append(max(min_k, min(max_k, int(np.argmax(mg)) + 2)))
    except Exception as e:
        log.debug("Linkage err: %s", e)

    # Method 3: silhouette score sweep (most reliable, O(n^2))
    if n <= 400:
        try:
            from sklearn.metrics import silhouette_score
            best_k, best_s = min_k, -1.0
            for k in range(min_k, min(max_k + 1, n)):
                lbl = AgglomerativeClustering(n_clusters=k, metric="cosine",
                                              linkage="average").fit_predict(X_norm)
                if len(np.unique(lbl)) < 2:
                    continue
                s = silhouette_score(X_norm, lbl, metric="cosine")
                if s > best_s:
                    best_s, best_k = s, k
            votes.append(best_k)
        except Exception as e:
            log.debug("Silhouette err: %s", e)

    if not votes:
        return min_k

    from collections import Counter
    freq    = Counter(votes)
    top     = max(freq.values())
    winners = sorted(k for k, c in freq.items() if c == top)
    k       = max(min_k, min(max_k, int(np.median(winners))))
    log.info("  >> Auto-detected %d speakers (votes: %s)", k, votes)
    return k


def cluster_speakers(embs: np.ndarray, n_speakers: Optional[int],
                     timestamps: Optional[list] = None) -> np.ndarray:
    n = len(embs)
    if n < 2:
        return np.zeros(n, dtype=int)

    X_raw = normalize(np.nan_to_num(embs, nan=0.0))
    X     = _reduce_dimensions(X_raw)
    k     = estimate_n_speakers(X) if n_speakers is None else max(2, min(int(n_speakers), n))
    k     = min(k, n)

    # Temporal connectivity: segments < 2s apart get a soft pull
    connectivity = None
    if timestamps and len(timestamps) == n:
        try:
            from scipy.sparse import lil_matrix
            conn = lil_matrix((n, n))
            for i in range(n - 1):
                if timestamps[i + 1][0] - timestamps[i][1] < 2.0:
                    conn[i, i + 1] = conn[i + 1, i] = 1
            if conn.nnz > 0:
                connectivity = conn.tocsr()
        except Exception:
            pass

    labels = None

    # Primary: Ward/Euclidean — best for balanced clusters
    try:
        labels = AgglomerativeClustering(
            n_clusters=k, metric="euclidean", linkage="ward",
            connectivity=connectivity).fit_predict(X)
        log.info("  [OK] %d segs -> %d speakers (Ward/Euclidean)", n, k)
    except Exception as exc:
        log.warning("  Ward failed (%s), trying average/cosine", exc)

    # Secondary: average/cosine
    if labels is None:
        try:
            labels = AgglomerativeClustering(
                n_clusters=k, metric="cosine", linkage="average",
                connectivity=connectivity).fit_predict(X_raw)
            log.info("  [OK] %d segs -> %d speakers (avg/cosine)", n, k)
        except Exception as exc:
            log.warning("  Avg/cosine failed (%s), trying spectral", exc)

    # Final fallback: Spectral
    if labels is None:
        try:
            A      = np.clip(X_raw @ X_raw.T, 0, 1)
            np.fill_diagonal(A, 1.0)
            labels = SpectralClustering(n_clusters=k, affinity="precomputed",
                                        assign_labels="kmeans", random_state=42,
                                        n_init=20).fit_predict(A)
            log.info("  [OK] %d segs -> %d speakers (spectral)", n, k)
        except Exception as exc:
            log.error("  All clustering failed: %s", exc)
            return np.zeros(n, dtype=int)

    # Smooth: median filter
    fs     = max(3, min(9, n // 15))
    labels = np.round(median_filter(labels.astype(float), size=fs)).astype(int)

    # Smooth: orphan merge — short segment between same speaker on both sides
    if timestamps and len(timestamps) == n:
        for i in range(1, n - 1):
            if labels[i - 1] == labels[i + 1] and labels[i] != labels[i - 1]:
                if timestamps[i][1] - timestamps[i][0] < 2.5:
                    labels[i] = labels[i - 1]

    # Post-correction: reassign if clearly closer to another centroid
    centroids = {spk: normalize(X_raw[labels == spk].mean(0, keepdims=True))[0]
                 for spk in np.unique(labels)}
    for i, lbl in enumerate(labels):
        sims = {spk: float(X_raw[i] @ c) for spk, c in centroids.items()}
        best = max(sims, key=sims.get)
        if best != lbl and sims[best] - sims[lbl] > 0.08:
            labels[i] = best

    # Re-index in order of first appearance
    remap, counter = {}, 0
    out = np.zeros_like(labels)
    for i, lbl in enumerate(labels):
        if lbl not in remap:
            remap[lbl] = counter; counter += 1
        out[i] = remap[lbl]
    return out


def speaker_confidence(embs: np.ndarray, labels: np.ndarray) -> np.ndarray:
    X     = normalize(np.nan_to_num(embs, nan=0.0))
    confs = np.ones(len(embs))
    for spk in np.unique(labels):
        mask     = labels == spk
        centroid = normalize(X[mask].mean(0, keepdims=True))[0]
        confs[mask] = np.clip(X[mask] @ centroid, 0, 1)
        log.info("    SPEAKER_%d: %d segs, mean_conf=%.3f", spk, mask.sum(), confs[mask].mean())
    return confs


def run(cfg: dict) -> list[dict]:
    paths         = cfg.get("paths", {})
    diar          = cfg.get("diarization", {})
    input_dir     = paths.get("input_dir", paths.get("mp3_dir", "mp3_output"))
    output_file   = diar.get("output_file", "diarization_result.json")
    whisper_model = diar.get("whisper_model", "tiny")
    language      = diar.get("language", "en")
    num_speakers  = diar.get("num_speakers")

    if num_speakers is None:
        log.info(">> Speaker count: AUTO-DETECT (3-method vote)")
    else:
        log.info(">> Speaker count: %s (manual)", num_speakers)

    mp3s = glob.glob(f"{input_dir}/*.mp3")
    if not mp3s:
        raise FileNotFoundError(f"No MP3 files found in: {input_dir}")

    results = []
    for audio_path in mp3s:
        log.info(">> Processing: %s", os.path.basename(audio_path))
        raw_segs = transcribe(audio_path, whisper_model, language)
        if not raw_segs:
            log.warning("No speech segments detected.")
            continue

        segs = merge_short_segments(raw_segs, gap_threshold=0.8)
        log.info("  >> %d raw -> %d merged segments", len(raw_segs), len(segs))

        valid_idx, embs = extract_embeddings(audio_path, segs)
        log.info("  >> %d embeddings extracted", len(embs))

        if len(embs) >= 2:
            timestamps = [(segs[i]["start"], segs[i]["end"]) for i in valid_idx]
            labels     = cluster_speakers(embs, num_speakers, timestamps)
            confs      = speaker_confidence(embs, labels)
            for rank, seg_i in enumerate(valid_idx):
                spk = f"SPEAKER_{labels[rank]}"
                segs[seg_i].update({"speaker_id": spk, "speaker_name": spk,
                                    "spk_conf": round(float(confs[rank]), 3)})

        # Map merged segment labels back to original raw segments
        orig_ptr = 0
        for m_seg in segs:
            spk_id   = m_seg.get("speaker_id",   "SPEAKER_0")
            spk_name = m_seg.get("speaker_name", spk_id)
            spk_conf = m_seg.get("spk_conf",     1.0)
            while orig_ptr < len(raw_segs):
                os_ = raw_segs[orig_ptr]
                if os_["start"] >= m_seg["start"] - 0.05 and os_["end"] <= m_seg["end"] + 0.05:
                    os_["speaker_id"]   = spk_id
                    os_["speaker_name"] = spk_name
                    os_["spk_conf"]     = spk_conf
                    orig_ptr += 1
                elif os_["start"] > m_seg["end"]:
                    break
                else:
                    orig_ptr += 1

        for uid, seg in enumerate(raw_segs):
            seg.setdefault("speaker_id",   "SPEAKER_0")
            seg.setdefault("speaker_name", seg["speaker_id"])
            seg.setdefault("spk_conf",     1.0)
            results.append({
                "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                "utterance_id": uid,
                "speaker_id": seg["speaker_id"], "speaker_name": seg["speaker_name"],
                "confidence": round(seg["conf"], 3),
                "spk_confidence": round(seg["spk_conf"], 3),
                "text": seg["text"],
            })

    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    n_spk = len({r["speaker_id"] for r in results})
    log.info("[OK] Saved %d segments, %d speakers -> %s", len(results), n_spk, output_file)
    return results


if __name__ == "__main__":
    run(resolve_cfg("configuration.yaml"))

