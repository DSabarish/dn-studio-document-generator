"""
brd_requirements_writer.py — BRD Pipeline Step 3: Requirements Writer

Reads the schema decision (Step 2) + transcript and fills every BRD field
using the LLM. Each field gets a value, a trace back to the transcript, and
a why_null code if it could not be filled.

Output: brd-response.json  (used by brd_traceability_linker.py)
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Dict, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from cfg_utils import resolve_cfg
from llm_utils import (
    MAX_RETRY_ATTEMPTS,
    build_model,
    extract_json,
    invoke_with_retry,
    load_json,
    save_json,
    to_str,
)

log = logging.getLogger(__name__)


def _recover_json(text: str, max_retries: int = 2) -> Dict:
    """
    BRD-specific JSON recovery: the response can be very long and sometimes
    truncated. Try brace-padding and line-trimming before giving up.
    """
    for attempt in range(max_retries + 1):
        result = extract_json(text)
        if result:
            return result
        if attempt == 0:
            text += "}" * max(0, text.count("{") - text.count("}"))
        elif attempt == 1:
            lines = text.split("\n")
            while lines and lines[-1].strip().rstrip(",").rstrip() not in ("}", "]"):
                lines.pop()
            text = "\n".join(lines) + "}"
    raise ValueError(
        f"BRD Requirements Writer: JSON parse failed after {max_retries} retries. "
        f"Preview: {text[:300]}..."
    )


def build_requirements_writer_chain(model, prompt_path: str, brd_template: Dict[str, Any]):
    p = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{p.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown. No trailing commas. Close all braces.",
        ),
        (
            "human",
            "Meeting Transcript (utterance_id range: 0 to {max_utid}):\n{transcript}\n\n"
            "Schema Decision (MUST follow for Section 6 & 7):\n{schema}\n\n"
            "BRD Template Structure:\n{brd_template}\n\n"
            "Rules:\n"
            "- Utterance IDs must be in range [0, {max_utid}]\n"
            "- Use why_null codes: not_mentioned, deferred_by_participants, not_yet_agreed, "
            "schema_excluded, insufficient_detail, not_applicable\n"
            "- Every non-null value needs a trace with valid utterance_id\n"
            "- Output valid, complete JSON only — no truncation\n\n"
            "Generate complete BRD JSON:",
        ),
    ])

    return (
        {
            "transcript":   RunnableLambda(lambda x: to_str(x["transcript"])),
            "schema":       RunnableLambda(lambda x: to_str(x["schema"])),
            "brd_template": RunnableLambda(lambda x: to_str(x["template"])),
            "max_utid":     RunnableLambda(
                lambda x: len(x["transcript"]) - 1 if isinstance(x["transcript"], list) else 0
            ),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(_recover_json)
    )


def run(cfg: dict) -> str:
    chain_cfg = cfg["chains"]["chain2_brd_generator"]

    model = build_model(cfg, temperature=0)

    transcript   = load_json(chain_cfg["input"]["transcript"])
    schema       = load_json(chain_cfg["input"]["schema"])
    prompt_path  = chain_cfg["input"]["prompt"]
    brd_template = load_json(prompt_path).get("BRD_Template", {})
    output_path  = chain_cfg["output"]["brd"]

    log.info(
        ">> Transcript: %d utterances | Schema modules: %d",
        len(transcript), len(schema.get("functional_modules", [])),
    )

    chain = build_requirements_writer_chain(model, prompt_path, brd_template)

    brd = invoke_with_retry(
        chain,
        {"transcript": transcript, "schema": schema, "template": brd_template},
        required_key="Header",
        label="BRD Requirements Writer",
    )

    if not brd:
        raise RuntimeError(f"BRD Requirements Writer failed after {MAX_RETRY_ATTEMPTS} attempts")

    save_json(brd, output_path)
    log.info("[OK] BRD saved → %s", output_path)
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg         = resolve_cfg("configuration.yaml")
    output_path = run(cfg)
    brd         = load_json(output_path)
    print(
        f"\n>> Requirements Writer complete: {output_path}\n"
        f"   Project  : {brd.get('Header', {}).get('Project Name', {}).get('value', 'N/A')}\n"
        f"   Sections : {sum(1 for v in brd.values() if isinstance(v, dict) and v.get('value'))}"
    )

