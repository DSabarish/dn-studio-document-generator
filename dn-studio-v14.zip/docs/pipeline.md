# Pipeline Reference

All document types run through the same pipeline thread. The step numbers are fixed:

| Step | Name                    | Script                          | BRD | MOM/Custom |
|------|-------------------------|---------------------------------|-----|------------|
| 0    | Convert to MP3          | scripts/to_mp3.py               | yes | yes        |
| 1    | Diarise + transcribe    | scripts/diarize.py              | yes | yes        |
| 2    | Schema / Fill           | brd_schema_decider.py / llm_filler | yes | yes   |
| 3    | Write requirements      | scripts/brd_requirements_writer.py | yes | —      |
| 4    | Link to transcript      | scripts/brd_traceability_linker.py | yes | —      |
| 5    | Build Word document     | scripts/generic_docx_runner.py  | yes | yes        |
| 6    | Gap analysis            | scripts/brd_gap_analyser.py     | yes | —          |

Steps 0 and 1 are skipped automatically if a transcript JSON is imported directly.
Steps 3, 4, and 6 are BRD-only and are silently skipped for all other doc types.

---

## Step 0 — Convert to MP3

**Script:** `scripts/to_mp3.py`

Converts the uploaded audio to MP3 using pydub. Skipped automatically if the file is already an MP3.

Supported input formats: WAV, M4A, MP4, OGG, FLAC, AAC, WEBM.

---

## Step 1 — Diarise + Transcribe

**Script:** `scripts/diarize.py`

1. Transcribes audio with Faster-Whisper (configurable model: tiny/base/small/large-v2)
2. Extracts speaker embeddings with Resemblyzer
3. Clusters speakers using AgglomerativeClustering (cosine distance) with spectral fallback
4. Auto-detects speaker count via eigengap + Ward linkage elbow vote if `num_speakers: null`
5. Applies median-filter smoothing and orphan segment merging

Output: `{experiment}/input/diarization_result.json`

```json
[
  {
    "utterance_id": 0,
    "speaker_id": "SPEAKER_0",
    "speaker_name": "SPEAKER_0",
    "text": "...",
    "start": 0.0,
    "end": 4.2,
    "confidence": 0.94,
    "spk_confidence": 0.87
  }
]
```

---

## Step 2 — BRD: Schema Decision

**Script:** `scripts/brd_schema_decider.py`
**Prompt:** `artifacts_library/BRD/schema_decider_prompt.json`

Reads the transcript and asks the LLM to decide which BRD sections to generate — project domain, functional modules, and NFR sections. This schema gates Steps 3 and 4.

Output: `{experiment}/output/brd-schema.json`

---

## Step 2 — MOM/Custom: Document Fill

**Script:** `scripts/llm_filler.py` via `run_fill(mode=...)`

Single-pass (generic) or two-pass (MOM) fill of all leaf nodes in the schema. Every field gets a `value`, a `trace` referencing the source utterance, and a `why_null` code if not found.

Output: `{experiment}/output/{type}_output.json`

---

## Step 3 — Write Requirements (BRD only)

**Script:** `scripts/brd_requirements_writer.py`
**Prompt:** `artifacts_library/BRD/schema_prompt.json`

Uses the schema decision from Step 2 to fill every BRD field from the transcript. The most LLM-intensive step — sends the full transcript and schema to Gemini with a maximum token output of 32k.

Output: `{experiment}/output/brd-response.json`

---

## Step 4 — Link to Transcript (BRD only)

**Script:** `scripts/brd_traceability_linker.py`

Pure data merge — no LLM call. Replaces every `trace.utterance_id` reference in the BRD with the full diarisation entry. Also injects `value` keys on functional requirement list items for consistency.

Output: `{experiment}/output/brd-response-trace.json`

---

## Step 5 — Build Word Document

**Script:** `scripts/generic_docx_runner.py`

Invokes Node.js with the doc-type-specific JS template:

```
node artifacts_library/{TYPE}/JS_template.js <filled_json> <output_docx>
```

The JS template reads the filled JSON and renders a `.docx` using the `docx` npm package (pre-installed in `scripts/node_modules/`). The template must log `[OK] <path>` on completion.

Outputs: `{experiment}/output/BRD.docx`, `MOM.docx`, or `{TYPE}.docx`

---

## Step 6 — Gap Analysis (BRD only)

**Script:** `scripts/brd_gap_analyser.py`

Reads the completed BRD trace and transcript, then asks the LLM to:
- Classify every null/incomplete field by severity (critical/major/minor)
- Surface open questions never resolved in the meeting
- Flag risks discussed but not captured as requirements
- Score each section 0–100 for transcript confidence

Also auto-generates `gap-report.docx` via `generic_docx_runner.py`.

Output: `{experiment}/output/gap-report.json` + `gap-report.docx`

---

## Shared utilities

`scripts/llm_utils.py` provides functions used by all chain scripts:

| Function           | Purpose                                              |
|--------------------|------------------------------------------------------|
| `build_model()`    | Instantiate ChatGoogleGenerativeAI from config       |
| `invoke_with_retry()` | Run a LangChain chain with retry + backoff        |
| `extract_json()`   | Robust JSON extraction from LLM text output          |
| `collect_leaves()` | Walk schema tree, return all fillable leaf nodes     |
| `write_back()`     | Write a filled value back to a leaf node by dotpath  |
| `retry_delay()`    | Parse Gemini retryDelay hint or use exponential backoff |
| `load_json()`      | Load JSON from file                                  |
| `save_json()`      | Save JSON to file (creates parent dirs)              |

