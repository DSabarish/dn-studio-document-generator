# Frontend

The entire frontend is a single file: `frontend.html`. No build step, no framework, no dependencies except two Google Fonts loaded from CDN.

---

## Structure

```
frontend.html
  <style>          CSS design system + component styles (~880 lines)
  <body>
    .sidebar       Navigation + experiment indicator + YAML panel
    .main
      .topbar      Page title + pipeline status chip
      .content
        #view-prepare     3 tabs: Configure / Input / Speakers
        #view-pipeline    (empty — pipeline is inline on Input tab)
        #view-outputs     Download cards
  <script>         Application logic (~2100 lines)
```

---

## Navigation

`go(viewName)` switches views. View names and their aliases:

| Argument    | Resolves to    | Tab       |
|-------------|----------------|-----------|
| `prepare`   | view-prepare   | config    |
| `setup`     | view-prepare   | config    |
| `upload`    | view-prepare   | input     |
| `speakers`  | view-prepare   | speakers  |
| `pipeline`  | view-pipeline  | —         |
| `run`       | view-pipeline  | —         |
| `outputs`   | view-outputs   | —         |

`go('pipeline')` and `go('run')` both call `showInlinePipeline()`, which opens the pipeline panel inline on the Input tab.

---

## DOM cache

All frequently-used elements are cached at startup by `_initDomCache()` into the `$el` map. The `$id(id)` helper returns the cached element or falls back to a live query.

Do not call `document.getElementById()` directly in hot paths — use `$id()`.

---

## Pipeline flow (JS)

```
runPipeline()
  |
  ├─ Quick Run: await /api/doctypes/register (uploads schema + JS)
  |
  ├─ POST /api/run  →  { job_id }
  |
  └─ _doPoll()   (setTimeout loop, adaptive: 1s running / 2s idle)
       |
       ├─ GET /api/jobs/{id}?since={cursor}
       ├─ addLog() for each new log entry
       ├─ setStepState() for each step status change
       ├─ diar_analytics → renderDiarView() (after step 1)
       ├─ studio_outputs → show download card (after step 5)
       └─ status done/error/stopped → stop polling, show banner
```

---

## Step cards

`renderStepCards()` renders the step selection UI. Steps shown depend on doc type:

| Doc type    | Steps shown   |
|-------------|---------------|
| BRD         | 0 1 2 3 4 5 6 |
| MOM/Custom  | 0 1 2 5       |
| Quick Run   | 0 1 2 5       |

For Quick Run, a file upload row appears above the step cards. `_renderQrFileRow()` updates it when files are loaded.

`setStepState(step, state, timing)` updates a step card's appearance and triggers `renderPipelineProgress()` and `_updateTopbarStatus()`.

---

## Log panel

The log panel starts with `visibility:hidden` (not `display:none`) to preserve the 2-column grid layout. It becomes visible (`visibility:visible`) when `runPipeline()` starts.

`addLog(msg)` calls `_formatLogLine(msg)` which classifies messages by their ASCII prefix:

| Prefix    | Style     |
|-----------|-----------|
| `[OK]`    | green     |
| `[ERR]`   | red       |
| `[WARN]`  | amber     |
| `[SKIP]`  | dim       |
| `[STOP]`  | dim       |
| `>>`      | info blue |
| `>> Starting` | bold |
| 2+ spaces | dim       |

---

## Doc type pills

`loadDoctypes()` fetches `/api/doctypes` at startup and on each `showInlinePipeline()` call. `renderDtPills()` renders the pill buttons. `selectDocType(key)` updates `_currentDocType`, shows/hides the Quick Run file row, and calls `renderStepCards()`.

---

## Outputs page

`loadOutputs()` fetches `/api/config` and builds download cards from the `outputs` map. Called at startup, on pipeline completion, and when navigating to the Outputs view.

`refreshOutputsNavDot()` lights up the Outputs nav button when any output file exists.

---

## Key state variables

| Variable              | Purpose                                      |
|-----------------------|----------------------------------------------|
| `EXP`                 | Current experiment name                      |
| `selected`            | Set of step numbers selected to run          |
| `stepStates`          | Map of step → current state                  |
| `_currentDocType`     | Active doc type key                          |
| `_pollJobId`          | Job ID being polled                          |
| `_pollTimer`          | setTimeout handle for polling loop           |
| `_logCursor`          | Index of last log entry received             |
| `_diarData`           | Cached diarisation analytics                 |
| `_transcriptImported` | True if transcript was imported (skip 0,1)   |
| `_qrSchemaFile`       | Quick Run schema file                        |
| `_qrJsFile`           | Quick Run JS template file                   |
| `$el`                 | DOM element cache (populated by _initDomCache) |

