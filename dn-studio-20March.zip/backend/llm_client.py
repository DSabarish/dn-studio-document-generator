# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/llm_client.py
# PURPOSE: Thin wrapper around LangChain + Gemini 2.5 Flash.
#          All LLM calls go through here — swap the model in one place.
# ─────────────────────────────────────────────────────────────────────────────

import os
import re
import json
import logging
from typing import Optional

log = logging.getLogger("dn_studio.llm")


def get_chain(max_output_tokens: int = 8192):
    """
    Return a LangChain chain: ChatGoogleGenerativeAI | StrOutputParser.
    API key is read from GOOGLE_API_KEY env var (set in app.py from st.secrets).
    """
    from langchain_google_genai import ChatGoogleGenerativeAI
    from langchain_core.output_parsers import StrOutputParser

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0.2,
        max_output_tokens=max_output_tokens,
    )
    log.debug("[LLM] Chain initialised  model=gemini-2.5-flash  max_tokens=%d", max_output_tokens)
    return llm | StrOutputParser()


def call_llm(prompt: str, max_output_tokens: int = 8192) -> str:
    """
    Single LLM call. Returns raw string response.
    Raises RuntimeError on failure.
    """
    from langchain_core.messages import HumanMessage

    log.info("[LLM] Calling Gemini  max_tokens=%d  prompt_len=%d chars",
             max_output_tokens, len(prompt))
    try:
        chain    = get_chain(max_output_tokens)
        response = chain.invoke([HumanMessage(content=prompt)])
        log.info("[LLM] Response received  len=%d chars", len(response))
        return response
    except Exception as e:
        log.error("[LLM] Call failed: %s", str(e))
        raise RuntimeError(f"LLM call failed: {e}") from e


def extract_json(text: str) -> dict:
    """
    Strip markdown fences, find the outermost JSON object, parse and return.
    Raises ValueError with context on parse failure.
    """
    cleaned = re.sub(r"```(?:json)?\s*", "", text).strip()
    cleaned = re.sub(r"```\s*$",         "", cleaned).strip()

    start = cleaned.find("{")
    end   = cleaned.rfind("}") + 1
    if start == -1 or end == 0:
        raise ValueError(
            f"[LLM] No JSON object found in response.\n"
            f"First 500 chars:\n{text[:500]}"
        )

    json_str = cleaned[start:end]

    try:
        parsed = json.loads(json_str)
        log.debug("[LLM] JSON parsed successfully  keys=%s", list(parsed.keys())[:5])
        return parsed
    except json.JSONDecodeError as e:
        lines    = json_str.splitlines()
        err_line = e.lineno - 1
        context  = "\n".join(lines[max(0, err_line - 2): err_line + 3])
        raise ValueError(
            f"[LLM] JSONDecodeError at line {e.lineno}, col {e.colno}: {e.msg}\n"
            f"Context:\n{context}\n\n"
            f"Hint: Response may be truncated or contain unescaped characters."
        ) from e


def build_prompt(template_path: str, placeholders: dict) -> str:
    """
    Read a .md prompt template and replace all {{KEY}} placeholders.
    Raises FileNotFoundError if template_path does not exist.
    """
    log.debug("[LLM] Loading prompt template: %s", template_path)
    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    for key, value in placeholders.items():
        tag      = f"{{{{{key}}}}}"
        template = template.replace(tag, str(value))
        log.debug("[LLM] Injected placeholder: %s  (%d chars)", key, len(str(value)))

    log.info("[LLM] Prompt built  template=%s  total_len=%d chars",
             template_path, len(template))
    return template
