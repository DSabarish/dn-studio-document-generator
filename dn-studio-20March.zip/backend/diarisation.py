# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/diarisation.py
# PURPOSE: Wraps the full diarisation pipeline from DN_Diarisation_v1.ipynb
#          into two clean functions callable from Streamlit:
#            run_diarisation(audio_path, config) → dict
#            build_dashboard(json_path, roster)  → str (html path)
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import logging
import tempfile
import subprocess
import re
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple
from datetime import datetime

import numpy as np
import librosa
import soundfile as sf
from sklearn.cluster import SpectralClustering, AgglomerativeClustering
from sklearn.preprocessing import normalize
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from scipy.ndimage import median_filter
from faster_whisper import WhisperModel

log = logging.getLogger("dn_studio.diarisation")

SEED = 42
np.random.seed(SEED)

# ── GPU detection ─────────────────────────────────────────────────────────────
try:
    import torch
    if torch.cuda.is_available():
        DEVICE, COMPUTE_TYPE = "cuda", "float16"
        log.info("[DEVICE] GPU detected: %s", torch.cuda.get_device_name(0))
    else:
        DEVICE, COMPUTE_TYPE = "cpu", "int8"
        log.info("[DEVICE] No GPU — using CPU int8")
except ImportError:
    DEVICE, COMPUTE_TYPE = "cpu", "int8"


# ─────────────────────────────────────────────────────────────────────────────
# DATA CLASS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ASRSegment:
    start:        float
    end:          float
    text:         str
    speaker:      Optional[str] = None
    utterance_id: Optional[int] = None
    confidence:   float         = 1.0


# ─────────────────────────────────────────────────────────────────────────────
# AUDIO CONVERSION
# ─────────────────────────────────────────────────────────────────────────────

def convert_to_wav(input_path: str, output_path: str) -> str:
    """Convert any audio/video to 16kHz mono WAV via ffmpeg."""
    log.info("[CONVERT] %s → WAV", Path(input_path).name)
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", input_path, "-ac", "1", "-ar", "16000", "-vn", output_path],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"[CONVERT] ffmpeg failed:\n{result.stderr[-800:]}")
    sz_mb = Path(output_path).stat().st_size / 1024 / 1024
    log.info("[CONVERT] WAV ready  %.1f MB", sz_mb)
    return output_path


# ─────────────────────────────────────────────────────────────────────────────
# TEXT CLEANING
# ─────────────────────────────────────────────────────────────────────────────

_FILLERS  = re.compile(
    r'\b(um+|uh+|er+|ah+|hmm+|mhm|uh-huh|you know|i mean'
    r'|like,?\s+(?=\w)|sort of|kind of|basically|literally|actually,?\s+)\b',
    re.IGNORECASE,
)
_STUTTER  = re.compile(r'\b(\w+)[–-]\s+\1',  re.IGNORECASE)
_REPEATED = re.compile(r'\b(\w{2,})\s+\1\b', re.IGNORECASE)
_MULTI_SP = re.compile(r'\s{2,}')
_LEAD_PCT = re.compile(r'^[,\.;\s]+')


def clean_text(raw, remove_fillers=True, remove_stutters=True, remove_repeats=True):
    t = raw.strip()
    if remove_stutters: t = _STUTTER.sub(r'\1', t)
    if remove_repeats:  t = _REPEATED.sub(r'\1', t)
    if remove_fillers:  t = _FILLERS.sub(' ', t)
    t = _LEAD_PCT.sub('', _MULTI_SP.sub(' ', t))
    return (t[0].upper() + t[1:]).strip() if t else t


# ─────────────────────────────────────────────────────────────────────────────
# ASR
# ─────────────────────────────────────────────────────────────────────────────

def transcribe(audio_path, model_size="base.en", beam_size=5, best_of=5,
               vad_filter=True, vad_silence_ms=500, condition_on_prev=True,
               no_speech_thresh=0.6, log_prob_thresh=-1.0, compression_thresh=2.4,
               remove_fillers=True, remove_stutters=True, remove_repeats=True):
    log.info("[ASR] model=%s  device=%s", model_size, DEVICE)
    model = WhisperModel(model_size, device=DEVICE, compute_type=COMPUTE_TYPE)
    segs, _ = model.transcribe(
        audio_path, language="en", beam_size=beam_size, best_of=best_of,
        temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
        compression_ratio_threshold=compression_thresh,
        log_prob_threshold=log_prob_thresh,
        no_speech_threshold=no_speech_thresh,
        condition_on_previous_text=condition_on_prev,
        vad_filter=vad_filter,
        vad_parameters=dict(min_silence_duration_ms=vad_silence_ms),
        word_timestamps=False,
    )
    out = []
    for s in segs:
        t = clean_text(s.text, remove_fillers, remove_stutters, remove_repeats)
        if not t:
            continue
        conf = float(np.clip(np.exp(s.avg_logprob), 0.0, 1.0))
        out.append(ASRSegment(float(s.start), float(s.end), t, confidence=conf))
    log.info("[ASR] %d segments produced", len(out))
    return out


# ─────────────────────────────────────────────────────────────────────────────
# EMBEDDINGS
# ─────────────────────────────────────────────────────────────────────────────

def _embed_chunk(encoder, y, sr, start, end, min_dur=0.5):
    chunk = y[int(start * sr):int(end * sr)]
    if len(chunk) < int(min_dur * sr):
        return None
    try:
        from resemblyzer import preprocess_wav
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            sf.write(tmp.name, chunk, sr)
            wav = preprocess_wav(tmp.name)
        os.unlink(tmp.name)
        return encoder.embed_utterance(wav)
    except Exception:
        return None


def extract_utterance_embeddings(audio_path, asr_segments, sr=16000):
    from resemblyzer import VoiceEncoder
    log.info("[EMB] Embedding %d utterances", len(asr_segments))
    enc = VoiceEncoder("cpu")
    y, _ = librosa.load(audio_path, sr=sr, mono=True)
    valid_idx, embeddings = [], []
    for i, seg in enumerate(asr_segments):
        emb = _embed_chunk(enc, y, sr, seg.start, seg.end)
        if emb is not None:
            valid_idx.append(i)
            embeddings.append(emb)
    arr = np.array(embeddings, dtype=np.float32)
    log.info("[EMB] %d embeddings extracted  dim=%d", len(valid_idx), arr.shape[1])
    return valid_idx, arr


# ─────────────────────────────────────────────────────────────────────────────
# CLUSTERING + DIARISATION
# ─────────────────────────────────────────────────────────────────────────────

def best_num_speakers(X, max_n=8):
    Xn = normalize(X)
    best_n, best_score = 2, -1.0
    log.info("[DIAR] Silhouette search  max_speakers=%d", max_n)
    for n in range(2, min(max_n + 1, len(X))):
        try:
            _aff = np.clip(Xn @ Xn.T, 0.0, 1.0)
            np.fill_diagonal(_aff, 1.0)
            labels = SpectralClustering(
                n_clusters=n, affinity="precomputed", random_state=SEED,
                assign_labels="discretize", n_init=20,
            ).fit_predict(_aff)
            if len(np.unique(labels)) < n:
                raise ValueError("collapsed")
            score = silhouette_score(Xn, labels, metric="cosine")
            log.info("[DIAR]   n=%d  silhouette=%.4f", n, score)
            if score > best_score:
                best_score, best_n = score, n
        except Exception as ex:
            log.warning("[DIAR]   n=%d  failed: %s", n, ex)
    log.info("[DIAR] Best n_speakers=%d  silhouette=%.4f", best_n, best_score)
    return best_n


def diarize_utterances(asr_segments, valid_idx, embeddings,
                       num_speakers=None, max_speakers=8,
                       smooth_window=3, pca_variance=0.99):
    embeddings = np.nan_to_num(embeddings)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = np.where(norms > 1e-8, embeddings,
                          np.random.default_rng(SEED).normal(0, 1e-4, embeddings.shape))
    Xn = normalize(embeddings)

    if pca_variance < 1.0 and Xn.shape[1] > 10:
        Xn = PCA(n_components=pca_variance, svd_solver="full").fit_transform(Xn)

    if num_speakers is None:
        num_speakers = best_num_speakers(Xn, max_speakers)
    else:
        log.info("[DIAR] Fixed num_speakers=%d", num_speakers)

    Xn = normalize(Xn)
    try:
        _aff = np.clip(Xn @ Xn.T, 0.0, 1.0)
        np.fill_diagonal(_aff, 1.0)
        labels = SpectralClustering(
            n_clusters=num_speakers, affinity="precomputed", random_state=SEED,
            assign_labels="discretize", n_init=50,
        ).fit_predict(_aff)
        if len(np.unique(labels)) < num_speakers:
            raise ValueError("collapsed")
    except Exception:
        labels = AgglomerativeClustering(
            n_clusters=num_speakers, metric="euclidean", linkage="ward",
        ).fit_predict(Xn)

    labels = np.round(median_filter(labels.astype(float), size=smooth_window)).astype(int)

    centroids = {}
    for lbl in np.unique(labels):
        mask = labels == lbl
        centroids[lbl] = normalize(Xn[mask].mean(axis=0, keepdims=True))[0]

    for rank, seg_idx in enumerate(valid_idx):
        lbl = int(labels[rank])
        spk_conf = float(np.clip(np.dot(Xn[rank], centroids[lbl]), 0.0, 1.0))
        asr_segments[seg_idx].speaker      = f"SPEAKER_{lbl}"
        asr_segments[seg_idx].utterance_id = seg_idx
        asr_segments[seg_idx].__dict__["spk_confidence"] = round(spk_conf, 3)

    for i, seg in enumerate(asr_segments):
        if seg.speaker is None:
            nearest = min(valid_idx, key=lambda j: abs(j - i), default=None)
            seg.speaker      = asr_segments[nearest].speaker if nearest else "SPEAKER_UNKNOWN"
            seg.utterance_id = i
            seg.__dict__["spk_confidence"] = 0.0

    log.info("[DIAR] Labels assigned to %d segments", len(asr_segments))
    return asr_segments


# ─────────────────────────────────────────────────────────────────────────────
# SERIALISE
# ─────────────────────────────────────────────────────────────────────────────

def to_diarisation_json(asr_segments):
    return [{
        "start":          round(s.start,  3),
        "end":            round(s.end,    3),
        "utterance_id":   s.utterance_id,
        "speaker_id":     s.speaker,
        "speaker_name":   s.speaker,
        "confidence":     round(s.confidence, 3),
        "spk_confidence": round(s.__dict__.get("spk_confidence", 0.0), 3),
        "text":           s.text,
    } for s in asr_segments]


# ─────────────────────────────────────────────────────────────────────────────
# t-SNE
# ─────────────────────────────────────────────────────────────────────────────

def compute_tsne_coords(valid_idx, embeddings, asr_segments):
    if len(embeddings) < 4:
        return []
    Xn  = normalize(embeddings)
    pre = PCA(n_components=min(30, len(Xn) - 1, Xn.shape[1]), random_state=0).fit_transform(Xn)
    perp   = max(5, min(30, len(pre) // 4))
    coords = TSNE(n_components=2, perplexity=perp, n_iter=1000,
                  metric="cosine", random_state=0, init="pca").fit_transform(pre)
    pts = []
    for rank, seg_idx in enumerate(valid_idx):
        seg = asr_segments[seg_idx]
        pts.append({
            "x":     round(float(coords[rank, 0]), 4),
            "y":     round(float(coords[rank, 1]), 4),
            "spk":   seg.speaker,
            "start": round(seg.start, 2),
            "end":   round(seg.end,   2),
            "text":  seg.text[:120],
        })
    return pts


# ─────────────────────────────────────────────────────────────────────────────
# HTML VIEW — imports from ui/view_builder.py to keep this file clean
# ─────────────────────────────────────────────────────────────────────────────

def _build_html(segments, tsne_pts, roster, run_meta):
    from ui.view_builder import build_view_html
    return build_view_html(segments, tsne_pts, roster, run_meta)


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────────────────────────────────────

def run_diarisation(audio_path: str, config: dict = None) -> dict:
    """
    Full diarisation pipeline: convert → ASR → embed → cluster → output JSON + HTML.

    Parameters
    ----------
    audio_path : str   path to any audio/video file
    config     : dict  optional overrides (see keys below)

    Returns
    -------
    dict  { json_path, html_path }
    """
    cfg = {
        "whisper_model":   "base.en",
        "num_speakers":    None,
        "max_speakers":    8,
        "smooth_window":   3,
        "min_seg_dur":     0.4,
        "pca_variance":    0.99,
        "remove_fillers":  True,
        "remove_stutters": True,
        "remove_repeats":  True,
        "beam_size":       5,
        "best_of":         5,
        "vad_filter":      True,
        "vad_silence_ms":  500,
        "no_speech_thresh":0.6,
        "output_dir":      "outputs/diarisation",
        "roster":          [],
    }
    if config:
        cfg.update(config)

    out_dir = Path(cfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    log.info("[DIAR] Starting pipeline  audio=%s  output_dir=%s",
             Path(audio_path).name, out_dir)

    wav_path = str(out_dir / "input_audio.wav")
    convert_to_wav(audio_path, wav_path)

    asr_segs = transcribe(
        wav_path,
        model_size        = cfg["whisper_model"],
        beam_size         = cfg["beam_size"],
        best_of           = cfg["best_of"],
        vad_filter        = cfg["vad_filter"],
        vad_silence_ms    = cfg["vad_silence_ms"],
        no_speech_thresh  = cfg["no_speech_thresh"],
        remove_fillers    = cfg["remove_fillers"],
        remove_stutters   = cfg["remove_stutters"],
        remove_repeats    = cfg["remove_repeats"],
    )
    if not asr_segs:
        raise ValueError("[DIAR] No speech detected. Check your audio file.")

    valid_idx, embeddings = extract_utterance_embeddings(wav_path, asr_segs)

    asr_segs = diarize_utterances(
        asr_segs, valid_idx, embeddings,
        num_speakers  = cfg["num_speakers"],
        max_speakers  = cfg["max_speakers"],
        smooth_window = cfg["smooth_window"],
        pca_variance  = cfg["pca_variance"],
    )

    log.info("[DIAR] Computing t-SNE coordinates")
    tsne_pts = compute_tsne_coords(valid_idx, embeddings, asr_segs)

    segments_data = to_diarisation_json(asr_segs)
    json_path = out_dir / "diarization_response.json"
    json_path.write_text(
        json.dumps(segments_data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("[DIAR] diarization_response.json saved  %d utterances", len(segments_data))

    run_meta = {
        "label": Path(audio_path).stem,
        "model": cfg["whisper_model"],
        "date":  datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    html = _build_html(segments_data, tsne_pts, cfg["roster"], run_meta)
    html_path = out_dir / "diarization_view.html"
    html_path.write_text(html, encoding="utf-8")
    log.info("[DIAR] diarization_view.html saved")

    log.info("[DIAR] Pipeline complete ✓")
    return {"json_path": str(json_path), "html_path": str(html_path)}


def build_dashboard(json_path: str, roster: list = None) -> str:
    """
    Rebuild diarization_view.html from an existing diarization_response.json.
    Returns path to written HTML.
    """
    p    = Path(json_path)
    segs = json.loads(p.read_text(encoding="utf-8"))
    run_meta = {
        "label": p.parent.name,
        "model": "",
        "date":  datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    html = _build_html(segs, [], roster or [], run_meta)
    html_path = p.parent / "diarization_view.html"
    html_path.write_text(html, encoding="utf-8")
    log.info("[DIAR] diarization_view.html rebuilt → %s", html_path)
    return str(html_path)
