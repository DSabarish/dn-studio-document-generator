# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/document_generator.py
# PURPOSE: Config-driven document generation pipeline.
#          Reads DOCUMENT_TYPES from config/document_types.yaml.
#          Adding a new doc type there is all that's needed — no code changes here.
#
# MAIN FUNCTIONS:
#   load_document_types()               → dict of all doc type configs
#   generate_document(doc_type, ...)    → runs Phase 1 (+ Phase 2) + DOCX render
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import logging
import subprocess
from pathlib import Path
from typing import Optional
import yaml

from backend.llm_client import call_llm, extract_json, build_prompt

log = logging.getLogger("dn_studio.generator")

CONFIG_PATH = Path("config/document_types.yaml")


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG LOADER
# ─────────────────────────────────────────────────────────────────────────────

def load_document_types() -> dict:
    """
    Load DOCUMENT_TYPES from config/document_types.yaml.
    Returns a dict keyed by doc type name (BPD, BRD, MOM, ...).
    """
    log.debug("[CFG] Loading document types from %s", CONFIG_PATH)
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    log.info("[CFG] Document types loaded: %s", list(cfg.keys()))
    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1 — Schema generation
# ─────────────────────────────────────────────────────────────────────────────

def run_phase1(
    doc_type: str,
    cfg: dict,
    diarisation_json: list,
    business_context: str,
    h1_sections: str,
    output_dir: Path,
) -> dict:
    """
    Phase 1: build schema prompt → call LLM → parse → save a_schema.json.
    Returns the parsed schema dict.
    """
    log.info("[GEN][%s] Phase 1 started — schema design", doc_type)

    prompt = build_prompt(cfg["p1_prompt"], {
        "BUSINESS_CONTEXT":  business_context,
        "H1_SECTIONS":       h1_sections,
        "DIARISATION_JSON":  json.dumps(diarisation_json, indent=2),
    })

    log.info("[GEN][%s] Phase 1 — calling LLM  prompt_len=%d chars", doc_type, len(prompt))
    raw = call_llm(prompt, max_output_tokens=8192)

    schema = extract_json(raw)
    log.info("[GEN][%s] Phase 1 — schema parsed", doc_type)

    # Count sections for log
    h1s = schema.get("structure", [])
    h2c = sum(len(h1.get("children", [])) for h1 in h1s)
    h3c = sum(len(h3.get("children", []))
              for h1 in h1s for h3 in h1.get("children", []))
    log.info("[GEN][%s] Schema structure — H1:%d  H2:%d  H3:%d", doc_type, len(h1s), h2c, h3c)

    schema_path = output_dir / "a_schema.json"
    schema_path.write_text(json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")
    log.info("[GEN][%s] Phase 1 complete — saved %s", doc_type, schema_path)

    return schema


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2 — Content population
# ─────────────────────────────────────────────────────────────────────────────

def run_phase2(
    doc_type: str,
    cfg: dict,
    diarisation_json: list,
    business_context: str,
    schema: dict,
    output_dir: Path,
) -> dict:
    """
    Phase 2: build populate prompt → call LLM (max 65536 tokens) → parse → save b_response.json.
    Returns the populated response dict.
    """
    log.info("[GEN][%s] Phase 2 started — content population", doc_type)

    prompt = build_prompt(cfg["p2_prompt"], {
        "BUSINESS_CONTEXT":  business_context,
        "SCHEMA_JSON":       json.dumps(schema, indent=2),
        "DIARISATION_JSON":  json.dumps(diarisation_json, indent=2),
    })

    log.info("[GEN][%s] Phase 2 — calling LLM  prompt_len=%d chars  max_tokens=65536",
             doc_type, len(prompt))
    raw = call_llm(prompt, max_output_tokens=65536)

    populated = extract_json(raw)
    log.info("[GEN][%s] Phase 2 — response parsed", doc_type)

    # Validate — count missing H3 sections
    missing = []
    for h1 in populated.get("structure", []):
        for h2 in h1.get("children", []):
            for h3 in h2.get("children", []):
                content = h3.get("content")
                if not content or content == "" or "TO BE CONFIRMED" in str(content):
                    missing.append(h3.get("name", "?"))

    if missing:
        log.warning("[GEN][%s] Phase 2 — %d sections missing content: %s",
                    doc_type, len(missing), missing[:5])
    else:
        log.info("[GEN][%s] Phase 2 — all sections populated ✓", doc_type)

    response_path = output_dir / "b_response.json"
    response_path.write_text(json.dumps(populated, indent=2, ensure_ascii=False), encoding="utf-8")
    log.info("[GEN][%s] Phase 2 complete — saved %s", doc_type, response_path)

    return populated


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 3 — DOCX render via Node.js
# ─────────────────────────────────────────────────────────────────────────────

def run_phase3(
    doc_type: str,
    cfg: dict,
    output_dir: Path,
) -> Path:
    """
    Phase 3: node <js_template> b_response.json <output.docx>
    Returns path to generated .docx file.
    """
    log.info("[GEN][%s] Phase 3 started — DOCX render", doc_type)

    response_path = output_dir / "b_response.json"
    docx_path     = output_dir / cfg["output_filename"]
    js_template   = cfg["js_template"]

    cmd = ["node", js_template, str(response_path), str(docx_path)]
    log.info("[GEN][%s] Running: %s", doc_type, " ".join(cmd))

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        for line in result.stdout.strip().splitlines():
            log.info("[NODE][%s] %s", doc_type, line)

    if result.returncode != 0:
        log.error("[GEN][%s] Node.js failed:\n%s", doc_type, result.stderr)
        raise RuntimeError(
            f"[GEN][{doc_type}] DOCX render failed.\n"
            f"stderr: {result.stderr[-800:]}"
        )

    size_kb = docx_path.stat().st_size / 1024
    log.info("[GEN][%s] Phase 3 complete — %s  (%.1f KB)", doc_type, docx_path, size_kb)
    return docx_path


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def generate_document(
    doc_type: str,
    diarisation_json: list,
    business_context: str = "",
    h1_sections: str = "",
    log_callback=None,
) -> dict:
    """
    Full pipeline: Phase 1 (+ Phase 2 if llm_calls==2) + Phase 3 DOCX render.

    Parameters
    ----------
    doc_type         : key from DOCUMENT_TYPES (e.g. "BPD", "BRD", "MOM")
    diarisation_json : parsed diarization_response.json list
    business_context : free-text business context injected into prompts
    h1_sections      : comma-separated H1 section names
    log_callback     : optional callable(str) for streaming log lines to Streamlit

    Returns
    -------
    dict with keys:
        schema_path   : str path to a_schema.json (or None for MOM)
        response_path : str path to b_response.json
        docx_path     : str path to output .docx
        doc_type      : str
    """
    def emit(msg: str):
        log.info(msg)
        if log_callback:
            log_callback(msg)

    emit(f"[GEN] Starting document generation  doc_type={doc_type}")

    # Load config
    all_types = load_document_types()
    if doc_type not in all_types:
        raise ValueError(f"[GEN] Unknown doc_type '{doc_type}'. "
                         f"Available: {list(all_types.keys())}")

    cfg = all_types[doc_type]
    emit(f"[GEN][{doc_type}] Config loaded  llm_calls={cfg['llm_calls']}")

    # Prepare output directory
    output_dir = Path(cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    emit(f"[GEN][{doc_type}] Output dir: {output_dir}")

    schema        = None
    schema_path   = None
    response_path = None

    # ── Phase 1 ──────────────────────────────────────────────────────────────
    emit(f"[GEN][{doc_type}] Phase 1 — schema design started")
    if cfg["llm_calls"] == 2:
        schema      = run_phase1(doc_type, cfg, diarisation_json,
                                  business_context, h1_sections, output_dir)
        schema_path = str(output_dir / "a_schema.json")
        emit(f"[GEN][{doc_type}] Phase 1 complete ✓")
    else:
        emit(f"[GEN][{doc_type}] Phase 1 skipped (MOM single-call mode)")

    # ── Phase 2 ──────────────────────────────────────────────────────────────
    emit(f"[GEN][{doc_type}] Phase 2 — content population started")
    if cfg["llm_calls"] == 2:
        populated     = run_phase2(doc_type, cfg, diarisation_json,
                                   business_context, schema, output_dir)
    else:
        # MOM: single call using p1_prompt, outputs b_response.json directly
        emit(f"[GEN][{doc_type}] Single-call mode — using p1_prompt for full output")
        prompt = build_prompt(cfg["p1_prompt"], {
            "BUSINESS_CONTEXT":  business_context,
            "DIARISATION_JSON":  json.dumps(diarisation_json, indent=2),
        })
        raw       = call_llm(prompt, max_output_tokens=8192)
        populated = extract_json(raw)
        response_path_obj = output_dir / "b_response.json"
        response_path_obj.write_text(
            json.dumps(populated, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        emit(f"[GEN][{doc_type}] Single-call response saved")

    response_path = str(output_dir / "b_response.json")
    emit(f"[GEN][{doc_type}] Phase 2 complete ✓")

    # ── Phase 3 ──────────────────────────────────────────────────────────────
    emit(f"[GEN][{doc_type}] Phase 3 — DOCX render started")
    docx_path = run_phase3(doc_type, cfg, output_dir)
    emit(f"[GEN][{doc_type}] Phase 3 complete ✓")

    emit(f"[GEN][{doc_type}] Pipeline complete — {docx_path}")

    return {
        "doc_type":     doc_type,
        "schema_path":  schema_path,
        "response_path": response_path,
        "docx_path":    str(docx_path),
    }
