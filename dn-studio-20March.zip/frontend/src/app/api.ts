// ─────────────────────────────────────────────────────────────────────────────
// FILE: frontend/src/app/api.ts
// ─────────────────────────────────────────────────────────────────────────────

export const API_BASE_URL =
  (import.meta.env.VITE_API_URL as string) ||
  (typeof window !== 'undefined' && window.location.hostname !== 'localhost'
    ? ''
    : 'http://localhost:8000');

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Segment {
  start: number;
  end: number;
  utterance_id: number;
  speaker_id: string;
  speaker_name: string;
  confidence: number;
  spk_confidence: number;
  text: string;
}

export interface DiarisationResult {
  status: string;
  filename: string;
  n_utterances: number;
  n_speakers: number;
  duration_sec: number;
  model: string;
  segments: Segment[];
  json_path: string;
  html_path: string | null;
}

export interface DiarProgress {
  pct: number;
  log?: string;
  done?: boolean;
  result?: DiarisationResult;
}

export interface DocumentType {
  id: string;
  label: string;
  description: string;
  llm_calls: number;
  output_filename: string;
}

export interface GenerateRequest {
  doc_type: string;
  diarisation_json: Segment[];
  business_context: string;
  h1_sections: string;
  gemini_api_key?: string;
}

export interface JobStatus {
  job_id: string;
  result: {
    status: 'running' | 'complete' | 'error';
    doc_type: string;
    schema_path?: string;
    response_path?: string;
    docx_path?: string;
    error?: string;
  };
  logs: string[];
}

// ─── Health ──────────────────────────────────────────────────────────────────

export async function checkHealth(): Promise<boolean> {
  try {
    const r = await fetch(API_BASE_URL + '/health');
    return r.ok;
  } catch { return false; }
}

// ─── Document types ───────────────────────────────────────────────────────────

export async function getDocumentTypes(): Promise<DocumentType[]> {
  const r = await fetch(API_BASE_URL + '/document-types');
  if (!r.ok) throw new Error('Failed to load document types');
  const data = await r.json();
  return data.document_types;
}

// ─── Diarisation — POST then stream progress ──────────────────────────────────

export async function startDiarisation(
  audioFile: File,
  config: {
    whisperModel: string;
    numSpeakers: number | null;
    removeFillers: boolean;
    removeStutters: boolean;
  }
): Promise<string> {
  const form = new FormData();
  form.append('audio_file', audioFile);
  form.append('whisper_model', config.whisperModel);
  if (config.numSpeakers !== null) form.append('num_speakers', String(config.numSpeakers));
  form.append('remove_fillers',  String(config.removeFillers));
  form.append('remove_stutters', String(config.removeStutters));

  const r = await fetch(API_BASE_URL + '/diarise', { method: 'POST', body: form });
  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error(err.detail || 'Failed to start diarisation');
  }
  const data = await r.json();
  return data.job_id;
}

export function streamDiarisation(
  jobId: string,
  onProgress: (p: DiarProgress) => void,
  onDone: (result: DiarisationResult) => void,
  onError: (msg: string) => void
): () => void {
  let es: EventSource;
  let closed    = false;
  let retries   = 0;
  const MAX_RETRY = 10;

  function connect() {
    es = new EventSource(API_BASE_URL + '/diarise/stream/' + jobId);

    es.onmessage = (e) => {
      // Skip SSE comment lines (keepalive pings start with ":")
      if (!e.data || e.data.startsWith(':')) return;
      try {
        const data: DiarProgress = JSON.parse(e.data);
        retries = 0;  // reset on successful message
        onProgress(data);
        if (data.done && data.result) {
          closed = true;
          es.close();
          onDone(data.result);
        }
      } catch { /* ignore parse errors */ }
    };

    es.onerror = () => {
      es.close();
      if (closed) return;
      retries++;
      if (retries > MAX_RETRY) {
        onError('Connection lost after ' + MAX_RETRY + ' retries. Check server logs.');
        return;
      }
      // Reconnect after short delay — job state is preserved on server
      const delay = Math.min(1000 * retries, 5000);
      setTimeout(connect, delay);
    };
  }

  connect();
  return () => { closed = true; es?.close(); };
}

// ─── Upload existing JSON — send as raw body to avoid localtunnel 1MB limit ──

export async function uploadDiarisationJson(
  file: File
): Promise<DiarisationResult> {
  // Send raw JSON body — no multipart wrapper — avoids localtunnel size limit
  const raw = await file.arrayBuffer();
  const r = await fetch(API_BASE_URL + '/upload-json', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: raw,
  });
  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error(err.detail || 'Upload failed');
  }
  return r.json();
}

export function getDiarisationJsonUrl(): string {
  return API_BASE_URL + '/download/diarisation-json';
}
export function getDiarisationHtmlUrl(): string {
  return API_BASE_URL + '/download/diarisation-html';
}

// ─── Document generation ─────────────────────────────────────────────────────

export async function startGeneration(req: GenerateRequest): Promise<string> {
  const r = await fetch(API_BASE_URL + '/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  });
  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error(err.detail || 'Failed to start generation');
  }
  return (await r.json()).job_id;
}

export async function getJobStatus(jobId: string): Promise<JobStatus> {
  const r = await fetch(API_BASE_URL + '/generate/status/' + jobId);
  if (!r.ok) throw new Error('Failed to get job status');
  return r.json();
}

export function streamJobLogs(
  jobId: string,
  onLog: (line: string) => void,
  onDone: (result: JobStatus['result']) => void,
  onError: (err: string) => void
): () => void {
  let es: EventSource;
  let closed  = false;
  let retries = 0;
  const MAX_RETRY = 10;

  function connect() {
    es = new EventSource(API_BASE_URL + '/generate/stream/' + jobId);
    es.onmessage = (e) => {
      if (!e.data || e.data.startsWith(':')) return;
      try {
        const data = JSON.parse(e.data);
        retries = 0;
        if (data.log)  onLog(data.log);
        if (data.done) { closed = true; es.close(); onDone(data.result); }
      } catch { /* ignore */ }
    };
    es.onerror = () => {
      es.close();
      if (closed) return;
      retries++;
      if (retries > MAX_RETRY) { onError('Connection lost. Check server logs.'); return; }
      setTimeout(connect, Math.min(1000 * retries, 5000));
    };
  }

  connect();
  return () => { closed = true; es?.close(); };
}

export function getDownloadUrl(
  type: 'schema' | 'response' | 'docx',
  jobId: string
): string {
  return API_BASE_URL + '/download/' + type + '/' + jobId;
}
