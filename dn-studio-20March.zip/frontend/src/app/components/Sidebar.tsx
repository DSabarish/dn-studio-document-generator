// FILE: frontend/src/app/components/Sidebar.tsx
import { useState } from 'react';
import type { DiarisationResult } from '../api';

interface SidebarProps {
  currentStage: number;
  onStageChange: (stage: number) => void;
  hasDiarisation: boolean;
  hasDocument: boolean;
  diarisationData?: DiarisationResult | null;
  documentData?: any;
  geminiApiKey: string;
  onApiKeyChange: (key: string) => void;
}

export function Sidebar({
  currentStage, onStageChange,
  hasDiarisation, hasDocument,
  diarisationData, documentData,
  geminiApiKey, onApiKeyChange,
}: SidebarProps) {
  const [showKey, setShowKey] = useState(false);

  return (
    <div className="w-52 bg-[#1a1a1a] border-r border-[#2a2a2a] flex flex-col h-screen flex-shrink-0">
      <div className="p-4 border-b border-[#2a2a2a]">
        <div className="text-white font-medium">DN-Studio</div>
        <div className="text-[#888] text-xs mt-0.5">v1.0 · Colab backend</div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="p-4">
          <div className="text-[#888] text-xs uppercase tracking-wider mb-3">Session</div>
          {[1, 2].map(stage => (
            <button key={stage} onClick={() => onStageChange(stage)}
              className={`w-full text-left px-3 py-2 rounded mb-2 flex items-center gap-2 transition-all ${
                currentStage === stage
                  ? 'bg-[#2a2a2a] text-white'
                  : 'text-[#aaa] hover:bg-[#252525] hover:text-white'
              }`}>
              <div className={`w-2 h-2 rounded-full transition-colors ${
                stage === 1 ? (hasDiarisation ? 'bg-green-500' : 'bg-[#444]')
                            : (hasDocument    ? 'bg-green-500' : 'bg-[#444]')
              }`} />
              <span className="text-sm">Stage {stage} — {stage === 1 ? 'Diarisation' : 'Documents'}</span>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-[#2a2a2a]">
          <div className="text-[#888] text-xs uppercase tracking-wider mb-3">State</div>

          <div className="mb-4">
            <div className="text-[#aaa] text-sm mb-2">diarisation JSON</div>
            {hasDiarisation ? (
              <>
                <div className="bg-green-600 text-white text-xs px-2 py-0.5 rounded inline-block mb-1">&#10003; loaded</div>
                <div className="text-[#888] text-xs">{diarisationData?.filename}</div>
                <div className="text-[#666] text-xs">{diarisationData?.n_utterances} utterances · {diarisationData?.n_speakers} speakers</div>
              </>
            ) : (
              <div className="bg-[#2a2a2a] text-[#888] text-xs px-2 py-1 rounded inline-block">— none yet</div>
            )}
          </div>

          <div>
            <div className="text-[#aaa] text-sm mb-2">last document</div>
            {hasDocument ? (
              <>
                <div className="bg-green-600 text-white text-xs px-2 py-0.5 rounded inline-block mb-1">&#10003; {documentData?.type} ready</div>
                <div className="text-[#666] text-xs">{documentData?.type}_output.docx</div>
              </>
            ) : (
              <div className="bg-[#2a2a2a] text-[#888] text-xs px-2 py-1 rounded inline-block">— none yet</div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-[#2a2a2a]">
          <div className="text-[#888] text-xs uppercase tracking-wider mb-2">Gemini API Key</div>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={geminiApiKey}
              onChange={e => onApiKeyChange(e.target.value)}
              placeholder="AIzaSy..."
              className="w-full bg-[#2a2a2a] text-white text-xs border border-[#333] rounded px-2 py-1.5 pr-8 focus:outline-none focus:border-[#555]"
            />
            <button onClick={() => setShowKey(v => !v)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[#666] hover:text-white transition text-xs">
              {showKey ? '●' : '○'}
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-[#2a2a2a] text-xs text-[#666]">
        Gemini 2.5 Flash<br />Colab runtime · active
      </div>
    </div>
  );
}
