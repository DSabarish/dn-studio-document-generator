// ─────────────────────────────────────────────────────────────────────────────
// FILE: frontend/src/app/components/Stage1.tsx
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useRef, useEffect } from 'react';
import { Upload, ChevronDown } from 'lucide-react';
import {
  startDiarisation,
  streamDiarisation,
  uploadDiarisationJson,
  getDiarisationJsonUrl,
  getDiarisationHtmlUrl,
  type DiarisationResult,
} from '../api';

interface Stage1Props {
  onDiarisationComplete: (data: DiarisationResult) => void;
  onClearSession: () => void;
  existingResult?: DiarisationResult | null;
}

// Pipeline steps shown in the progress UI
const STEPS = [
  { pct: 5,   label: 'Converting audio to WAV' },
  { pct: 15,  label: 'Loading Whisper model' },
  { pct: 35,  label: 'Transcribing speech' },
  { pct: 55,  label: 'Extracting speaker embeddings' },
  { pct: 70,  label: 'Running speaker clustering' },
  { pct: 82,  label: 'Computing t-SNE' },
  { pct: 90,  label: 'Writing diarization JSON' },
  { pct: 95,  label: 'Building HTML view' },
  { pct: 100, label: 'Complete ✓' },
];

function currentStep(pct: number) {
  return STEPS.findLast(s => pct >= s.pct) ?? STEPS[0];
}

export function Stage1({ onDiarisationComplete, onClearSession, existingResult }: Stage1Props) {
  const [isDragging,     setIsDragging]     = useState(false);
  const [isProcessing,   setIsProcessing]   = useState(false);
  const [progress,       setProgress]       = useState(0);   // 0-100
  const [statusMsg,      setStatusMsg]      = useState('');
  const [logLines,       setLogLines]       = useState<string[]>([]);
  const [error,          setError]          = useState('');
  const [whisperModel,   setWhisperModel]   = useState('base.en');
  const [speakerCount,   setSpeakerCount]   = useState('auto');
  const [removeFillers,  setRemoveFillers]  = useState(true);
  const [removeStutters, setRemoveStutters] = useState(true);
  const [activeTab,      setActiveTab]      = useState<'preview'|'json'|'swimlane'>('preview');

  const audioRef    = useRef<HTMLInputElement>(null);
  const jsonRef     = useRef<HTMLInputElement>(null);
  const stopStream  = useRef<(() => void) | null>(null);
  const logEndRef   = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logLines]);

  // Clean up SSE on unmount
  useEffect(() => () => { stopStream.current?.(); }, []);

  const COLORS = ['#8b5cf6','#10b981','#f97316','#eab308','#3b82f6','#ec4899'];

  function buildLanes(segs: DiarisationResult['segments']) {
    const spks  = [...new Set(segs.map(s => s.speaker_id))].sort();
    const total = Math.max(...segs.map(s => s.end), 1);
    return spks.map((sp, i) => ({
      name:  sp,
      color: COLORS[i % COLORS.length],
      segs:  segs.filter(s => s.speaker_id === sp).map(s => ({
        left:  (s.start / total) * 100,
        width: Math.max(0.3, ((s.end - s.start) / total) * 100),
      })),
    }));
  }

  async function doAudio(file: File) {
    setIsProcessing(true);
    setError('');
    setProgress(0);
    setLogLines([]);
    setStatusMsg('Uploading audio file…');

    try {
      const n     = speakerCount === 'auto' ? null : parseInt(speakerCount);
      const jobId = await startDiarisation(file, {
        whisperModel,
        numSpeakers:    n,
        removeFillers,
        removeStutters,
      });

      setStatusMsg('Pipeline started — streaming progress…');

      stopStream.current = streamDiarisation(
        jobId,
        (p) => {
          if (p.pct >= 0) setProgress(p.pct);
          if (p.log)      setLogLines(prev => [...prev, p.log!]);
          setStatusMsg(currentStep(p.pct ?? 0).label);
        },
        (result) => {
          setIsProcessing(false);
          setProgress(100);
          if (result.status === 'error') {
            setError((result as any).error || 'Diarisation failed');
          } else {
            onDiarisationComplete(result);
          }
        },
        (err) => {
          setIsProcessing(false);
          setError(err);
        }
      );
    } catch (e: any) {
      setIsProcessing(false);
      setError(e.message || 'Diarisation failed');
    }
  }

  async function doJson(file: File) {
    setIsProcessing(true);
    setError('');
    setProgress(0);
    setStatusMsg('Uploading JSON…');
    try {
      const res = await uploadDiarisationJson(file);
      setProgress(100);
      onDiarisationComplete(res);
    } catch (e: any) {
      setError(e.message || 'Upload failed');
    } finally {
      setIsProcessing(false);
      setStatusMsg('');
    }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) f.name.endsWith('.json') ? doJson(f) : doAudio(f);
  }

  const res      = existingResult;
  const lanes    = res ? buildLanes(res.segments) : [];
  const durStr   = res
    ? (Math.floor(res.duration_sec / 60) > 0
        ? Math.floor(res.duration_sec / 60) + 'm'
        : res.duration_sec + 's')
    : '';

  // Which STEPS are "done" at current progress
  function stepStatus(s: typeof STEPS[0]) {
    if (progress >= s.pct)              return 'done';
    if (progress >= s.pct - 15)        return 'active';
    return 'pending';
  }

  return (
    <div className="flex-1 bg-[#111] text-white overflow-auto">
      <div className="p-6">

        {/* Title */}
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl font-bold">Stage 1 — Diarisation</h1>
          <div className="flex gap-3">
            {res && <span className="px-5 py-2 bg-white text-black rounded-full text-sm font-semibold">JSON ready</span>}
            <button onClick={onClearSession}
              className="px-5 py-2 bg-[#2a2a2a] text-white rounded-full hover:bg-[#333] transition text-sm">
              Clear session
            </button>
          </div>
        </div>
        <p className="text-[#888] text-sm mb-6">Run once — reuse the JSON for every document</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-lg text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Input + Config */}
        <div className="grid grid-cols-2 gap-6 mb-6">

          {/* Input card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Input</h3>
            <p className="text-[#888] text-xs mb-4">Upload audio/video — or skip if you already have a JSON</p>

            {/* Drop zone */}
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={onDrop}
              onClick={() => !isProcessing && audioRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200 mb-4 ${
                isDragging ? 'border-white bg-white/5' : 'border-[#444] hover:border-[#666]'
              } ${isProcessing ? 'cursor-default' : ''}`}
            >
              {isProcessing ? (
                <div className="space-y-4">
                  {/* Spinner gone — replaced by progress */}
                  <div className="text-sm text-white">{statusMsg}</div>

                  {/* Progress bar */}
                  <div className="w-full bg-[#2a2a2a] rounded-full h-3 overflow-hidden">
                    <div
                      className="h-3 rounded-full transition-all duration-500"
                      style={{
                        width: progress + '%',
                        background: 'linear-gradient(90deg, #6366f1, #8b5cf6)',
                      }}
                    />
                  </div>
                  <div className="text-[#888] text-xs font-mono">{progress}% complete</div>

                  {/* Step list */}
                  <div className="space-y-1 text-left mt-2">
                    {STEPS.map(s => {
                      const st = stepStatus(s);
                      return (
                        <div key={s.pct} className={`flex items-center gap-2 text-xs transition-colors ${
                          st === 'done'   ? 'text-green-400' :
                          st === 'active' ? 'text-purple-300 font-semibold' :
                                           'text-[#555]'
                        }`}>
                          <span className="w-3 text-center">
                            {st === 'done' ? '✓' : st === 'active' ? '›' : '·'}
                          </span>
                          <span>{s.label}</span>
                          {st === 'done' && <span className="text-[#444] ml-auto">{s.pct}%</span>}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <>
                  <Upload className={`mx-auto mb-3 transition-colors ${isDragging ? 'text-white' : 'text-[#666]'}`} size={32} />
                  <div className="font-medium mb-1">Drop audio / video here</div>
                  <div className="text-[#666] text-xs">mp3, mp4, m4a, wav, mkv — any format</div>
                </>
              )}
            </div>

            <input ref={audioRef} type="file"
              accept="audio/*,video/*,.mp3,.mp4,.m4a,.wav,.mkv,.ogg,.flac,.webm"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doAudio(f); }} />

            {/* Log lines (shown while processing) */}
            {isProcessing && logLines.length > 0 && (
              <div className="bg-[#0a0a0a] rounded-lg p-3 font-mono text-[10px] text-[#666] max-h-28 overflow-y-auto mb-4">
                {logLines.map((l, i) => <div key={i}>{l}</div>)}
                <div ref={logEndRef} />
              </div>
            )}

            <div className="text-center text-[#666] text-xs my-3">or</div>

            <button
              onClick={() => jsonRef.current?.click()}
              disabled={isProcessing}
              className="w-full px-4 py-3 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed">
              Upload existing<br />diarization_response.json
            </button>
            <input ref={jsonRef} type="file" accept=".json" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doJson(f); }} />
          </div>

          {/* Config card */}
          <div className="bg-[#1a1a1a] rounded-xl p-6 border border-[#2a2a2a]">
            <h3 className="font-semibold mb-1">Pipeline config</h3>
            <p className="text-[#888] text-xs mb-4">Adjust before running</p>

            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs block mb-2">Whisper model</label>
                <div className="relative">
                  <select value={whisperModel} onChange={e => setWhisperModel(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="tiny.en">tiny.en (fastest)</option>
                    <option value="base.en">base.en</option>
                    <option value="small.en">small.en</option>
                    <option value="medium.en">medium.en (best)</option>
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>

              <div>
                <label className="text-[#888] text-xs block mb-2">Speaker count</label>
                <div className="relative">
                  <select value={speakerCount} onChange={e => setSpeakerCount(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 border border-[#3a3a3a] focus:outline-none focus:border-[#555]">
                    <option value="auto">Auto-detect (silhouette)</option>
                    {[2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} speakers</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666] pointer-events-none" size={16} />
                </div>
              </div>

              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeFillers}
                  onChange={e => setRemoveFillers(e.target.checked)}
                  className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove fillers</span>
              </label>

              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={removeStutters}
                  onChange={e => setRemoveStutters(e.target.checked)}
                  className="w-4 h-4 accent-white" />
                <span className="text-sm">Remove stutters</span>
              </label>

              <button
                onClick={() => audioRef.current?.click()}
                disabled={isProcessing}
                className="w-full px-4 py-3 bg-white text-black rounded-lg hover:bg-gray-200 transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed">
                {isProcessing ? `Running… ${progress}%` : 'Run diarisation'}
              </button>
            </div>
          </div>
        </div>

        {/* Output */}
        {res && (
          <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold">Diarisation output</h3>
              <div className="flex gap-1 bg-[#0d0d0d] rounded-lg p-1">
                {(['preview','json','swimlane'] as const).map(t => (
                  <button key={t} onClick={() => setActiveTab(t)}
                    className={`px-3 py-1.5 text-xs rounded-md transition-all ${
                      activeTab === t ? 'bg-[#2a2a2a] text-white' : 'text-[#888] hover:text-white'
                    }`}>
                    {t === 'swimlane' ? 'Swimlane view' : t.charAt(0).toUpperCase() + t.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[
                ['Speakers',   res.n_speakers],
                ['Utterances', res.n_utterances],
                ['Duration',   durStr],
                ['Model',      res.model],
              ].map(([label, value]) => (
                <div key={String(label)}>
                  <div className="text-[#888] text-xs mb-1">{label}</div>
                  <div className="text-2xl font-semibold">{value}</div>
                </div>
              ))}
            </div>

            {/* Swimlanes */}
            {(activeTab === 'preview' || activeTab === 'swimlane') && (
              <div>
                <div className="text-[#888] text-xs mb-3 uppercase tracking-wider">Speaker lanes</div>
                <div className="space-y-2">
                  {lanes.map((lane, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="text-[#666] text-xs w-24 flex-shrink-0 text-right">{lane.name}</div>
                      <div className={`flex-1 bg-[#0a0a0a] rounded relative overflow-hidden ${activeTab === 'swimlane' ? 'h-8' : 'h-5'}`}>
                        {lane.segs.map((s, si) => (
                          <div key={si} className="absolute top-0.5 rounded-sm"
                            style={{
                              left:  s.left  + '%',
                              width: s.width + '%',
                              height: activeTab === 'swimlane' ? '28px' : '16px',
                              backgroundColor: lane.color,
                              opacity: 0.9,
                            }} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'json' && (
              <pre className="bg-[#0a0a0a] rounded-lg p-4 text-xs text-[#888] overflow-auto max-h-64 font-mono">
                {JSON.stringify(res.segments.slice(0, 5), null, 2)}
              </pre>
            )}

            {/* Actions */}
            <div className="flex gap-3 mt-6">
              <a href={getDiarisationJsonUrl()} download="diarization_response.json"
                className="px-6 py-2.5 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium">
                Download JSON
              </a>
              {res.html_path && (
                <a href={getDiarisationHtmlUrl()} download="diarization_view.html"
                  className="px-6 py-2.5 bg-[#2a2a2a] text-white rounded-lg hover:bg-[#333] transition text-sm font-medium">
                  Open HTML view
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
