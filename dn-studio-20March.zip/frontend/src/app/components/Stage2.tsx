// ─────────────────────────────────────────────────────────────────────────────
// FILE: frontend/src/app/components/Stage2.tsx
// PURPOSE: Stage 2 — Document generation. Wired to FastAPI /generate with
//          SSE log streaming. Doc types loaded from /document-types.
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';
import {
  getDocumentTypes,
  startGeneration,
  streamJobLogs,
  getDownloadUrl,
  type DocumentType,
  type DiarisationResult,
  type JobStatus,
} from '../api';

interface Stage2Props {
  onDocumentGenerate: (data: any) => void;
  diarisationData?: DiarisationResult | null;
  geminiApiKey?: string;
}

type PhaseStatus = 'pending' | 'running' | 'done' | 'error';

interface Phase {
  num: number;
  title: string;
  desc: string;
  status: PhaseStatus;
  badge?: string;
}

export function Stage2({ onDocumentGenerate, diarisationData, geminiApiKey }: Stage2Props) {
  const [docTypes,      setDocTypes]      = useState<DocumentType[]>([]);
  const [selectedType,  setSelectedType]  = useState('BPD');
  const [bizContext,    setBizContext]     = useState('Refund automation for utility customers with eligibility rules and batch processing.');
  const [h1Sections,   setH1Sections]    = useState('Business Process Overview, Business Process Design, Business Process Flow');
  const [phases,        setPhases]        = useState<Phase[]>([]);
  const [logs,          setLogs]          = useState<string[]>([]);
  const [isGenerating,  setIsGenerating]  = useState(false);
  const [jobId,         setJobId]         = useState<string | null>(null);
  const [jobResult,     setJobResult]     = useState<JobStatus['result'] | null>(null);
  const [error,         setError]         = useState('');

  const logEndRef   = useRef<HTMLDivElement>(null);
  const stopStream  = useRef<(() => void) | null>(null);

  // Load document types from API
  useEffect(() => {
    getDocumentTypes()
      .then(types => {
        setDocTypes(types);
        if (types.length > 0) setSelectedType(types[0].id);
      })
      .catch(() => {
        // Fallback static types if API not reachable
        setDocTypes([
          { id: 'BPD', label: 'BPD', description: 'Business Process Document', llm_calls: 2, output_filename: 'BPD_output.docx' },
          { id: 'BRD', label: 'BRD', description: 'Business Requirement Document', llm_calls: 2, output_filename: 'BRD_output.docx' },
          { id: 'MOM', label: 'MOM', description: 'Minutes of Meeting', llm_calls: 1, output_filename: 'MOM_output.docx' },
        ]);
      });
  }, []);

  // Auto-scroll logs
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Cleanup stream on unmount
  useEffect(() => () => { stopStream.current?.(); }, []);

  const selectedCfg = docTypes.find(d => d.id === selectedType);

  function buildInitialPhases(cfg: DocumentType): Phase[] {
    const phases: Phase[] = [
      {
        num: 1,
        title: 'Phase 1 — ' + (cfg.llm_calls >= 2 ? 'Schema design' : 'Single-call generation'),
        desc:  'p1_prompt + diarisation JSON → ' + (cfg.llm_calls >= 2 ? 'a_schema.json' : 'b_response.json'),
        status: 'pending',
      },
    ];
    if (cfg.llm_calls >= 2) {
      phases.push({
        num: 2, title: 'Phase 2 — Content population',
        desc: 'p2_prompt + schema + diarisation → b_response.json', status: 'pending',
      });
    }
    phases.push({
      num: cfg.llm_calls >= 2 ? 3 : 2,
      title: 'Phase ' + (cfg.llm_calls >= 2 ? 3 : 2) + ' — DOCX render',
      desc: 'node template.js b_response.json → ' + cfg.output_filename,
      status: 'pending',
    });
    return phases;
  }

  function updatePhaseFromLog(log: string, prev: Phase[]): Phase[] {
    const updated = [...prev];
    // Detect phase transitions from log messages
    if (log.includes('Phase 1') && log.includes('started')) {
      updated[0] = { ...updated[0], status: 'running' };
    } else if (log.includes('Phase 1') && log.includes('complete')) {
      updated[0] = { ...updated[0], status: 'done', badge: '✓' };
      if (updated[1]) updated[1] = { ...updated[1], status: 'running' };
    } else if (log.includes('Phase 2') && log.includes('complete')) {
      const idx = updated.findIndex(p => p.title.includes('Phase 2'));
      if (idx >= 0) updated[idx] = { ...updated[idx], status: 'done', badge: '✓' };
      const lastIdx = updated.length - 1;
      if (lastIdx >= 0) updated[lastIdx] = { ...updated[lastIdx], status: 'running' };
    } else if (log.includes('Phase 3') && log.includes('complete')) {
      const lastIdx = updated.length - 1;
      if (lastIdx >= 0) updated[lastIdx] = { ...updated[lastIdx], status: 'done', badge: '✓' };
    } else if (log.includes('single-call') && log.includes('complete')) {
      updated[0] = { ...updated[0], status: 'done', badge: '✓' };
      if (updated[1]) updated[1] = { ...updated[1], status: 'running' };
    } else if (log.includes('DOCX') && log.includes('complete')) {
      const lastIdx = updated.length - 1;
      if (lastIdx >= 0) updated[lastIdx] = { ...updated[lastIdx], status: 'done', badge: '✓' };
    }
    return updated;
  }

  async function handleGenerate() {
    if (!diarisationData) {
      setError('No diarisation JSON in session. Go to Stage 1 first.');
      return;
    }
    if (!selectedCfg) return;

    setIsGenerating(true);
    setError('');
    setLogs([]);
    setJobResult(null);
    setPhases(buildInitialPhases(selectedCfg));

    // Mark phase 1 as running immediately
    setPhases(prev => {
      const u = [...prev];
      if (u[0]) u[0] = { ...u[0], status: 'running' };
      return u;
    });

    try {
      const jid = await startGeneration({
        doc_type:        selectedType,
        diarisation_json: diarisationData.segments,
        business_context: bizContext,
        h1_sections:     h1Sections,
        gemini_api_key:  geminiApiKey,
      });
      setJobId(jid);

      stopStream.current = streamJobLogs(
        jid,
        (line) => {
          setLogs(prev => [...prev, line]);
          setPhases(prev => updatePhaseFromLog(line, prev));
        },
        (result) => {
          setJobResult(result);
          setIsGenerating(false);
          if (result.status === 'complete') {
            // Mark all phases done
            setPhases(prev => prev.map(p => ({ ...p, status: 'done', badge: '✓' })));
            onDocumentGenerate({ type: selectedType, jobId: jid, ...result });
          } else if (result.status === 'error') {
            setError(result.error || 'Generation failed');
            setPhases(prev => {
              const u = [...prev];
              const running = u.findIndex(p => p.status === 'running');
              if (running >= 0) u[running] = { ...u[running], status: 'error' };
              return u;
            });
          }
        },
        (err) => {
          setError(err);
          setIsGenerating(false);
        }
      );
    } catch (e: any) {
      setError(e.message || 'Failed to start generation');
      setIsGenerating(false);
    }
  }

  function logColor(line: string): string {
    if (line.includes('ERROR') || line.includes('failed')) return '#f87171';
    if (line.includes('✓') || line.includes('complete') || line.includes('saved')) return '#6ee7b7';
    if (line.includes('started') || line.includes('calling') || line.includes('running')) return '#60a5fa';
    if (line.includes('WARN')) return '#fbbf24';
    return '#888';
  }

  function phaseStyle(status: PhaseStatus) {
    if (status === 'done')    return 'bg-green-600/20 text-green-400 border border-green-600/30';
    if (status === 'running') return 'bg-yellow-600/20 text-yellow-400 border border-yellow-600/30 animate-pulse';
    if (status === 'error')   return 'bg-red-600/20 text-red-400 border border-red-600/30';
    return 'bg-[#2a2a2a] text-[#666] border border-[#3a3a3a]';
  }

  function phaseBadge(p: Phase) {
    if (p.status === 'done')    return <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap">done {p.badge}</span>;
    if (p.status === 'running') return <span className="bg-yellow-600 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap animate-pulse">running…</span>;
    if (p.status === 'error')   return <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap">error</span>;
    return <span className="bg-[#2a2a2a] text-[#888] text-xs px-2 py-0.5 rounded whitespace-nowrap">pending</span>;
  }

  return (
    <div className="flex-1 bg-[#111] text-white overflow-auto">
      <div className="p-6">
        <h1 className="text-2xl mb-2">Stage 2 — Document generation</h1>
        <p className="text-[#888] text-sm mb-6">Using session JSON — no re-diarisation needed</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded text-red-400 text-sm">{error}</div>
        )}

        {!diarisationData && (
          <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded text-yellow-400 text-sm">
            No diarisation data in session. Go to Stage 1 and run diarisation or upload a JSON first.
          </div>
        )}

        {/* Document type */}
        <div className="bg-[#1a1a1a] rounded-lg p-6 border border-[#2a2a2a] mb-6">
          <h3 className="mb-1">Document type</h3>
          <p className="text-[#888] text-xs mb-4">Pulled from DOCUMENT_TYPES config — adding a new entry auto-adds it here</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {docTypes.map(dt => (
              <button key={dt.id} onClick={() => setSelectedType(dt.id)}
                className={`p-4 rounded-lg border-2 transition-all text-left ${
                  selectedType === dt.id
                    ? 'border-white bg-[#2a2a2a]'
                    : 'border-[#333] hover:border-[#555] hover:bg-[#1f1f1f]'
                }`}>
                <div className="font-medium mb-1">{dt.label}</div>
                <div className="text-[#888] text-xs">{dt.llm_calls} LLM {dt.llm_calls > 1 ? 'calls' : 'call'}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Config */}
        {selectedCfg && (
          <div className="bg-[#1a1a1a] rounded-lg p-6 border border-[#2a2a2a] mb-6">
            <h3 className="mb-1">{selectedType} config</h3>
            <p className="text-[#888] text-xs mb-4">Business context injected into prompts</p>

            <div className="mb-4">
              <label className="text-[#888] text-xs block mb-2">Business context</label>
              <textarea value={bizContext} onChange={e => setBizContext(e.target.value)}
                className="w-full bg-[#2a2a2a] text-white border border-[#333] rounded px-3 py-2 text-sm min-h-20 resize-none focus:outline-none focus:border-[#555] transition-colors"
                placeholder="Describe the business context…" />
            </div>

            {selectedCfg.llm_calls >= 2 && (
              <div className="mb-4">
                <label className="text-[#888] text-xs block mb-2">H1 section names</label>
                <input value={h1Sections} onChange={e => setH1Sections(e.target.value)}
                  className="w-full bg-[#2a2a2a] text-white border border-[#333] rounded px-3 py-2 text-sm focus:outline-none focus:border-[#555]"
                  placeholder="Section 1, Section 2, Section 3" />
              </div>
            )}

            <div className="text-[#666] text-xs">
              {selectedCfg.description} · {selectedCfg.llm_calls} LLM {selectedCfg.llm_calls > 1 ? 'calls' : 'call'}
            </div>
          </div>
        )}

        {/* Generation log */}
        <div className="bg-[#1a1a1a] rounded-lg p-6 border border-[#2a2a2a]">
          <div className="flex items-center justify-between mb-6">
            <h3>Generation log</h3>
            <button onClick={handleGenerate} disabled={isGenerating || !diarisationData}
              className={`px-6 py-2 rounded font-medium transition-all flex items-center gap-2 ${
                isGenerating || !diarisationData
                  ? 'bg-[#333] text-[#888] cursor-not-allowed'
                  : 'bg-white text-black hover:bg-gray-200'
              }`}>
              {isGenerating && <Loader2 size={14} className="animate-spin" />}
              Generate {selectedType}
            </button>
          </div>

          {phases.length > 0 ? (
            <>
              <div className="space-y-4 mb-6">
                {phases.map(p => (
                  <div key={p.num} className="flex items-start gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0 font-semibold ${phaseStyle(p.status)}`}>
                      {p.status === 'running' ? <Loader2 size={14} className="animate-spin" /> : p.num}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-3 mb-1">
                        <div>
                          <p className="font-medium">{p.title}</p>
                          <p className="text-[#888] text-xs mt-0.5">{p.desc}</p>
                        </div>
                        {phaseBadge(p)}
                      </div>
                      {p.status === 'running' && (
                        <div className="mt-2 h-1 bg-[#333] rounded-full overflow-hidden">
                          <div className="h-full bg-yellow-500 rounded-full" style={{ width: '60%', animation: 'pulse 1.5s ease-in-out infinite' }} />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-[#0a0a0a] rounded p-4 font-mono text-xs max-h-48 overflow-y-auto space-y-0.5">
                {logs.length === 0
                  ? <div className="text-[#444]">Waiting for logs…</div>
                  : logs.map((line, i) => (
                    <div key={i} style={{ color: logColor(line) }}>{line}</div>
                  ))
                }
                <div ref={logEndRef} />
              </div>

              {jobResult?.status === 'complete' && jobId && (
                <div className="mt-6 flex gap-3 flex-wrap">
                  {jobResult.schema_path && (
                    <a href={getDownloadUrl('schema', jobId)} download="a_schema.json"
                      className="px-5 py-2.5 bg-[#2a2a2a] text-white rounded hover:bg-[#333] transition text-sm">
                      Download a_schema.json
                    </a>
                  )}
                  {jobResult.response_path && (
                    <a href={getDownloadUrl('response', jobId)} download="b_response.json"
                      className="px-5 py-2.5 bg-[#2a2a2a] text-white rounded hover:bg-[#333] transition text-sm">
                      Download b_response.json
                    </a>
                  )}
                  {jobResult.docx_path && (
                    <a href={getDownloadUrl('docx', jobId)} download={selectedType + '_output.docx'}
                      className="px-5 py-2.5 bg-white text-black rounded hover:bg-gray-200 transition text-sm font-medium">
                      Download {selectedType}.docx
                    </a>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12">
              <p className="text-[#666] text-sm">No generation in progress. Click "Generate {selectedType}" to start.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
