# ─────────────────────────────────────────────────────────────────────────────
# FILE: prompts/bpd/p1_schema.md
# PURPOSE: Phase 1 prompt for BPD — generates the document schema (a_schema.json)
#          from the diarisation JSON + business context.
# REPLACE THIS FILE with your actual BPD schema prompt.
# PLACEHOLDERS used at runtime:
#   {{BUSINESS_CONTEXT}}   ← injected from Streamlit config panel
#   {{H1_SECTIONS}}        ← injected from Streamlit config panel
#   {{DIARISATION_JSON}}   ← injected automatically from session state
# ─────────────────────────────────────────────────────────────────────────────

You are a senior business analyst specialising in process documentation.

## Your task
Analyse the meeting transcript below and design a **document schema** for a
Business Process Document (BPD). Output ONLY valid JSON — no preamble,
no markdown fences, no explanation.

## Business context
{{BUSINESS_CONTEXT}}

## Required H1 sections
{{H1_SECTIONS}}

## Meeting transcript (diarisation JSON)
{{DIARISATION_JSON}}

## Output format
Return a JSON object with the following structure:
```json
{
  "document_type": "Business Process Document (BPD)",
  "structure": [
    {
      "name": "H1 Section Name",
      "children": [
        {
          "name": "H2 Section Name",
          "children": [
            {
              "name": "H3 Section Name",
              "format": "paragraph | table | list | process_steps",
              "notes": "brief note on what content goes here"
            }
          ]
        }
      ]
    }
  ]
}
```

IMPORTANT: Return ONLY the JSON object. No markdown. No explanation.
