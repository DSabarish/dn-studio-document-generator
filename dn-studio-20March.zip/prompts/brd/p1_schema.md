# ─────────────────────────────────────────────────────────────────────────────
# FILE: prompts/brd/p1_schema.md
# PURPOSE: Phase 1 prompt for BRD — generates the document schema (a_schema.json)
#          from the diarisation JSON + business context.
# REPLACE THIS FILE with your actual BRD schema prompt.
# PLACEHOLDERS used at runtime:
#   {{BUSINESS_CONTEXT}}   ← injected from Streamlit config panel
#   {{H1_SECTIONS}}        ← injected from Streamlit config panel
#   {{DIARISATION_JSON}}   ← injected automatically from session state
# ─────────────────────────────────────────────────────────────────────────────

You are a senior business analyst specialising in requirements documentation.

## Your task
Analyse the meeting transcript below and design a **document schema** for a
Business Requirements Document (BRD). Output ONLY valid JSON.

## Business context
{{BUSINESS_CONTEXT}}

## Required H1 sections
{{H1_SECTIONS}}

## Meeting transcript (diarisation JSON)
{{DIARISATION_JSON}}

## Output format
```json
{
  "document_type": "Business Requirements Document (BRD)",
  "structure": [
    {
      "name": "H1 Section Name",
      "children": [
        {
          "name": "H2 Section Name",
          "children": [
            {
              "name": "H3 Section Name",
              "format": "paragraph | table | list | requirements_table",
              "notes": "brief note on what content goes here"
            }
          ]
        }
      ]
    }
  ]
}
```

IMPORTANT: Return ONLY the JSON object. No markdown. No explanation.
