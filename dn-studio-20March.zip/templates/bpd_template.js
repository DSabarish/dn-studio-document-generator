// ─────────────────────────────────────────────────────────────────────────────
// FILE: templates/bpd_template.js
// PURPOSE: Node.js script that reads b_response.json and renders BPD_output.docx
// USAGE:   node templates/bpd_template.js <input_json> <output_docx>
// REPLACE THIS FILE with your actual BPD JS template.
// DEPENDENCIES: npm install docx   (run once in Colab)
// ─────────────────────────────────────────────────────────────────────────────

const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } = require("docx");
const fs = require("fs");

// ── Args ─────────────────────────────────────────────────────────────────────
const inputPath  = process.argv[2];
const outputPath = process.argv[3];

if (!inputPath || !outputPath) {
    console.error("Usage: node bpd_template.js <b_response.json> <output.docx>");
    process.exit(1);
}

// ── Load JSON ────────────────────────────────────────────────────────────────
const data = JSON.parse(fs.readFileSync(inputPath, "utf-8"));
console.log(`[BPD] Loaded: ${inputPath}`);
console.log(`[BPD] Title : ${data.title || "Untitled"}`);

// ── Build document sections ──────────────────────────────────────────────────
const children = [];

// Cover page metadata
children.push(
    new Paragraph({
        text: data.title || "Business Process Document",
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Version: ${data.version || "v1.0"}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Date: ${data.date || ""}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Status: ${data.status || "Draft"}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({ text: "" }),
);

// ── Walk the structure tree ───────────────────────────────────────────────────
// REPLACE THIS SECTION with your actual rendering logic.
// This scaffold renders H1 → H2 → H3 headings + content paragraphs.
for (const h1 of (data.structure || [])) {
    children.push(
        new Paragraph({ text: h1.name, heading: HeadingLevel.HEADING_1 })
    );

    for (const h2 of (h1.children || [])) {
        children.push(
            new Paragraph({ text: h2.name, heading: HeadingLevel.HEADING_2 })
        );

        for (const h3 of (h2.children || [])) {
            children.push(
                new Paragraph({ text: h3.name, heading: HeadingLevel.HEADING_3 })
            );

            const content = h3.content;
            if (Array.isArray(content)) {
                // List format
                for (const item of content) {
                    children.push(new Paragraph({ text: `• ${item}` }));
                }
            } else if (typeof content === "string" && content.trim()) {
                children.push(new Paragraph({ text: content }));
            } else {
                // Placeholder for empty sections
                children.push(
                    new Paragraph({
                        children: [new TextRun({ text: "[Content pending]", italics: true, color: "999999" })]
                    })
                );
            }
            children.push(new Paragraph({ text: "" }));
        }
    }
}

// ── Build and write docx ─────────────────────────────────────────────────────
const doc = new Document({ sections: [{ properties: {}, children }] });

Packer.toBuffer(doc).then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    const kb = (buffer.length / 1024).toFixed(1);
    console.log(`[BPD] DOCX written → ${outputPath}  (${kb} KB)`);
    console.log(`[BPD] Done ✓`);
}).catch((err) => {
    console.error(`[BPD] ERROR: ${err.message}`);
    process.exit(1);
});
