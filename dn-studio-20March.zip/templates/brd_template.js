// ─────────────────────────────────────────────────────────────────────────────
// FILE: templates/brd_template.js
// PURPOSE: Node.js script that reads b_response.json and renders BRD_output.docx
// USAGE:   node templates/brd_template.js <input_json> <output_docx>
// REPLACE THIS FILE with your actual BRD JS template.
// DEPENDENCIES: npm install docx   (run once in Colab)
// ─────────────────────────────────────────────────────────────────────────────

const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
        Table, TableRow, TableCell, WidthType, BorderStyle } = require("docx");
const fs = require("fs");

// ── Args ─────────────────────────────────────────────────────────────────────
const inputPath  = process.argv[2];
const outputPath = process.argv[3];

if (!inputPath || !outputPath) {
    console.error("Usage: node brd_template.js <b_response.json> <output.docx>");
    process.exit(1);
}

// ── Load JSON ────────────────────────────────────────────────────────────────
const data = JSON.parse(fs.readFileSync(inputPath, "utf-8"));
console.log(`[BRD] Loaded: ${inputPath}`);
console.log(`[BRD] Title : ${data.title || "Untitled"}`);

// ── Build document ───────────────────────────────────────────────────────────
const children = [];

// Cover page
children.push(
    new Paragraph({
        text: data.title || "Business Requirements Document",
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Version: ${data.version || "v1.0"}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Date: ${data.date || ""}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Status: ${data.status || "Draft"}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({ text: "" }),
);

// ── Walk the structure tree ───────────────────────────────────────────────────
// REPLACE THIS SECTION with your actual BRD rendering logic.
// BRD-specific: requirements tables, acceptance criteria, MoSCoW prioritisation.
for (const h1 of (data.structure || [])) {
    children.push(
        new Paragraph({ text: h1.name, heading: HeadingLevel.HEADING_1 })
    );

    for (const h2 of (h1.children || [])) {
        children.push(
            new Paragraph({ text: h2.name, heading: HeadingLevel.HEADING_2 })
        );

        for (const h3 of (h2.children || [])) {
            children.push(
                new Paragraph({ text: h3.name, heading: HeadingLevel.HEADING_3 })
            );

            const content = h3.content;
            if (h3.format === "requirements_table" && Array.isArray(content)) {
                // TODO: replace with actual requirements table rendering
                for (const req of content) {
                    children.push(new Paragraph({ text: `${req.id || "REQ"}: ${req.text || req}` }));
                }
            } else if (Array.isArray(content)) {
                for (const item of content) {
                    children.push(new Paragraph({ text: `• ${item}` }));
                }
            } else if (typeof content === "string" && content.trim()) {
                children.push(new Paragraph({ text: content }));
            } else {
                children.push(
                    new Paragraph({
                        children: [new TextRun({ text: "[Content pending]", italics: true, color: "999999" })]
                    })
                );
            }
            children.push(new Paragraph({ text: "" }));
        }
    }
}

// ── Write docx ───────────────────────────────────────────────────────────────
const doc = new Document({ sections: [{ properties: {}, children }] });

Packer.toBuffer(doc).then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    const kb = (buffer.length / 1024).toFixed(1);
    console.log(`[BRD] DOCX written → ${outputPath}  (${kb} KB)`);
    console.log(`[BRD] Done ✓`);
}).catch((err) => {
    console.error(`[BRD] ERROR: ${err.message}`);
    process.exit(1);
});
