# ─────────────────────────────────────────────────────────────────────────────
# FILE: tests/test_backend.py
# PURPOSE: pytest test suite — unit tests for backend modules.
# RUN:     pytest tests/ -v
# ─────────────────────────────────────────────────────────────────────────────

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, mock_open

import pytest
import yaml

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))


# ─────────────────────────────────────────────────────────────────────────────
# FIXTURES
# ─────────────────────────────────────────────────────────────────────────────

SAMPLE_SEGMENTS = [
    {
        "start": 0.0, "end": 5.5, "utterance_id": 0,
        "speaker_id": "SPEAKER_0", "speaker_name": "SPEAKER_0",
        "confidence": 0.92, "spk_confidence": 0.88,
        "text": "Hello and welcome to the meeting.",
    },
    {
        "start": 5.8, "end": 12.3, "utterance_id": 1,
        "speaker_id": "SPEAKER_1", "speaker_name": "SPEAKER_1",
        "confidence": 0.85, "spk_confidence": 0.79,
        "text": "Thanks for having me today.",
    },
    {
        "start": 12.5, "end": 20.0, "utterance_id": 2,
        "speaker_id": "SPEAKER_0", "speaker_name": "SPEAKER_0",
        "confidence": 0.90, "spk_confidence": 0.91,
        "text": "Let's get started with the agenda.",
    },
]

SAMPLE_SCHEMA = {
    "document_type": "Business Process Document (BPD)",
    "structure": [
        {
            "name": "Business Process Overview",
            "children": [
                {
                    "name": "Executive Summary",
                    "children": [
                        {"name": "Background", "format": "paragraph", "notes": "Context"},
                    ]
                }
            ]
        }
    ]
}

SAMPLE_DOC_TYPES = {
    "BPD": {
        "label": "BPD",
        "description": "Business Process Document",
        "llm_calls": 2,
        "p1_prompt": "prompts/bpd/p1_schema.md",
        "p2_prompt": "prompts/bpd/p2_populate.md",
        "js_template": "templates/bpd_template.js",
        "output_dir": "outputs/bpd/",
        "output_filename": "BPD_output.docx",
    },
    "MOM": {
        "label": "MOM",
        "description": "Minutes of Meeting",
        "llm_calls": 1,
        "p1_prompt": "prompts/mom/p1_direct.md",
        "p2_prompt": None,
        "js_template": "templates/mom_template.js",
        "output_dir": "outputs/mom/",
        "output_filename": "MOM_output.docx",
    },
}


@pytest.fixture
def sample_segments():
    return SAMPLE_SEGMENTS


@pytest.fixture
def sample_schema():
    return SAMPLE_SCHEMA


@pytest.fixture
def tmp_output_dir(tmp_path):
    d = tmp_path / "outputs"
    d.mkdir()
    return d


@pytest.fixture
def config_yaml(tmp_path):
    cfg_path = tmp_path / "document_types.yaml"
    cfg_path.write_text(yaml.dump(SAMPLE_DOC_TYPES))
    return cfg_path


# ─────────────────────────────────────────────────────────────────────────────
# TEST: llm_client.py
# ─────────────────────────────────────────────────────────────────────────────

class TestExtractJson:
    def test_clean_json(self):
        from backend.llm_client import extract_json
        raw = '{"key": "value", "num": 42}'
        result = extract_json(raw)
        assert result == {"key": "value", "num": 42}

    def test_strips_markdown_fences(self):
        from backend.llm_client import extract_json
        raw = '```json\n{"key": "value"}\n```'
        result = extract_json(raw)
        assert result["key"] == "value"

    def test_strips_fence_no_lang(self):
        from backend.llm_client import extract_json
        raw = '```\n{"key": "value"}\n```'
        result = extract_json(raw)
        assert result["key"] == "value"

    def test_json_with_preamble(self):
        from backend.llm_client import extract_json
        raw = 'Here is the JSON output:\n\n{"structure": []}'
        result = extract_json(raw)
        assert "structure" in result

    def test_raises_on_no_json(self):
        from backend.llm_client import extract_json
        with pytest.raises(ValueError, match="No JSON object found"):
            extract_json("This has no JSON at all.")

    def test_raises_on_invalid_json(self):
        from backend.llm_client import extract_json
        with pytest.raises(ValueError, match="JSONDecodeError"):
            extract_json("{invalid json: true}")

    def test_nested_json(self):
        from backend.llm_client import extract_json
        raw = '{"a": {"b": {"c": [1, 2, 3]}}}'
        result = extract_json(raw)
        assert result["a"]["b"]["c"] == [1, 2, 3]


class TestBuildPrompt:
    def test_replaces_placeholders(self, tmp_path):
        from backend.llm_client import build_prompt
        tpl = tmp_path / "prompt.md"
        tpl.write_text("Context: {{BUSINESS_CONTEXT}}\nData: {{DIARISATION_JSON}}")
        result = build_prompt(str(tpl), {
            "BUSINESS_CONTEXT": "test context",
            "DIARISATION_JSON": "[]",
        })
        assert "test context" in result
        assert "[]" in result
        assert "{{" not in result

    def test_missing_template_raises(self):
        from backend.llm_client import build_prompt
        with pytest.raises(FileNotFoundError):
            build_prompt("/nonexistent/path/prompt.md", {})

    def test_partial_replacement(self, tmp_path):
        from backend.llm_client import build_prompt
        tpl = tmp_path / "p.md"
        tpl.write_text("{{A}} and {{B}} and {{C}}")
        result = build_prompt(str(tpl), {"A": "alpha", "B": "beta"})
        assert "alpha" in result
        assert "beta" in result
        assert "{{C}}" in result  # unreplaced placeholder stays


class TestCallLlm:
    def test_returns_string_on_success(self):
        from backend.llm_client import call_llm
        mock_chain = MagicMock()
        mock_chain.invoke.return_value = '{"result": "ok"}'

        with patch("backend.llm_client.get_chain", return_value=mock_chain):
            result = call_llm("test prompt")
        assert result == '{"result": "ok"}'

    def test_raises_runtime_error_on_failure(self):
        from backend.llm_client import call_llm
        mock_chain = MagicMock()
        mock_chain.invoke.side_effect = Exception("API error")

        with patch("backend.llm_client.get_chain", return_value=mock_chain):
            with pytest.raises(RuntimeError, match="LLM call failed"):
                call_llm("test prompt")


# ─────────────────────────────────────────────────────────────────────────────
# TEST: document_generator.py
# ─────────────────────────────────────────────────────────────────────────────

class TestLoadDocumentTypes:
    def test_loads_yaml(self, config_yaml, monkeypatch):
        monkeypatch.chdir(config_yaml.parent)
        # Patch the CONFIG_PATH
        with patch("backend.document_generator.CONFIG_PATH", config_yaml):
            from backend.document_generator import load_document_types
            result = load_document_types()
        assert "BPD" in result
        assert "MOM" in result
        assert result["BPD"]["llm_calls"] == 2
        assert result["MOM"]["llm_calls"] == 1

    def test_returns_dict(self, config_yaml):
        with patch("backend.document_generator.CONFIG_PATH", config_yaml):
            from backend.document_generator import load_document_types
            result = load_document_types()
        assert isinstance(result, dict)


class TestRunPhase1:
    def test_saves_schema_json(self, tmp_output_dir, sample_segments):
        from backend.document_generator import run_phase1

        mock_schema = {"document_type": "BPD", "structure": []}
        cfg = SAMPLE_DOC_TYPES["BPD"]

        with patch("backend.document_generator.build_prompt", return_value="prompt text"), \
             patch("backend.document_generator.call_llm", return_value='{"document_type":"BPD","structure":[]}'), \
             patch("backend.document_generator.extract_json", return_value=mock_schema):

            result = run_phase1("BPD", cfg, sample_segments, "context", "H1", tmp_output_dir)

        assert result == mock_schema
        schema_file = tmp_output_dir / "a_schema.json"
        assert schema_file.exists()
        saved = json.loads(schema_file.read_text())
        assert saved["document_type"] == "BPD"

    def test_returns_schema_dict(self, tmp_output_dir, sample_segments):
        from backend.document_generator import run_phase1

        cfg         = SAMPLE_DOC_TYPES["BPD"]
        mock_schema = {"document_type": "BPD", "structure": [{"name": "H1", "children": []}]}

        with patch("backend.document_generator.build_prompt", return_value="p"), \
             patch("backend.document_generator.call_llm",   return_value="{}"), \
             patch("backend.document_generator.extract_json", return_value=mock_schema):

            result = run_phase1("BPD", cfg, sample_segments, "ctx", "h1", tmp_output_dir)

        assert isinstance(result, dict)
        assert "structure" in result


class TestRunPhase2:
    def test_saves_response_json(self, tmp_output_dir, sample_segments, sample_schema):
        from backend.document_generator import run_phase2

        cfg      = SAMPLE_DOC_TYPES["BPD"]
        mock_pop = {"document_type": "BPD", "title": "Test", "structure": []}

        with patch("backend.document_generator.build_prompt", return_value="p"), \
             patch("backend.document_generator.call_llm",    return_value="{}"), \
             patch("backend.document_generator.extract_json", return_value=mock_pop):

            result = run_phase2("BPD", cfg, sample_segments, "ctx", sample_schema, tmp_output_dir)

        assert (tmp_output_dir / "b_response.json").exists()
        assert result["title"] == "Test"


class TestGenerateDocument:
    def test_unknown_doc_type_raises(self):
        from backend.document_generator import generate_document

        with patch("backend.document_generator.load_document_types", return_value=SAMPLE_DOC_TYPES):
            with pytest.raises(ValueError, match="Unknown doc_type"):
                generate_document("UNKNOWN", [], "ctx", "h1")

    def test_mom_single_call_path(self, tmp_output_dir, sample_segments):
        from backend.document_generator import generate_document

        mom_types = {"MOM": SAMPLE_DOC_TYPES["MOM"]}
        mom_types["MOM"]["output_dir"] = str(tmp_output_dir)
        mock_resp = {"document_type": "MOM", "meeting_title": "Test"}

        with patch("backend.document_generator.load_document_types", return_value=mom_types), \
             patch("backend.document_generator.build_prompt",  return_value="p"), \
             patch("backend.document_generator.call_llm",      return_value="{}"), \
             patch("backend.document_generator.extract_json",  return_value=mock_resp), \
             patch("backend.document_generator.run_phase3",    return_value=tmp_output_dir / "MOM_output.docx"):

            # Create dummy docx
            (tmp_output_dir / "MOM_output.docx").write_bytes(b"fake")

            result = generate_document("MOM", sample_segments, "ctx", "", lambda m: None)

        assert result["doc_type"] == "MOM"
        assert result["response_path"] is not None

    def test_bpd_two_call_path(self, tmp_output_dir, sample_segments):
        from backend.document_generator import generate_document

        bpd_types = {"BPD": dict(SAMPLE_DOC_TYPES["BPD"])}
        bpd_types["BPD"]["output_dir"] = str(tmp_output_dir)
        mock_schema = {"structure": []}
        mock_resp   = {"document_type": "BPD", "structure": []}

        with patch("backend.document_generator.load_document_types", return_value=bpd_types), \
             patch("backend.document_generator.run_phase1", return_value=mock_schema), \
             patch("backend.document_generator.run_phase2", return_value=mock_resp), \
             patch("backend.document_generator.run_phase3", return_value=tmp_output_dir / "BPD_output.docx"):

            (tmp_output_dir / "BPD_output.docx").write_bytes(b"fake")

            result = generate_document("BPD", sample_segments, "ctx", "H1, H2", lambda m: None)

        assert result["doc_type"] == "BPD"
        assert result["schema_path"] is not None


# ─────────────────────────────────────────────────────────────────────────────
# TEST: diarisation.py
# ─────────────────────────────────────────────────────────────────────────────

class TestCleanText:
    def test_strips_fillers(self):
        from backend.diarisation import clean_text
        result = clean_text("Um, let me think about this.")
        assert "Um" not in result

    def test_strips_stutters(self):
        from backend.diarisation import clean_text
        result = clean_text("I- I think we should go.")
        assert result  # should not be empty

    def test_capitalises_first_letter(self):
        from backend.diarisation import clean_text
        result = clean_text("hello world")
        assert result[0].isupper()

    def test_empty_input(self):
        from backend.diarisation import clean_text
        result = clean_text("")
        assert result == ""

    def test_no_cleaning_when_flags_false(self):
        from backend.diarisation import clean_text
        text   = "Um hello there"
        result = clean_text(text, remove_fillers=False, remove_stutters=False, remove_repeats=False)
        assert "Um" in result


class TestToDiarisationJson:
    def test_output_has_required_keys(self):
        from backend.diarisation import ASRSegment, to_diarisation_json

        seg = ASRSegment(start=0.0, end=5.0, text="Hello", speaker="SPEAKER_0",
                         utterance_id=0, confidence=0.9)
        seg.__dict__["spk_confidence"] = 0.85

        result = to_diarisation_json([seg])
        assert len(result) == 1
        row = result[0]
        for key in ["start", "end", "utterance_id", "speaker_id",
                    "speaker_name", "confidence", "spk_confidence", "text"]:
            assert key in row, f"Missing key: {key}"

    def test_rounds_timestamps(self):
        from backend.diarisation import ASRSegment, to_diarisation_json
        seg = ASRSegment(start=1.23456, end=5.98765, text="Hi",
                         speaker="SPEAKER_0", utterance_id=0, confidence=0.9)
        seg.__dict__["spk_confidence"] = 0.8
        result = to_diarisation_json([seg])
        assert result[0]["start"] == 1.235
        assert result[0]["end"] == 5.988

    def test_speaker_name_defaults_to_speaker_id(self):
        from backend.diarisation import ASRSegment, to_diarisation_json
        seg = ASRSegment(start=0.0, end=3.0, text="Test",
                         speaker="SPEAKER_2", utterance_id=0, confidence=0.8)
        seg.__dict__["spk_confidence"] = 0.7
        result = to_diarisation_json([seg])
        assert result[0]["speaker_name"] == "SPEAKER_2"


class TestBestNumSpeakers:
    def test_returns_int(self):
        from backend.diarisation import best_num_speakers
        import numpy as np
        # 4 clusters of 5 points each
        X = np.vstack([
            np.random.default_rng(0).normal([i * 10, 0], 0.5, (5, 2))
            for i in range(4)
        ])
        result = best_num_speakers(X, max_n=6)
        assert isinstance(result, int)
        assert 2 <= result <= 6

    def test_min_two_speakers(self):
        from backend.diarisation import best_num_speakers
        import numpy as np
        X = np.random.default_rng(42).normal(0, 1, (10, 10))
        result = best_num_speakers(X, max_n=4)
        assert result >= 2


# ─────────────────────────────────────────────────────────────────────────────
# TEST: server.py (FastAPI integration)
# ─────────────────────────────────────────────────────────────────────────────

class TestServerEndpoints:
    @pytest.fixture
    def client(self, config_yaml, monkeypatch):
        """Create a TestClient with config patched."""
        monkeypatch.chdir(config_yaml.parent)
        from fastapi.testclient import TestClient
        with patch("backend.server.CONFIG_PATH", config_yaml):
            from backend.server import app
            yield TestClient(app)

    def test_health(self, client):
        r = client.get("/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_document_types(self, client):
        r = client.get("/document-types")
        assert r.status_code == 200
        types = r.json()["document_types"]
        assert isinstance(types, list)
        assert any(t["id"] == "BPD" for t in types)
        assert any(t["id"] == "MOM" for t in types)

    def test_document_types_have_required_fields(self, client):
        r = client.get("/document-types")
        for dt in r.json()["document_types"]:
            assert "id" in dt
            assert "label" in dt
            assert "llm_calls" in dt
            assert "description" in dt

    def test_upload_json_valid(self, client):
        payload = json.dumps(SAMPLE_SEGMENTS).encode()
        r = client.post("/upload-json", files={"json_file": ("test.json", payload, "application/json")})
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "success"
        assert data["n_utterances"] == len(SAMPLE_SEGMENTS)
        assert data["n_speakers"] == 2  # SPEAKER_0 and SPEAKER_1

    def test_upload_json_invalid(self, client):
        r = client.post("/upload-json", files={"json_file": ("bad.json", b"not json", "application/json")})
        assert r.status_code == 400

    def test_generate_unknown_doc_type(self, client):
        r = client.post("/generate", json={
            "doc_type": "UNKNOWN_TYPE",
            "diarisation_json": SAMPLE_SEGMENTS,
            "business_context": "test",
            "h1_sections": "",
        })
        # Returns 200 with job_id (error surfaces via SSE stream)
        assert r.status_code == 200
        assert "job_id" in r.json()

    def test_generate_status_not_found(self, client):
        r = client.get("/generate/status/nonexistent_job_id")
        assert r.status_code == 404

    def test_download_diarisation_json_not_found(self, client):
        r = client.get("/download/diarisation-json")
        assert r.status_code == 404

    def test_download_schema_not_found(self, client):
        r = client.get("/download/schema/fake_job_id")
        assert r.status_code == 404


# ─────────────────────────────────────────────────────────────────────────────
# TEST: Integration — upload JSON → generate document flow
# ─────────────────────────────────────────────────────────────────────────────

class TestIntegrationFlow:
    @pytest.fixture
    def client(self, config_yaml, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Create required dirs
        (tmp_path / "outputs" / "diarisation").mkdir(parents=True)
        (tmp_path / "outputs" / "bpd").mkdir(parents=True)
        (tmp_path / "outputs" / "mom").mkdir(parents=True)

        with patch("backend.server.CONFIG_PATH", config_yaml):
            from fastapi.testclient import TestClient
            from backend.server import app
            yield TestClient(app)

    def test_full_flow_upload_then_list_types(self, client):
        # Step 1: upload JSON
        payload = json.dumps(SAMPLE_SEGMENTS).encode()
        r1 = client.post("/upload-json",
                         files={"json_file": ("d.json", payload, "application/json")})
        assert r1.status_code == 200
        assert r1.json()["n_utterances"] == 3

        # Step 2: list document types
        r2 = client.get("/document-types")
        assert r2.status_code == 200
        assert len(r2.json()["document_types"]) >= 1

    def test_generate_starts_job(self, client):
        with patch("backend.server._run_generation_job"):
            r = client.post("/generate", json={
                "doc_type": "BPD",
                "diarisation_json": SAMPLE_SEGMENTS,
                "business_context": "test context",
                "h1_sections": "Overview, Design",
            })
        assert r.status_code == 200
        body = r.json()
        assert "job_id" in body
        assert body["status"] == "started"

    def test_job_status_after_start(self, client):
        with patch("backend.server._run_generation_job"):
            r1 = client.post("/generate", json={
                "doc_type": "BPD",
                "diarisation_json": SAMPLE_SEGMENTS,
                "business_context": "test",
                "h1_sections": "",
            })
        job_id = r1.json()["job_id"]

        # Job should be registered
        import time; time.sleep(0.1)
        r2 = client.get("/generate/status/" + job_id)
        assert r2.status_code == 200
        data = r2.json()
        assert data["job_id"] == job_id
        assert "result" in data
        assert "logs" in data
