# ─────────────────────────────────────────────────────────────────────────────
# FILE: prompts/mom/p1_direct.md
# PURPOSE: Single prompt for MOM — schema design AND content population
#          happen in one LLM call. Outputs b_response.json directly.
# REPLACE THIS FILE with your actual MOM prompt.
# PLACEHOLDERS used at runtime:
#   {{BUSINESS_CONTEXT}}   ← injected from Streamlit config panel
#   {{DIARISATION_JSON}}   ← injected automatically from session state
# NOTE: MOM has no p2 prompt (llm_calls: 1 in document_types.yaml)
# ─────────────────────────────────────────────────────────────────────────────

You are a senior engagement manager with McKinsey-standard documentation skills.

## Your task
Convert the meeting transcript below into a complete, structured
Minutes of Meeting (MOM) document. Output ONLY valid JSON.

## Business context
{{BUSINESS_CONTEXT}}

## Meeting transcript (diarisation JSON)
{{DIARISATION_JSON}}

## Output format
Return a single JSON object:

```json
{
  "document_type": "Minutes of Meeting (MOM)",
  "meeting_title": "...",
  "date": "...",
  "duration_minutes": 0,
  "attendees": ["Speaker 1", "Speaker 2"],
  "executive_summary": "2-3 sentence summary of the meeting outcome.",
  "agenda_items": [
    {
      "topic": "Topic discussed",
      "discussion": "Summary of what was discussed",
      "outcome": "Decision or conclusion reached"
    }
  ],
  "decisions": [
    {
      "id": "D-001",
      "decision": "What was decided",
      "owner": "Who owns it"
    }
  ],
  "action_items": [
    {
      "id": "A-001",
      "action": "What needs to be done",
      "owner": "Who is responsible",
      "due_date": "Target date or TBD"
    }
  ],
  "open_questions": [
    {
      "id": "Q-001",
      "question": "Unresolved question",
      "owner": "Who will resolve it"
    }
  ],
  "next_steps": "Summary of what happens next.",
  "next_meeting": "Date/time of next meeting or TBD"
}
```

IMPORTANT: Return ONLY the JSON object. No markdown. No explanation.
