# 🎙️ DN-Studio

Speaker diarisation → structured Word documents.
React + Tailwind frontend · FastAPI backend · Gemini 2.5 Flash LLM.

---

## Project structure

```
dn-studio/
├── backend/
│   ├── server.py              ← FastAPI app — all API endpoints
│   ├── diarisation.py         ← Whisper + resemblyzer pipeline
│   ├── document_generator.py  ← Config-driven doc generation
│   ├── llm_client.py          ← Gemini / LangChain wrapper
│   └── view_builder.py        ← diarization_view.html generator
├── frontend/
│   ├── src/app/
│   │   ├── App.tsx            ← Root component
│   │   ├── api.ts             ← All fetch calls to FastAPI
│   │   └── components/
│   │       ├── Sidebar.tsx
│   │       ├── Stage1.tsx     ← Diarisation UI
│   │       └── Stage2.tsx     ← Document generation UI
│   ├── package.json
│   └── vite.config.ts
├── config/
│   └── document_types.yaml    ← Add new doc types here only
├── prompts/
│   ├── bpd/  p1_schema.md  p2_populate.md
│   ├── brd/  p1_schema.md  p2_populate.md
│   └── mom/  p1_direct.md
├── templates/
│   ├── bpd_template.js
│   ├── brd_template.js
│   └── mom_template.js
├── outputs/                   ← gitignored, generated at runtime
├── tests/
│   ├── conftest.py
│   └── test_backend.py        ← 42 pytest tests
├── requirements.txt
├── packages.txt
└── pytest.ini
```

---

## Setup in Google Colab — single cell

### Cell 1 — System dependencies
```python
!apt-get install -y ffmpeg nodejs npm -qq
```

---

### Cell 2 — Python + Node dependencies
```python
!pip install -r requirements.txt -q
!npm install docx --silent
```

---

### Cell 3 — Upload and unzip
```python
from google.colab import files
uploaded = files.upload()          # select dn-studio-final.zip

import zipfile, os
with zipfile.ZipFile(list(uploaded.keys())[0], 'r') as z:
    z.extractall('/content/dn-studio')

os.chdir('/content/dn-studio')
!ls
```

---

### Cell 4 — Run tests
```python
!pytest tests/ -v
```

---

### Cell 5 — Start FastAPI backend in background
# ⚠️  Use nohup + & so the cell finishes immediately and does NOT block.
```python
import subprocess, time

proc = subprocess.Popen(
    ['python', '-m', 'uvicorn', 'backend.server:app',
     '--host', '0.0.0.0', '--port', '8000'],
    stdout=open('uvicorn.log', 'w'),
    stderr=subprocess.STDOUT
)

time.sleep(3)                      # give it 3 seconds to start

# Confirm it is running
import urllib.request
try:
    r = urllib.request.urlopen('http://localhost:8000/health', timeout=5)
    print('✅ Backend running —', r.read().decode())
except Exception as e:
    print('❌ Backend not responding:', e)
    print('Check uvicorn.log for errors:')
    !tail -20 uvicorn.log
```

---

### Cell 6 — Build frontend and serve via FastAPI
```python
import os
os.chdir('/content/dn-studio/frontend')

!npm install --legacy-peer-deps --silent
!npm run build

os.chdir('/content/dn-studio')
print('✅ Frontend built — FastAPI now serves it at /')
```

---

### Cell 7 — Get public URL via localtunnel
```python
import subprocess, time, threading

# Install localtunnel
subprocess.run(['npm', 'install', '-g', 'localtunnel', '--silent'], check=True)

# Get Colab VM's external IP (needed as tunnel password)
import urllib.request
ip = urllib.request.urlopen('https://api.ipify.org').read().decode()
print(f'Tunnel password (copy this): {ip}')

# Start tunnel in background thread so cell completes
def run_tunnel():
    proc = subprocess.Popen(
        ['lt', '--port', '8000'],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
    )
    for line in proc.stdout:
        print(line, end='')

t = threading.Thread(target=run_tunnel, daemon=True)
t.start()
time.sleep(3)
print('\n✅ Tunnel started. Copy the https://xxxx.loca.lt URL above.')
print('When prompted for password, paste the IP shown above.')
```

---

### Cell 8 — (Optional) Check backend logs
```python
!tail -30 uvicorn.log
```

### Cell 9 — (Optional) Stop backend
```python
proc.terminate()
print('Backend stopped')
```

---

## Key points

- **Cell 5 must use `subprocess.Popen`** — never `!uvicorn ...` directly.
  The `!` shell command blocks until the process exits. `Popen` returns immediately and lets the server run in the background.

- **Cell 7 uses a thread** for the same reason — `lt` blocks forever waiting for connections.

- Logs stream to `uvicorn.log` in the project root. Check them with Cell 8 if anything seems wrong.

---

## Adding a new document type

1. Add prompts to `prompts/your_type/`
2. Add JS template to `templates/your_type_template.js`
3. Add one entry to `config/document_types.yaml`:

```yaml
YOUR_TYPE:
  label: "Your Type"
  description: "What it produces"
  llm_calls: 2        # 1 or 2
  p1_prompt: "prompts/your_type/p1_schema.md"
  p2_prompt: "prompts/your_type/p2_populate.md"  # null if llm_calls: 1
  js_template: "templates/your_type_template.js"
  output_dir: "outputs/your_type/"
  output_filename: "YourType_output.docx"
```

The frontend card grid and `/document-types` endpoint pick it up automatically — no other code changes.

---

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Server health check |
| GET | `/document-types` | All doc types from config |
| POST | `/diarise` | Upload audio/video → run diarisation |
| POST | `/upload-json` | Upload existing diarization JSON |
| GET | `/download/diarisation-json` | Download diarization_response.json |
| GET | `/download/diarisation-html` | Download diarization_view.html |
| POST | `/generate` | Start document generation, returns job_id |
| GET | `/generate/status/{job_id}` | Poll job status + logs |
| GET | `/generate/stream/{job_id}` | SSE live log stream |
| GET | `/download/schema/{job_id}` | Download a_schema.json |
| GET | `/download/response/{job_id}` | Download b_response.json |
| GET | `/download/docx/{job_id}` | Download output .docx |

---

## Running tests

```bash
pytest tests/ -v                      # all 42 tests
pytest tests/ -v -k "TestExtractJson" # specific class
pytest tests/ -v -k "integration"     # integration only
pytest tests/ --tb=short              # short tracebacks
```
