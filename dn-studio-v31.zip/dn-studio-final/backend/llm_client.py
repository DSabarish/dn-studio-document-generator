# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/llm_client.py
# PURPOSE: LangChain + Gemini 2.5 Flash wrapper.
#          Every call returns a LLMResult with text + tokens + cost + time.
# ─────────────────────────────────────────────────────────────────────────────

import os
import re
import json
import time
import logging
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("dn_studio.llm")

# ── Gemini 2.5 Flash pricing (USD per 1M tokens) ─────────────────────────────
# Source: Google AI pricing as of 2025
# Prompts ≤200k tokens use the standard tier
PRICE_INPUT_PER_M  = 0.075   # $0.075  per 1M input tokens
PRICE_OUTPUT_PER_M = 0.30    # $0.30   per 1M output tokens

MODEL_NAME = "gemini-2.5-flash"


def _calc_cost(input_tokens: int, output_tokens: int) -> float:
    """Return cost in USD for the given token counts."""
    return (
        (input_tokens  / 1_000_000) * PRICE_INPUT_PER_M +
        (output_tokens / 1_000_000) * PRICE_OUTPUT_PER_M
    )


@dataclass
class LLMResult:
    """Everything returned by a single LLM call."""
    text:          str
    input_tokens:  int   = 0
    output_tokens: int   = 0
    total_tokens:  int   = 0
    cost_usd:      float = 0.0
    elapsed_sec:   float = 0.0
    model:         str   = MODEL_NAME


def _get_llm(max_output_tokens: int = 8192):
    """Return a ChatGoogleGenerativeAI instance (NOT a chain — we need metadata)."""
    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(
        model           = MODEL_NAME,
        temperature     = 0.2,
        max_output_tokens = max_output_tokens,
    )


def call_llm(prompt: str, max_output_tokens: int = 8192) -> LLMResult:
    """
    Single LLM call.
    Returns LLMResult with text, token counts, cost, and elapsed time.
    Raises RuntimeError on failure.

    Usage:
        result = call_llm(prompt)
        print(result.text)
        print(f"Cost: ${result.cost_usd:.4f}  Tokens: {result.total_tokens}")
    """
    from langchain_core.messages import HumanMessage

    log.info("[LLM] Calling %s  max_tokens=%d  prompt_len=%d chars",
             MODEL_NAME, max_output_tokens, len(prompt))

    t_start = time.perf_counter()

    try:
        llm      = _get_llm(max_output_tokens)
        ai_msg   = llm.invoke([HumanMessage(content=prompt)])
        elapsed  = round(time.perf_counter() - t_start, 2)

        # ── Extract token usage from response_metadata ────────────────────────
        meta          = getattr(ai_msg, "response_metadata", {}) or {}
        usage         = meta.get("usage_metadata") or meta.get("token_usage") or {}

        # LangChain google-genai returns usage_metadata with these keys:
        input_tokens  = (
            usage.get("input_tokens") or
            usage.get("prompt_tokens") or
            usage.get("prompt_token_count") or 0
        )
        output_tokens = (
            usage.get("output_tokens") or
            usage.get("completion_tokens") or
            usage.get("candidates_token_count") or 0
        )
        total_tokens  = (
            usage.get("total_tokens") or
            usage.get("total_token_count") or
            (input_tokens + output_tokens)
        )

        # Fallback: estimate from text length if API didn't return counts
        if total_tokens == 0:
            input_tokens  = len(prompt)    // 4   # ~4 chars per token
            output_tokens = len(ai_msg.content) // 4
            total_tokens  = input_tokens + output_tokens
            log.warning("[LLM] Token counts not in response_metadata — estimated from length")

        cost = _calc_cost(input_tokens, output_tokens)

        log.info("[LLM] Done  %.2fs  in=%d  out=%d  total=%d  cost=$%.4f",
                 elapsed, input_tokens, output_tokens, total_tokens, cost)

        return LLMResult(
            text          = ai_msg.content,
            input_tokens  = input_tokens,
            output_tokens = output_tokens,
            total_tokens  = total_tokens,
            cost_usd      = cost,
            elapsed_sec   = elapsed,
            model         = MODEL_NAME,
        )

    except Exception as e:
        elapsed = round(time.perf_counter() - t_start, 2)
        log.error("[LLM] Call failed after %.2fs: %s", elapsed, str(e))
        raise RuntimeError(f"LLM call failed: {e}") from e


def extract_json(text: str) -> dict:
    """
    Strip markdown fences, find the outermost JSON object, parse and return.
    Raises ValueError with context on parse failure.

    Accepts either a raw string or an LLMResult — call extract_json(result.text)
    or extract_json(result) directly.
    """
    # Accept LLMResult transparently
    if hasattr(text, "text"):
        text = text.text

    cleaned = re.sub(r"```(?:json)?\s*", "", text).strip()
    cleaned = re.sub(r"```\s*$",          "", cleaned).strip()

    start = cleaned.find("{")
    end   = cleaned.rfind("}") + 1
    if start == -1 or end == 0:
        raise ValueError(
            f"[LLM] No JSON object found in response.\n"
            f"First 500 chars:\n{text[:500]}"
        )

    json_str = cleaned[start:end]

    try:
        parsed = json.loads(json_str)
        log.debug("[LLM] JSON parsed  keys=%s", list(parsed.keys())[:5])
        return parsed
    except json.JSONDecodeError as e:
        lines    = json_str.splitlines()
        err_line = e.lineno - 1
        context  = "\n".join(lines[max(0, err_line - 2): err_line + 3])
        raise ValueError(
            f"[LLM] JSONDecodeError at line {e.lineno}, col {e.colno}: {e.msg}\n"
            f"Context:\n{context}\n\n"
            f"Hint: Response may be truncated or contain unescaped characters."
        ) from e


def build_prompt(template_path: str, placeholders: dict) -> str:
    """
    Read a .md prompt template and replace all {{KEY}} placeholders.
    Raises FileNotFoundError if template_path does not exist.
    """
    log.debug("[LLM] Loading prompt template: %s", template_path)
    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    for key, value in placeholders.items():
        tag      = "{{" + key + "}}"
        template = template.replace(tag, str(value))
        log.debug("[LLM] Injected placeholder: %s  (%d chars)", key, len(str(value)))

    log.info("[LLM] Prompt built  template=%s  total_len=%d chars",
             template_path, len(template))
    return template
