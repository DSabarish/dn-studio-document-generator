# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/view_builder.py
# SOURCE: DN-Studio v2300 BRD ipynb — timeline_renderer.py (cell 8), verbatim.
#
# REPO ADDITION (bottom of file):
#   build_view_html(segments: list, out_path: str) -> str
#   Thin wrapper: writes segments to temp JSON → calls render_html().
#   Called by backend/diarisation.py after pipeline completes.
#
# render_html(json_path, out_path) — original ipynb signature, unchanged.
# ─────────────────────────────────────────────────────────────────────────────

"""
visualize.py  –  Speaker Diarization Visualization
====================================================
Generates a self-contained interactive HTML file from step_0.json.
Zero extra dependencies beyond what the pipeline already installs.

Usage (standalone):
    python visualize.py output_v2/step_0.json

Or call from inside the pipeline:
    from visualize import render_html
    render_html("output_v2/step_0.json", "output_v2/viz.html")
"""

import os, sys, json
import numpy as np
from pathlib import Path


# ───────────────────────────────────────────────────────────────────────────────
# CORE ANALYTICS  (pure Python / numpy, no extra deps)
# ───────────────────────────────────────────────────────────────────────────────

def load_segments(json_path: str) -> list:
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def compute_stats(segments: list) -> dict:
    """Per-speaker stats used by charts."""
    spk_data: dict = {}
    for seg in segments:
        spk = seg.get("speaker_id", "UNKNOWN")
        dur = max(0.0, seg["end"] - seg["start"])
        wc  = len(seg["text"].split())
        if spk not in spk_data:
            spk_data[spk] = {"total_sec": 0.0, "utterances": 0, "words": 0, "durations": []}
        spk_data[spk]["total_sec"]   += dur
        spk_data[spk]["utterances"]  += 1
        spk_data[spk]["words"]       += wc
        spk_data[spk]["durations"].append(dur)

    # add derived fields
    for spk, d in spk_data.items():
        durs = np.array(d["durations"])
        d["avg_dur"]    = float(durs.mean())
        d["median_dur"] = float(np.median(durs))
        d["max_dur"]    = float(durs.max())

    return spk_data


def build_density(segments: list, total: float, bucket: float = 10.0) -> list:
    """Activity density per bucket (seconds), returns list of dicts."""
    n_buckets = int(np.ceil(total / bucket))
    counts    = [0] * n_buckets
    spk_map   = {}   # bucket_idx -> set of speakers
    for seg in segments:
        b0 = int(seg["start"] // bucket)
        b1 = int(seg["end"]   // bucket)
        for b in range(max(0, b0), min(n_buckets, b1 + 1)):
            counts[b] += 1
            spk_map.setdefault(b, set()).add(seg["speaker_id"])
    return [
        {"t": b * bucket, "count": counts[b],
         "speakers": list(spk_map.get(b, set()))}
        for b in range(n_buckets)
    ]


# ───────────────────────────────────────────────────────────────────────────────
# HTML / JS  GENERATOR
# ───────────────────────────────────────────────────────────────────────────────

PALETTE = [
    {"bg": "#3b82f6", "light": "#93c5fd", "track": "#1e3a5f"},
    {"bg": "#10b981", "light": "#6ee7b7", "track": "#064e3b"},
    {"bg": "#f59e0b", "light": "#fcd34d", "track": "#451a03"},
    {"bg": "#ec4899", "light": "#f9a8d4", "track": "#500724"},
    {"bg": "#8b5cf6", "light": "#c4b5fd", "track": "#2e1065"},
    {"bg": "#06b6d4", "light": "#67e8f9", "track": "#083344"},
]


def _color_map(speakers: list) -> dict:
    return {spk: PALETTE[i % len(PALETTE)] for i, spk in enumerate(sorted(speakers))}


def _fmt(sec: float) -> str:
    m, s = int(sec) // 60, int(sec) % 60
    return f"{m}:{s:02d}"


def render_html(json_path: str, out_path: str = None) -> str:
    """
    Build a fully self-contained HTML file with:
      1. Speaker swimlane timeline (interactive, hover + click)
      2. Activity density heatmap
      3. Talk-time / word-count bar charts  (matplotlib-style via SVG)
      4. Turn-duration scatter plot
      5. Scrollable utterance log (click to highlight in timeline)

    Returns the output path.
    """
    segments = load_segments(json_path)
    if not segments:
        raise ValueError("No segments found in JSON.")

    total    = max(seg["end"] for seg in segments)
    stats    = compute_stats(segments)
    density  = build_density(segments, total)
    speakers = sorted(stats.keys())
    cmap     = _color_map(speakers)

    if out_path is None:
        out_path = str(Path(json_path).with_suffix(".html"))

    # ── serialise data for JS ──────────────────────────────────────────────
    js_segments = json.dumps(segments, ensure_ascii=False)
    js_stats    = json.dumps({
        spk: {**d, "durations": d["durations"]}
        for spk, d in stats.items()
    }, ensure_ascii=False)
    js_density  = json.dumps(density, ensure_ascii=False)
    js_cmap     = json.dumps({
        spk: {"bg": c["bg"], "light": c["light"], "track": c["track"]}
        for spk, c in cmap.items()
    }, ensure_ascii=False)
    js_speakers = json.dumps(speakers, ensure_ascii=False)
    js_total    = json.dumps(float(total))

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Diarization Report</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Unbounded:wght@600;800&display=swap');
  *{{box-sizing:border-box;margin:0;padding:0}}
  html{{scroll-behavior:smooth}}
  body{{background:#09090e;color:#e2e8f0;font-family:'DM Mono',monospace;min-height:100vh;padding:28px 32px}}
  h1{{font-family:'Unbounded',sans-serif;font-size:1.5rem;font-weight:800;
      background:linear-gradient(90deg,#60a5fa,#34d399,#fbbf24);
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:4px}}
  .subtitle{{font-size:0.65rem;letter-spacing:0.08em;color:#475569;margin-bottom:28px}}
  .section-label{{font-size:0.58rem;letter-spacing:0.16em;color:#334155;text-transform:uppercase;margin-bottom:12px}}
  .card{{background:#0c0c14;border:1px solid #1e293b;border-radius:12px;padding:20px 24px;margin-bottom:18px}}
  /* timeline */
  .lane-row{{display:flex;align-items:center;margin-bottom:8px}}
  .lane-label{{width:100px;font-size:0.62rem;text-align:right;padding-right:12px;flex-shrink:0}}
  .lane-track{{flex:1;height:26px;background:#111827;border-radius:4px;position:relative;overflow:hidden;cursor:crosshair}}
  .seg-block{{position:absolute;top:3px;height:20px;border-radius:3px;cursor:pointer;transition:opacity .12s,transform .1s}}
  .seg-block:hover{{opacity:.8;transform:scaleY(1.15)}}
  .seg-block.selected{{outline:2px solid #fff;z-index:10}}
  /* cursor line */
  #cursor-line{{position:absolute;top:0;bottom:0;width:1px;background:#ffffff25;pointer-events:none;display:none}}
  #cursor-time{{position:absolute;top:-20px;background:#1e293b;border-radius:3px;padding:1px 5px;
               font-size:0.58rem;color:#94a3b8;transform:translateX(-50%);white-space:nowrap}}
  /* detail box */
  #detail-box{{display:none;border-radius:10px;padding:14px 18px;margin-bottom:16px;border:1px solid}}
  /* utterance log */
  .utt-row{{display:flex;gap:12px;padding:9px 16px;border-bottom:1px solid #111827;cursor:pointer;transition:background .1s}}
  .utt-row:hover{{background:#111827}}
  .utt-row.active{{background:#1e293b}}
  .utt-time{{font-size:0.6rem;color:#334155;min-width:40px;padding-top:2px;flex-shrink:0}}
  .utt-spk{{font-size:0.62rem;min-width:80px;padding-top:2px;flex-shrink:0}}
  .utt-text{{font-size:0.75rem;color:#94a3b8;line-height:1.55}}
  /* tabs */
  .tabs{{display:flex;gap:3px;background:#0f0f17;border-radius:8px;padding:3px;width:fit-content;margin-bottom:20px}}
  .tab{{padding:6px 18px;border-radius:6px;border:none;font-family:inherit;font-size:0.65rem;
        letter-spacing:0.06em;cursor:pointer;background:transparent;color:#475569;transition:all .15s}}
  .tab.active{{background:#1e293b;color:#e2e8f0}}
  /* speaker filters */
  .spk-chips{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px}}
  .chip{{padding:5px 14px;border-radius:20px;border:1px solid #1e293b;background:#0f0f17;
         font-size:0.65rem;font-family:inherit;cursor:pointer;transition:all .15s;color:#64748b}}
  .chip.active{{border-color:var(--chip-color);background:color-mix(in srgb,var(--chip-color) 12%,transparent);color:var(--chip-light)}}
  /* scrollbar */
  ::-webkit-scrollbar{{width:4px;height:4px}}
  ::-webkit-scrollbar-track{{background:#111}}
  ::-webkit-scrollbar-thumb{{background:#333;border-radius:2px}}
  /* chart panels */
  .chart-grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
  @media(max-width:700px){{.chart-grid{{grid-template-columns:1fr}}}}
  .bar-row{{margin-bottom:13px}}
  .bar-label{{display:flex;justify-content:space-between;margin-bottom:5px;font-size:0.65rem}}
  .bar-track{{height:10px;background:#111827;border-radius:5px;overflow:hidden}}
  .bar-fill{{height:100%;border-radius:5px;transition:width .8s cubic-bezier(.16,1,.3,1)}}
  /* density */
  .density-bars{{display:flex;gap:1px;align-items:flex-end;height:52px}}
  .d-bar{{flex:1;border-radius:1px 1px 0 0;cursor:default;transition:opacity .1s}}
  .d-bar:hover{{opacity:1!important}}
  /* scatter */
  #scatter-svg{{width:100%;overflow:visible}}
  .dot{{cursor:pointer;transition:all .1s}}
  .dot:hover{{opacity:1!important}}
  .tooltip{{position:fixed;background:#1e293b;border-radius:6px;padding:7px 11px;font-size:0.62rem;
            pointer-events:none;display:none;z-index:100;border:1px solid #334155;line-height:1.6}}
  /* audio player */
  .audio-player{{background:#0c0c14;border:1px solid #1e293b;border-radius:12px;
                padding:16px 20px;margin-bottom:18px;display:flex;align-items:center;
                gap:14px;flex-wrap:wrap}}
  .audio-upload{{background:#111827;border:1px solid #1e293b;border-radius:8px;
                padding:6px 14px;font-size:0.62rem;color:#94a3b8;cursor:pointer;
                font-family:inherit;transition:all .15s}}
  .audio-upload:hover{{border-color:#3b82f6;color:#60a5fa}}
  .audio-upload input{{display:none}}
  #audio-el{{flex:1;min-width:200px;height:32px;accent-color:#3b82f6;
              border-radius:6px;background:transparent}}
  audio::-webkit-media-controls-panel{{background:#111827}}
  .audio-time-disp{{font-size:0.62rem;color:#475569;min-width:90px;text-align:right;
                    font-variant-numeric:tabular-nums}}
  /* playhead */
  #playhead-line{{position:absolute;top:0;bottom:0;width:2px;
                  background:linear-gradient(180deg,#ef4444,#f97316);
                  pointer-events:none;display:none;z-index:20;
                  box-shadow:0 0 8px #ef444488}}
  #playhead-label{{position:absolute;top:-22px;left:50%;transform:translateX(-50%);
                   background:#ef4444;color:#fff;font-size:0.55rem;
                   padding:1px 5px;border-radius:3px;white-space:nowrap}}
  /* active utterance row highlight */
  .utt-row.now-playing{{background:#1e293b;border-left:2px solid #ef4444}}
</style>
</head>
<body>

<div style="margin-bottom:28px">
  <div style="font-size:0.58rem;letter-spacing:0.2em;color:#334155;margin-bottom:6px;font-family:'Unbounded',sans-serif">DIARIZATION REPORT</div>
  <h1>Voice Timeline</h1>
  <div class="subtitle" id="meta-line">loading…</div>
</div>

<!-- TABS -->
<div class="tabs">
  <button class="tab active" onclick="switchTab('timeline')">▬ Timeline</button>
  <button class="tab" onclick="switchTab('charts')">▤ Charts</button>
  <button class="tab" onclick="switchTab('scatter')">◈ Scatter</button>
</div>

<!-- SPEAKER FILTER CHIPS -->
<div class="spk-chips" id="spk-chips"></div>

<!-- TOOLTIP -->
<div class="tooltip" id="tooltip"></div>

<!-- ══ TIMELINE TAB ══════════════════════════════════════════════════════ -->
<div id="tab-timeline">

  <!-- ══ AUDIO PLAYER ═════════════════════════════════════════════════════ -->
  <div class="audio-player">
    <label class="audio-upload" title="Load your audio file">
      <input type="file" id="audio-file-input" accept="audio/*,video/*">
      📂 Load Audio
    </label>
    <audio id="audio-el" controls></audio>
    <div class="audio-time-disp" id="audio-time-disp">0:00 / 0:00</div>
  </div>

  <div class="card">
    <div class="section-label">Speaker Swimlanes</div>
    <!-- ruler -->
    <div style="display:flex;margin-bottom:6px">
      <div style="width:100px;flex-shrink:0"></div>
      <div style="flex:1;position:relative;height:16px" id="ruler"></div>
    </div>
    <!-- lanes -->
    <div id="lanes-container" style="position:relative">
      <div id="cursor-line"><div id="cursor-time"></div></div>
      <div id="playhead-line"><div id="playhead-label"></div></div>
    </div>
    <div style="margin-left:100px;height:1px;background:#1e293b;margin-top:2px"></div>
  </div>

  <!-- Density heatmap -->
  <div class="card">
    <div class="section-label">Activity Density (10 s buckets)</div>
    <div class="density-bars" id="density-bars"></div>
    <div style="display:flex;justify-content:space-between;margin-top:4px" id="density-ruler"></div>
  </div>

  <!-- Selected segment detail -->
  <div id="detail-box"></div>

  <!-- Utterance log -->
  <div class="card" style="padding:0;overflow:hidden">
    <div style="padding:12px 18px;border-bottom:1px solid #111827;font-size:0.58rem;letter-spacing:.14em;color:#334155"
         id="log-header">UTTERANCES</div>
    <div style="max-height:340px;overflow-y:auto" id="utt-log"></div>
  </div>
</div>

<!-- ══ CHARTS TAB ════════════════════════════════════════════════════════ -->
<div id="tab-charts" style="display:none">
  <div class="chart-grid">
    <div class="card" style="grid-column:1/-1">
      <div class="section-label">Speaking Time Share</div>
      <div id="chart-time"></div>
    </div>
    <div class="card">
      <div class="section-label">Word Count</div>
      <div id="chart-words"></div>
    </div>
    <div class="card">
      <div class="section-label">Turn Count</div>
      <div id="chart-turns"></div>
    </div>
    <div class="card" style="grid-column:1/-1">
      <div class="section-label">Avg Turn Duration</div>
      <div id="chart-avg" style="display:flex;gap:10px;align-items:flex-end;height:90px;padding-top:10px"></div>
    </div>
  </div>
</div>

<!-- ══ SCATTER TAB ════════════════════════════════════════════════════════ -->
<div id="tab-scatter" style="display:none">
  <div class="card">
    <div class="section-label">Turn Pattern — x=time · y=duration · size=words</div>
    <svg id="scatter-svg" viewBox="0 0 900 300"></svg>
    <div style="display:flex;gap:16px;margin-top:10px;flex-wrap:wrap" id="scatter-legend"></div>
  </div>
</div>

<!-- ══ DATA + LOGIC ═══════════════════════════════════════════════════════ -->
<script>
const SEGMENTS = {js_segments};
const STATS    = {js_stats};
const DENSITY  = {js_density};
const CMAP     = {js_cmap};
const SPEAKERS = {js_speakers};
const TOTAL    = {js_total};

// ── helpers ─────────────────────────────────────────────────────────────────
const fmt = t => `${{Math.floor(t/60)}}:${{String(Math.floor(t%60)).padStart(2,'0')}}`;
let activeSpk = null, selectedSeg = null, currentTab = 'timeline';

// meta
document.getElementById('meta-line').textContent =
  `${{fmt(0)}} → ${{fmt(TOTAL)}}  ·  ${{SEGMENTS.length}} utterances  ·  ${{SPEAKERS.length}} speakers`;

// ── tab switching ─────────────────────────────────────────────────────────
function switchTab(name) {{
  currentTab = name;
  ['timeline','charts','scatter'].forEach(t => {{
    document.getElementById('tab-'+t).style.display = t===name?'block':'none';
    document.querySelectorAll('.tab').forEach((b,i)=>{{
      if(['timeline','charts','scatter'][i]===name) b.classList.add('active');
      else b.classList.remove('active');
    }});
  }});
}}

// ── speaker filter chips ──────────────────────────────────────────────────
const chipsEl = document.getElementById('spk-chips');
SPEAKERS.forEach(spk => {{
  const c = CMAP[spk];
  const btn = document.createElement('button');
  btn.className = 'chip';
  btn.style.setProperty('--chip-color', c.bg);
  btn.style.setProperty('--chip-light', c.light);
  btn.innerHTML = `<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${{c.bg}};margin-right:7px;vertical-align:middle"></span>${{spk}}`;
  btn.onclick = () => {{
    activeSpk = activeSpk===spk ? null : spk;
    document.querySelectorAll('.chip').forEach(b=>b.classList.remove('active'));
    if(activeSpk) btn.classList.add('active');
    renderAll();
  }};
  chipsEl.appendChild(btn);
}});

// ── TIMELINE ────────────────────────────────────────────────────────────────
function buildTimeline() {{
  const cont = document.getElementById('lanes-container');
  // keep cursor line
  const cursorLine = document.getElementById('cursor-line');

  // remove old lanes
  cont.querySelectorAll('.lane-row').forEach(e=>e.remove());

  const filtered = activeSpk ? SEGMENTS.filter(s=>s.speaker_id===activeSpk) : SEGMENTS;

  SPEAKERS.forEach(spk => {{
    const c = CMAP[spk];
    const segs = filtered.filter(s=>s.speaker_id===spk);
    if(!segs.length && activeSpk && activeSpk!==spk) return;

    const row = document.createElement('div');
    row.className='lane-row';
    row.innerHTML=`
      <div class="lane-label" style="color:${{c.light}}">${{spk}}</div>
      <div class="lane-track" id="track-${{spk}}"></div>`;
    cont.insertBefore(row, cursorLine.parentNode===cont ? cursorLine : null);

    const track = row.querySelector('.lane-track');
    segs.forEach(seg => {{
      const left  = (seg.start/TOTAL)*100;
      const width = Math.max(0.15, ((seg.end-seg.start)/TOTAL)*100);
      const block = document.createElement('div');
      block.className = 'seg-block' + (selectedSeg&&selectedSeg.start===seg.start?' selected':'');
      block.style.cssText=`left:${{left}}%;width:${{width}}%;background:${{c.bg}};box-shadow:${{
        selectedSeg&&selectedSeg.start===seg.start?`0 0 0 2px #fff,0 0 10px ${{c.bg}}`:'none'}}`;
      block.title = `${{fmt(seg.start)}} – ${{fmt(seg.end)}}: ${{seg.text.slice(0,80)}}`;
      block.onclick = e => {{ e.stopPropagation(); selectSeg(seg); }};
      track.appendChild(block);
    }});

    // cursor tracking on each track
    track.addEventListener('mousemove', e => {{
      const rect = track.getBoundingClientRect();
      const pct  = (e.clientX-rect.left)/rect.width;
      const t    = pct*TOTAL;
      // position cursor line relative to lanes-container
      const contRect = cont.getBoundingClientRect();
      const x = (e.clientX - contRect.left);
      cursorLine.style.left  = x+'px';
      cursorLine.style.display='block';
      document.getElementById('cursor-time').textContent = fmt(t);
    }});
    track.addEventListener('mouseleave', ()=>{{ cursorLine.style.display='none'; }});
  }});

  // ruler
  const ruler = document.getElementById('ruler');
  ruler.innerHTML='';
  const ticks = Math.min(12, Math.ceil(TOTAL/60));
  for(let i=0;i<=ticks;i++) {{
    const t = i*(TOTAL/ticks);
    const d = document.createElement('div');
    d.style.cssText=`position:absolute;left:${{(t/TOTAL)*100}}%;transform:translateX(-50%);font-size:.55rem;color:#334155`;
    d.textContent=fmt(t);
    ruler.appendChild(d);
  }}
}}

// ── density heatmap ──────────────────────────────────────────────────────────
function buildDensity() {{
  const el  = document.getElementById('density-bars');
  const rul = document.getElementById('density-ruler');
  el.innerHTML=''; rul.innerHTML='';
  const maxC = Math.max(...DENSITY.map(d=>d.count), 1);
  DENSITY.forEach(d => {{
    const div=document.createElement('div');
    div.className='d-bar';
    const h = Math.max(2, (d.count/maxC)*50);
    const spks = d.speakers.filter(s=>!activeSpk||s===activeSpk);
    const col  = spks.length===0?'#111827':spks.length===1?CMAP[spks[0]]?.bg||'#6366f1':'#a78bfa';
    div.style.cssText=`height:${{h}}px;background:${{col}};opacity:${{d.count?0.75:0.12}}`;
    div.title=`${{fmt(d.t)}}–${{fmt(d.t+10)}}: ${{d.count}} seg`;
    el.appendChild(div);
  }});
  // ruler labels every 60s
  for(let t=0;t<=TOTAL;t+=60) {{
    const sp=document.createElement('span');
    sp.style.cssText='font-size:.55rem;color:#334155';
    sp.textContent=fmt(t);
    rul.appendChild(sp);
  }}
}}

// ── segment detail ────────────────────────────────────────────────────────────
function selectSeg(seg) {{
  selectedSeg = selectedSeg&&selectedSeg.start===seg.start ? null : seg;
  const box = document.getElementById('detail-box');
  if(!selectedSeg) {{ box.style.display='none'; buildTimeline(); buildUttLog(); return; }}
  const c=CMAP[seg.speaker_id]||{{bg:'#6366f1',light:'#a5b4fc'}};
  box.style.cssText=`display:block;background:${{c.bg}}18;border-color:${{c.bg}}50;margin-bottom:16px;border-radius:10px;padding:14px 18px;border:1px solid`;
  box.innerHTML=`
    <div style="display:flex;justify-content:space-between;margin-bottom:8px;align-items:center">
      <span style="font-size:.7rem;color:${{c.light}};letter-spacing:.05em">${{seg.speaker_id}}</span>
      <span style="font-size:.62rem;color:#475569">${{fmt(seg.start)}} → ${{fmt(seg.end)}} &nbsp;(${{Math.round(seg.end-seg.start)}}s)</span>
    </div>
    <p style="font-size:.8rem;line-height:1.65;color:#cbd5e1">${{seg.text}}</p>`;
  buildTimeline(); buildUttLog();
}}

// ── utterance log ─────────────────────────────────────────────────────────────
function buildUttLog() {{
  const el   = document.getElementById('utt-log');
  const hdr  = document.getElementById('log-header');
  const segs = activeSpk ? SEGMENTS.filter(s=>s.speaker_id===activeSpk) : SEGMENTS;
  hdr.textContent = `UTTERANCES${{activeSpk?' · '+activeSpk:''}} (${{segs.length}})`;
  el.innerHTML='';
  segs.forEach(seg=>{{
    const c=CMAP[seg.speaker_id]||{{bg:'#6366f1',light:'#94a3b8'}};
    const row=document.createElement('div');
    row.className='utt-row'+(selectedSeg&&selectedSeg.start===seg.start?' active':'');
    row.innerHTML=`
      <div style="width:2px;flex-shrink:0;align-self:stretch;background:${{c.bg}};border-radius:1px;opacity:.7"></div>
      <div class="utt-time">${{fmt(seg.start)}}</div>
      <div class="utt-spk" style="color:${{c.light}}">${{seg.speaker_id}}</div>
      <div class="utt-text">${{seg.text}}</div>`;
    row.onclick=()=>selectSeg(seg);
    el.appendChild(row);
  }});
}}

// ── CHARTS ────────────────────────────────────────────────────────────────────
function buildBarChart(containerId, data, valFn, labelFn, colorFn) {{
  const el=document.getElementById(containerId);
  el.innerHTML='';
  const max=Math.max(...data.map(valFn),1);
  data.forEach(d=>{{
    const v=valFn(d); const pct=(v/max)*100;
    el.innerHTML+=`
      <div class="bar-row">
        <div class="bar-label">
          <span style="color:${{colorFn(d).light}}">${{d.spk}}</span>
          <span style="color:#475569">${{labelFn(d,v)}}</span>
        </div>
        <div class="bar-track">
          <div class="bar-fill" style="width:${{pct}}%;background:linear-gradient(90deg,${{colorFn(d).bg}},${{colorFn(d).bg}}88)"></div>
        </div>
      </div>`;
  }});
}}

function buildCharts() {{
  const data = SPEAKERS
    .filter(s=>STATS[s])
    .map(s=>({{spk:s,...STATS[s]}}));
  const totalSec = data.reduce((a,d)=>a+d.total_sec,0)||1;

  buildBarChart('chart-time', data,
    d=>d.total_sec,
    (d,v)=>`${{fmt(v)}} (${{Math.round((v/totalSec)*100)}}%)`,
    d=>CMAP[d.spk]||{{bg:'#6366f1',light:'#a5b4fc'}}
  );
  buildBarChart('chart-words', data,
    d=>d.words, (d,v)=>`${{v.toLocaleString()}} words`,
    d=>CMAP[d.spk]||{{bg:'#6366f1',light:'#a5b4fc'}}
  );
  buildBarChart('chart-turns', data,
    d=>d.utterances, (d,v)=>`${{v}} turns`,
    d=>CMAP[d.spk]||{{bg:'#6366f1',light:'#a5b4fc'}}
  );

  // avg duration column chart
  const avgEl=document.getElementById('chart-avg');
  avgEl.innerHTML='';
  const maxAvg=Math.max(...data.map(d=>d.avg_dur),1);
  data.forEach(d=>{{
    const c=CMAP[d.spk]||{{bg:'#6366f1',light:'#a5b4fc',track:'#1e1b4b'}};
    const h=Math.max(8,(d.avg_dur/maxAvg)*72);
    avgEl.innerHTML+=`
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px">
        <span style="font-size:.65rem;color:${{c.light}}">${{d.avg_dur.toFixed(1)}}s</span>
        <div style="width:100%;height:${{h}}px;background:linear-gradient(180deg,${{c.bg}},${{c.bg}}66);
             border-radius:4px 4px 0 0;box-shadow:0 -4px 12px ${{c.bg}}30"></div>
        <span style="font-size:.58rem;color:#334155">${{d.spk}}</span>
      </div>`;
  }});
}}

// ── SCATTER ────────────────────────────────────────────────────────────────────
function buildScatter() {{
  const svg   = document.getElementById('scatter-svg');
  const W=860, H=260, PL=30, PR=10, PT=10, PB=30;
  const tip   = document.getElementById('tooltip');

  svg.innerHTML='';

  const segs = activeSpk ? SEGMENTS.filter(s=>s.speaker_id===activeSpk) : SEGMENTS;
  const maxDur = Math.max(...segs.map(s=>s.end-s.start), 10);

  // grid lines
  for(let t=0;t<=TOTAL;t+=60) {{
    const x=PL+(t/TOTAL)*(W-PL-PR);
    svg.innerHTML+=`<line x1="${{x}}" y1="${{PT}}" x2="${{x}}" y2="${{H-PB}}" stroke="#111827" stroke-width="1"/>
      <text x="${{x}}" y="${{H-PB+12}}" text-anchor="middle" font-size="8" fill="#334155">${{fmt(t)}}</text>`;
  }}
  for(let d=0;d<=maxDur;d+=Math.ceil(maxDur/5)) {{
    const y=H-PB-((d/maxDur)*(H-PB-PT));
    svg.innerHTML+=`<line x1="${{PL}}" y1="${{y}}" x2="${{W-PR}}" y2="${{y}}" stroke="#0f172a" stroke-width="1"/>
      <text x="${{PL-4}}" y="${{y+3}}" text-anchor="end" font-size="8" fill="#334155">${{Math.round(d)}}s</text>`;
  }}

  segs.forEach(seg=>{{
    const c  = CMAP[seg.speaker_id]||{{bg:'#6366f1'}};
    const cx = PL+(seg.start/TOTAL)*(W-PL-PR);
    const dur= seg.end-seg.start;
    const cy = H-PB-((dur/maxDur)*(H-PB-PT));
    const wc = seg.text.split(' ').length;
    const r  = Math.max(3, Math.min(14, wc/7));
    const circle = document.createElementNS('http://www.w3.org/2000/svg','circle');
    circle.setAttribute('cx',cx); circle.setAttribute('cy',cy); circle.setAttribute('r',r);
    circle.setAttribute('fill',c.bg); circle.setAttribute('opacity','0.65');
    circle.classList.add('dot');
    circle.addEventListener('mouseenter',e=>{{
      circle.setAttribute('opacity','1');
      circle.style.filter=`drop-shadow(0 0 6px ${{c.bg}})`;
      tip.style.display='block';
      tip.innerHTML=`<span style="color:${{c.light}}">${{seg.speaker_id}}</span> · ${{fmt(seg.start)}}<br>
        <span style="color:#64748b">${{Math.round(dur)}}s · ${{wc}} words</span><br>
        <span style="color:#475569;font-size:.6rem">${{seg.text.slice(0,70)}}…</span>`;
    }});
    circle.addEventListener('mousemove',e=>{{
      tip.style.left=(e.clientX+14)+'px'; tip.style.top=(e.clientY-10)+'px';
    }});
    circle.addEventListener('mouseleave',()=>{{
      circle.setAttribute('opacity','0.65'); circle.style.filter=''; tip.style.display='none';
    }});
    circle.addEventListener('click',()=>selectSeg(seg));
    svg.appendChild(circle);
  }});

  // legend
  const leg=document.getElementById('scatter-legend');
  leg.innerHTML='';
  SPEAKERS.forEach(spk=>{{
    const c=CMAP[spk];
    leg.innerHTML+=`<div style="display:flex;align-items:center;gap:6px">
      <div style="width:8px;height:8px;border-radius:50%;background:${{c.bg}}"></div>
      <span style="font-size:.62rem;color:#475569">${{spk}}</span></div>`;
  }});
  leg.innerHTML+=`<div style="margin-left:auto;font-size:.6rem;color:#334155">dot size ∝ word count</div>`;
}}


// ══ AUDIO SYNC ═══════════════════════════════════════════════════════════════
const audioEl    = document.getElementById('audio-el');
const fileInput  = document.getElementById('audio-file-input');
const timeDisp   = document.getElementById('audio-time-disp');
const playhead   = document.getElementById('playhead-line');
const playLabel  = document.getElementById('playhead-label');

let audioReady   = false;
let lastUttIdx   = -1;   // track which utterance is currently highlighted

// ── Load audio file from disk (user upload) ──────────────────────────────────
fileInput.addEventListener('change', e => {{
  const file = e.target.files[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  audioEl.src = url;
  audioEl.load();
  audioReady  = true;
  playhead.style.display = 'block';
  console.log('[AUDIO] Loaded:', file.name, '| Duration will be available after canplay.');
}});

// ── Click on a swimlane block → seek audio to that segment ──────────────────
// We override selectSeg to also seek when audio is loaded
const _origSelectSeg = selectSeg;
function selectSeg(seg) {{
  _origSelectSeg(seg);
  if (audioReady && seg) {{
    audioEl.currentTime = seg.start;
    audioEl.play().catch(() => {{}});   // autoplay may be blocked; ignore
  }}
}}

// ── Click on the swimlane track area → seek to that time position ────────────
document.addEventListener('click', e => {{
  const track = e.target.closest('.lane-track');
  if (!track || !audioReady) return;
  const rect = track.getBoundingClientRect();
  const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  audioEl.currentTime = pct * TOTAL;
  audioEl.play().catch(() => {{}});
}});

// ── timeupdate: move playhead + highlight utterance + scroll log ─────────────
audioEl.addEventListener('timeupdate', () => {{
  const t = audioEl.currentTime;

  // 1. Update time display
  const dur = audioEl.duration || TOTAL;
  timeDisp.textContent = `${{fmt(t)}} / ${{fmt(dur)}}`;

  // 2. Move playhead line across swimlanes
  const cont     = document.getElementById('lanes-container');
  const contW    = cont.getBoundingClientRect().width;
  const headPx   = (t / TOTAL) * contW;
  playhead.style.left    = headPx + 'px';
  playhead.style.display = 'block';
  playLabel.textContent  = fmt(t);

  // 3. Find the utterance that is currently playing
  let nowIdx = -1;
  for (let i = 0; i < SEGMENTS.length; i++) {{
    if (t >= SEGMENTS[i].start && t < SEGMENTS[i].end) {{
      nowIdx = i;
      break;
    }}
  }}

  if (nowIdx !== lastUttIdx) {{
    lastUttIdx = nowIdx;

    // Remove now-playing from all rows
    document.querySelectorAll('.utt-row.now-playing').forEach(r => r.classList.remove('now-playing'));

    if (nowIdx >= 0) {{
      const seg = SEGMENTS[nowIdx];
      const spk = seg.speaker_id;

      // 4a. Highlight the utterance log row
      const logRows = document.querySelectorAll('#utt-log .utt-row');
      // map position: only rendered rows for activeSpk or all
      const visSegs = activeSpk ? SEGMENTS.filter(s => s.speaker_id === activeSpk) : SEGMENTS;
      const visIdx  = visSegs.findIndex(s => s.start === seg.start);
      if (visIdx >= 0 && logRows[visIdx]) {{
        logRows[visIdx].classList.add('now-playing');
        // Auto-scroll the utterance log so the active row is visible
        logRows[visIdx].scrollIntoView({{ block: 'nearest', behavior: 'smooth' }});
      }}

      // 4b. Flash the detail box with the current segment text
      const box = document.getElementById('detail-box');
      const c   = CMAP[spk] || {{bg:'#6366f1', light:'#a5b4fc'}};
      box.style.cssText = `display:block;background:${{c.bg}}18;border-color:${{c.bg}}50;
        margin-bottom:16px;border-radius:10px;padding:14px 18px;border:1px solid`;
      box.innerHTML = `
        <div style="display:flex;justify-content:space-between;margin-bottom:8px;align-items:center">
          <span style="font-size:.7rem;color:${{c.light}};letter-spacing:.05em">${{spk}}</span>
          <span style="font-size:.62rem;color:#475569">${{fmt(seg.start)}} → ${{fmt(seg.end)}}</span>
        </div>
        <p style="font-size:.8rem;line-height:1.65;color:#cbd5e1">${{seg.text}}</p>`;
    }}
  }}
}});

// ── Pause/play toggle on space bar (when audio is ready) ─────────────────────
document.addEventListener('keydown', e => {{
  if (e.code === 'Space' && audioReady && e.target === document.body) {{
    e.preventDefault();
    audioEl.paused ? audioEl.play() : audioEl.pause();
  }}
}});

console.log('[AUDIO] Sync engine initialised. Load an audio file to begin.');
// ══════════════════════════════════════════════════════════════════════════════


// ── render all ────────────────────────────────────────────────────────────────
function renderAll() {{
  buildTimeline();
  buildDensity();
  buildUttLog();
  buildCharts();
  buildScatter();
}}

renderAll();
</script>
</body>
</html>"""

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[VIZ] Interactive chart saved → {out_path}")
    return out_path


# ───────────────────────────────────────────────────────────────────────────────
# CLI
# ───────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Visualize diarization JSON")
    parser.add_argument("json_path", help="Path to step_0.json")
    parser.add_argument("--out", default=None, help="Output HTML path (default: same dir as JSON)")
    args = parser.parse_args()
    path = render_html(args.json_path, args.out)
    print(f"Open in browser: file://{os.path.abspath(path)}")

# ─────────────────────────────────────────────────────────────────────────────
# REPO INTEGRATION WRAPPER
# ─────────────────────────────────────────────────────────────────────────────

def build_view_html(segments: list, out_path: str) -> str:
    """
    Called by backend/diarisation.py with an in-memory segments list.
    Writes segments to a temp JSON file then calls render_html().
    Returns out_path on success.
    """
    import tempfile as _tempfile
    import os as _os
    import json as _json

    if not segments:
        raise ValueError("[VIEW] No segments supplied.")

    with _tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as tmp:
        _json.dump(segments, tmp, ensure_ascii=False)
        tmp_path = tmp.name

    try:
        render_html(tmp_path, out_path)
    finally:
        try:
            _os.unlink(tmp_path)
        except OSError:
            pass

    return out_path
