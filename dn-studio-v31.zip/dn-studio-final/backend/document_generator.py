# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/document_generator.py
# PURPOSE: Config-driven document generation pipeline.
#          Every phase is timed and token-tracked.
#          generate_document() returns full metrics for the frontend.
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import time
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import yaml

from backend.llm_client import call_llm, extract_json, build_prompt, LLMResult

log = logging.getLogger("dn_studio.generator")

CONFIG_PATH = Path("config/document_types.yaml")


# ─────────────────────────────────────────────────────────────────────────────
# RESULT TYPES
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PhaseMetrics:
    name:          str
    elapsed_sec:   float = 0.0
    input_tokens:  int   = 0
    output_tokens: int   = 0
    total_tokens:  int   = 0
    cost_usd:      float = 0.0


@dataclass
class GenerationMetrics:
    phases:          list = field(default_factory=list)   # list[PhaseMetrics]
    total_tokens:    int   = 0
    total_cost_usd:  float = 0.0
    total_elapsed_sec: float = 0.0

    def add_phase(self, pm: PhaseMetrics):
        self.phases.append(pm)
        self.total_tokens      += pm.total_tokens
        self.total_cost_usd    += pm.cost_usd
        self.total_elapsed_sec += pm.elapsed_sec

    def to_dict(self) -> dict:
        return {
            "phases": [
                {
                    "name":          p.name,
                    "elapsed_sec":   round(p.elapsed_sec, 2),
                    "input_tokens":  p.input_tokens,
                    "output_tokens": p.output_tokens,
                    "total_tokens":  p.total_tokens,
                    "cost_usd":      round(p.cost_usd, 6),
                }
                for p in self.phases
            ],
            "total_tokens":      self.total_tokens,
            "total_cost_usd":    round(self.total_cost_usd, 6),
            "total_elapsed_sec": round(self.total_elapsed_sec, 2),
        }


# ─────────────────────────────────────────────────────────────────────────────
# CONFIG LOADER
# ─────────────────────────────────────────────────────────────────────────────

def load_document_types() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    log.info("[CFG] Document types: %s", list(cfg.keys()))
    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1 — Schema generation
# ─────────────────────────────────────────────────────────────────────────────

def run_phase1(
    doc_type: str,
    cfg: dict,
    diarisation_json: list,
    business_context: str,
    h1_sections: str,
    output_dir: Path,
) -> tuple:
    """
    Phase 1: schema design via LLM.
    Returns (schema_dict, PhaseMetrics).
    """
    log.info("[GEN][%s] Phase 1 started — schema design", doc_type)
    t0 = time.perf_counter()

    prompt = build_prompt(cfg["p1_prompt"], {
        "BUSINESS_CONTEXT": business_context,
        "H1_SECTIONS":      h1_sections,
        "DIARISATION_JSON": json.dumps(diarisation_json, indent=2),
    })

    result = call_llm(prompt, max_output_tokens=8192)
    schema = extract_json(result.text)

    h1s = schema.get("structure", [])
    h2c = sum(len(h1.get("children", [])) for h1 in h1s)
    h3c = sum(len(h3.get("children", []))
              for h1 in h1s for h3 in h1.get("children", []))

    schema_path = output_dir / "a_schema.json"
    schema_path.write_text(json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")

    pm = PhaseMetrics(
        name          = "Schema design",
        elapsed_sec   = result.elapsed_sec,
        input_tokens  = result.input_tokens,
        output_tokens = result.output_tokens,
        total_tokens  = result.total_tokens,
        cost_usd      = result.cost_usd,
    )

    log.info("[GEN][%s] Phase 1 done  %.2fs  H1:%d H2:%d H3:%d  tokens=%d  cost=$%.4f",
             doc_type, pm.elapsed_sec, len(h1s), h2c, h3c, pm.total_tokens, pm.cost_usd)
    return schema, pm


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2 — Content population
# ─────────────────────────────────────────────────────────────────────────────

def run_phase2(
    doc_type: str,
    cfg: dict,
    diarisation_json: list,
    business_context: str,
    schema: dict,
    output_dir: Path,
) -> tuple:
    """
    Phase 2: content population via LLM (65k token budget).
    Returns (populated_dict, PhaseMetrics).
    """
    log.info("[GEN][%s] Phase 2 started — content population", doc_type)

    prompt = build_prompt(cfg["p2_prompt"], {
        "BUSINESS_CONTEXT": business_context,
        "SCHEMA_JSON":      json.dumps(schema, indent=2),
        "DIARISATION_JSON": json.dumps(diarisation_json, indent=2),
    })

    result    = call_llm(prompt, max_output_tokens=65536)
    populated = extract_json(result.text)

    # Validate completeness
    missing = [
        h3.get("name", "?")
        for h1 in populated.get("structure", [])
        for h2 in h1.get("children", [])
        for h3 in h2.get("children", [])
        if not h3.get("content") or h3.get("content") == ""
    ]
    if missing:
        log.warning("[GEN][%s] Phase 2 — %d sections missing content: %s",
                    doc_type, len(missing), missing[:5])

    response_path = output_dir / "b_response.json"
    response_path.write_text(json.dumps(populated, indent=2, ensure_ascii=False), encoding="utf-8")

    pm = PhaseMetrics(
        name          = "Content population",
        elapsed_sec   = result.elapsed_sec,
        input_tokens  = result.input_tokens,
        output_tokens = result.output_tokens,
        total_tokens  = result.total_tokens,
        cost_usd      = result.cost_usd,
    )

    log.info("[GEN][%s] Phase 2 done  %.2fs  tokens=%d  cost=$%.4f",
             doc_type, pm.elapsed_sec, pm.total_tokens, pm.cost_usd)
    return populated, pm


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 3 — DOCX render via Node.js
# ─────────────────────────────────────────────────────────────────────────────

def run_phase3(
    doc_type: str,
    cfg: dict,
    output_dir: Path,
) -> tuple:
    """
    Phase 3: Node.js DOCX renderer.
    Returns (docx_path, PhaseMetrics).
    """
    log.info("[GEN][%s] Phase 3 started — DOCX render", doc_type)
    t0 = time.perf_counter()

    response_path = output_dir / "b_response.json"
    docx_path     = output_dir / cfg["output_filename"]
    js_template   = cfg["js_template"]

    cmd    = ["node", js_template, str(response_path), str(docx_path)]
    result = subprocess.run(cmd, capture_output=True, text=True)

    elapsed = round(time.perf_counter() - t0, 2)

    if result.stdout.strip():
        for line in result.stdout.strip().splitlines():
            log.info("[NODE][%s] %s", doc_type, line)

    if result.returncode != 0:
        log.error("[GEN][%s] Node.js failed:\n%s", doc_type, result.stderr)
        raise RuntimeError(
            f"[GEN][{doc_type}] DOCX render failed.\n"
            f"stderr: {result.stderr[-800:]}"
        )

    size_kb = docx_path.stat().st_size / 1024
    log.info("[GEN][%s] Phase 3 done  %.2fs  %.1f KB", doc_type, elapsed, size_kb)

    pm = PhaseMetrics(
        name        = "DOCX render",
        elapsed_sec = elapsed,
        # Node render has no token cost
    )
    return docx_path, pm


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def generate_document(
    doc_type: str,
    diarisation_json: list,
    business_context: str = "",
    h1_sections: str = "",
    log_callback = None,
) -> dict:
    """
    Full pipeline: Phase 1 (+ Phase 2 if llm_calls==2) + Phase 3 DOCX render.

    Returns dict with keys:
        doc_type, schema_path, response_path, docx_path,
        metrics (GenerationMetrics.to_dict())

    log_callback(msg: str) — optional streaming log to frontend.
    The callback also accepts structured SSE events as dicts:
        log_callback({"type": "metrics_update", ...})
    """
    pipeline_start = time.perf_counter()

    def emit(msg: str):
        log.info(msg)
        if log_callback:
            log_callback(msg)

    def emit_metrics(metrics: GenerationMetrics):
        """Push a live metrics update through the SSE stream."""
        if log_callback:
            log_callback({
                "type":    "metrics_update",
                "metrics": metrics.to_dict(),
            })

    emit(f"[GEN] Starting {doc_type} generation")

    all_types = load_document_types()
    if doc_type not in all_types:
        raise ValueError(f"[GEN] Unknown doc_type '{doc_type}'. "
                         f"Available: {list(all_types.keys())}")

    cfg        = all_types[doc_type]
    output_dir = Path(cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    metrics    = GenerationMetrics()

    emit(f"[GEN][{doc_type}] Config loaded — {cfg['llm_calls']} LLM call(s)")

    schema_path   = None
    response_path = None

    # ── Phase 1 ───────────────────────────────────────────────────────────────
    if cfg["llm_calls"] == 2:
        emit(f"[GEN][{doc_type}] Phase 1 — designing document schema...")
        schema, pm1 = run_phase1(
            doc_type, cfg, diarisation_json,
            business_context, h1_sections, output_dir
        )
        metrics.add_phase(pm1)
        schema_path = str(output_dir / "a_schema.json")
        emit(f"[GEN][{doc_type}] Phase 1 complete — {pm1.elapsed_sec:.1f}s · "
             f"{pm1.total_tokens:,} tokens · ${pm1.cost_usd:.4f}")
        emit_metrics(metrics)
    else:
        emit(f"[GEN][{doc_type}] Single-call mode (no schema phase)")

    # ── Phase 2 ───────────────────────────────────────────────────────────────
    if cfg["llm_calls"] == 2:
        emit(f"[GEN][{doc_type}] Phase 2 — writing document content...")
        populated, pm2 = run_phase2(
            doc_type, cfg, diarisation_json,
            business_context, schema, output_dir
        )
        metrics.add_phase(pm2)
        emit(f"[GEN][{doc_type}] Phase 2 complete — {pm2.elapsed_sec:.1f}s · "
             f"{pm2.total_tokens:,} tokens · ${pm2.cost_usd:.4f}")
        emit_metrics(metrics)
    else:
        emit(f"[GEN][{doc_type}] Phase 2 — generating full document in one call...")
        prompt = build_prompt(cfg["p1_prompt"], {
            "BUSINESS_CONTEXT": business_context,
            "DIARISATION_JSON": json.dumps(diarisation_json, indent=2),
        })
        result    = call_llm(prompt, max_output_tokens=8192)
        populated = extract_json(result.text)
        response_path_obj = output_dir / "b_response.json"
        response_path_obj.write_text(
            json.dumps(populated, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        pm_single = PhaseMetrics(
            name          = "Document generation",
            elapsed_sec   = result.elapsed_sec,
            input_tokens  = result.input_tokens,
            output_tokens = result.output_tokens,
            total_tokens  = result.total_tokens,
            cost_usd      = result.cost_usd,
        )
        metrics.add_phase(pm_single)
        emit(f"[GEN][{doc_type}] Generation complete — {result.elapsed_sec:.1f}s · "
             f"{result.total_tokens:,} tokens · ${result.cost_usd:.4f}")
        emit_metrics(metrics)

    response_path = str(output_dir / "b_response.json")

    # ── Phase 3 ───────────────────────────────────────────────────────────────
    emit(f"[GEN][{doc_type}] Phase 3 — rendering Word document...")
    docx_path, pm3 = run_phase3(doc_type, cfg, output_dir)
    metrics.add_phase(pm3)
    size_kb = docx_path.stat().st_size / 1024
    emit(f"[GEN][{doc_type}] Phase 3 complete — {pm3.elapsed_sec:.1f}s · "
         f"{size_kb:.0f} KB document created")
    emit_metrics(metrics)

    total_elapsed = round(time.perf_counter() - pipeline_start, 2)
    metrics.total_elapsed_sec = total_elapsed  # update with wall-clock total

    emit(f"[GEN][{doc_type}] Pipeline complete ✓ — "
         f"total {total_elapsed:.1f}s · "
         f"{metrics.total_tokens:,} tokens · "
         f"${metrics.total_cost_usd:.4f}")

    # Final metrics push with complete data
    emit_metrics(metrics)

    return {
        "doc_type":      doc_type,
        "schema_path":   schema_path,
        "response_path": response_path,
        "docx_path":     str(docx_path),
        "metrics":       metrics.to_dict(),
    }
