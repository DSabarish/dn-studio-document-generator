// FILE: frontend/src/app/App.tsx
import { useState, useCallback, useEffect } from 'react';
import { Sidebar }        from './components/Sidebar';
import { Stage1 }         from './components/Stage1';
import { Stage2 }         from './components/Stage2';
import { ToastProvider }  from './components/Toast';
import { Confetti }       from './components/Confetti';
import type { DiarisationResult } from './api';

export default function App() {
  const [currentStage,    setCurrentStage]    = useState(1);
  const [diarisationData, setDiarisationData] = useState<DiarisationResult | null>(null);
  const [documentData,    setDocumentData]    = useState<any>(null);
  const [geminiApiKey,    setGeminiApiKey]    = useState('');
  const [diarisationSec,  setDiarisationSec]  = useState(0);
  const [stageKey,        setStageKey]        = useState(0);   // re-mount for fade-in
  const [confetti,        setConfetti]        = useState(false);

  const handleDiarisationComplete = useCallback((data: DiarisationResult, elapsedSec: number) => {
    setDiarisationData(data);
    setDiarisationSec(elapsedSec);
  }, []);

  const handleClearSession = useCallback(() => {
    setDiarisationData(null);
    setDocumentData(null);
    setCurrentStage(1);
    setStageKey(k => k + 1);
  }, []);

  const handleStageChange = useCallback((s: number) => {
    setCurrentStage(s);
    setStageKey(k => k + 1);
  }, []);

  const handleDocumentGenerate = useCallback((data: any) => {
    setDocumentData(data);
    // Trigger confetti, reset after 3s
    setConfetti(true);
    setTimeout(() => setConfetti(false), 3000);
  }, []);

  // Keyboard shortcut: Space = play/pause (handled in Stage1 via event)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && e.target === document.body) {
        // Escape handling delegated to Stage1 via custom event
        window.dispatchEvent(new CustomEvent('dn-escape'));
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <ToastProvider>
      <div className="size-full flex dark" style={{ background: 'var(--dn-bg, #111)', color: 'var(--dn-text, #fff)' }}>
        <Sidebar
          currentStage={currentStage}
          onStageChange={handleStageChange}
          hasDiarisation={!!diarisationData}
          hasDocument={!!documentData}
          diarisationData={diarisationData}
          documentData={documentData}
          geminiApiKey={geminiApiKey}
          onApiKeyChange={setGeminiApiKey}
        />
        <div key={stageKey} className="flex-1 animate-fade-in" style={{ minWidth: 0 }}>
          {currentStage === 1 ? (
            <Stage1
              onDiarisationComplete={handleDiarisationComplete}
              onClearSession={handleClearSession}
              existingResult={diarisationData}
            />
          ) : (
            <Stage2
              onDocumentGenerate={handleDocumentGenerate}
              diarisationData={diarisationData}
              geminiApiKey={geminiApiKey}
              diarisationSec={diarisationSec}
            />
          )}
        </div>
        <Confetti trigger={confetti} />
      </div>
    </ToastProvider>
  );
}
