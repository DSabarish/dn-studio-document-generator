// FILE: frontend/src/app/components/Sidebar.tsx
import { useState, useEffect } from 'react';
import type { DiarisationResult } from '../api';
import THEMES_JSON from '../../themes.json';

interface SidebarProps {
  currentStage: number;
  onStageChange: (stage: number) => void;
  hasDiarisation: boolean;
  hasDocument: boolean;
  diarisationData?: DiarisationResult | null;
  documentData?: any;
  geminiApiKey: string;
  onApiKeyChange: (key: string) => void;
}

function applyTheme(vars: Record<string, string>, isLight: boolean) {
  const root = document.documentElement;
  Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.classList.toggle('dark', !isLight);
}

export function Sidebar({
  currentStage, onStageChange,
  hasDiarisation, hasDocument,
  diarisationData, documentData,
  geminiApiKey, onApiKeyChange,
}: SidebarProps) {
  const [showKey,  setShowKey]  = useState(false);
  const [themeId,  setThemeId]  = useState('dark');
  const [themeOpen, setThemeOpen] = useState(false);

  useEffect(() => {
    const t = THEMES_JSON.find(t => t.id === themeId) ?? THEMES_JSON[0];
    const isLight = themeId === 'light' || themeId === 'pro-not-corporate';
    applyTheme(t.vars, isLight);
  }, [themeId]);

  return (
    <div className="w-56 flex flex-col h-screen flex-shrink-0"
      style={{ background: 'var(--dn-surface)', borderRight: '1px solid var(--dn-border)' }}>

      {/* Logo */}
      <div className="px-4 py-3" style={{ borderBottom: '1px solid var(--dn-border)' }}>
        <div className="font-semibold tracking-tight" style={{ color: 'var(--dn-text)' }}>DN-Studio</div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--dn-text3)' }}>v1.0 · Colab backend</div>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* Session nav */}
        <div className="p-4">
          <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: 'var(--dn-text3)' }}>Session</div>
          {([
            { stage: 1, label: 'Diarisation',        ready: hasDiarisation, locked: false },
            { stage: 2, label: 'Document generation', ready: hasDocument,    locked: !hasDiarisation },
          ] as const).map(({ stage, label, ready, locked }) => (
            <button key={stage}
              onClick={() => !locked && onStageChange(stage)}
              disabled={locked}
              title={locked ? 'Run diarisation first' : undefined}
              className="w-full text-left px-3 py-2 rounded-lg mb-1.5 flex items-center gap-2.5 transition-all text-sm"
              style={{
                color:      locked ? 'var(--dn-text3)' : currentStage === stage ? 'var(--dn-text)' : 'var(--dn-text2)',
                background: currentStage === stage ? 'var(--dn-surface2)' : 'transparent',
                cursor:     locked ? 'not-allowed' : 'pointer',
              }}>
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                style={{ background: ready ? '#22c55e' : 'var(--dn-border)' }} />
              <span>{label}</span>
            </button>
          ))}
        </div>

        {/* CTA */}
        {hasDiarisation && currentStage === 1 && (
          <div className="px-4 pb-4">
            <button onClick={() => onStageChange(2)}
              className="w-full px-3 py-2 rounded-lg text-xs font-semibold transition"
              style={{ background: 'var(--dn-accent)', color: 'var(--dn-accent-fg)' }}>
              Generate document
            </button>
          </div>
        )}

        {/* State summary */}
        <div className="px-4 pb-4 pt-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
          <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: 'var(--dn-text3)' }}>State</div>
          <div className="mb-4">
            <div className="text-xs mb-1.5" style={{ color: 'var(--dn-text2)' }}>Diarisation JSON</div>
            {hasDiarisation ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">loaded</div>
                <div className="text-[10px] truncate" style={{ color: 'var(--dn-text3)' }} title={diarisationData?.filename}>{diarisationData?.filename}</div>
                <div className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>{diarisationData?.n_utterances} utt | {diarisationData?.n_speakers} spk</div>
              </div>
            ) : (
              <div className="text-[10px] px-2 py-1 rounded border" style={{ color: 'var(--dn-text3)', background: 'var(--dn-bg)', borderColor: 'var(--dn-border)' }}>none yet</div>
            )}
          </div>
          <div>
            <div className="text-xs mb-1.5" style={{ color: 'var(--dn-text2)' }}>Last document</div>
            {hasDocument ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">{documentData?.type} ready</div>
                <div className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>{documentData?.type}_output.docx</div>
              </div>
            ) : (
              <div className="text-[10px] px-2 py-1 rounded border" style={{ color: 'var(--dn-text3)', background: 'var(--dn-bg)', borderColor: 'var(--dn-border)' }}>none yet</div>
            )}
          </div>
        </div>

        {/* API key */}
        <div className="px-4 pb-4 pt-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
          <div className="text-[10px] uppercase tracking-widest mb-2" style={{ color: 'var(--dn-text3)' }}>Gemini API Key</div>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={geminiApiKey}
              onChange={e => onApiKeyChange(e.target.value)}
              placeholder="AIzaSy..."
              aria-label="Gemini API key"
              className="w-full text-xs rounded-lg px-2.5 py-1.5 pr-8 focus:outline-none transition-colors"
              style={{ background: 'var(--dn-bg)', color: 'var(--dn-text)', border: '1px solid var(--dn-border)' }}
            />
            <button onClick={() => setShowKey(v => !v)}
              aria-label={showKey ? 'Hide API key' : 'Show API key'}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs transition"
              style={{ color: 'var(--dn-text3)' }}>
              {showKey ? 'hide' : 'show'}
            </button>
          </div>
          {geminiApiKey && (
            <div className="mt-1.5 flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
              <span className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>key set</span>
            </div>
          )}
        </div>

        {/* ── Theme palette picker — collapsible ── */}
        <div className="px-4 pb-4 pt-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
          <button
            onClick={() => setThemeOpen(v => !v)}
            className="w-full flex items-center justify-between mb-2"
          >
            <div className="text-[10px] uppercase tracking-widest" style={{ color: 'var(--dn-text3)' }}>Theme</div>
            <div className="flex items-center gap-1.5">
              {/* Show active theme swatches when collapsed */}
              {!themeOpen && (() => {
                const active = THEMES_JSON.find(t => t.id === themeId) ?? THEMES_JSON[0];
                return (
                  <div className="flex gap-0.5">
                    {active.swatches.map((c, i) => (
                      <span key={i} className="w-2.5 h-2.5 rounded-sm inline-block"
                        style={{ background: c, border: '1px solid rgba(0,0,0,0.2)' }} />
                    ))}
                  </div>
                );
              })()}
              <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                style={{ color: 'var(--dn-text3)', transform: themeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
                <path d="M2 3.5L5 6.5L8 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </button>

          {themeOpen && (
            <div className="space-y-1">
              {THEMES_JSON.map(t => (
                <button key={t.id}
                  onClick={() => { setThemeId(t.id); setThemeOpen(false); }}
                  className="w-full flex items-center gap-2.5 px-2 py-1.5 rounded-lg transition-all text-left"
                  style={{
                    background: themeId === t.id ? 'var(--dn-surface2)' : 'transparent',
                    border:     themeId === t.id ? '1px solid var(--dn-accent)' : '1px solid transparent',
                  }}>
                  <div className="flex gap-0.5 flex-shrink-0">
                    {t.swatches.map((c, i) => (
                      <span key={i} className="w-3 h-3 rounded-sm inline-block"
                        style={{ background: c, border: '1px solid rgba(0,0,0,0.15)' }} />
                    ))}
                  </div>
                  <span className="text-[11px] font-medium truncate" style={{ color: 'var(--dn-text2)' }}>
                    {t.name}
                  </span>
                  {themeId === t.id && (
                    <span className="ml-auto text-[9px] font-semibold flex-shrink-0" style={{ color: 'var(--dn-accent)' }}>✓</span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="px-4 py-3" style={{ borderTop: '1px solid var(--dn-border)' }}>
        <div className="text-[10px] leading-relaxed" style={{ color: 'var(--dn-text3)' }}>
          Gemini 2.5 Flash<br />
          <span className="inline-flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
            Colab runtime active
          </span>
        </div>
      </div>
    </div>
  );
}
