// FILE: Toast.tsx — floating toast notification system
import React, { useState, useCallback, createContext, useContext } from 'react';

type ToastType = 'success' | 'error' | 'info';
interface Toast { id: number; msg: string; type: ToastType; }

const ToastCtx = createContext<(msg: string, type?: ToastType) => void>(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  let counter = 0;
  const push = useCallback((msg: string, type: ToastType = 'info') => {
    const id = Date.now() + counter++;
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4000);
  }, []);

  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map(t => (
          <div key={t.id}
            className="pointer-events-auto px-4 py-2.5 rounded-xl text-sm font-medium shadow-lg flex items-center gap-2.5 animate-slide-up"
            style={{
              background: t.type === 'success' ? 'var(--dn-surface)' : t.type === 'error' ? '#2d1515' : 'var(--dn-surface)',
              color:      t.type === 'success' ? '#4ade80' : t.type === 'error' ? '#f87171' : 'var(--dn-text)',
              border:     `1px solid ${t.type === 'success' ? '#16a34a44' : t.type === 'error' ? '#ef444444' : 'var(--dn-border)'}`,
            }}>
            <span>{t.type === 'success' ? '✓' : t.type === 'error' ? '✕' : 'ℹ'}</span>
            {t.msg}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
