import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  // Output goes to frontend/dist — FastAPI serves it from there
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
  assetsInclude: ['**/*.svg', '**/*.csv'],
  // Allow Vite to work behind localtunnel proxy
  server: {
    allowedHosts: 'all',
    proxy: {
      '/api': 'http://localhost:8000',
    },
  },
})
