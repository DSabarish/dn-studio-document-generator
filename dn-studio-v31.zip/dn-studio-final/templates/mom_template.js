// ─────────────────────────────────────────────────────────────────────────────
// FILE: templates/mom_template.js
// PURPOSE: Node.js script that reads b_response.json and renders MOM_output.docx
// USAGE:   node templates/mom_template.js <input_json> <output_docx>
// REPLACE THIS FILE with your actual MOM JS template.
// DEPENDENCIES: npm install docx   (run once in Colab)
// NOTE: MOM b_response.json has a different schema to BPD/BRD.
//       It uses flat keys (attendees, action_items, decisions) not a structure tree.
// ─────────────────────────────────────────────────────────────────────────────

const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } = require("docx");
const fs = require("fs");

// ── Args ─────────────────────────────────────────────────────────────────────
const inputPath  = process.argv[2];
const outputPath = process.argv[3];

if (!inputPath || !outputPath) {
    console.error("Usage: node mom_template.js <b_response.json> <output.docx>");
    process.exit(1);
}

// ── Load JSON ────────────────────────────────────────────────────────────────
const data = JSON.parse(fs.readFileSync(inputPath, "utf-8"));
console.log(`[MOM] Loaded : ${inputPath}`);
console.log(`[MOM] Meeting: ${data.meeting_title || "Untitled"}`);

// ── Build document ───────────────────────────────────────────────────────────
const children = [];

// Cover
children.push(
    new Paragraph({
        text: data.meeting_title || "Minutes of Meeting",
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({
        children: [new TextRun({ text: `Date: ${data.date || ""}`, size: 24 })],
        alignment: AlignmentType.CENTER,
    }),
    new Paragraph({ text: "" }),
);

// Attendees
children.push(new Paragraph({ text: "Attendees", heading: HeadingLevel.HEADING_1 }));
for (const a of (data.attendees || [])) {
    children.push(new Paragraph({ text: `• ${a}` }));
}
children.push(new Paragraph({ text: "" }));

// Executive summary
children.push(new Paragraph({ text: "Executive Summary", heading: HeadingLevel.HEADING_1 }));
children.push(new Paragraph({ text: data.executive_summary || "" }));
children.push(new Paragraph({ text: "" }));

// Agenda items
children.push(new Paragraph({ text: "Discussion", heading: HeadingLevel.HEADING_1 }));
for (const item of (data.agenda_items || [])) {
    children.push(new Paragraph({ text: item.topic, heading: HeadingLevel.HEADING_2 }));
    children.push(new Paragraph({ text: item.discussion || "" }));
    if (item.outcome) {
        children.push(new Paragraph({
            children: [
                new TextRun({ text: "Outcome: ", bold: true }),
                new TextRun({ text: item.outcome }),
            ]
        }));
    }
    children.push(new Paragraph({ text: "" }));
}

// Decisions
children.push(new Paragraph({ text: "Decisions", heading: HeadingLevel.HEADING_1 }));
for (const d of (data.decisions || [])) {
    children.push(new Paragraph({ text: `${d.id}: ${d.decision} (Owner: ${d.owner || "TBD"})` }));
}
children.push(new Paragraph({ text: "" }));

// Action items
children.push(new Paragraph({ text: "Action Items", heading: HeadingLevel.HEADING_1 }));
for (const a of (data.action_items || [])) {
    children.push(new Paragraph({
        text: `${a.id}: ${a.action} — ${a.owner || "TBD"} by ${a.due_date || "TBD"}`
    }));
}
children.push(new Paragraph({ text: "" }));

// Open questions
children.push(new Paragraph({ text: "Open Questions", heading: HeadingLevel.HEADING_1 }));
for (const q of (data.open_questions || [])) {
    children.push(new Paragraph({ text: `${q.id}: ${q.question} (Owner: ${q.owner || "TBD"})` }));
}
children.push(new Paragraph({ text: "" }));

// Next steps
children.push(new Paragraph({ text: "Next Steps", heading: HeadingLevel.HEADING_1 }));
children.push(new Paragraph({ text: data.next_steps || "" }));
children.push(new Paragraph({ text: `Next meeting: ${data.next_meeting || "TBD"}` }));

// ── Write docx ───────────────────────────────────────────────────────────────
const doc = new Document({ sections: [{ properties: {}, children }] });

Packer.toBuffer(doc).then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    const kb = (buffer.length / 1024).toFixed(1);
    console.log(`[MOM] DOCX written → ${outputPath}  (${kb} KB)`);
    console.log(`[MOM] Done ✓`);
}).catch((err) => {
    console.error(`[MOM] ERROR: ${err.message}`);
    process.exit(1);
});
