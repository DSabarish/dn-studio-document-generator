"use strict";
/**
 * BRD_template.js — Business Requirements Document .docx generator
 *
 * CLI:  node BRD_template.js <populated-brd.json> <output.docx>
 *       Logs "SUCCESS: <path>" on completion.
 *
 * NUMBERING — computed dynamically from array index:
 *   H1  "1."       primary  #003366
 *   H2  "1.1"      accent   #0070C0
 *   H3  "1.1.1"    dark     #404040
 *
 * SUPPORTED H3 FORMATS:
 *   PARAGRAPH[n]         prose paragraphs
 *   BULLETS[n]           bullet list
 *   NUMBERED[n]          numbered steps
 *   TABLE[n_rows,n_cols] generic table
 *   REQTABLE[n]          ID | Requirement | Priority (colour-coded)
 *   FLOWCHART            process flow box
 *
 * TOC STRATEGY:
 *   docx-js TableOfContents generates invalid XML Word rejects.
 *   We emit a hidden placeholder paragraph then post-process the ZIP in memory:
 *   - Replace placeholder with correct fldChar begin/instrText/separate/end
 *   - Inject TOC1/TOC2/TOC3 styles (black, dot-leaders, indented per level)
 *   - Inject TOCTitle style (non-heading, excluded from TOC index)
 *   - Set updateFields=true so Word auto-builds TOC with real page numbers on open
 *   - \h switch in TOC field creates clickable navigation hyperlinks
 *
 * SPACING RATIONALE:
 *   Word adds style spacing + paragraph inline spacing together.
 *   Heading1 style: before:240 after:80  + inline before:0  after:60  → 14pt before
 *   Heading2 style: before:160 after:60  + inline before:80 after:0   → 17pt before
 *   Heading3 style: before:80  after:40  + inline before:60 after:40  → 10pt before
 *   sp(40) between H3 blocks, sp(60) between H2 groups — minimal rhythm only.
 *   divider after:80 (not 200) — tight gap between rule and first H2.
 */

var fs   = require("fs");
var path = require("path");
var zlib = require("zlib");

/* ─── resolve docx ─────────────────────────────────────────────────────────── */
function requireDocx() {
  var c = [], np = process.env.NODE_PATH || "";
  np.split(path.delimiter).filter(Boolean).forEach(function(p){ c.push(path.join(p,"docx")); });
  var d = path.dirname(path.resolve(__filename));
  c.push(path.join(d,"..","..","scripts","node_modules","docx"));
  c.push(path.join(d,"node_modules","docx")); c.push("docx");
  for (var i=0;i<c.length;i++){ try{ return require(c[i]); }catch(_){} }
  throw new Error("Cannot find 'docx'. Run: npm install -g docx");
}
var docx = requireDocx();
var Document=docx.Document, Packer=docx.Packer, Paragraph=docx.Paragraph, TextRun=docx.TextRun;
var Table=docx.Table, TableRow=docx.TableRow, TableCell=docx.TableCell;
var Header=docx.Header, Footer=docx.Footer, AlignmentType=docx.AlignmentType;
var HeadingLevel=docx.HeadingLevel, BorderStyle=docx.BorderStyle;
var WidthType=docx.WidthType, ShadingType=docx.ShadingType;
var PageNumber=docx.PageNumber, PageBreak=docx.PageBreak, LevelFormat=docx.LevelFormat;
var TabStopType=docx.TabStopType, TabStopPosition=docx.TabStopPosition;

/* ─── CLI ───────────────────────────────────────────────────────────────────── */
var jsonPath=process.argv[2], outputPath=process.argv[3];
if (!jsonPath||!outputPath){ console.error("Usage: node BRD_template.js <brd.json> <output.docx>"); process.exit(1); }
var D = JSON.parse(fs.readFileSync(jsonPath,"utf-8"));

/* ══════════════════════════════════════════════════════════════════════════════
   PALETTE
══════════════════════════════════════════════════════════════════════════════ */
var C = {
  primary:"003366", accent:"0070C0", dark:"404040",
  mid:"666666", border:"CCCCCC", white:"FFFFFF", note:"888888", rowAlt:"F4F8FC",
  p1bg:"DEEAF1", p1txt:"1F3864",
  p2bg:"E2EFDA", p2txt:"375623",
  p3bg:"EDEDED", p3txt:"595959",
};
var FONT="Arial", PW=9360;

/* ══════════════════════════════════════════════════════════════════════════════
   FORMAT PARSER
══════════════════════════════════════════════════════════════════════════════ */
function parseFmt(f){
  if(!f) return {type:"PARAGRAPH",n:1};
  f=String(f).trim().toUpperCase();
  if(f.startsWith("REQTABLE")){ var r=f.match(/REQTABLE\[(\d+)\]/); return {type:"REQTABLE",n:r?+r[1]:4}; }
  if(f.startsWith("TABLE"))   { var t=f.match(/TABLE\[(\d+)[,\s]+(\d+)\]/); return t?{type:"TABLE",rows:+t[1],cols:+t[2]}:{type:"TABLE",rows:3,cols:2}; }
  if(f.startsWith("FLOWCHART")) return {type:"FLOWCHART"};
  var p=f.match(/^(PARAGRAPH|BULLETS|NUMBERED)\[(\d+)\]/);
  return p?{type:p[1],n:+p[2]}:{type:"PARAGRAPH",n:1};
}

/* ══════════════════════════════════════════════════════════════════════════════
   NUMBERING — 40 bullet + 40 decimal refs
══════════════════════════════════════════════════════════════════════════════ */
var numCfg=[];
for(var i=0;i<40;i++) numCfg.push({reference:"b"+i,levels:[{level:0,format:LevelFormat.BULLET,text:"\u2022",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720,hanging:360}}}}]});
for(var i=0;i<40;i++) numCfg.push({reference:"n"+i,levels:[{level:0,format:LevelFormat.DECIMAL,text:"%1.",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720,hanging:360}}}}]});
var bCtr=0, nCtr=0;

/* ══════════════════════════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════════════════════════ */
function bd(col)  { return {style:BorderStyle.SINGLE,size:1,color:col||C.border}; }
function bds(col) { var b=bd(col); return {top:b,bottom:b,left:b,right:b}; }
function sp(n)    { return new Paragraph({spacing:{before:n||40,after:0},children:[new TextRun("")]}); }
function divider(){ return new Paragraph({border:{bottom:{style:BorderStyle.SINGLE,size:12,color:C.accent,space:1}},spacing:{before:0,after:80},children:[new TextRun("")]}); }
function stripNote(s){ return String(s||"").replace(/⚠\s*INFERRED:[^.]+\./g,"").replace(/INFERRED:\s*Validate[^.]+\./g,"").trim(); }
function stripNum(s) { return String(s||"").replace(/^\d+(\.\d+)*\.?\s+/,"").trim(); }
function clean(s)    { return stripNote(String(s||"")); }

/* ══════════════════════════════════════════════════════════════════════════════
   HEADINGS
   Run 1: "1.2 Section Name" or "1.2 Section Name [INFERRED]" — full colour,
          captured verbatim by Word's TOC field → [INFERRED] appears in TOC.
   Run 2: "  [INFERRED]" italic grey badge — visual indicator in body only.
══════════════════════════════════════════════════════════════════════════════ */
function mkH1(num,text,pgBrk){
  var inf=String(text).includes("[INFERRED]");
  var label=num+" "+stripNum(text).replace(/\[INFERRED\]/gi,"").trim();
  var runs=[new TextRun({text:label+(inf?" [INFERRED]":""),bold:true,color:C.primary})];
  return new Paragraph({heading:HeadingLevel.HEADING_1,pageBreakBefore:pgBrk!==false,
    children:runs,spacing:{before:0,after:60}});
}
function mkH2(num,text){
  var inf=String(text).includes("[INFERRED]");
  var label=num+" "+stripNum(text).replace(/\[INFERRED\]/gi,"").trim();
  var runs=[new TextRun({text:label,bold:true,color:C.accent})];
  if(inf) runs.push(new TextRun({text:"   [INFERRED]",italics:true,color:C.note,size:20,font:FONT}));
  return new Paragraph({heading:HeadingLevel.HEADING_2,children:runs,spacing:{before:80,after:0}});
}
function mkH3(num,text){
  var inf=String(text).includes("[INFERRED]");
  var label=num+" "+stripNum(text).replace(/\[INFERRED\]/gi,"").trim();
  var runs=[new TextRun({text:label,bold:true,color:C.dark,size:24,font:FONT})];
  if(inf) runs.push(new TextRun({text:"  [INFERRED]",italics:true,color:C.note,size:20,font:FONT}));
  return new Paragraph({heading:HeadingLevel.HEADING_3,children:runs,spacing:{before:60,after:40}});
}

/* ══════════════════════════════════════════════════════════════════════════════
   BODY
══════════════════════════════════════════════════════════════════════════════ */
function body(t){ return new Paragraph({alignment:AlignmentType.JUSTIFIED,indent:{firstLine:720},children:[new TextRun({text:clean(t),size:22,color:C.dark,font:FONT})],spacing:{before:60,after:60}}); }
function blt(t,ref){ return new Paragraph({numbering:{reference:ref,level:0},alignment:AlignmentType.JUSTIFIED,children:[new TextRun({text:clean(t),size:22,color:C.dark,font:FONT})],spacing:{before:40,after:40}}); }
function num(t,ref){ return new Paragraph({numbering:{reference:ref,level:0},alignment:AlignmentType.JUSTIFIED,children:[new TextRun({text:clean(t),size:22,color:C.dark,font:FONT})],spacing:{before:40,after:40}}); }

/* ══════════════════════════════════════════════════════════════════════════════
   GENERIC TABLE
══════════════════════════════════════════════════════════════════════════════ */
function genericTbl(content,cols){
  var hdrs=(content&&Array.isArray(content.headers))?content.headers.slice():[];
  var rows=(content&&Array.isArray(content.rows))?content.rows:[];
  cols=cols||hdrs.length||2;
  while(hdrs.length<cols) hdrs.push("Col "+(hdrs.length+1));
  hdrs=hdrs.slice(0,cols);
  var cw=Math.floor(PW/cols);
  var ws=Array.from({length:cols},function(_,i){ return i===cols-1?PW-cw*(cols-1):cw; });
  var hrow=new TableRow({children:hdrs.map(function(h,i){
    return new TableCell({borders:bds(),width:{size:ws[i],type:WidthType.DXA},shading:{fill:C.primary,type:ShadingType.CLEAR},margins:{top:100,bottom:100,left:150,right:150},
      children:[new Paragraph({children:[new TextRun({text:String(h||""),bold:true,size:20,color:C.white,font:FONT})]})]});
  })});
  var drows=rows.map(function(row,ri){
    var bg=ri%2===0?"FFFFFF":C.rowAlt;
    return new TableRow({children:ws.map(function(_,ci){
      var v=Array.isArray(row)&&row[ci]!==undefined?String(row[ci]):"\u2014";
      return new TableCell({borders:bds(),width:{size:ws[ci],type:WidthType.DXA},shading:{fill:bg,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:AlignmentType.JUSTIFIED,children:[new TextRun({text:v,size:20,color:C.dark,font:FONT})]})]});
    })});
  });
  return new Table({width:{size:PW,type:WidthType.DXA},columnWidths:ws,rows:[hrow].concat(drows)});
}

/* ══════════════════════════════════════════════════════════════════════════════
   REQUIREMENTS TABLE  ID(1400) | Requirement(6200) | Priority(1760)
══════════════════════════════════════════════════════════════════════════════ */
var RW=[1400,6200,1760];
var PM={P1:{bg:C.p1bg,txt:C.p1txt,lbl:"P1 \u2014 Must Have"},P2:{bg:C.p2bg,txt:C.p2txt,lbl:"P2 \u2014 Should Have"},P3:{bg:C.p3bg,txt:C.p3txt,lbl:"P3 \u2014 Nice to Have"}};
function reqTbl(content){
  var rows=(content&&Array.isArray(content.rows))?content.rows:(Array.isArray(content)?content:[]);
  var hrow=new TableRow({children:["ID","Requirement","Priority"].map(function(h,i){
    return new TableCell({borders:bds(),width:{size:RW[i],type:WidthType.DXA},shading:{fill:C.primary,type:ShadingType.CLEAR},margins:{top:100,bottom:100,left:150,right:150},
      children:[new Paragraph({children:[new TextRun({text:h,bold:true,size:20,color:C.white,font:FONT})]})]});
  })});
  var drows=rows.map(function(row,ri){
    var id=String(Array.isArray(row)?row[0]:row.id||"");
    var req=String(Array.isArray(row)?row[1]:row.requirement||"");
    var prio=String(Array.isArray(row)?row[2]:row.priority||"").trim().toUpperCase();
    var key=(prio.match(/P[123]/)||["P1"])[0];
    var pm=PM[key]||PM.P1, bg=ri%2===0?"FFFFFF":C.rowAlt;
    return new TableRow({children:[
      new TableCell({borders:bds(),width:{size:RW[0],type:WidthType.DXA},shading:{fill:bg,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({children:[new TextRun({text:id,bold:true,size:20,color:C.primary,font:FONT})]})]}),
      new TableCell({borders:bds(),width:{size:RW[1],type:WidthType.DXA},shading:{fill:bg,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:AlignmentType.JUSTIFIED,children:[new TextRun({text:req,size:20,color:C.dark,font:FONT})]})]}),
      new TableCell({borders:bds(),width:{size:RW[2],type:WidthType.DXA},shading:{fill:pm.bg,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:pm.lbl,bold:true,size:18,color:pm.txt,font:FONT})]})]})]});
  });
  return new Table({width:{size:PW,type:WidthType.DXA},columnWidths:RW,rows:[hrow].concat(drows)});
}

/* ══════════════════════════════════════════════════════════════════════════════
   PRIORITY SCALE LEGEND
══════════════════════════════════════════════════════════════════════════════ */
function priorityScale(){
  var defs=[{key:"P1",desc:"Must Have \u2014 blocking requirement; project fails UAT without this."},{key:"P2",desc:"Should Have \u2014 strongly desired; can defer only with stakeholder agreement."},{key:"P3",desc:"Nice to Have \u2014 valuable enhancement for a future phase."}];
  var cw=[1760,PW-1760];
  var hrow=new TableRow({children:["Priority","Definition"].map(function(h,i){
    return new TableCell({borders:bds(),width:{size:cw[i],type:WidthType.DXA},shading:{fill:C.primary,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
      children:[new Paragraph({children:[new TextRun({text:h,bold:true,size:20,color:C.white,font:FONT})]})]});
  })});
  var drows=defs.map(function(d,ri){
    var pm=PM[d.key];
    return new TableRow({children:[
      new TableCell({borders:bds(),width:{size:cw[0],type:WidthType.DXA},shading:{fill:pm.bg,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:pm.lbl,bold:true,size:18,color:pm.txt,font:FONT})]})]}),
      new TableCell({borders:bds(),width:{size:cw[1],type:WidthType.DXA},shading:{fill:ri%2===0?"FFFFFF":C.rowAlt,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:150,right:150},
        children:[new Paragraph({children:[new TextRun({text:d.desc,size:20,color:C.dark,font:FONT})]})]})]});
  });
  return new Table({width:{size:PW,type:WidthType.DXA},columnWidths:cw,rows:[hrow].concat(drows)});
}

/* ══════════════════════════════════════════════════════════════════════════════
   FLOWCHART
══════════════════════════════════════════════════════════════════════════════ */
function flowchart(text){
  var s=String(text||"").replace(/\n/g," \u2192 ");
  while(s.includes("\u2192  \u2192")) s=s.replace(/\u2192\s*\u2192/g,"\u2192");
  var nodes=s.split("\u2192").map(function(x){ return x.trim(); }).filter(Boolean);
  var title=new Table({width:{size:PW,type:WidthType.DXA},columnWidths:[PW],rows:[new TableRow({children:[
    new TableCell({borders:bds(C.accent),width:{size:PW,type:WidthType.DXA},shading:{fill:C.primary,type:ShadingType.CLEAR},margins:{top:80,bottom:80,left:200,right:200},
      children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:"PROCESS FLOW DIAGRAM",bold:true,size:18,color:C.white,font:FONT})]})]})]})]});
  var content=new Table({width:{size:PW,type:WidthType.DXA},columnWidths:[PW],rows:[new TableRow({children:[
    new TableCell({borders:bds(C.accent),width:{size:PW,type:WidthType.DXA},shading:{fill:"F2F8FF",type:ShadingType.CLEAR},margins:{top:160,bottom:160,left:280,right:280},
      children:nodes.map(function(n,i){
        var dec=n.includes("<"),term=n==="START"||n.startsWith("END");
        return new Paragraph({spacing:{before:50,after:50},children:[new TextRun({
          text:(i===0?"":"\u2192  ")+n,size:20,bold:dec||term,
          color:dec?C.accent:(term?C.primary:C.dark),font:"Courier New"})]});
      })})]})]});
  return [title,content];
}

/* ══════════════════════════════════════════════════════════════════════════════
   H3 DISPATCHER
══════════════════════════════════════════════════════════════════════════════ */
function renderH3(node){
  var fmt=parseFmt(node.format), con=node.content, out=[];
  if(fmt.type==="PARAGRAPH"){
    var a=Array.isArray(con)?con:[String(con||"")];
    for(var i=0;i<fmt.n;i++) out.push(body(a[i]||""));
  } else if(fmt.type==="BULLETS"){
    var a=Array.isArray(con)?con:[String(con||"")]; var r="b"+(bCtr++);
    for(var i=0;i<fmt.n;i++) out.push(blt(a[i]||"",r));
  } else if(fmt.type==="NUMBERED"){
    var a=Array.isArray(con)?con:[String(con||"")]; var r="n"+(nCtr++);
    for(var i=0;i<fmt.n;i++) out.push(num(a[i]||"",r));
  } else if(fmt.type==="TABLE"){
    out.push(sp(40)); out.push(genericTbl(con&&typeof con==="object"?con:{headers:[],rows:[]},fmt.cols));
  } else if(fmt.type==="REQTABLE"){
    out.push(sp(40)); out.push(reqTbl(con&&typeof con==="object"?con:{headers:[],rows:[]}));
  } else if(fmt.type==="FLOWCHART"){
    out.push(sp(40)); flowchart(con).forEach(function(b){ out.push(b); });
  } else {
    out.push(body(String(con||"")));
  }
  return out;
}

/* ══════════════════════════════════════════════════════════════════════════════
   COVER PAGE
══════════════════════════════════════════════════════════════════════════════ */
function cover(meta){
  var out=[];
  out.push(new Paragraph({spacing:{before:1800,after:0},children:[new TextRun("")]}));
  out.push(new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:String(meta.title||"BUSINESS REQUIREMENTS DOCUMENT").toUpperCase(),bold:true,size:52,color:C.primary,font:FONT})]}));
  out.push(sp(200));
  out.push(new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({text:meta.subtitle||"",bold:true,size:40,color:C.accent,font:FONT})]}));
  out.push(sp(300));
  out.push(new Paragraph({alignment:AlignmentType.CENTER,border:{bottom:{style:BorderStyle.SINGLE,size:6,color:C.accent,space:1}},children:[new TextRun("")]}));
  out.push(sp(200));
  [["Document Type",meta.document_type||"Business Requirements Document (BRD)"],
   ["Version",meta.version||"v0.1 \u2014 Draft"],
   ["Date",meta.date||new Date().toISOString().slice(0,10)],
   ["Status",meta.status||"Pending Sign-Off"]].forEach(function(p){
    out.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:80,after:80},
      children:[new TextRun({text:p[0]+": ",bold:true,size:22,color:C.mid,font:FONT}),
                new TextRun({text:p[1],size:22,color:C.dark,font:FONT})]}));
  });
  out.push(new Paragraph({children:[new PageBreak()]}));
  return out;
}

/* ══════════════════════════════════════════════════════════════════════════════
   MAIN BUILD
══════════════════════════════════════════════════════════════════════════════ */
function build(data){
  var ch=[], str=data.structure||[];
  cover({document_type:data.document_type,title:"BUSINESS REQUIREMENTS DOCUMENT",
    subtitle:data.title||"",version:data.version,date:data.date,status:data.status
  }).forEach(function(b){ ch.push(b); });

  ch.push(new Paragraph({style:"TOCTitle",
    children:[new TextRun({text:"Table of Contents",bold:true,size:36,color:C.primary,font:FONT})],
    spacing:{before:200,after:120}}));
  ch.push(divider());
  ch.push(new Paragraph({spacing:{before:0,after:0},
    children:[new TextRun({text:"__BRD_TOC__",color:"FFFFFF",size:2})]}));
  ch.push(new Paragraph({children:[new PageBreak()]}));

  str.forEach(function(h1n,h1i){
    var n1=(h1i+1)+".", name=String(h1n.name||"").toLowerCase();
    var isFR=name.includes("functional requirement");
    ch.push(mkH1(n1,h1n.name,true));
    ch.push(divider());
    if(isFR){
      ch.push(sp(40));
      ch.push(new Paragraph({alignment:AlignmentType.LEFT,
        children:[new TextRun({text:"Priority Rating Scale",bold:true,size:22,color:C.dark,font:FONT})],
        spacing:{before:40,after:40}}));
      ch.push(priorityScale());
      ch.push(sp(40));
    }
    (h1n.children||[]).forEach(function(h2n,h2i){
      ch.push(mkH2((h1i+1)+"."+(h2i+1),h2n.name));
      (h2n.children||[]).forEach(function(h3n,h3i){
        ch.push(mkH3((h1i+1)+"."+(h2i+1)+"."+(h3i+1),h3n.name));
        renderH3(h3n).forEach(function(b){ ch.push(b); });
        ch.push(sp(40));
      });
      ch.push(sp(60));
    });
  });
  return ch;
}

/* ══════════════════════════════════════════════════════════════════════════════
   ZIP HELPERS
══════════════════════════════════════════════════════════════════════════════ */
function crc32(buf){
  var t=crc32._t||(function(){var a=new Uint32Array(256);for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?(0xEDB88320^(c>>>1)):(c>>>1);a[n]=c;}return(crc32._t=a);})();
  var c=0xFFFFFFFF;for(var i=0;i<buf.length;i++)c=t[(c^buf[i])&0xFF]^(c>>>8);return(c^0xFFFFFFFF)>>>0;
}
function readZipEntries(buf){
  var entries={},pos=0;
  while(pos<buf.length-4){
    if(buf.readUInt32LE(pos)!==0x04034b50){pos++;continue;}
    var method=buf.readUInt16LE(pos+8),csize=buf.readUInt32LE(pos+18),usize=buf.readUInt32LE(pos+22);
    var fnlen=buf.readUInt16LE(pos+26),exlen=buf.readUInt16LE(pos+28);
    var name=buf.slice(pos+30,pos+30+fnlen).toString("utf8");
    var dstart=pos+30+fnlen+exlen;
    entries[name]={raw:buf.slice(dstart,dstart+csize),method:method,usize:usize};
    pos=dstart+csize;
  }
  return entries;
}
function getEntry(e){ return e.patched||(e.method===0?e.raw:zlib.inflateRawSync(e.raw)); }
function buildZip(entries){
  var parts=[],cdirs=[],offset=0;
  Object.keys(entries).forEach(function(name){
    var data=getEntry(entries[name]);
    var comp=zlib.deflateRawSync(data,{level:6});
    var method,payload;
    if(comp.length>=data.length){method=0;payload=data;}else{method=8;payload=comp;}
    var crc=crc32(data),fn=Buffer.from(name,"utf8");
    var lh=Buffer.alloc(30+fn.length);
    lh.writeUInt32LE(0x04034b50,0);lh.writeUInt16LE(20,4);lh.writeUInt16LE(0,6);
    lh.writeUInt16LE(method,8);lh.writeUInt16LE(0,10);lh.writeUInt16LE(0,12);
    lh.writeUInt32LE(crc,14);lh.writeUInt32LE(payload.length,18);lh.writeUInt32LE(data.length,22);
    lh.writeUInt16LE(fn.length,26);lh.writeUInt16LE(0,28);fn.copy(lh,30);
    var cd=Buffer.alloc(46+fn.length);
    cd.writeUInt32LE(0x02014b50,0);cd.writeUInt16LE(20,4);cd.writeUInt16LE(20,6);
    cd.writeUInt16LE(0,8);cd.writeUInt16LE(method,10);cd.writeUInt16LE(0,12);cd.writeUInt16LE(0,14);
    cd.writeUInt32LE(crc,16);cd.writeUInt32LE(payload.length,20);cd.writeUInt32LE(data.length,24);
    cd.writeUInt16LE(fn.length,28);cd.writeUInt16LE(0,30);cd.writeUInt16LE(0,32);
    cd.writeUInt16LE(0,34);cd.writeUInt16LE(0,36);cd.writeUInt32LE(0,38);cd.writeUInt32LE(offset,42);
    fn.copy(cd,46);
    parts.push(lh,payload);cdirs.push(cd);offset+=lh.length+payload.length;
  });
  var cdBuf=Buffer.concat(cdirs),eocd=Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50,0);eocd.writeUInt16LE(0,4);eocd.writeUInt16LE(0,6);
  eocd.writeUInt16LE(cdirs.length,8);eocd.writeUInt16LE(cdirs.length,10);
  eocd.writeUInt32LE(cdBuf.length,12);eocd.writeUInt32LE(offset,16);eocd.writeUInt16LE(0,20);
  return Buffer.concat(parts.concat([cdBuf,eocd]));
}

/* ══════════════════════════════════════════════════════════════════════════════
   TOC INJECTOR
   Patches word/document.xml, word/styles.xml, word/settings.xml in the ZIP.
   TOC field switches:
     \o "1-3"  index Heading1-3
     \h        clickable hyperlink navigation
     \z        hide tab/page in web layout
     \u        use paragraph outline level
   TOC styles: black #000000, dot-leader tab at 9360 DXA, indented per level.
   TOCTitle:   plain non-heading style, excluded from TOC field index.
   updateFields: Word auto-renders real page numbers on first open.
══════════════════════════════════════════════════════════════════════════════ */
function injectTOC(zipBuf){
  var entries=readZipEntries(zipBuf);

  var docXml=getEntry(entries["word/document.xml"]).toString("utf8");
  var TOC_FIELD=
    '<w:p>'+
      '<w:pPr><w:pStyle w:val="TOC1"/><w:spacing w:before="0" w:after="400"/></w:pPr>'+
      '<w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r>'+
      '<w:r><w:instrText xml:space="preserve"> TOC \\o &quot;1-3&quot; \\h \\z \\u </w:instrText></w:r>'+
      '<w:r><w:fldChar w:fldCharType="separate"/></w:r>'+
      '<w:r><w:t>Table of Contents</w:t></w:r>'+
      '<w:r><w:fldChar w:fldCharType="end"/></w:r>'+
    '</w:p>';
  var re=/<w:p\b(?:(?!<w:p[\s>]).)*?__BRD_TOC__(?:(?!<\/w:p>).)*?<\/w:p>/s;
  if(re.test(docXml)) docXml=docXml.replace(re,TOC_FIELD);
  entries["word/document.xml"].patched=Buffer.from(docXml,"utf8");

  var stylesXml=getEntry(entries["word/styles.xml"]).toString("utf8");
  if(!stylesXml.includes('styleId="TOC1"')){
    var toc=
      '<w:style w:type="paragraph" w:styleId="TOC1">'+
        '<w:name w:val="toc 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/>'+
        '<w:pPr><w:spacing w:before="80" w:after="0"/><w:ind w:left="0" w:right="0"/>'+
          '<w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9360"/></w:tabs></w:pPr>'+
        '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:b/>'+
          '<w:color w:val="000000"/><w:sz w:val="22"/></w:rPr></w:style>'+
      '<w:style w:type="paragraph" w:styleId="TOC2">'+
        '<w:name w:val="toc 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/>'+
        '<w:pPr><w:spacing w:before="40" w:after="0"/><w:ind w:left="360" w:right="0"/>'+
          '<w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9360"/></w:tabs></w:pPr>'+
        '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>'+
          '<w:color w:val="000000"/><w:sz w:val="20"/></w:rPr></w:style>'+
      '<w:style w:type="paragraph" w:styleId="TOC3">'+
        '<w:name w:val="toc 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/>'+
        '<w:pPr><w:spacing w:before="20" w:after="0"/><w:ind w:left="720" w:right="0"/>'+
          '<w:tabs><w:tab w:val="right" w:leader="dot" w:pos="9360"/></w:tabs></w:pPr>'+
        '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>'+
          '<w:color w:val="000000"/><w:sz w:val="20"/></w:rPr></w:style>'+
      '<w:style w:type="paragraph" w:styleId="TOCTitle">'+
        '<w:name w:val="TOC Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/>'+
        '<w:pPr><w:spacing w:before="200" w:after="120"/></w:pPr>'+
        '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/>'+
          '<w:b/><w:color w:val="003366"/><w:sz w:val="36"/></w:rPr></w:style>';
    stylesXml=stylesXml.replace("</w:styles>",toc+"</w:styles>");
    entries["word/styles.xml"].patched=Buffer.from(stylesXml,"utf8");
  }

  var setXml=getEntry(entries["word/settings.xml"]).toString("utf8");
  if(!setXml.includes("updateFields")){
    setXml=setXml.includes("<w:compat>")?
      setXml.replace("<w:compat>",'<w:updateFields w:val="true"/><w:compat>'):
      setXml.replace("</w:settings>",'<w:updateFields w:val="true"/></w:settings>');
    entries["word/settings.xml"].patched=Buffer.from(setXml,"utf8");
  }
  return buildZip(entries);
}

/* ══════════════════════════════════════════════════════════════════════════════
   DOCUMENT
══════════════════════════════════════════════════════════════════════════════ */
var children=build(D);
var proj=D.title||"Business Requirements Document";
var ver=D.version||"v0.1";
var dt=D.date||new Date().toISOString().slice(0,10);

var doc=new Document({
  numbering:{config:numCfg},
  styles:{
    default:{document:{run:{font:FONT,size:22,color:C.dark}}},
    paragraphStyles:[
      {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:36,bold:true,font:FONT,color:C.primary},
        paragraph:{spacing:{before:240,after:80},outlineLevel:0}},
      {id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:28,bold:true,font:FONT,color:C.accent},
        paragraph:{spacing:{before:160,after:60},outlineLevel:1}},
      {id:"Heading3",name:"Heading 3",basedOn:"Normal",next:"Normal",quickFormat:true,
        run:{size:24,bold:true,font:FONT,color:C.dark},
        paragraph:{spacing:{before:80,after:40},outlineLevel:2}},
      {id:"TOCTitle",name:"TOC Title",basedOn:"Normal",next:"Normal",
        run:{size:36,bold:true,font:FONT,color:C.primary},
        paragraph:{spacing:{before:200,after:120}}}
    ]
  },
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1440,right:1440,bottom:1440,left:1440}}},
    headers:{default:new Header({children:[new Paragraph({
      children:[new TextRun({text:"CONFIDENTIAL DRAFT  |  "+proj,size:16,color:C.mid,font:FONT}),
                new TextRun({text:"\t",size:16}),
                new TextRun({children:["Page ",PageNumber.CURRENT," of ",PageNumber.TOTAL_PAGES],size:16,color:C.mid,font:FONT})],
      tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
      border:{bottom:{style:BorderStyle.SINGLE,size:4,color:C.accent,space:4}}})]})},
    footers:{default:new Footer({children:[new Paragraph({
      children:[new TextRun({text:ver+"  |  "+dt+"  |  Business Requirements Document",size:16,color:C.mid,font:FONT})],
      border:{top:{style:BorderStyle.SINGLE,size:4,color:C.accent,space:4}}})]})},
    children:children
  }]
});

Packer.toBuffer(doc).then(function(rawBuf){
  var finalBuf=injectTOC(rawBuf);
  fs.writeFileSync(outputPath,finalBuf);
  console.log("SUCCESS: "+outputPath);
}).catch(function(err){ console.error("ERROR:",err.message); process.exit(1); });
