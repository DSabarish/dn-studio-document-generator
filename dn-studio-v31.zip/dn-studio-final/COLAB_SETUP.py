# ═══════════════════════════════════════════════════════════════════
# DN-STUDIO — SINGLE CELL COLAB SETUP
# HOW TO USE:
#   1. Upload dn-studio-final.zip via Colab Files panel (left sidebar)
#   2. Run in a Colab cell:
#        import zipfile
#        with zipfile.ZipFile('dn-studio-final.zip') as z:
#            z.extract('COLAB_SETUP.py', '/content/')
#        exec(open('/content/COLAB_SETUP.py').read())
# ═══════════════════════════════════════════════════════════════════

import subprocess, zipfile, os, time, threading, urllib.request, glob, sys

def run(cmd, cwd=None, check=True):
    """Run shell command. Print output only on failure."""
    result = subprocess.run(
        cmd, shell=True, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
    )
    if check and result.returncode != 0:
        print(f"\n❌ Command failed (exit {result.returncode}): {cmd}")
        print("─" * 50)
        print(result.stdout[-3000:])
        print("─" * 50)
        raise RuntimeError(f"Command failed: {cmd}")
    return result

# ── Step 1: Find the uploaded zip ───────────────────────────────
print("🔍 [1/7] Locating uploaded zip file...")
search_paths = (
    glob.glob("/content/dn-studio-final.zip") +
    glob.glob("/content/*.zip") +
    glob.glob("/root/*.zip")
)
if not search_paths:
    raise FileNotFoundError(
        "❌ Cannot find dn-studio-final.zip.\n"
        "   Upload it via Colab Files panel (left sidebar → upload icon) then re-run."
    )
zip_path = search_paths[0]
print(f"✅ Found: {zip_path}")

# ── Step 2: Extract ─────────────────────────────────────────────
print("\n📂 [2/7] Extracting project...")
extract_to = "/content/dn-studio"
os.makedirs(extract_to, exist_ok=True)
with zipfile.ZipFile(zip_path, "r") as z:
    z.extractall(extract_to)
os.chdir(extract_to)
print(f"✅ Extracted to {extract_to}")
print(f"   Contents: {', '.join(sorted(os.listdir('.')))}")
for required in ["backend/server.py", "requirements.txt", "frontend/package.json"]:
    if not os.path.exists(required):
        raise FileNotFoundError(f"❌ Missing after extraction: {required}")
print("✅ All required files present")

# ── Step 3: System deps ─────────────────────────────────────────
print("\n📦 [3/7] Installing system dependencies...")
run("apt-get install -y ffmpeg -qq")
node_ver = subprocess.run("node --version", shell=True,
                          capture_output=True, text=True).stdout.strip()
major = int(node_ver.lstrip("v").split(".")[0]) if node_ver.startswith("v") else 0
if major < 18:
    print(f"   Node {node_ver} too old — upgrading to Node 20...")
    run("curl -fsSL https://deb.nodesource.com/setup_20.x -o /tmp/ns.sh")
    run("bash /tmp/ns.sh")
    run("apt-get install -y nodejs")
    node_ver = subprocess.run("node --version", shell=True,
                              capture_output=True, text=True).stdout.strip()
print(f"✅ System deps ready  (Node {node_ver})")

# ── Step 4: Python + Node backend deps ─────────────────────────
print("\n🐍 [4/7] Installing Python + Node dependencies...")
run("pip install -r requirements.txt -q", cwd=extract_to)
run("npm install docx", cwd=extract_to)
print("✅ All dependencies installed")

# ── Step 5: Build React frontend ────────────────────────────────
print("\n⚛️  [5/7] Building React frontend...")
frontend_dir = os.path.join(extract_to, "frontend")
print("   npm install (1-2 min)...")
run("npm install --legacy-peer-deps", cwd=frontend_dir)
print("   npm run build...")
run("npm run build", cwd=frontend_dir)
if not os.path.exists(os.path.join(frontend_dir, "dist")):
    raise RuntimeError("❌ dist/ folder not found after build.")
print("✅ Frontend built")

# ── Step 6: Start FastAPI (non-blocking) ────────────────────────
print("\n🚀 [6/7] Starting FastAPI backend on port 8000...")
log_path = os.path.join(extract_to, "uvicorn.log")
server_proc = subprocess.Popen(
    [sys.executable, "-m", "uvicorn", "backend.server:app",
     "--host", "0.0.0.0", "--port", "8000"],
    stdout=open(log_path, "w"),
    stderr=subprocess.STDOUT,
    cwd=extract_to,
)
print("   Waiting for server", end="")
for _ in range(15):
    time.sleep(1)
    print(".", end="", flush=True)
    try:
        r = urllib.request.urlopen("http://localhost:8000/health", timeout=3)
        print(f"\n✅ Backend ready — {r.read().decode()}")
        break
    except Exception:
        pass
else:
    print("\n❌ Backend did not start. Log:")
    print(open(log_path).read())
    raise RuntimeError("FastAPI failed to start.")

# ── Step 7: Localtunnel public URL (non-blocking) ───────────────
print("\n🌐 [7/7] Setting up public URL via localtunnel...")
run("npm install -g localtunnel")

try:
    ip = urllib.request.urlopen(
        "https://api.ipify.org", timeout=5
    ).read().decode().strip()
except Exception:
    ip = "run:  !curl ifconfig.me"

tunnel_lines = []

def _tunnel():
    proc = subprocess.Popen(
        ["lt", "--port", "8000"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, cwd=extract_to,
    )
    for line in proc.stdout:
        line = line.strip()
        if line:
            print(f"   🔗 {line}")
            tunnel_lines.append(line)

threading.Thread(target=_tunnel, daemon=True).start()
time.sleep(5)

# ── Done ────────────────────────────────────────────────────────
tunnel_url = next((l for l in tunnel_lines if "loca.lt" in l), "see 🔗 line above")

print("\n" + "═" * 62)
print("  ✅  DN-STUDIO IS RUNNING")
print("═" * 62)
print(f"  App URL         →  {tunnel_url}")
print(f"  Tunnel password →  {ip}")
print(f"  Server logs     →  {log_path}")
print("═" * 62)
print()
print("  HOW TO OPEN:")
print(f"  1. Go to: {tunnel_url}")
print(f"  2. When asked for password, enter: {ip}")
print()
print("  NOTE: API calls use relative URLs — no CORS issues.")
print("        The frontend and backend are on the same tunnel host.")
print()
print("  To stop server :  server_proc.terminate()")
print("  To check logs  :  !tail -40 uvicorn.log")
