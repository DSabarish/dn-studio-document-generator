// FILE: frontend/src/app/components/Stage1.tsx

import { useState, useRef, useEffect } from 'react';
import { Upload, ChevronDown } from 'lucide-react';
import { useToast } from './Toast';
import {
  startDiarisation,
  streamDiarisation,
  uploadDiarisationJson,
  getDiarisationJsonUrl,
  type DiarisationResult,
  type Segment,
} from '../api';

interface Stage1Props {
  onDiarisationComplete: (data: DiarisationResult, elapsedSec: number) => void;
  onClearSession: () => void;
  existingResult?: DiarisationResult | null;
}

const PIPELINE_STEPS = [
  { pct: 5,   label: 'Converting audio to WAV' },
  { pct: 15,  label: 'Loading transcription model' },
  { pct: 20,  label: 'Transcribing speech' },
  { pct: 50,  label: 'Extracting speaker embeddings' },
  { pct: 70,  label: 'Running speaker clustering' },
  { pct: 90,  label: 'Writing transcription data' },
  { pct: 100, label: 'Complete' },
];

// Prepend uploading step so it shows in the checklist during upload phase
const ALL_STEPS = [
  { pct: -1,  label: 'Uploading audio file' },
  ...PIPELINE_STEPS,
];

const SPK_COLORS = ['#8b5cf6','#10b981','#f97316','#eab308','#3b82f6','#ec4899','#06b6d4','#84cc16'];

type ProcessPhase = 'idle' | 'uploading' | 'processing' | 'done';

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}
function fmtDur(sec: number): string {
  const n = Math.max(0, sec);
  if (n >= 60) return Math.floor(n / 60) + 'm ' + String(Math.round(n % 60)).padStart(2,'0') + 's';
  return Math.round(n) + 's';
}
function confColor(c: number): string {
  if (c >= 0.85) return '#22c55e';
  if (c >= 0.65) return '#f59e0b';
  return '#ef4444';
}

export function Stage1({ onDiarisationComplete, onClearSession, existingResult }: Stage1Props) {
  const toast = useToast();

  // ── Processing state ──────────────────────────────────────────────────────
  const [isDragging,    setIsDragging]    = useState(false);
  const [phase,         setPhase]         = useState<ProcessPhase>('idle');
  const [uploadPct,     setUploadPct]     = useState(0);
  const [pipelinePct,   setPipelinePct]   = useState(0);
  const [uploadStatus,  setUploadStatus]  = useState('');
  const [logLines,      setLogLines]      = useState<string[]>([]);
  const [error,         setError]         = useState('');
  const [processingSec, setProcessingSec] = useState(0);

  // ── Config state ──────────────────────────────────────────────────────────
  const [whisperModel,   setWhisperModel]   = useState('base.en');
  const [speakerCount,   setSpeakerCount]   = useState('2');
  const [removeFillers,  setRemoveFillers]  = useState(true);
  const [removeStutters, setRemoveStutters] = useState(true);
  const [language,       setLanguage]       = useState('en');
  const [llmModel,       setLlmModel]       = useState('gemini-2.5-flash');
  const [llmTemp,        setLlmTemp]        = useState('0.2');
  const [maxTokens,      setMaxTokens]      = useState('20000');
  const [activePreset,   setActivePreset]   = useState<string|null>('balanced');

  // ── Output / audio state ──────────────────────────────────────────────────
  const [isPlaying,   setIsPlaying]   = useState(false);
  const [audioSrc,    setAudioSrc]    = useState<string | null>(null);
  const [audioDur,    setAudioDur]    = useState(0);
  const [audioTime,   setAudioTime]   = useState(0);
  const [activeUttId, setActiveUttId] = useState<number | null>(null);
  const audioFileRef  = useRef<File | null>(null);

  // ── Speaker renaming ──────────────────────────────────────────────────────
  const [nameMap,     setNameMap]     = useState<Record<string, string>>({});
  const [editingSp,   setEditingSp]   = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  // ── Refs ──────────────────────────────────────────────────────────────────
  const audioRef     = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const jsonInputRef = useRef<HTMLInputElement>(null);
  const stopStream   = useRef<(() => void) | null>(null);
  const logEndRef    = useRef<HTMLDivElement>(null);
  const uttRefs      = useRef<Record<number, HTMLDivElement | null>>({});
  const timerRef     = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef     = useRef<number>(0);
  const audioTimeRef   = useRef(0);
  const activeUttIdRef = useRef<number | null>(null);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logLines]);

  useEffect(() => () => {
    stopStream.current?.();
    clearInterval(timerRef.current!);
    if (audioSrc) URL.revokeObjectURL(audioSrc);
  }, []);

  useEffect(() => {
    if (editingSp) setTimeout(() => editInputRef.current?.select(), 30);
  }, [editingSp]);

  useEffect(() => {
    uttRefs.current = {};
    if (!existingResult) { setNameMap({}); return; }
    const speakers = [...new Set(existingResult.segments.map(s => s.speaker_id))].sort();
    setNameMap(prev => {
      const next: Record<string, string> = {};
      speakers.forEach(sp => { next[sp] = prev[sp] || sp; });
      return next;
    });
  }, [existingResult]);

  useEffect(() => {
    audioTimeRef.current = audioTime;
    if (!existingResult) return;
    const seg = existingResult.segments.find(s => audioTime >= s.start && audioTime < s.end);
    const id  = seg?.utterance_id ?? null;
    if (id !== activeUttIdRef.current) {
      activeUttIdRef.current = id;
      setActiveUttId(id);
      if (id !== null && uttRefs.current[id]) {
        uttRefs.current[id]?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [audioTime, existingResult]);

  // ── Derived data ──────────────────────────────────────────────────────────
  const res      = existingResult;
  const speakers = res ? [...new Set(res.segments.map(s => s.speaker_id))].sort() : [];
  const colorMap: Record<string, string> = {};
  speakers.forEach((sp, i) => { colorMap[sp] = SPK_COLORS[i % SPK_COLORS.length]; });
  const totalDur = res ? Math.max(...res.segments.map(s => s.end), 1) : 1;
  const talkTime: Record<string, number> = {};
  if (res) speakers.forEach(sp => {
    talkTime[sp] = res.segments.filter(s => s.speaker_id === sp)
      .reduce((a, s) => a + (s.end - s.start), 0);
  });
  const wordCount = res
    ? res.segments.reduce((a, s) => a + s.text.trim().split(/\s+/).filter(Boolean).length, 0)
    : 0;
  const avgConf = res && res.segments.length > 0
    ? Math.round(res.segments.reduce((a, s) => a + s.confidence, 0) / res.segments.length * 100)
    : 0;
  const durStr = res ? fmtDur(res.duration_sec) : '';

  // ── Step status — unified across upload + pipeline ────────────────────────
  // ALL_STEPS[0] = "Uploading audio file" (pct: -1)
  // ALL_STEPS[1..] = pipeline steps
  function allStepStatus(step: typeof ALL_STEPS[0], idx: number): 'done' | 'active' | 'pending' {
    if (step.pct === -1) {
      // Upload step
      if (phase === 'processing' || phase === 'done') return 'done';
      if (phase === 'uploading') return 'active';
      return 'pending';
    }
    // Pipeline steps
    if (phase === 'uploading') return 'pending';
    if (phase !== 'processing' && phase !== 'done') return 'pending';
    const prevPct = idx === 1 ? 0 : ALL_STEPS[idx - 1].pct;
    if (pipelinePct >= step.pct) return 'done';
    if (pipelinePct >= prevPct)  return 'active';
    return 'pending';
  }

  // ── Speaker rename handlers ───────────────────────────────────────────────
  function startEdit(sp: string) { setEditingSp(sp); setEditingName(nameMap[sp] || sp); }
  function commitEdit() {
    if (!editingSp) return;
    const t = editingName.trim();
    if (t) setNameMap(prev => ({ ...prev, [editingSp]: t }));
    setEditingSp(null);
  }
  function cancelEdit() { setEditingSp(null); }
  function handleEditKey(e: React.KeyboardEvent) {
    if (e.key === 'Enter')  { e.preventDefault(); commitEdit(); }
    if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
  }
  function displayName(spId: string) { return nameMap[spId] || spId; }
  function buildRenamedJson() {
    if (!res) return '[]';
    return JSON.stringify(res.segments.map(s => ({ ...s, speaker_name: displayName(s.speaker_id) })), null, 2);
  }
  const hasRenames = res && speakers.some(sp => nameMap[sp] && nameMap[sp] !== sp);

  // ── Audio handlers ────────────────────────────────────────────────────────
  function togglePlay() {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
  }
  function seekTo(sec: number) {
    if (audioRef.current) {
      audioRef.current.currentTime = sec;
      audioRef.current.play().catch(() => {});
    }
  }
  function handleLaneSegClick(e: React.MouseEvent, seg: Segment) { e.stopPropagation(); seekTo(seg.start); }
  function handleLaneBarClick(e: React.MouseEvent<HTMLDivElement>) {
    if (!res) return;
    const rect = e.currentTarget.getBoundingClientRect();
    seekTo((e.clientX - rect.left) / rect.width * totalDur);
  }
  const playheadPct = audioDur > 0 ? (audioTime / audioDur) * 100 : 0;

  // ── Pipeline handlers ─────────────────────────────────────────────────────
  async function doAudio(file: File) {
    audioFileRef.current = file;
    setPhase('uploading');
    setError('');
    setUploadPct(0);
    setPipelinePct(0);
    setLogLines([]);
    setProcessingSec(0);
    setUploadStatus('Uploading ' + file.name + ' (' + (file.size / 1024 / 1024).toFixed(1) + ' MB)');
    startRef.current = Date.now();

    try {
      const n     = speakerCount === 'auto' ? null : parseInt(speakerCount);
      const jobId = await startDiarisation(
        file,
        { whisperModel, numSpeakers: n, removeFillers, removeStutters },
        (loaded, total) => {
          const pct = Math.round((loaded / total) * 100);
          setUploadPct(pct);
          setUploadStatus(
            'Uploading ' + (loaded / 1024 / 1024).toFixed(1) +
            ' / ' + (total / 1024 / 1024).toFixed(1) + ' MB  (' + pct + '%)'
          );
        }
      );

      setPhase('processing');
      timerRef.current = setInterval(() => {
        setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      }, 1000);

      stopStream.current = streamDiarisation(
        jobId,
        (p) => {
          if (p.pct != null && p.pct >= 0) setPipelinePct(p.pct);
          if (p.log) setLogLines(prev => [...prev, p.log!]);
        },
        (result) => {
          clearInterval(timerRef.current!);
          setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
          if (result.status === 'error') {
            setError((result as any).error || 'Diarisation failed');
            setPhase('idle');
          } else {
            setPhase('done');
            setPipelinePct(100);
            if (audioFileRef.current) {
              const newUrl = URL.createObjectURL(audioFileRef.current);
              setAudioSrc(prev => { if (prev) URL.revokeObjectURL(prev); return newUrl; });
              setAudioTime(0);
            }
            toast('Diarisation complete — transcription ready', 'success');
            onDiarisationComplete(result as DiarisationResult, Math.round((Date.now() - startRef.current) / 1000));
          }
        },
        (err) => { clearInterval(timerRef.current!); setError(err); setPhase('idle'); }
      );
    } catch (e: any) {
      clearInterval(timerRef.current!);
      setPhase('idle');
      setError(e.message || 'Failed to start diarisation');
    }
  }

  async function doJson(file: File) {
    setPhase('uploading');
    setError('');
    setUploadStatus('Uploading JSON...');
    setProcessingSec(0);
    startRef.current = Date.now();
    try {
      const r = await uploadDiarisationJson(file);
      setProcessingSec(Math.round((Date.now() - startRef.current) / 1000));
      setPhase('done');
      onDiarisationComplete(r, Math.round((Date.now() - startRef.current) / 1000));
    } catch (e: any) { setError(e.message || 'Upload failed'); setPhase('idle'); }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) f.name.endsWith('.json') ? doJson(f) : doAudio(f);
  }

  const isProcessing = phase === 'uploading' || phase === 'processing';

  // ── Keyboard shortcuts ────────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Space = play/pause (only when result is available and not typing)
      if (e.code === 'Space' && res && audioRef.current &&
          !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        e.preventDefault();
        togglePlay();
      }
    };
    // Escape = cancel upload
    const escHandler = () => {
      if (isProcessing) {
        stopStream.current?.();
        clearInterval(timerRef.current!);
        setPhase('idle');
        setError('');
        toast('Upload cancelled', 'info');
      }
    };
    window.addEventListener('keydown', handler);
    window.addEventListener('dn-escape', escHandler);
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('dn-escape', escHandler);
    };
  }, [res, isPlaying, isProcessing]);

  const isProcessingCheck = phase === 'uploading' || phase === 'processing'; // alias for pipeline handlers
  return (
    <div className="flex-1 overflow-auto" style={{ background: 'var(--dn-bg, #111)', color: 'var(--dn-text, #fff)' }}>
      <div className="p-8">

        {/* Title */}
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl font-bold">Diarisation</h1>
          <div className="flex gap-3">
            {res && (
              <span className="px-5 py-2 bg-white text-black rounded-full text-sm font-semibold">
                Transcription ready
              </span>
            )}
            <button onClick={onClearSession}
              className="px-5 py-2 rounded-full transition text-sm" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)" }}>
              Clear session
            </button>
          </div>
        </div>
        <p className="dn-text2 text-sm mb-6">Run once — reuse the transcription for every document</p>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700/60 rounded-lg text-red-400 text-sm">{error}</div>
        )}

        {/* Input + Config grid */}
        <div className="grid grid-cols-2 gap-6 mb-6">

          {/* Input card */}
          <div className="rounded-xl p-6" style={{ background: "var(--dn-surface)", border: "1px solid var(--dn-border)" }}>
            <h3 className="font-semibold mb-1">Input</h3>
            <p className="dn-text2 text-xs mb-4">Upload audio/video — or skip if you already have a JSON</p>

            {/* Drop zone — grows naturally with content, no height clipping */}
            <div
              onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={onDrop}
              onClick={() => !isProcessing && fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-5 text-center transition-all duration-200 mb-4 ${
                isProcessing ? 'cursor-default border-[#444]' :
                isDragging   ? 'cursor-pointer border-white bg-white/5' :
                               'cursor-pointer border-[#444] hover:border-[#666]'
              }`}
              style={{ overflow: 'visible' }}
            >
              {isProcessing ? (
                <div className="space-y-3">
                  {/* Progress bar + status */}
                  {phase === 'uploading' && (
                    <>
                      <div className="w-full dn-surface2 rounded-full h-2 overflow-hidden">
                        <div className="h-2 rounded-full bg-blue-500 transition-all duration-300"
                          style={{ width: uploadPct + '%' }} />
                      </div>
                      <div className="dn-text2 text-xs font-mono">{uploadStatus}</div>
                    </>
                  )}
                  {phase === 'processing' && (
                    <>
                      {/* Active step pill */}
                      {(() => {
                        const activeStep = PIPELINE_STEPS.find((s, idx) => {
                          const prev = idx === 0 ? 0 : PIPELINE_STEPS[idx - 1].pct;
                          return pipelinePct < s.pct && pipelinePct >= prev;
                        });
                        return activeStep ? (
                          <div className="inline-flex items-center gap-1.5 bg-purple-900/40 border border-purple-700/50 rounded-full px-2.5 py-0.5 text-xs text-purple-300 font-medium">
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse inline-block" />
                            {activeStep.label}
                          </div>
                        ) : null;
                      })()}
                      <div className="w-full dn-surface2 rounded-full h-2 overflow-hidden">
                        <div className="h-2 rounded-full transition-all duration-500"
                          style={{ width: pipelinePct + '%', background: 'linear-gradient(90deg,#6366f1,#8b5cf6)' }} />
                      </div>
                      <div className="dn-text2 text-xs font-mono">{pipelinePct}% — {fmtDur(processingSec)} elapsed</div>
                    </>
                  )}

                  {/* Unified step checklist — upload + pipeline steps together */}
                  <div className="space-y-0.5 text-left mt-3 w-full">
                    {ALL_STEPS.map((s, idx) => {
                      const st = allStepStatus(s, idx);
                      return (
                        <div key={idx} className={`flex items-center gap-2 text-xs transition-colors ${
                          st === 'done'   ? 'text-green-400' :
                          st === 'active' ? 'text-purple-300 font-semibold' :
                                           'dn-text3'
                        }`}>
                          <span className="w-3 text-center flex-shrink-0">
                            {st === 'done' ? '+' : st === 'active' ? '›' : '.'}
                          </span>
                          <span>{s.label}</span>
                          {st === 'active' && s.pct === -1 && (
                            <span className="text-[9px] bg-blue-900/50 border border-blue-700/40 text-blue-400 px-1.5 rounded-full">
                              {uploadPct}%
                            </span>
                          )}
                          {st === 'active' && s.pct !== -1 && (
                            <span className="text-[9px] bg-purple-900/50 border border-purple-700/40 text-purple-400 px-1.5 rounded-full">
                              in progress
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <>
                  <Upload className={`mx-auto mb-3 ${isDragging ? 'dn-text' : 'dn-text3'}`} size={32} />
                  <div className="font-medium mb-1">Drop audio / video here</div>
                  <div className="dn-text3 text-xs">mp3, mp4, m4a, wav, mkv — any format</div>
                </>
              )}
            </div>

            <input ref={fileInputRef} type="file"
              accept="audio/*,video/*,.mp3,.mp4,.m4a,.wav,.mkv,.ogg,.flac,.webm"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doAudio(f); e.target.value = ''; }} />

            <div className="text-center dn-text3 text-xs my-3">or</div>

            <button onClick={() => jsonInputRef.current?.click()} disabled={isProcessing}
              className="w-full px-4 py-3 rounded-lg transition text-sm font-medium disabled:opacity-50" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)" }}>
              Upload existing diarization_response.json
            </button>
            <input ref={jsonInputRef} type="file" accept=".json" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) doJson(f); e.target.value = ''; }} />
          </div>

          {/* Config card — 2-column layout */}
          <div className="rounded-xl p-6 border" style={{ background: 'var(--dn-surface)', borderColor: 'var(--dn-border)' }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-semibold mb-0.5">Pipeline config</h3>
                <p className="text-xs" style={{ color: 'var(--dn-text2)' }}>Adjust before running</p>
              </div>
              {/* Preset selector — plain text, smaller, more breathing room */}
              <div className="flex items-center gap-0.5 rounded-lg p-1 mr-1"
                style={{ background: 'var(--dn-bg)', border: '1px solid var(--dn-border)' }}>
                {[
                  { id: 'fast',     label: 'Fast',     model: 'tiny.en',   spk: '2' },
                  { id: 'balanced', label: 'Balanced', model: 'base.en',   spk: '2' },
                  { id: 'accurate', label: 'Accurate', model: 'medium.en', spk: '2' },
                ].map(p => (
                  <button key={p.id}
                    onClick={() => { setWhisperModel(p.model); setSpeakerCount(p.spk); setActivePreset(p.id); }}
                    className="px-2 py-0.5 rounded-md text-[10px] font-medium transition-all"
                    style={{
                      background: activePreset === p.id ? 'var(--dn-surface2)' : 'transparent',
                      color:      activePreset === p.id ? 'var(--dn-text)' : 'var(--dn-text3)',
                    }}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              {/* ── LEFT: Diarisation — plain text header */}
              <div className="space-y-4">
                <div className="text-[10px] uppercase tracking-widest pb-1" style={{ color: "var(--dn-text3)", borderBottom: "1px solid var(--dn-border)" }}>
                  Diarisation
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">Diarisation model</label>
                  <div className="relative">
                    <select value={whisperModel} onChange={e => { setWhisperModel(e.target.value); setActivePreset(null); }}
                      className="w-full rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}>
                      <option value="tiny.en">tiny.en — fastest</option>
                      <option value="base.en">base.en — balanced</option>
                      <option value="small.en">small.en — better</option>
                      <option value="medium.en">medium.en — most accurate</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 dn-text3 pointer-events-none" size={16} />
                  </div>
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">Language</label>
                  <div className="relative">
                    <select value={language} onChange={e => setLanguage(e.target.value)}
                      className="w-full rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}>
                      <option value="en">English</option>
                      <option value="auto">Auto-detect</option>
                      <option value="hi">Hindi</option>
                      <option value="fr">French</option>
                      <option value="de">German</option>
                      <option value="es">Spanish</option>
                      <option value="ar">Arabic</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 dn-text3 pointer-events-none" size={16} />
                  </div>
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">Speaker count</label>
                  <div className="relative">
                    <select value={speakerCount} onChange={e => { setSpeakerCount(e.target.value); setActivePreset(null); }}
                      className="w-full rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}>
                      {[2,3,4,5,6,7,8].map(n => <option key={n} value={String(n)}>{n} speakers</option>)}
                      <option value="auto">Auto-detect — slow, less accurate</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 dn-text3 pointer-events-none" size={16} />
                  </div>
                </div>
                <div className="space-y-2.5 pt-1">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={removeFillers} onChange={e => setRemoveFillers(e.target.checked)} className="w-4 h-4 accent-white" />
                    <span className="text-sm">Remove fillers</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={removeStutters} onChange={e => setRemoveStutters(e.target.checked)} className="w-4 h-4 accent-white" />
                    <span className="text-sm">Remove stutters</span>
                  </label>
                </div>
              </div>

              {/* ── RIGHT: AI / LLM — plain text header */}
              <div className="space-y-4">
                <div className="text-[10px] uppercase tracking-widest pb-1" style={{ color: "var(--dn-text3)", borderBottom: "1px solid var(--dn-border)" }}>
                  AI / LLM
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">LLM model</label>
                  <div className="relative">
                    <select value={llmModel} onChange={e => setLlmModel(e.target.value)}
                      className="w-full rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}>
                      <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                      <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                      <option value="gemini-2.0-flash">Gemini 2.0 Flash</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 dn-text3 pointer-events-none" size={16} />
                  </div>
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">Temperature</label>
                  <div className="relative">
                    <select value={llmTemp} onChange={e => setLlmTemp(e.target.value)}
                      className="w-full rounded-lg px-3 py-2.5 text-sm appearance-none pr-8 focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}>
                      <option value="0">0 — deterministic</option>
                      <option value="0.2">0.2 — default</option>
                      <option value="0.5">0.5 — creative</option>
                      <option value="1.0">1.0 — max variety</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 dn-text3 pointer-events-none" size={16} />
                  </div>
                </div>
                <div>
                  <label className="dn-text2 text-xs block mb-2">Max output tokens</label>
                  <input
                    type="number"
                    value={maxTokens}
                    onChange={e => setMaxTokens(e.target.value)}
                    min="1000"
                    step="1000"
                    className="w-full rounded-lg px-3 py-2.5 text-sm focus:outline-none" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)", border: "1px solid var(--dn-border)" }}
                  />
                  <div className="dn-text3 text-[10px] mt-1">tokens per generation call</div>
                </div>
                {/* Live cost indicator */}
                <div className="dn-bg rounded-lg px-3 py-2.5 border dn-border border flex items-center justify-between">
                  <span className="dn-text3 text-xs">Est. cost / document</span>
                  <span className="text-[#a78bfa] text-xs font-mono font-semibold">
                    {llmModel === 'gemini-2.5-pro' ? '~$0.12' : llmModel === 'gemini-2.0-flash' ? '~$0.02' : '~$0.04'}
                  </span>
                </div>
              </div>
            </div>

            {/* Run button */}
            <button onClick={() => fileInputRef.current?.click()} disabled={isProcessing}
              className="w-full mt-6 px-4 py-3 bg-white text-black rounded-lg hover:bg-gray-200 transition font-semibold disabled:opacity-50 disabled:cursor-not-allowed">
              {phase === 'uploading'  ? 'Uploading ' + uploadPct + '%' :
               phase === 'processing' ? 'Processing ' + pipelinePct + '%' :
               'Run diarisation'}
            </button>
          </div>
        </div>

        {/* ── OUTPUT SECTION ─────────────────────────────────────────────── */}
        {res && (
          <div className="rounded-xl overflow-hidden w-full" style={{ background: "var(--dn-surface)", border: "1px solid var(--dn-border)" }}>

            {/* Stats row — sticky */}
            <div className="grid grid-cols-5 border-b sticky top-0 z-10"
              style={{ borderColor: 'var(--dn-border)', background: 'var(--dn-surface)' }}>
              {[
                { label: 'Utterances', value: String(res.n_utterances) },
                { label: 'Duration',   value: durStr },
                { label: 'Words',      value: wordCount.toLocaleString() },
                { label: 'Processed',  value: processingSec > 0 ? fmtDur(processingSec) : '-' },
                { label: 'Confidence', value: avgConf + '%' },
              ].map(({ label, value }, i) => (
                <div key={label} className={`p-4 text-center ${i < 4 ? 'border-r dn-border border' : ''}`}>
                  <div className="dn-text3 text-[10px] uppercase tracking-wider mb-1">{label}</div>
                  <div className={`text-xl font-bold ${
                    label === 'Confidence'
                      ? avgConf >= 85 ? 'text-green-400' : avgConf >= 65 ? 'text-yellow-400' : 'text-red-400'
                      : 'dn-text'
                  }`}>{value}</div>
                </div>
              ))}
            </div>

            {/* Hidden audio element — controlled programmatically */}
            {audioSrc && (
              <audio ref={audioRef} src={audioSrc}
                onTimeUpdate={() => { if (audioRef.current) setAudioTime(audioRef.current.currentTime); }}
                onLoadedMetadata={() => { if (audioRef.current) setAudioDur(audioRef.current.duration); }}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
                className="hidden" />
            )}

            {/* ── Combined view: Play button + speaker info + lanes + transcript ── */}
            <div className="p-5">

              {/* Header row: play button + time + speaker label hint */}
              <div className="flex items-center gap-4 mb-4">
                {audioSrc && (
                  <button onClick={togglePlay}
                    className="w-9 h-9 rounded-full dn-surface2 border dn-border border hover:border-[#555] flex items-center justify-center transition flex-shrink-0"
                    title={(isPlaying ? 'Pause' : 'Play') + ' [Space]'}>
                    {isPlaying ? (
                      /* Pause icon */
                      <svg width="12" height="14" viewBox="0 0 12 14" fill="none">
                        <rect x="1" y="1" width="3.5" height="12" rx="1" fill="white"/>
                        <rect x="7.5" y="1" width="3.5" height="12" rx="1" fill="white"/>
                      </svg>
                    ) : (
                      /* Play icon */
                      <svg width="12" height="14" viewBox="0 0 12 14" fill="none">
                        <path d="M2 1.5L11 7L2 12.5V1.5Z" fill="white"/>
                      </svg>
                    )}
                  </button>
                )}
                <div className="flex items-center gap-3 flex-1">
                  <span className="dn-text3 text-xs font-mono">
                    {fmtTime(audioTime)} / {fmtTime(audioDur || totalDur)}
                  </span>
                  <div className="dn-text3 text-[10px] uppercase tracking-wider">
                    Speaker lanes — click a name to rename
                  </div>
                  {hasRenames && (
                    <span className="dn-text3 text-[10px]">names edited</span>
                  )}
                </div>
                {/* Speaker count badge */}
                <span className="dn-text3 text-[10px]">
                  {res.n_speakers} speaker{res.n_speakers !== 1 ? 's' : ''}
                </span>
              </div>

              {/* Speaker lanes */}
              <div className="space-y-3 mb-5">
                {speakers.map(sp => {
                  const segs     = res.segments.filter(s => s.speaker_id === sp);
                  const color    = colorMap[sp];
                  const pct      = Math.round((talkTime[sp] / totalDur) * 100);
                  const isActive = segs.some(s => audioTime >= s.start && audioTime < s.end);
                  const name     = displayName(sp);
                  const isEditing = editingSp === sp;

                  return (
                    <div key={sp} className="flex items-center gap-3">
                      {/* Active speaker left glow indicator */}
                      <div className="w-1 h-7 rounded-full flex-shrink-0 transition-all duration-300"
                        style={{
                          background: isActive ? color : 'transparent',
                          boxShadow:  isActive ? `0 0 8px ${color}` : 'none',
                          animation:  isActive ? 'pulsGlow 1.4s ease-in-out infinite' : 'none',
                        }} />
                      <div className="w-24 flex-shrink-0 text-right">
                        {isEditing ? (
                          <input ref={editInputRef} value={editingName}
                            onChange={e => setEditingName(e.target.value)}
                            onKeyDown={handleEditKey} onBlur={commitEdit}
                            className="w-full dn-bg dn-text text-xs border rounded px-1.5 py-0.5 text-right focus:outline-none"
                            style={{ borderColor: color }} />
                        ) : (
                          <button onClick={() => startEdit(sp)} title="Click to rename"
                            className={`w-full text-right text-xs font-medium truncate hover:underline cursor-text transition-colors ${
                              isActive ? 'dn-text' : 'dn-text2 hover:dn-text'
                            }`}>
                            {name}
                            {name !== sp && <span className="dn-text3 ml-1">*</span>}
                          </button>
                        )}
                        <div className="dn-text3 text-[10px] mt-0.5">{pct}% talk</div>
                      </div>

                      <div className="flex-1 h-7 dn-bg rounded-lg relative overflow-hidden cursor-pointer border dn-border border"
                        onClick={handleLaneBarClick}>
                        {segs.map(seg => {
                          const left        = (seg.start / totalDur) * 100;
                          const width       = Math.max(0.3, ((seg.end - seg.start) / totalDur) * 100);
                          const isActiveSeg = audioTime >= seg.start && audioTime < seg.end;
                          return (
                            <div key={seg.utterance_id}
                              className="absolute top-1 rounded-sm cursor-pointer"
                              style={{
                                left: left + '%', width: width + '%', height: '20px',
                                backgroundColor: color,
                                opacity: isActiveSeg ? 1 : 0.72,
                                boxShadow: isActiveSeg ? '0 0 0 1.5px ' + color : 'none',
                                borderBottom: '2px solid ' + confColor(seg.confidence),
                              }}
                              title={fmtTime(seg.start) + ' | ' + name + ' | ' + Math.round(seg.confidence * 100) + '% conf | ' + seg.text.slice(0, 80)}
                              onClick={e => handleLaneSegClick(e, seg)} />
                          );
                        })}
                        {audioSrc && playheadPct > 0 && (
                          <div className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
                            style={{ left: playheadPct + '%' }} />
                        )}
                        {Array.from({ length: Math.floor(totalDur / 30) }, (_, i) => (
                          <div key={i} className="absolute top-0 bottom-0 w-px dn-surface pointer-events-none"
                            style={{ left: ((i + 1) * 30 / totalDur * 100) + '%' }} />
                        ))}
                      </div>
                    </div>
                  );
                })}

                {/* Time axis */}
                <div className="flex items-center gap-3">
                  <div className="w-1 flex-shrink-0" />
                  <div className="w-24 flex-shrink-0" />
                  <div className="flex-1 flex justify-between text-[10px] font-mono px-0.5" style={{ color: 'var(--dn-text3)' }}>
                    <span>0:00</span>
                    <span>{fmtTime(totalDur / 4)}</span>
                    <span>{fmtTime(totalDur / 2)}</span>
                    <span>{fmtTime(totalDur * 3 / 4)}</span>
                    <span>{fmtTime(totalDur)}</span>
                  </div>
                </div>

                {/* Confidence legend */}
                <div className="flex items-center gap-3">
                  <div className="w-1 flex-shrink-0" />
                  <div className="w-24 flex-shrink-0" />
                  <div className="flex items-center gap-4 text-[10px] dn-text3">
                    <span>Confidence stripe:</span>
                    {[['#22c55e','high (85%+)'],['#f59e0b','medium (65-84%)'],['#ef4444','low (<65%)']].map(([c,l]) => (
                      <span key={l} className="flex items-center gap-1">
                        <span className="inline-block w-4 h-1 rounded-full" style={{ backgroundColor: c as string }} />
                        {l}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* ── Transcript list — directly below lanes, no tab ── */}
              <div className="border dn-border border rounded-lg overflow-hidden">
                <div className="flex items-center gap-4 px-4 py-2 dn-bg border-b dn-border border">
                  <span className="dn-text3 text-[10px] uppercase tracking-wider w-12 flex-shrink-0">Time</span>
                  <span className="dn-text3 text-[10px] uppercase tracking-wider w-24 flex-shrink-0">Speaker</span>
                  <span className="dn-text3 text-[10px] uppercase tracking-wider flex-1">Transcript</span>
                  <span className="dn-text3 text-[10px] uppercase tracking-wider w-10 text-right flex-shrink-0">Conf.</span>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {res.segments.map(seg => {
                    const isActive = seg.utterance_id === activeUttId;
                    const color    = colorMap[seg.speaker_id] || '#888';
                    return (
                      <div key={seg.utterance_id}
                        ref={el => { uttRefs.current[seg.utterance_id ?? 0] = el; }}
                        onClick={() => seekTo(seg.start)}
                        className={`flex items-start gap-4 px-4 py-2.5 cursor-pointer border-b border-[#161616] transition-colors ${
                          isActive ? 'bg-[#1a1630]' : 'hover:dn-surface'
                        }`}>
                        <span className="text-[#555] text-xs font-mono w-12 flex-shrink-0 pt-0.5">{fmtTime(seg.start)}</span>
                        {/* Speaker avatar — circular with initials */}
                        <span className="w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center text-[10px] font-bold mt-0.5"
                          style={{ background: color + '30', color, border: '1.5px solid ' + color + '60' }}
                          title={displayName(seg.speaker_id)}>
                          {displayName(seg.speaker_id).slice(0, 2).toUpperCase()}
                        </span>
                        <span className={`text-sm leading-relaxed flex-1 ${isActive ? 'dn-text' : 'text-[#bbb]'}`}>
                          {seg.text}
                          {isActive && audioSrc && (
                            <span className="text-red-400 ml-2 animate-pulse" style={{ fontSize: '10px' }}>[playing]</span>
                          )}
                        </span>
                        <span className="text-[10px] font-mono w-10 text-right flex-shrink-0 pt-0.5"
                          style={{ color: confColor(seg.confidence) }}>
                          {Math.round(seg.confidence * 100)}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 p-5 border-t dn-border border">
              {hasRenames ? (
                <button
                  onClick={() => {
                    const blob = new Blob([buildRenamedJson()], { type: 'application/json' });
                    const url  = URL.createObjectURL(blob);
                    const a    = document.createElement('a');
                    a.href = url; a.download = 'diarization_response.json';
                    a.click(); URL.revokeObjectURL(url);
                  }}
                  className="px-5 py-2.5 bg-white text-black rounded-lg hover:bg-gray-100 transition text-sm font-semibold">
                  Download Transcription (with renamed speakers)
                </button>
              ) : (
                <a href={getDiarisationJsonUrl()} download="diarization_response.json"
                  className="px-5 py-2.5 rounded-lg transition text-sm font-medium" style={{ background: "var(--dn-surface2)", color: "var(--dn-text)" }}>
                  Download Transcription
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
