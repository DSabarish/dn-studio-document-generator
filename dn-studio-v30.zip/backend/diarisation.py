# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/diarisation.py
# FIXES applied (production):
#   FIX-1: GPU auto-detection using torch.cuda — float16 on GPU, int8 on CPU
#   FIX-2: Sliding-window embedding path restored (1.5s window, 0.5s hop)
#   FIX-3: kmeans retry before Agglomerative fallback in clustering
#   FIX-4: t-SNE and HTML view removed from pipeline (dead code eliminated)
# ─────────────────────────────────────────────────────────────────────────────

import os
import json
import logging
import tempfile
import subprocess
import re
from pathlib import Path
from dataclasses import dataclass
from typing import List, Optional, Tuple
from datetime import datetime

import numpy as np
import librosa
import soundfile as sf
from sklearn.cluster import SpectralClustering, AgglomerativeClustering
from sklearn.preprocessing import normalize
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
from scipy.ndimage import median_filter
from faster_whisper import WhisperModel

log = logging.getLogger("dn_studio.diarisation")

SEED = 42
np.random.seed(SEED)

# ─────────────────────────────────────────────────────────────────────────────
# FIX-1: GPU detection — float16 on CUDA, int8 on CPU
# ─────────────────────────────────────────────────────────────────────────────
try:
    import torch
    if torch.cuda.is_available():
        DEVICE       = "cuda"
        COMPUTE_TYPE = "float16"
        log.info("[DEVICE] GPU detected: %s — using float16", torch.cuda.get_device_name(0))
    else:
        DEVICE       = "cpu"
        COMPUTE_TYPE = "int8"
        log.info("[DEVICE] No GPU — using CPU int8")
except ImportError:
    DEVICE       = "cpu"
    COMPUTE_TYPE = "int8"
    log.info("[DEVICE] torch not available — using CPU int8")


# ─────────────────────────────────────────────────────────────────────────────
# DATA CLASS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ASRSegment:
    start:        float
    end:          float
    text:         str
    speaker:      Optional[str] = None
    utterance_id: Optional[int] = None
    confidence:   float         = 1.0


# ─────────────────────────────────────────────────────────────────────────────
# AUDIO CONVERSION
# ─────────────────────────────────────────────────────────────────────────────

def convert_to_wav(input_path: str, output_path: str) -> str:
    """Convert any audio/video to 16kHz mono WAV via ffmpeg."""
    log.info("[CONVERT] %s → WAV", Path(input_path).name)
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", input_path, "-ac", "1", "-ar", "16000", "-vn", output_path],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"[CONVERT] ffmpeg failed:\n{result.stderr[-800:]}")
    sz_mb = Path(output_path).stat().st_size / 1024 / 1024
    log.info("[CONVERT] WAV ready  %.1f MB", sz_mb)
    return output_path


# ─────────────────────────────────────────────────────────────────────────────
# TEXT CLEANING
# ─────────────────────────────────────────────────────────────────────────────

_FILLERS  = re.compile(
    r'\b(um+|uh+|er+|ah+|hmm+|mhm|uh-huh|you know|i mean'
    r'|like,?\s+(?=\w)|sort of|kind of|basically|literally|actually,?\s+)\b',
    re.IGNORECASE,
)
_STUTTER  = re.compile(r'\b(\w+)[–-]\s+\1',  re.IGNORECASE)
_REPEATED = re.compile(r'\b(\w{2,})\s+\1\b', re.IGNORECASE)
_MULTI_SP = re.compile(r'\s{2,}')
_LEAD_PCT = re.compile(r'^[,\.;\s]+')


def clean_text(raw, remove_fillers=True, remove_stutters=True, remove_repeats=True):
    t = raw.strip()
    if remove_stutters: t = _STUTTER.sub(r'\1', t)
    if remove_repeats:  t = _REPEATED.sub(r'\1', t)
    if remove_fillers:  t = _FILLERS.sub(' ', t)
    t = _LEAD_PCT.sub('', _MULTI_SP.sub(' ', t))
    return (t[0].upper() + t[1:]).strip() if t else t


# ─────────────────────────────────────────────────────────────────────────────
# ASR — uses FIX-1 DEVICE/COMPUTE_TYPE globals
# ─────────────────────────────────────────────────────────────────────────────

def transcribe(audio_path, model_size="base.en", beam_size=5, best_of=5,
               vad_filter=True, vad_silence_ms=500, condition_on_prev=True,
               no_speech_thresh=0.6, log_prob_thresh=-1.0, compression_thresh=2.4,
               remove_fillers=True, remove_stutters=True, remove_repeats=True):
    log.info("[ASR] model=%s  device=%s  compute=%s", model_size, DEVICE, COMPUTE_TYPE)
    model = WhisperModel(model_size, device=DEVICE, compute_type=COMPUTE_TYPE)
    segs, _ = model.transcribe(
        audio_path, language="en", beam_size=beam_size, best_of=best_of,
        temperature=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
        compression_ratio_threshold=compression_thresh,
        log_prob_threshold=log_prob_thresh,
        no_speech_threshold=no_speech_thresh,
        condition_on_previous_text=condition_on_prev,
        vad_filter=vad_filter,
        vad_parameters=dict(min_silence_duration_ms=vad_silence_ms),
        word_timestamps=False,
    )
    out = []
    for s in segs:
        t = clean_text(s.text, remove_fillers, remove_stutters, remove_repeats)
        if not t:
            continue
        conf = float(np.clip(np.exp(s.avg_logprob), 0.0, 1.0))
        out.append(ASRSegment(float(s.start), float(s.end), t, confidence=conf))
    log.info("[ASR] %d segments produced", len(out))
    return out


# ─────────────────────────────────────────────────────────────────────────────
# EMBEDDINGS
# ─────────────────────────────────────────────────────────────────────────────

def _embed_chunk(encoder, y: np.ndarray, sr: int, start: float, end: float,
                 min_dur: float = 0.5) -> Optional[np.ndarray]:
    """Embed a single audio slice [start, end] seconds into a 256-dim d-vector."""
    chunk = y[int(start * sr):int(end * sr)]
    if len(chunk) < int(min_dur * sr):
        return None
    try:
        from resemblyzer import preprocess_wav
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            sf.write(tmp.name, chunk, sr)
            wav = preprocess_wav(tmp.name)
        os.unlink(tmp.name)
        return encoder.embed_utterance(wav)
    except Exception:
        return None


def extract_utterance_embeddings(audio_path: str, asr_segments: List[ASRSegment],
                                  sr: int = 16000) -> Tuple[List[int], np.ndarray]:
    """Utterance-level path: embed each ASR segment individually."""
    from resemblyzer import VoiceEncoder
    log.info("[EMB] Utterance-level: embedding %d segments", len(asr_segments))
    enc = VoiceEncoder("cpu")
    y, _ = librosa.load(audio_path, sr=sr, mono=True)
    valid_idx, embeddings = [], []
    for i, seg in enumerate(asr_segments):
        emb = _embed_chunk(enc, y, sr, seg.start, seg.end)
        if emb is not None:
            valid_idx.append(i)
            embeddings.append(emb)
    arr = np.array(embeddings, dtype=np.float32)
    log.info("[EMB] %d embeddings extracted  dim=%d", len(valid_idx), arr.shape[1])
    return valid_idx, arr


# ─────────────────────────────────────────────────────────────────────────────
# FIX-2: Sliding-window embedding path (restored from old pipeline)
# Produces fixed-length 1.5s embeddings — reliable regardless of utterance length
# ─────────────────────────────────────────────────────────────────────────────

def extract_sliding_embeddings(audio_path: str, sr: int = 16000,
                                window_sec: float = 1.5,
                                hop_sec: float = 0.5
                                ) -> Tuple[List[Tuple[float, float]], np.ndarray]:
    """
    Sliding-window path: embed overlapping 1.5s windows across the full audio.
    Much more reliable than utterance-level for short utterances and noisy audio.
    """
    from resemblyzer import VoiceEncoder, preprocess_wav
    log.info("[EMB] Sliding-window: window=%.1fs  hop=%.1fs", window_sec, hop_sec)
    enc      = VoiceEncoder("cpu")
    y, _     = librosa.load(audio_path, sr=sr, mono=True)
    duration = len(y) / sr

    times: List[Tuple[float, float]] = []
    embeddings: List[np.ndarray]     = []
    t = 0.0

    while t + window_sec <= duration:
        s, e  = int(t * sr), int((t + window_sec) * sr)
        chunk = y[s:e]
        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                sf.write(tmp.name, chunk, sr)
                wav = preprocess_wav(tmp.name)
            os.unlink(tmp.name)
            emb = enc.embed_utterance(wav)
            times.append((t, t + window_sec))
            embeddings.append(emb)
        except Exception:
            pass
        t += hop_sec

    arr = np.array(embeddings, dtype=np.float32)
    log.info("[EMB] %d windows  dim=%d", len(times), arr.shape[1])
    return times, arr


def assign_speakers_from_windows(asr_segments: List[ASRSegment],
                                  times: List[Tuple[float, float]],
                                  labels: np.ndarray) -> List[ASRSegment]:
    """
    Map sliding-window cluster labels back to ASR segments by overlap.
    Each segment gets the speaker label with maximum overlap.
    """
    for i, seg in enumerate(asr_segments):
        dur = max(seg.end - seg.start, 1e-6)
        scores: dict = {}
        for j, (ws, we) in enumerate(times):
            ov = max(0.0, min(seg.end, we) - max(seg.start, ws))
            if ov > 0:
                lbl = str(labels[j])
                scores[lbl] = scores.get(lbl, 0.0) + ov / dur
        seg.speaker      = "SPEAKER_" + max(scores, key=scores.get) if scores else "SPEAKER_UNKNOWN"
        seg.utterance_id = i
        seg.__dict__["spk_confidence"] = round(max(scores.values()) if scores else 0.0, 3)
    return asr_segments


# ─────────────────────────────────────────────────────────────────────────────
# SPEAKER COUNT AUTO-DETECTION (silhouette — only used when user picks auto)
# ─────────────────────────────────────────────────────────────────────────────

def best_num_speakers(X: np.ndarray, max_n: int = 8) -> int:
    Xn = normalize(X)
    best_n, best_score = 2, -1.0
    log.info("[DIAR] Silhouette search  max_speakers=%d", max_n)
    for n in range(2, min(max_n + 1, len(X))):
        try:
            _aff = np.clip(Xn @ Xn.T, 0.0, 1.0)
            np.fill_diagonal(_aff, 1.0)
            labels = SpectralClustering(
                n_clusters=n, affinity="precomputed", random_state=SEED,
                assign_labels="discretize", n_init=20,
            ).fit_predict(_aff)
            if len(np.unique(labels)) < n:
                raise ValueError("collapsed")
            score = silhouette_score(Xn, labels, metric="cosine")
            log.info("[DIAR]   n=%d  silhouette=%.4f", n, score)
            if score > best_score:
                best_score, best_n = score, n
        except Exception as ex:
            log.warning("[DIAR]   n=%d  failed: %s", n, ex)
    log.info("[DIAR] Best n_speakers=%d  silhouette=%.4f", best_n, best_score)
    return best_n


# ─────────────────────────────────────────────────────────────────────────────
# FIX-3: Clustering with kmeans retry before Agglomerative fallback
# ─────────────────────────────────────────────────────────────────────────────

def _cluster(Xn: np.ndarray, num_speakers: int) -> np.ndarray:
    """
    Spectral clustering with:
      1. discretize assignment (primary)
      2. kmeans assignment retry if discretize collapses  ← FIX-3
      3. AgglomerativeClustering ward fallback if both fail
    """
    Xn_norm = normalize(Xn)
    aff     = np.clip(Xn_norm @ Xn_norm.T, 0.0, 1.0)
    np.fill_diagonal(aff, 1.0)

    # Attempt 1: discretize
    try:
        labels = SpectralClustering(
            n_clusters=num_speakers, affinity="precomputed", random_state=SEED,
            assign_labels="discretize", n_init=50,
        ).fit_predict(aff)
        if len(np.unique(labels)) >= num_speakers:
            log.info("[DIAR] Spectral (discretize) → %d clusters ✓", len(np.unique(labels)))
            return labels
        log.warning("[DIAR] Spectral discretize collapsed → %d clusters, retrying kmeans",
                    len(np.unique(labels)))
    except Exception as ex:
        log.warning("[DIAR] Spectral discretize failed: %s", ex)

    # Attempt 2: kmeans (FIX-3 — was missing)
    try:
        labels = SpectralClustering(
            n_clusters=num_speakers, affinity="precomputed", random_state=SEED + 1,
            assign_labels="kmeans", n_init=50,
        ).fit_predict(aff)
        if len(np.unique(labels)) >= num_speakers:
            log.info("[DIAR] Spectral (kmeans) → %d clusters ✓", len(np.unique(labels)))
            return labels
        log.warning("[DIAR] Spectral kmeans also collapsed → %d clusters", len(np.unique(labels)))
    except Exception as ex:
        log.warning("[DIAR] Spectral kmeans failed: %s", ex)

    # Attempt 3: Agglomerative fallback
    log.warning("[DIAR] Falling back to AgglomerativeClustering (ward)")
    labels = AgglomerativeClustering(
        n_clusters=num_speakers, metric="euclidean", linkage="ward",
    ).fit_predict(Xn_norm)
    log.info("[DIAR] Agglomerative → %d clusters", len(np.unique(labels)))
    return labels


def diarize_utterances(asr_segments: List[ASRSegment], valid_idx: List[int],
                        embeddings: np.ndarray, num_speakers: Optional[int] = None,
                        max_speakers: int = 8, smooth_window: int = 3,
                        pca_variance: float = 0.99) -> List[ASRSegment]:
    """Cluster utterance-level embeddings and assign speakers to ASR segments."""
    embeddings = np.nan_to_num(embeddings, nan=0.0, posinf=0.0, neginf=0.0)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = np.where(norms > 1e-8, embeddings,
                          np.random.default_rng(SEED).normal(0, 1e-4, embeddings.shape))
    Xn = normalize(embeddings)

    if pca_variance < 1.0 and Xn.shape[1] > 10:
        Xn = PCA(n_components=pca_variance, svd_solver="full").fit_transform(Xn)

    if num_speakers is None:
        num_speakers = best_num_speakers(Xn, max_speakers)
    else:
        log.info("[DIAR] Fixed num_speakers=%d (user-specified)", num_speakers)

    labels = _cluster(Xn, num_speakers)
    labels = np.round(median_filter(labels.astype(float), size=smooth_window)).astype(int)

    # Compute centroids for spk_confidence
    Xn_norm = normalize(Xn)
    centroids = {}
    for lbl in np.unique(labels):
        mask = labels == lbl
        centroids[lbl] = normalize(Xn_norm[mask].mean(axis=0, keepdims=True))[0]

    # Assign labels to embedded segments
    for rank, seg_idx in enumerate(valid_idx):
        lbl = int(labels[rank])
        spk_conf = float(np.clip(np.dot(Xn_norm[rank], centroids[lbl]), 0.0, 1.0))
        asr_segments[seg_idx].speaker                    = f"SPEAKER_{lbl}"
        asr_segments[seg_idx].utterance_id               = seg_idx
        asr_segments[seg_idx].__dict__["spk_confidence"] = round(spk_conf, 3)

    # Fill gaps (unembedded segments) by nearest-neighbour
    for i, seg in enumerate(asr_segments):
        if seg.speaker is None:
            nearest = min(valid_idx, key=lambda j: abs(j - i), default=None)
            seg.speaker                    = asr_segments[nearest].speaker if nearest else "SPEAKER_UNKNOWN"
            seg.utterance_id               = i
            seg.__dict__["spk_confidence"] = 0.0

    log.info("[DIAR] Labels assigned to %d segments", len(asr_segments))
    return asr_segments


def diarize_sliding(asr_segments: List[ASRSegment],
                    times: List[Tuple[float, float]],
                    embeddings: np.ndarray,
                    num_speakers: Optional[int] = None,
                    max_speakers: int = 8,
                    smooth_window: int = 3,
                    pca_variance: float = 0.99) -> List[ASRSegment]:
    """Cluster sliding-window embeddings and map labels back to ASR segments."""
    embeddings = np.nan_to_num(embeddings, nan=0.0, posinf=0.0, neginf=0.0)
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    embeddings = np.where(norms > 1e-8, embeddings,
                          np.random.default_rng(SEED).normal(0, 1e-4, embeddings.shape))
    Xn = normalize(embeddings)

    if pca_variance < 1.0 and Xn.shape[1] > 10:
        Xn = PCA(n_components=pca_variance, svd_solver="full").fit_transform(Xn)

    if num_speakers is None:
        num_speakers = best_num_speakers(Xn, max_speakers)
    else:
        log.info("[DIAR] Sliding-window fixed num_speakers=%d (user-specified)", num_speakers)

    labels = _cluster(Xn, num_speakers)
    labels = np.round(median_filter(labels.astype(float), size=smooth_window)).astype(int)

    return assign_speakers_from_windows(asr_segments, times, labels)


# ─────────────────────────────────────────────────────────────────────────────
# SERIALISE
# ─────────────────────────────────────────────────────────────────────────────

def to_diarisation_json(asr_segments: List[ASRSegment]) -> list:
    return [{
        "start":          round(s.start,  3),
        "end":            round(s.end,    3),
        "utterance_id":   s.utterance_id,
        "speaker_id":     s.speaker,
        "speaker_name":   s.speaker,
        "confidence":     round(s.confidence, 3),
        "spk_confidence": round(s.__dict__.get("spk_confidence", 0.0), 3),
        "text":           s.text,
    } for s in asr_segments]


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# FIX-4: t-SNE and HTML view removed — pipeline ends at JSON write
# ─────────────────────────────────────────────────────────────────────────────

def run_diarisation(audio_path: str, config: dict = None,
                    progress_callback=None) -> dict:
    """
    Full diarisation pipeline: convert → ASR → embed → cluster → JSON.

    Config keys:
      whisper_model   str   'base.en'
      num_speakers    int   None = auto (silhouette), int = user-specified (fast+accurate)
      use_sliding     bool  True = sliding-window embeddings (better quality)
                            False = utterance-level embeddings
      max_speakers    int   8
      smooth_window   int   3
      pca_variance    float 0.99
      remove_fillers  bool  True
      remove_stutters bool  True
      output_dir      str   'outputs/diarisation'
    """
    def emit(pct: int, msg: str):
        log.info("[DIAR] %d%%  %s", pct, msg)
        if progress_callback:
            progress_callback(pct, msg)

    cfg = {
        "whisper_model":   "base.en",
        "num_speakers":    None,
        "use_sliding":     True,        # FIX-2: default to sliding-window
        "max_speakers":    8,
        "smooth_window":   3,
        "min_seg_dur":     0.4,
        "pca_variance":    0.99,
        "remove_fillers":  True,
        "remove_stutters": True,
        "remove_repeats":  True,
        "beam_size":       5,
        "best_of":         5,
        "vad_filter":      True,
        "vad_silence_ms":  500,
        "no_speech_thresh":0.6,
        "output_dir":      "outputs/diarisation",
        "roster":          [],
    }
    if config:
        cfg.update(config)

    out_dir = Path(cfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    log.info("[DIAR] Starting pipeline  audio=%s  device=%s  compute=%s  sliding=%s",
             Path(audio_path).name, DEVICE, COMPUTE_TYPE, cfg["use_sliding"])

    # ── Step 1: Convert ───────────────────────────────────────────────────────
    emit(5, "Converting audio to WAV...")
    wav_path = str(out_dir / "input_audio.wav")
    convert_to_wav(audio_path, wav_path)

    # ── Step 2: Transcribe ────────────────────────────────────────────────────
    emit(15, "Loading transcription model...")
    emit(20, "Transcribing speech...")
    asr_segs = transcribe(
        wav_path,
        model_size        = cfg["whisper_model"],
        beam_size         = cfg["beam_size"],
        best_of           = cfg["best_of"],
        vad_filter        = cfg["vad_filter"],
        vad_silence_ms    = cfg["vad_silence_ms"],
        no_speech_thresh  = cfg["no_speech_thresh"],
        remove_fillers    = cfg["remove_fillers"],
        remove_stutters   = cfg["remove_stutters"],
        remove_repeats    = cfg["remove_repeats"],
    )
    if not asr_segs:
        raise ValueError("[DIAR] No speech detected. Check your audio file.")
    emit(40, f"Transcription done — {len(asr_segs)} segments")

    # ── Step 3: Embed + Cluster ───────────────────────────────────────────────
    emit(50, "Extracting speaker embeddings...")

    if cfg["use_sliding"]:
        # FIX-2: Sliding-window path — better quality
        times, embeddings = extract_sliding_embeddings(wav_path)
        emit(65, f"Embeddings extracted — {len(times)} windows")
        emit(70, "Running speaker clustering...")
        asr_segs = diarize_sliding(
            asr_segs, times, embeddings,
            num_speakers  = cfg["num_speakers"],
            max_speakers  = cfg["max_speakers"],
            smooth_window = cfg["smooth_window"],
            pca_variance  = cfg["pca_variance"],
        )
    else:
        # Utterance-level path (fallback)
        valid_idx, embeddings = extract_utterance_embeddings(wav_path, asr_segs)
        emit(65, f"Embeddings extracted — {len(valid_idx)} utterances")
        emit(70, "Running speaker clustering...")
        asr_segs = diarize_utterances(
            asr_segs, valid_idx, embeddings,
            num_speakers  = cfg["num_speakers"],
            max_speakers  = cfg["max_speakers"],
            smooth_window = cfg["smooth_window"],
            pca_variance  = cfg["pca_variance"],
        )

    n_spk = len(set(s.speaker for s in asr_segs if s.speaker))
    emit(80, f"Clustering done — {n_spk} speakers detected")

    # ── Step 4: Write JSON (FIX-4: t-SNE and HTML removed) ───────────────────
    emit(90, "Writing transcription data...")
    segments_data = to_diarisation_json(asr_segs)
    json_path = out_dir / "diarization_response.json"
    json_path.write_text(
        json.dumps(segments_data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("[DIAR] diarization_response.json saved  %d utterances", len(segments_data))

    emit(100, "Diarisation complete ✓")
    return {"json_path": str(json_path), "html_path": None}
