// FILE: frontend/src/app/App.tsx
import { useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Stage1 } from './components/Stage1';
import { Stage2 } from './components/Stage2';
import type { DiarisationResult } from './api';

export default function App() {
  const [currentStage,    setCurrentStage]    = useState(1);
  const [diarisationData, setDiarisationData] = useState<DiarisationResult | null>(null);
  const [documentData,    setDocumentData]    = useState<any>(null);
  const [geminiApiKey,    setGeminiApiKey]    = useState('');
  const [diarisationSec,  setDiarisationSec]  = useState(0);

  const handleDiarisationComplete = useCallback((data: DiarisationResult, elapsedSec: number) => {
    setDiarisationData(data);
    setDiarisationSec(elapsedSec);
    // Intentionally NOT calling setCurrentStage(2) - user decides when to proceed
  }, []);

  const handleClearSession = useCallback(() => {
    setDiarisationData(null);
    setDocumentData(null);
    setCurrentStage(1);
  }, []);

  return (
    <div className="size-full flex bg-[#111] dark">
      <Sidebar
        currentStage={currentStage}
        onStageChange={setCurrentStage}
        hasDiarisation={!!diarisationData}
        hasDocument={!!documentData}
        diarisationData={diarisationData}
        documentData={documentData}
        geminiApiKey={geminiApiKey}
        onApiKeyChange={setGeminiApiKey}
      />
      {currentStage === 1 ? (
        <Stage1
          onDiarisationComplete={handleDiarisationComplete}
          onClearSession={handleClearSession}
          existingResult={diarisationData}
        />
      ) : (
        <Stage2
          onDocumentGenerate={setDocumentData}
          diarisationData={diarisationData}
          geminiApiKey={geminiApiKey}
          diarisationSec={diarisationSec}
        />
      )}
    </div>
  );
}
