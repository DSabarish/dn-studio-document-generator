import subprocess, zipfile, os, time, threading, urllib.request, sys, shutil

# ─── helpers ────────────────────────────────────────────────────────────────
def run(cmd, cwd=None, check=True):
    r = subprocess.run(cmd, shell=True, cwd=cwd,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if check and r.returncode != 0:
        print(f"\n❌  Command failed: {cmd}")
        print("─" * 50)
        print(r.stdout[-3000:])
        print("─" * 50)
        raise RuntimeError(f"Failed: {cmd}")
    return r

REPO      = "https://github.com/DSabarish/dn-studio-document-generator"
ZIP_NAME  = "dn-studio-v20.zip"
WORK_DIR  = "/content/dn-studio"

# ── 1  Clone repo ────────────────────────────────────────────────────────────
print("📥 [1/7] Cloning repo …")
run(f"git clone --depth 1 {REPO} /tmp/dn-repo")
zip_src = f"/tmp/dn-repo/{ZIP_NAME}"
if not os.path.exists(zip_src):
    # fallback: search anywhere in the clone
    matches = subprocess.run(f"find /tmp/dn-repo -name '*.zip'",
                             shell=True, capture_output=True, text=True).stdout.strip().split()
    if not matches:
        raise FileNotFoundError(f"❌  {ZIP_NAME} not found in repo. Files: "
                                + run("ls /tmp/dn-repo", check=False).stdout)
    zip_src = matches[0]
print(f"✅  Found zip: {zip_src}")

# ── 2  Move zip to /content, wipe everything else ───────────────────────────
print("\n🧹 [2/7] Cleaning /content …")
shutil.copy(zip_src, f"/content/{ZIP_NAME}")
for item in os.listdir("/content"):
    path = f"/content/{item}"
    if item == ZIP_NAME:
        continue
    try:
        shutil.rmtree(path) if os.path.isdir(path) else os.remove(path)
    except Exception:
        pass
print(f"✅  /content now contains only: {os.listdir('/content')}")

# ── 3  Unzip ─────────────────────────────────────────────────────────────────
print(f"\n📂 [3/7] Extracting {ZIP_NAME} …")
os.makedirs(WORK_DIR, exist_ok=True)
with zipfile.ZipFile(f"/content/{ZIP_NAME}", "r") as z:
    z.extractall(WORK_DIR)
os.chdir(WORK_DIR)
print(f"✅  Extracted to {WORK_DIR}")
print(f"   Contents: {', '.join(sorted(os.listdir('.')))}")
for f in ["backend/server.py", "requirements.txt", "frontend/package.json"]:
    if not os.path.exists(f):
        raise FileNotFoundError(f"❌  Missing after unzip: {f}")
print("✅  All required files present")

# ── 4  System deps ───────────────────────────────────────────────────────────
print("\n📦 [4/7] Installing system deps …")
run("apt-get install -y ffmpeg -qq")
node_ver = subprocess.run("node --version", shell=True, capture_output=True, text=True).stdout.strip()
major = int(node_ver.lstrip("v").split(".")[0]) if node_ver.startswith("v") else 0
if major < 18:
    print(f"   Node {node_ver} too old — upgrading to Node 20 …")
    run("curl -fsSL https://deb.nodesource.com/setup_20.x -o /tmp/ns.sh")
    run("bash /tmp/ns.sh")
    run("apt-get install -y nodejs")
    node_ver = subprocess.run("node --version", shell=True, capture_output=True, text=True).stdout.strip()
print(f"✅  ffmpeg + Node {node_ver} ready")

# ── 5  Python + Node backend deps ───────────────────────────────────────────
print("\n🐍 [5/7] Installing Python + Node deps …")
run("pip install -r requirements.txt -q", cwd=WORK_DIR)
run("npm install docx --silent", cwd=WORK_DIR)
print("✅  All deps installed")

# ── 6  Build React frontend ──────────────────────────────────────────────────
print("\n⚛️  [6/7] Building React frontend …")
FE = os.path.join(WORK_DIR, "frontend")
print("   npm install (may take 1-2 min) …")
run("npm install --legacy-peer-deps", cwd=FE)
print("   npm run build …")
run("npm run build", cwd=FE)
if not os.path.exists(os.path.join(FE, "dist")):
    raise RuntimeError("❌  dist/ not found after build")
print("✅  Frontend built — FastAPI will serve it at /")

# ── 7a  Start FastAPI (non-blocking) ─────────────────────────────────────────
print("\n🚀 [7/7] Starting backend + tunnel …")
LOG = os.path.join(WORK_DIR, "uvicorn.log")
server_proc = subprocess.Popen(
    [sys.executable, "-m", "uvicorn", "backend.server:app",
     "--host", "0.0.0.0", "--port", "8000"],
    stdout=open(LOG, "w"), stderr=subprocess.STDOUT,
    cwd=WORK_DIR,
)
print("   Waiting for server", end="")
for _ in range(20):
    time.sleep(1)
    print(".", end="", flush=True)
    try:
        resp = urllib.request.urlopen("http://localhost:8000/health", timeout=3)
        print(f"\n✅  Backend ready — {resp.read().decode()}")
        break
    except Exception:
        pass
else:
    print("\n❌  Backend did not start. Last 40 lines of log:")
    print(open(LOG).read())
    raise RuntimeError("FastAPI failed to start — see log above")

# ── 7b  Localtunnel public URL (non-blocking thread) ─────────────────────────
run("npm install -g localtunnel --silent")
try:
    ip = urllib.request.urlopen("https://api.ipify.org", timeout=5).read().decode().strip()
except Exception:
    ip = "run: !curl ifconfig.me"

tunnel_lines = []

def _tunnel():
    proc = subprocess.Popen(
        ["lt", "--port", "8000"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, cwd=WORK_DIR,
    )
    for line in proc.stdout:
        line = line.strip()
        if line:
            print(f"   🔗 {line}", flush=True)
            tunnel_lines.append(line)

threading.Thread(target=_tunnel, daemon=True).start()
time.sleep(5)

url = next((l for l in tunnel_lines if "loca.lt" in l), "— see 🔗 line above —")

# ── Done ─────────────────────────────────────────────────────────────────────
print("\n" + "═" * 62)
print("  ✅  DN-STUDIO IS RUNNING")
print("═" * 62)
print(f"  App URL         →  {url}")
print(f"  Tunnel password →  {ip}")
print(f"  Server logs     →  {LOG}")
print("═" * 62)
print()
print("  HOW TO OPEN:")
print(f"  1. Visit:  {url}")
print(f"  2. Password when prompted:  {ip}")
print()
print("  To stop:        server_proc.terminate()")
print("  To check logs:  !tail -50 uvicorn.log")
