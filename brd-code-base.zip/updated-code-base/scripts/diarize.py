"""Diarization — speaker-labelled transcript from MP3 audio."""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import glob
import json
import logging
import re
import tempfile
from typing import Any, Dict, List, Optional, Tuple

import librosa
import numpy as np
import soundfile as sf
from faster_whisper import WhisperModel
from resemblyzer import VoiceEncoder, preprocess_wav
from scipy.ndimage import median_filter
from sklearn.cluster import SpectralClustering
from sklearn.preprocessing import normalize

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)
logging.getLogger("faster_whisper").setLevel(logging.WARNING)

_FILLERS = re.compile(r"\b(um+|uh+|er+|like,?\s+|you know|i mean)\b", re.I)
_MIN_CHUNK_SECS = 0.3
_SAMPLE_RATE = 16_000


# ── Text cleaning ────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    text = _FILLERS.sub(" ", text.strip())
    return re.sub(r"\s+", " ", text).strip().capitalize()


# ── Transcription ────────────────────────────────────────────────────────────

def transcribe(path: str, model_size: str, lang: str) -> List[Dict]:
    device = "cuda" if os.path.exists("/usr/local/cuda") else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"
    mdl = WhisperModel(model_size, device=device, compute_type=compute_type)
    segs, _ = mdl.transcribe(path, language=lang, vad_filter=True)
    return [
        {
            "start": s.start,
            "end": s.end,
            "text": clean_text(s.text),
            "conf": float(np.clip(np.exp(s.avg_logprob), 0, 1)),
        }
        for s in segs
        if clean_text(s.text)
    ]


# ── Speaker embeddings ───────────────────────────────────────────────────────

def extract_embeddings(
    path: str, segs: List[Dict]
) -> Tuple[List[int], np.ndarray]:
    encoder = VoiceEncoder("cpu")
    audio, _ = librosa.load(path, sr=_SAMPLE_RATE, mono=True)
    valid_idx, embeddings = [], []

    for i, seg in enumerate(segs):
        chunk = audio[int(seg["start"] * _SAMPLE_RATE): int(seg["end"] * _SAMPLE_RATE)]
        if len(chunk) < _SAMPLE_RATE * _MIN_CHUNK_SECS:
            continue
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            sf.write(tmp.name, chunk, _SAMPLE_RATE)
            try:
                wav = preprocess_wav(tmp.name)
                embeddings.append(encoder.embed_utterance(wav))
                valid_idx.append(i)
            except Exception as exc:
                log.warning(f"Skipping segment {i}: {exc}")
            finally:
                os.unlink(tmp.name)

    emb_array = np.array(embeddings, dtype=np.float32) if embeddings else np.empty((0, 256))
    return valid_idx, emb_array


# ── Speaker clustering ───────────────────────────────────────────────────────

def cluster_speakers(embs: np.ndarray, n_speakers: Optional[int]) -> np.ndarray:
    if len(embs) < 2:
        return np.zeros(len(embs), dtype=int)

    X = normalize(np.nan_to_num(embs, nan=0.0))
    k = max(2, min(5, len(X) // 3)) if n_speakers is None else int(n_speakers)
    affinity = np.clip(X @ X.T, 0, 1)
    np.fill_diagonal(affinity, 1.0)

    try:
        labels = SpectralClustering(
            n_clusters=k,
            affinity="precomputed",
            assign_labels="discretize",
            random_state=42,
        ).fit_predict(affinity)
        return np.round(median_filter(labels.astype(float), size=5)).astype(int)
    except Exception as exc:
        log.error(f"Clustering failed ({exc}). Defaulting to single speaker.")
        return np.zeros(len(embs), dtype=int)


# ── Main pipeline ────────────────────────────────────────────────────────────

def run(cfg: Dict[str, Any]) -> List[Dict]:
    paths = cfg.get("paths", {})
    diar = cfg.get("diarization", {})

    input_dir = paths.get("input_dir", paths.get("mp3_dir", "mp3_output"))
    output_file = diar.get("output_file", "diarization_result.json")
    whisper_model = diar.get("whisper_model", "tiny")
    language = diar.get("language", "en")
    num_speakers = diar.get("num_speakers")

    mp3s = glob.glob(f"{input_dir}/*.mp3")
    if not mp3s:
        raise FileNotFoundError(f"No MP3 files found in: {input_dir}")

    results: List[Dict] = []
    for audio_path in mp3s:
        log.info(f"🎤 Processing: {os.path.basename(audio_path)}")
        segs = transcribe(audio_path, whisper_model, language)
        if not segs:
            log.warning("No speech segments detected.")
            continue

        valid_idx, embs = extract_embeddings(audio_path, segs)
        if len(embs) >= 2:
            labels = cluster_speakers(embs, num_speakers)
            for rank, seg_i in enumerate(valid_idx):
                speaker = f"SPEAKER_{labels[rank]}"
                segs[seg_i].update({"speaker_id": speaker, "speaker_name": speaker})

        for uid, seg in enumerate(segs):
            seg.setdefault("speaker_id", "SPEAKER_0")
            seg.setdefault("speaker_name", seg["speaker_id"])
            results.append({
                "start":        round(seg["start"], 3),
                "end":          round(seg["end"], 3),
                "utterance_id": uid,
                "speaker_id":   seg["speaker_id"],
                "speaker_name": seg["speaker_name"],
                "confidence":   round(seg["conf"], 3),
                "text":         seg["text"],
            })

    out_dir = os.path.dirname(output_file)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)

    log.info(f"✅ Saved {len(results)} segments → {output_file}")
    return results


if __name__ == "__main__":
    run(resolve_cfg("configuration.yaml"))
