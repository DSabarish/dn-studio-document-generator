"""BRD Pipeline — Chain 1: Schema Decider"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json
import logging
import re
from typing import Any, Dict

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_json(data: Any, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


def to_str(obj: Any) -> str:
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)


def extract_json(text: str) -> Dict:
    text = text.strip()
    match = re.search(r"\{[\s\S]*\}", text)
    if match:
        return json.loads(match.group())
    return json.loads(text)


# ── Chain Builder ─────────────────────────────────────────────────────────────

def build_chain1(model, prompt_path: str):
    prompt_file = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{prompt_file.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown.",
        ),
        (
            "human",
            "Meeting Transcript:\n{transcript}\n\n"
            "Instructions:\n{instructions}\n\n"
            "Output Format:\n{output_format}\n\n"
            "Return JSON only:",
        ),
    ])

    chain = (
        {
            "transcript":   RunnableLambda(lambda x: to_str(x["transcript"])),
            "instructions": RunnableLambda(lambda x: to_str(prompt_file.get("Instructions", {}))),
            "output_format": RunnableLambda(lambda x: to_str(prompt_file.get("Output Format", {}))),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(extract_json)
    )
    return chain


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain1(cfg: Dict[str, Any]) -> str:
    llm_cfg = cfg["llm"]
    chain_cfg = cfg["chains"]["chain1_schema_decider"]

    model = ChatGoogleGenerativeAI(
        model=llm_cfg["model"],
        google_api_key=llm_cfg["api_key"],
        temperature=llm_cfg.get("temperature", 0),
        max_output_tokens=llm_cfg.get("max_tokens", 4096),
    )

    transcript = load_json(chain_cfg["input"]["transcript"])
    log.info(f"📄 Loaded {len(transcript)} utterances")

    schema = build_chain1(model, chain_cfg["input"]["prompt"]).invoke(
        {"transcript": transcript}
    )

    output_path = chain_cfg["output"]["schema"]
    save_json(schema, output_path)
    log.info(f"✅ Schema saved → {output_path}")
    return output_path


if __name__ == "__main__":
    path = run_chain1(resolve_cfg("configuration.yaml"))
    schema = load_json(path)
    print(
        f"\n🎯 Chain 1 Complete: {path}\n"
        f"   Domain  : {schema.get('project_domain', 'N/A')}\n"
        f"   Modules : {len(schema.get('functional_modules', []))}\n"
        f"   NFRs    : {len(schema.get('nfr_sections', []))}"
    )
