"""BRD Pipeline — Chain 2: BRD Generator (JSON Mode + Retry)"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json
import logging
import re
import time
from typing import Any, Dict, Optional

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_google_genai import ChatGoogleGenerativeAI

from cfg_utils import resolve_cfg

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


# ── Helpers ──────────────────────────────────────────────────────────────────

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_json(data: Any, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


def to_str(obj: Any) -> str:
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)


def extract_json(text: str) -> Optional[Dict]:
    """Brace-matched extraction with trailing-comma fix."""
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    start = text.find("{")
    if start == -1:
        return None

    depth, end, in_string, escape = 0, -1, False, False
    for i, ch in enumerate(text[start:], start):
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"' and not escape:
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break

    if end == -1:
        return None

    json_str = re.sub(r",\s*([}\]])", r"\1", text[start:end])
    try:
        return json.loads(json_str)
    except json.JSONDecodeError:
        return None


def safe_extract_json(text: str, max_retries: int = 2) -> Dict:
    for attempt in range(max_retries + 1):
        result = extract_json(text)
        if result:
            return result
        if attempt == 0:
            text += "}" * max(0, text.count("{") - text.count("}"))
        elif attempt == 1:
            lines = text.split("\n")
            while lines and lines[-1].strip().rstrip(",").rstrip() not in ("}", "]"):
                lines.pop()
            text = "\n".join(lines) + "}"
    raise ValueError(f"Failed to parse JSON after {max_retries} retries. Preview: {text[:300]}...")


# ── Chain Builder ─────────────────────────────────────────────────────────────

def build_chain2(model, prompt_path: str, brd_template: Dict[str, Any]):
    p = load_json(prompt_path)

    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            f"{p.get('Task', {}).get('description', '')}\n\n"
            "Output ONLY valid JSON. No markdown. No trailing commas. Close all braces.",
        ),
        (
            "human",
            "Meeting Transcript (utterance_id range: 0 to {max_utid}):\n{transcript}\n\n"
            "Schema Decision (MUST follow for Section 6 & 7):\n{schema}\n\n"
            "BRD Template Structure:\n{brd_template}\n\n"
            "Rules:\n"
            "- Utterance IDs must be in range [0, {max_utid}]\n"
            "- Use why_null codes: not_mentioned, deferred_by_participants, not_yet_agreed, "
            "schema_excluded, insufficient_detail, not_applicable\n"
            "- Every non-null value needs a trace with valid utterance_id\n"
            "- Output valid, complete JSON only — no truncation\n\n"
            "Generate complete BRD JSON:",
        ),
    ])

    chain = (
        {
            "transcript":   RunnableLambda(lambda x: to_str(x["transcript"])),
            "schema":       RunnableLambda(lambda x: to_str(x["schema"])),
            "brd_template": RunnableLambda(lambda x: to_str(x["template"])),
            "max_utid":     RunnableLambda(
                lambda x: len(x["transcript"]) - 1 if isinstance(x["transcript"], list) else 0
            ),
        }
        | prompt
        | model
        | StrOutputParser()
        | RunnableLambda(safe_extract_json)
    )
    return chain


# ── Execute ───────────────────────────────────────────────────────────────────

def run_chain2(cfg: Dict[str, Any]) -> str:
    llm_cfg = cfg["llm"]
    chain_cfg = cfg["chains"]["chain2_brd_generator"]

    model = ChatGoogleGenerativeAI(
        model=llm_cfg["model"],
        google_api_key=llm_cfg["api_key"],
        temperature=llm_cfg.get("temperature", 0),
        max_output_tokens=llm_cfg.get("max_tokens", 32768),
        response_mime_type="application/json",
    )

    transcript = load_json(chain_cfg["input"]["transcript"])
    schema = load_json(chain_cfg["input"]["schema"])
    prompt_path = chain_cfg["input"]["prompt"]
    brd_template = load_json(prompt_path).get("BRD_Template", {})
    output_path = chain_cfg["output"]["brd"]

    log.info(
        f"📄 Transcript: {len(transcript)} utterances | "
        f"Schema modules: {len(schema.get('functional_modules', []))}"
    )

    chain2 = build_chain2(model, prompt_path, brd_template)
    brd: Optional[Dict] = None

    for attempt in range(1, 4):
        try:
            log.info(f"🔄 Chain 2 attempt {attempt}/3...")
            result = chain2.invoke({"transcript": transcript, "schema": schema, "template": brd_template})
            if result and isinstance(result, dict):
                brd = result
                break
        except Exception as exc:
            log.warning(f"⚠️  Attempt {attempt} failed: {exc}")
            if attempt < 3:
                time.sleep(2 ** (attempt - 1))

    if not brd:
        raise RuntimeError("Chain 2 failed after 3 attempts")

    save_json(brd, output_path)
    log.info(f"✅ BRD saved → {output_path}")
    return output_path


if __name__ == "__main__":
    cfg = resolve_cfg("configuration.yaml")
    output_path = run_chain2(cfg)
    brd = load_json(output_path)
    print(
        f"\n🎯 Chain 2 Complete: {output_path}\n"
        f"   Project  : {brd.get('Header', {}).get('Project Name', {}).get('value', 'N/A')}\n"
        f"   Sections : {sum(1 for v in brd.values() if isinstance(v, dict) and v.get('value'))}"
    )
