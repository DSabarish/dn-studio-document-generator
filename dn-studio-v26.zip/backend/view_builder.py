# ─────────────────────────────────────────────────────────────────────────────
# FILE: backend/view_builder.py
# PURPOSE: Generates the self-contained diarization_view.html file.
#          Called by backend/diarisation.py — separated here to keep
#          the pipeline code clean.
# ─────────────────────────────────────────────────────────────────────────────

import json
from typing import List, Dict

PALETTE = [
    {"bg": "#534AB7", "light": "#AFA9EC", "track": "#26215C"},
    {"bg": "#0F6E56", "light": "#5DCAA5", "track": "#04342C"},
    {"bg": "#993C1D", "light": "#F0997B", "track": "#4A1B0C"},
    {"bg": "#BA7517", "light": "#EF9F27", "track": "#412402"},
    {"bg": "#185FA5", "light": "#85B7EB", "track": "#042C53"},
    {"bg": "#993556", "light": "#ED93B1", "track": "#4B1528"},
    {"bg": "#3B6D11", "light": "#97C459", "track": "#173404"},
    {"bg": "#5F5E5A", "light": "#B4B2A9", "track": "#2C2C2A"},
]


def _fmt(sec):
    m, s = int(sec) // 60, int(sec) % 60
    return f"{m}:{s:02d}"


def build_view_html(
    segments: List[Dict],
    tsne_pts: List[Dict],
    roster: List[str],
    run_meta: Dict,
) -> str:
    """
    Build the full self-contained diarization_view.html.
    Dark theme. Audio player + swimlanes + utterance table + t-SNE scatter.
    Speaker tagging with roster dropdown + update JSON download.
    """
    speakers = sorted(set(s["speaker_id"] for s in segments))
    cmap     = {spk: PALETTE[i % len(PALETTE)] for i, spk in enumerate(speakers)}
    total    = max(s["end"] for s in segments) if segments else 1.0

    tick_step = 30 if total > 300 else (10 if total > 60 else 5)
    ruler_ticks = []
    t = 0
    while t <= total:
        ruler_ticks.append({"t": t, "label": _fmt(t)})
        t += tick_step

    js_segs   = json.dumps(segments,    ensure_ascii=False)
    js_tsne   = json.dumps(tsne_pts,    ensure_ascii=False)
    js_cmap   = json.dumps(cmap,        ensure_ascii=False)
    js_spks   = json.dumps(speakers,    ensure_ascii=False)
    js_total  = json.dumps(float(total))
    js_roster = json.dumps(roster,      ensure_ascii=False)
    js_meta   = json.dumps(run_meta,    ensure_ascii=False)
    js_ticks  = json.dumps(ruler_ticks, ensure_ascii=False)

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Diarisation View</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Unbounded:wght@600;800&display=swap');
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{background:#09090e;color:#e2e8f0;font-family:'DM Mono',monospace;min-height:100vh;padding:24px 28px}}
  h1{{font-family:'Unbounded',sans-serif;font-size:1.4rem;font-weight:800;
      background:linear-gradient(90deg,#60a5fa,#34d399,#fbbf24);
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:4px}}
  .subtitle{{font-size:0.62rem;letter-spacing:0.08em;color:#475569;margin-bottom:22px}}
  .card{{background:#0c0c14;border:1px solid #1e293b;border-radius:10px;padding:18px 22px;margin-bottom:16px}}
  .section-label{{font-size:0.55rem;letter-spacing:0.18em;color:#334155;text-transform:uppercase;margin-bottom:10px}}
  .audio-bar{{display:flex;align-items:center;gap:12px;background:#0c0c14;border:1px solid #1e293b;
              border-radius:10px;padding:12px 18px;margin-bottom:14px;flex-wrap:wrap}}
  .audio-upload{{background:#111827;border:1px solid #1e293b;border-radius:7px;padding:5px 13px;
                 font-size:0.62rem;color:#94a3b8;cursor:pointer;font-family:inherit}}
  .audio-upload:hover{{border-color:#3b82f6;color:#60a5fa}}
  .audio-upload input{{display:none}}
  #audio-el{{flex:1;min-width:180px;height:30px;accent-color:#3b82f6}}
  .audio-time{{font-size:0.6rem;color:#475569;min-width:88px;text-align:right;font-variant-numeric:tabular-nums}}
  .lane-row{{display:flex;align-items:center;margin-bottom:6px}}
  .lane-label-wrap{{width:110px;flex-shrink:0;display:flex;align-items:center;gap:5px}}
  .lane-label{{font-size:0.6rem;text-align:right;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
  .tag-btn{{background:transparent;border:1px solid #1e293b;border-radius:4px;padding:1px 5px;
            font-size:0.55rem;color:#475569;cursor:pointer;font-family:inherit}}
  .tag-btn:hover{{border-color:#3b82f6;color:#60a5fa}}
  .lane-track{{flex:1;height:24px;background:#111827;border-radius:4px;position:relative;overflow:hidden}}
  .seg-block{{position:absolute;top:3px;height:18px;border-radius:3px;cursor:pointer;transition:opacity .1s}}
  .seg-block:hover{{opacity:0.7}}
  .seg-block.active-seg{{outline:2px solid #fff;z-index:10}}
  #playhead{{position:absolute;top:0;bottom:0;width:2px;background:#ef4444;
             pointer-events:none;display:none;z-index:20;box-shadow:0 0 8px #ef444488}}
  #cursor-line{{position:absolute;top:0;bottom:0;width:1px;background:#ffffff18;pointer-events:none;display:none}}
  #cursor-time{{position:absolute;top:-18px;background:#1e293b;border-radius:3px;padding:1px 5px;
                font-size:0.56rem;color:#94a3b8;transform:translateX(-50%);white-space:nowrap}}
  .modal-overlay{{position:fixed;inset:0;background:#00000088;z-index:200;display:none;
                  align-items:center;justify-content:center}}
  .modal-box{{background:#0f0f17;border:1px solid #1e293b;border-radius:12px;padding:22px 26px;min-width:280px}}
  .modal-title{{font-size:0.68rem;color:#94a3b8;margin-bottom:14px}}
  .modal-select,.modal-input{{width:100%;background:#111827;border:1px solid #1e293b;border-radius:6px;
                color:#e2e8f0;font-family:inherit;font-size:0.7rem;padding:6px 10px;margin-bottom:12px}}
  .modal-btns{{display:flex;gap:8px;justify-content:flex-end}}
  .btn-primary{{background:#3b82f6;border:none;border-radius:6px;padding:6px 16px;
                color:#fff;font-family:inherit;font-size:0.65rem;cursor:pointer}}
  .btn-secondary{{background:transparent;border:1px solid #1e293b;border-radius:6px;padding:6px 14px;
                  color:#64748b;font-family:inherit;font-size:0.65rem;cursor:pointer}}
  #detail{{display:none;border-radius:8px;padding:12px 16px;margin-bottom:14px;border:1px solid}}
  .utt-row{{display:flex;gap:10px;padding:8px 14px;border-bottom:1px solid #111827;cursor:pointer;transition:background .1s}}
  .utt-row:hover{{background:#111827}}
  .utt-row.now{{background:#1e293b;border-left:2px solid #ef4444}}
  .utt-t{{font-size:0.58rem;color:#334155;min-width:38px;padding-top:2px;flex-shrink:0}}
  .utt-s{{font-size:0.6rem;min-width:88px;padding-top:2px;flex-shrink:0}}
  .utt-txt{{font-size:0.72rem;color:#94a3b8;line-height:1.5}}
  .scatter-wrap{{background:#0c0c14;border:1px solid #1e293b;border-radius:10px;padding:16px 20px;margin-bottom:16px}}
  .dot{{cursor:pointer;transition:all .1s}}
  .dot:hover{{r:8}}
  .scat-legend{{display:flex;gap:14px;flex-wrap:wrap;margin-top:10px}}
  .scat-leg-item{{display:flex;align-items:center;gap:6px;font-size:0.6rem;color:#64748b}}
  .scat-dot{{width:10px;height:10px;border-radius:50%}}
  .tooltip{{position:fixed;background:#1e293b;border:1px solid #334155;border-radius:7px;
            padding:7px 11px;font-size:0.6rem;pointer-events:none;display:none;z-index:100;
            line-height:1.6;max-width:260px}}
  #update-bar{{background:#0c0c14;border:1px solid #f59e0b44;border-radius:8px;
               padding:10px 16px;margin-bottom:14px;display:none;align-items:center;gap:12px;flex-wrap:wrap}}
  #update-bar span{{font-size:0.62rem;color:#94a3b8;flex:1}}
  ::-webkit-scrollbar{{width:4px;height:4px}}
  ::-webkit-scrollbar-track{{background:#111}}
  ::-webkit-scrollbar-thumb{{background:#333;border-radius:2px}}
</style>
</head>
<body>
<div style="margin-bottom:20px">
  <div style="font-size:0.55rem;letter-spacing:0.2em;color:#334155;font-family:'Unbounded',sans-serif;margin-bottom:4px">DN-STUDIO · DIARISATION VIEW</div>
  <h1>Voice Timeline</h1>
  <div class="subtitle" id="meta-line">loading…</div>
</div>

<div class="audio-bar">
  <label class="audio-upload"><input type="file" id="audio-input" accept="audio/*,video/*">📂 Load Audio</label>
  <audio id="audio-el" controls></audio>
  <div class="audio-time" id="audio-time">0:00 / 0:00</div>
</div>

<div class="modal-overlay" id="tag-modal">
  <div class="modal-box">
    <div class="modal-title">Tag speaker — <span id="modal-spk-id"></span></div>
    <select class="modal-select" id="modal-select"><option value="">— pick from roster —</option></select>
    <input class="modal-input" id="modal-custom" placeholder="or type a custom name…">
    <div class="modal-btns">
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="applyTag()">Apply</button>
    </div>
  </div>
</div>

<div class="card">
  <div class="section-label">Speaker Swimlanes</div>
  <div style="display:flex;margin-bottom:5px">
    <div style="width:110px;flex-shrink:0"></div>
    <div style="flex:1;position:relative;height:14px" id="ruler"></div>
  </div>
  <div id="lanes" style="position:relative">
    <div id="playhead"></div>
    <div id="cursor-line"><div id="cursor-time"></div></div>
  </div>
</div>

<div id="detail"></div>

<div id="update-bar">
  <span>Speaker names updated — pending save.</span>
  <button class="btn-primary" onclick="saveTagsToJSON()">💾 Update diarization_response.json</button>
  <button class="btn-secondary" onclick="discardTags()">Discard</button>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <div style="padding:10px 16px;border-bottom:1px solid #111827;font-size:0.54rem;letter-spacing:.14em;color:#334155" id="utt-header">UTTERANCES</div>
  <div style="max-height:320px;overflow-y:auto" id="utt-log"></div>
</div>

<div class="scatter-wrap">
  <div class="section-label">Speaker Clusters — t-SNE</div>
  <svg id="scatter-svg" viewBox="0 0 700 340" width="100%" xmlns="http://www.w3.org/2000/svg"></svg>
  <div class="scat-legend" id="scat-legend"></div>
</div>

<div class="tooltip" id="tooltip"></div>

<script>
const SEGMENTS={js_segs};
const TSNE_PTS={js_tsne};
const CMAP={js_cmap};
const SPEAKERS={js_spks};
const TOTAL={js_total};
const ROSTER={js_roster};
const META={js_meta};
const RULER_TICKS={js_ticks};

const nameMap={{}};
SPEAKERS.forEach(s=>nameMap[s]=s);
let pendingChanges=false;

function spkColor(spk,key='bg'){{return(CMAP[spk]||{{bg:'#534AB7',light:'#AFA9EC',track:'#26215C'}})[key];}}
function displayName(spk){{return nameMap[spk]||spk;}}
function fmt(sec){{const m=Math.floor(sec/60),s=Math.floor(sec%60);return m+':'+(s<10?'0'+s:s);}}

document.getElementById('meta-line').textContent=
  `${{META.label||''}}  ·  ${{SPEAKERS.length}} speakers  ·  ${{SEGMENTS.length}} utterances  ·  ${{fmt(TOTAL)}}  ·  ${{META.model||''}}  ·  ${{META.date||''}}`;

const audioEl=document.getElementById('audio-el');
const audioTm=document.getElementById('audio-time');
document.getElementById('audio-input').addEventListener('change',e=>{{
  const f=e.target.files[0];if(!f)return;
  audioEl.src=URL.createObjectURL(f);audioEl.load();
}});
audioEl.addEventListener('timeupdate',()=>{{
  const c=audioEl.currentTime,d=audioEl.duration||TOTAL;
  audioTm.textContent=fmt(c)+' / '+fmt(d);
  updatePlayhead(c);highlightCurrentUtterance(c);
}});

const lanesEl=document.getElementById('lanes');
const rulerEl=document.getElementById('ruler');
const playhead=document.getElementById('playhead');
const cursorLn=document.getElementById('cursor-line');
const cursorTm=document.getElementById('cursor-time');
const detailEl=document.getElementById('detail');

RULER_TICKS.forEach(tick=>{{
  const el=document.createElement('div');
  el.style.cssText=`position:absolute;left:${{tick.t/TOTAL*100}}%;font-size:0.5rem;color:#334155;transform:translateX(-50%)`;
  el.textContent=tick.label;rulerEl.appendChild(el);
}});

function buildLanes(){{
  [...lanesEl.children].forEach(c=>{{if(c.id!=='playhead'&&c.id!=='cursor-line')c.remove();}});
  SPEAKERS.forEach(spk=>{{
    const row=document.createElement('div');row.className='lane-row';
    const wrap=document.createElement('div');wrap.className='lane-label-wrap';
    const lbl=document.createElement('div');lbl.className='lane-label';
    lbl.style.color=spkColor(spk,'light');lbl.textContent=displayName(spk);lbl.id='lbl-'+spk;
    const tagBtn=document.createElement('button');tagBtn.className='tag-btn';
    tagBtn.textContent='🏷';tagBtn.onclick=()=>openModal(spk);
    wrap.appendChild(lbl);wrap.appendChild(tagBtn);
    const track=document.createElement('div');track.className='lane-track';
    track.style.background=spkColor(spk,'track');
    SEGMENTS.filter(s=>s.speaker_id===spk).forEach(seg=>{{
      const blk=document.createElement('div');blk.className='seg-block';
      blk.id='seg-'+seg.utterance_id;
      blk.style.left=(seg.start/TOTAL*100)+'%';
      blk.style.width=Math.max(0.3,(seg.end-seg.start)/TOTAL*100)+'%';
      blk.style.background=spkColor(spk,'bg');
      blk.onclick=()=>selectSegment(seg);track.appendChild(blk);
    }});
    row.appendChild(wrap);row.appendChild(track);lanesEl.appendChild(row);
  }});
  lanesEl.appendChild(playhead);lanesEl.appendChild(cursorLn);
}}
buildLanes();

lanesEl.addEventListener('mousemove',e=>{{
  const r=lanesEl.getBoundingClientRect();
  if(e.clientX-r.left<110){{cursorLn.style.display='none';return;}}
  const tw=r.width-110,tp=(e.clientX-r.left-110)/tw;
  cursorLn.style.display='block';
  cursorLn.style.left=(110+tp*tw)+'px';
  cursorTm.textContent=fmt(tp*TOTAL);
}});
lanesEl.addEventListener('mouseleave',()=>{{cursorLn.style.display='none';}});

function updatePlayhead(t){{
  playhead.style.display='block';
  playhead.style.left=(t/TOTAL*100)+'%';
}}

let lastSelected=null;
function selectSegment(seg){{
  if(lastSelected!=null){{const p=document.getElementById('seg-'+lastSelected);if(p)p.classList.remove('active-seg');}}
  const el=document.getElementById('seg-'+seg.utterance_id);
  if(el)el.classList.add('active-seg');lastSelected=seg.utterance_id;
  const c=CMAP[seg.speaker_id]||{{bg:'#534AB7',light:'#AFA9EC',track:'#26215C'}};
  detailEl.style.display='block';detailEl.style.background=c.track;detailEl.style.borderColor=c.bg;
  detailEl.innerHTML=`<div style="font-size:0.58rem;color:#64748b;margin-bottom:4px">${{displayName(seg.speaker_id)}} · ${{fmt(seg.start)}}–${{fmt(seg.end)}} · conf ${{seg.confidence}} · spk_conf ${{seg.spk_confidence}}</div><div style="font-size:0.75rem;line-height:1.6">${{seg.text}}</div>`;
  const uttEl=document.getElementById('utt-'+seg.utterance_id);
  if(uttEl)uttEl.scrollIntoView({{block:'nearest'}});
}}

const uttLog=document.getElementById('utt-log');
document.getElementById('utt-header').textContent=`UTTERANCES (${{SEGMENTS.length}})`;

function buildUttLog(){{
  uttLog.innerHTML='';
  SEGMENTS.forEach(seg=>{{
    const row=document.createElement('div');row.className='utt-row';row.id='utt-'+seg.utterance_id;
    row.innerHTML=`<div class="utt-t">${{fmt(seg.start)}}</div><div class="utt-s" style="color:${{spkColor(seg.speaker_id,'light')}}">${{displayName(seg.speaker_id)}}</div><div class="utt-txt">${{seg.text}}</div>`;
    row.onclick=()=>{{selectSegment(seg);if(audioEl.src)audioEl.currentTime=seg.start;}};
    uttLog.appendChild(row);
  }});
}}
buildUttLog();

function highlightCurrentUtterance(t){{
  const cur=SEGMENTS.find(s=>t>=s.start&&t<s.end);
  document.querySelectorAll('.utt-row.now').forEach(r=>r.classList.remove('now'));
  if(cur){{const el=document.getElementById('utt-'+cur.utterance_id);if(el){{el.classList.add('now');el.scrollIntoView({{block:'nearest'}});}}}}
}}

let currentTagSpk=null;
const tagModal=document.getElementById('tag-modal');
const modalSelect=document.getElementById('modal-select');
const modalCustom=document.getElementById('modal-custom');
ROSTER.forEach(name=>{{const opt=document.createElement('option');opt.value=name;opt.textContent=name;modalSelect.appendChild(opt);}});
function openModal(spk){{currentTagSpk=spk;document.getElementById('modal-spk-id').textContent=spk;modalCustom.value=nameMap[spk]||'';modalSelect.value='';tagModal.style.display='flex';}}
function closeModal(){{tagModal.style.display='none';}}
tagModal.addEventListener('click',e=>{{if(e.target===tagModal)closeModal();}});
function applyTag(){{
  const name=(modalCustom.value.trim()||modalSelect.value).trim();
  if(!name||!currentTagSpk){{closeModal();return;}}
  nameMap[currentTagSpk]=name;pendingChanges=true;
  const lbl=document.getElementById('lbl-'+currentTagSpk);if(lbl)lbl.textContent=name;
  buildUttLog();document.getElementById('update-bar').style.display='flex';closeModal();
}}
function discardTags(){{SPEAKERS.forEach(s=>nameMap[s]=s);pendingChanges=false;buildLanes();buildUttLog();document.getElementById('update-bar').style.display='none';}}
function saveTagsToJSON(){{
  const updated=SEGMENTS.map(seg=>{{return{{...seg,speaker_name:nameMap[seg.speaker_id]||seg.speaker_id}};}});
  const blob=new Blob([JSON.stringify(updated,null,2)],{{type:'application/json'}});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='diarization_response.json';a.click();
  pendingChanges=false;document.getElementById('update-bar').style.display='none';
}}

const svg=document.getElementById('scatter-svg');
const tooltip=document.getElementById('tooltip');
const legend=document.getElementById('scat-legend');
if(TSNE_PTS&&TSNE_PTS.length>0){{
  const xs=TSNE_PTS.map(p=>p.x),ys=TSNE_PTS.map(p=>p.y);
  const xMin=Math.min(...xs),xMax=Math.max(...xs),yMin=Math.min(...ys),yMax=Math.max(...ys);
  const pad=30,W=700,H=340;
  function scaleX(v){{return pad+(v-xMin)/(xMax-xMin+1e-9)*(W-2*pad);}}
  function scaleY(v){{return H-pad-(v-yMin)/(yMax-yMin+1e-9)*(H-2*pad);}}
  TSNE_PTS.forEach(pt=>{{
    const circle=document.createElementNS('http://www.w3.org/2000/svg','circle');
    circle.setAttribute('cx',scaleX(pt.x));circle.setAttribute('cy',scaleY(pt.y));
    circle.setAttribute('r',5);circle.setAttribute('fill',spkColor(pt.spk,'bg'));
    circle.setAttribute('opacity','0.82');circle.setAttribute('stroke',spkColor(pt.spk,'light'));
    circle.setAttribute('stroke-width','0.5');circle.className.baseVal='dot';
    circle.addEventListener('mouseenter',e=>{{tooltip.style.display='block';tooltip.innerHTML=`<b style="color:${{spkColor(pt.spk,'light')}}">${{displayName(pt.spk)}}</b><br>${{fmt(pt.start)}}–${{fmt(pt.end)}}<br><span style="color:#64748b">${{pt.text}}</span>`;}});
    circle.addEventListener('mousemove',e=>{{tooltip.style.left=(e.clientX+12)+'px';tooltip.style.top=(e.clientY+12)+'px';}});
    circle.addEventListener('mouseleave',()=>{{tooltip.style.display='none';}});
    circle.addEventListener('click',()=>{{const seg=SEGMENTS.find(s=>s.start===pt.start);if(seg)selectSegment(seg);}});
    svg.appendChild(circle);
  }});
  SPEAKERS.forEach(spk=>{{
    const item=document.createElement('div');item.className='scat-leg-item';
    item.innerHTML=`<div class="scat-dot" style="background:${{spkColor(spk,'bg')}}"></div><span>${{displayName(spk)}}</span>`;
    legend.appendChild(item);
  }});
}}else{{
  svg.innerHTML='<text x="350" y="170" fill="#334155" font-size="12" text-anchor="middle" font-family="monospace">t-SNE not available (too few segments)</text>';
}}
</script>
</body>
</html>'''
