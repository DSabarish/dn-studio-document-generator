// FILE: frontend/src/app/components/Sidebar.tsx
import { useState, useEffect } from 'react';
import type { DiarisationResult } from '../api';

interface SidebarProps {
  currentStage: number;
  onStageChange: (stage: number) => void;
  hasDiarisation: boolean;
  hasDocument: boolean;
  diarisationData?: DiarisationResult | null;
  documentData?: any;
  geminiApiKey: string;
  onApiKeyChange: (key: string) => void;
}

type ThemeId = 'dark' | 'light' | 'purple' | 'teal';

const THEMES: { id: ThemeId; label: string; dot: string; vars: Record<string, string> }[] = [
  {
    id: 'dark', label: 'Dark', dot: '#2a2a2a',
    vars: {
      '--dn-bg':        '#111111',
      '--dn-surface':   '#1a1a1a',
      '--dn-surface2':  '#2a2a2a',
      '--dn-border':    '#2a2a2a',
      '--dn-text':      '#ffffff',
      '--dn-text2':     '#888888',
      '--dn-text3':     '#555555',
      '--dn-accent':    '#ffffff',
      '--dn-accent-fg': '#000000',
    },
  },
  {
    id: 'light', label: 'Light', dot: '#e0e0e0',
    vars: {
      '--dn-bg':        '#f5f5f5',
      '--dn-surface':   '#ffffff',
      '--dn-surface2':  '#eeeeee',
      '--dn-border':    '#dddddd',
      '--dn-text':      '#111111',
      '--dn-text2':     '#555555',
      '--dn-text3':     '#999999',
      '--dn-accent':    '#111111',
      '--dn-accent-fg': '#ffffff',
    },
  },
  {
    id: 'purple', label: 'Violet', dot: '#7c3aed',
    vars: {
      '--dn-bg':        '#0f0a1e',
      '--dn-surface':   '#1a1030',
      '--dn-surface2':  '#2a1a4a',
      '--dn-border':    '#3b2a6a',
      '--dn-text':      '#f0e8ff',
      '--dn-text2':     '#a78bfa',
      '--dn-text3':     '#6d4dac',
      '--dn-accent':    '#7c3aed',
      '--dn-accent-fg': '#ffffff',
    },
  },
  {
    id: 'teal', label: 'Teal', dot: '#0d9488',
    vars: {
      '--dn-bg':        '#061414',
      '--dn-surface':   '#0a1f1f',
      '--dn-surface2':  '#0f2e2e',
      '--dn-border':    '#134040',
      '--dn-text':      '#e0fafa',
      '--dn-text2':     '#2dd4bf',
      '--dn-text3':     '#0f766e',
      '--dn-accent':    '#0d9488',
      '--dn-accent-fg': '#ffffff',
    },
  },
];

function applyTheme(id: ThemeId) {
  const theme = THEMES.find(t => t.id === id)!;
  const root  = document.documentElement;
  Object.entries(theme.vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.classList.toggle('dark', id !== 'light');
}

export function Sidebar({
  currentStage, onStageChange,
  hasDiarisation, hasDocument,
  diarisationData, documentData,
  geminiApiKey, onApiKeyChange,
}: SidebarProps) {
  const [showKey, setShowKey] = useState(false);
  const [themeId, setThemeId] = useState<ThemeId>('dark');

  useEffect(() => { applyTheme(themeId); }, [themeId]);

  return (
    <div className="w-52 flex flex-col h-screen flex-shrink-0"
      style={{ background: 'var(--dn-surface)', borderRight: '1px solid var(--dn-border)' }}>

      {/* Logo */}
      <div className="p-4" style={{ borderBottom: '1px solid var(--dn-border)' }}>
        <div className="font-semibold tracking-tight" style={{ color: 'var(--dn-text)' }}>DN-Studio</div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--dn-text3)' }}>v1.0 · Colab backend</div>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* Session nav */}
        <div className="p-4">
          <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: 'var(--dn-text3)' }}>Session</div>
          {([
            { stage: 1, label: 'Diarisation',         ready: hasDiarisation, locked: false },
            { stage: 2, label: 'Document generation',  ready: hasDocument,    locked: !hasDiarisation },
          ] as const).map(({ stage, label, ready, locked }) => (
            <button key={stage}
              onClick={() => !locked && onStageChange(stage)}
              disabled={locked}
              title={locked ? 'Run diarisation first' : undefined}
              className="w-full text-left px-3 py-2 rounded-lg mb-1.5 flex items-center gap-2.5 transition-all text-sm"
              style={{
                color:      locked            ? 'var(--dn-text3)'
                          : currentStage === stage ? 'var(--dn-text)' : 'var(--dn-text2)',
                background: currentStage === stage ? 'var(--dn-surface2)' : 'transparent',
                cursor:     locked ? 'not-allowed' : 'pointer',
              }}>
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                style={{ background: ready ? '#22c55e' : 'var(--dn-border)' }} />
              <span>{label}</span>
            </button>
          ))}
        </div>

        {/* CTA */}
        {hasDiarisation && currentStage === 1 && (
          <div className="px-4 pb-4">
            <button onClick={() => onStageChange(2)}
              className="w-full px-3 py-2 rounded-lg text-xs font-semibold transition"
              style={{ background: 'var(--dn-accent)', color: 'var(--dn-accent-fg)' }}>
              Generate document
            </button>
          </div>
        )}

        {/* State summary */}
        <div className="px-4 pb-4 pt-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
          <div className="text-[10px] uppercase tracking-widest mb-3" style={{ color: 'var(--dn-text3)' }}>State</div>
          <div className="mb-4">
            <div className="text-xs mb-1.5" style={{ color: 'var(--dn-text2)' }}>Diarisation JSON</div>
            {hasDiarisation ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">loaded</div>
                <div className="text-[10px] truncate" style={{ color: 'var(--dn-text3)' }} title={diarisationData?.filename}>{diarisationData?.filename}</div>
                <div className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>{diarisationData?.n_utterances} utt | {diarisationData?.n_speakers} spk</div>
              </div>
            ) : (
              <div className="text-[10px] px-2 py-1 rounded border" style={{ color: 'var(--dn-text3)', background: 'var(--dn-bg)', borderColor: 'var(--dn-border)' }}>none yet</div>
            )}
          </div>
          <div>
            <div className="text-xs mb-1.5" style={{ color: 'var(--dn-text2)' }}>Last document</div>
            {hasDocument ? (
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 bg-green-900/30 text-green-400 text-[10px] px-2 py-0.5 rounded-full border border-green-900/50">{documentData?.type} ready</div>
                <div className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>{documentData?.type}_output.docx</div>
              </div>
            ) : (
              <div className="text-[10px] px-2 py-1 rounded border" style={{ color: 'var(--dn-text3)', background: 'var(--dn-bg)', borderColor: 'var(--dn-border)' }}>none yet</div>
            )}
          </div>
        </div>

        {/* API key */}
        <div className="px-4 pb-4 pt-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
          <div className="text-[10px] uppercase tracking-widest mb-2" style={{ color: 'var(--dn-text3)' }}>Gemini API Key</div>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={geminiApiKey}
              onChange={e => onApiKeyChange(e.target.value)}
              placeholder="AIzaSy..."
              aria-label="Gemini API key"
              className="w-full text-xs rounded-lg px-2.5 py-1.5 pr-8 focus:outline-none transition-colors"
              style={{ background: 'var(--dn-bg)', color: 'var(--dn-text)', border: '1px solid var(--dn-border)' }}
            />
            <button onClick={() => setShowKey(v => !v)}
              aria-label={showKey ? 'Hide API key' : 'Show API key'}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs transition"
              style={{ color: 'var(--dn-text3)' }}>
              {showKey ? 'hide' : 'show'}
            </button>
          </div>
          {geminiApiKey && (
            <div className="mt-1.5 flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
              <span className="text-[10px]" style={{ color: 'var(--dn-text3)' }}>key set</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer — theme + runtime */}
      <div className="p-4" style={{ borderTop: '1px solid var(--dn-border)' }}>
        <div className="text-[10px] uppercase tracking-widest mb-2" style={{ color: 'var(--dn-text3)' }}>Theme</div>
        <div className="flex items-center gap-2 mb-3">
          {THEMES.map(t => (
            <button key={t.id} onClick={() => setThemeId(t.id)}
              title={t.label}
              className="w-5 h-5 rounded-full transition-all flex-shrink-0"
              style={{
                background:  t.dot,
                outline:     themeId === t.id ? '2px solid var(--dn-text)' : '2px solid transparent',
                outlineOffset: '2px',
              }} />
          ))}
          <span className="text-[10px] ml-0.5" style={{ color: 'var(--dn-text3)' }}>
            {THEMES.find(t => t.id === themeId)?.label}
          </span>
        </div>
        <div className="text-[10px] leading-relaxed" style={{ color: 'var(--dn-text3)' }}>
          Gemini 2.5 Flash<br />
          <span className="inline-flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
            Colab runtime active
          </span>
        </div>
      </div>
    </div>
  );
}
