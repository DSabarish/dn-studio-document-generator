# Documentation

| File               | Contents                                              |
|--------------------|-------------------------------------------------------|
| architecture.md    | System design, data flow, key design decisions        |
| pipeline.md        | Every pipeline step: inputs, outputs, scripts         |
| api.md             | All API endpoints with request/response schemas       |
| diarization.md     | Whisper + speaker clustering technical details        |
| gap_analyser.md    | Gap analysis output schema and severity guide         |
| frontend.md        | Frontend structure, navigation, state variables       |

Start with `architecture.md` to understand the overall design, then `pipeline.md` for step-by-step details.
