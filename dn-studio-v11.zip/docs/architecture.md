# Architecture

## Overview

DN-Studio is a single-process FastAPI application. The backend runs in Python, the frontend is a single HTML file served at `/`. Document generation uses a combination of Python (LLM chains via LangChain) and Node.js (Word document rendering via the `docx` npm package).

```
Browser  <──HTTP──>  app.py (FastAPI)
                          |
                     _pipeline_thread (background thread)
                          |
              ┌───────────┴───────────────────┐
              │                               │
         BRD pipeline                Studio pipeline
      (subprocess steps)          (in-process llm_filler)
              │                               │
    brd_schema_decider.py          llm_filler.run_fill()
    brd_requirements_writer.py          │
    brd_traceability_linker.py     generic_docx_runner.py
    brd_gap_analyser.py
    generic_docx_runner.py
```

## Key design decisions

**Single pipeline thread for all doc types.** `_pipeline_thread(job_id, steps, doc_type)` handles BRD, MOM, Quick Run, and custom types. BRD-only steps (3, 4, 6) are skipped via `_BRD_ONLY_STEPS`. No code is duplicated between pipeline variants.

**Background threads + polling, not SSE.** Each pipeline job runs in a daemon thread. The frontend polls `/api/jobs/{id}` every 1s (running) or 2s (idle). This is Colab-safe and avoids WebSocket/SSE complexity.

**In-memory job store.** Jobs live in a dict. Completed jobs are pruned when the store exceeds 50 entries. Every terminal state (done/error/stopped) is also written to `{experiment}/output/job_history.json` atomically.

**BRD runs subprocesses; Studio runs in-process.** BRD chain scripts are invoked as subprocesses so their stdout streams into the live log. Studio (MOM/custom) calls `llm_filler.run_fill()` directly with a custom log handler that captures output to the same log stream.

**One JS template per doc type.** All Word document rendering goes through `generic_docx_runner.py`, which calls `node JS_template.js <filled_json> <output_docx>`. The JS template is the only doc-type-specific artefact for document layout.

## Data flow

### BRD

```
Audio
  -> MP3 (to_mp3.py)
  -> diarization_result.json (diarize.py: Whisper + AgglomerativeClustering)
  -> brd-schema.json (brd_schema_decider.py: Gemini decides structure)
  -> brd-response.json (brd_requirements_writer.py: Gemini fills all fields)
  -> brd-response-trace.json (brd_traceability_linker.py: utterance IDs resolved)
  -> BRD.docx (generic_docx_runner.py + artifacts_library/BRD/JS_template.js)
  -> gap-report.json + gap-report.docx (brd_gap_analyser.py)
```

### MOM / Custom / Quick Run

```
Audio (or imported transcript JSON)
  -> MP3 (to_mp3.py) [skipped if transcript imported]
  -> diarization_result.json (diarize.py) [skipped if transcript imported]
  -> {type}_output.json (llm_filler.run_fill())
  -> {TYPE}.docx (generic_docx_runner.py + JS_template.js)
```

## File layout (runtime)

```
{experiment}/
  input/
    audio.mp3                   uploaded audio
    diarization_result.json     Whisper output with speaker labels
  output/
    brd-schema.json             BRD structure decision
    brd-response.json           BRD filled fields
    brd-response-trace.json     BRD with utterance traces resolved
    BRD.docx                    final Word document
    gap-report.json             gap analysis data
    gap-report.docx             gap analysis Word document
    mom_output.json             MOM filled fields (or {type}_output.json)
    MOM.docx                    MOM Word document
    job_history.json            pipeline run summaries
```
