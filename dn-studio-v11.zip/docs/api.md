# API Reference

Base URL: `http://localhost:8000`

---

## Configuration

### GET /api/config
Returns current configuration (API key masked).

```json
{
  "experiment": "my-project",
  "api_key": "AIzaSyABC•••••",
  "api_key_set": true,
  "num_speakers": 2,
  "whisper_model": "tiny",
  "gemini_model": "gemini-2.5-flash",
  "supported_models": ["gemini-2.5-flash", "gemini-2.5-pro", ...],
  "outputs": { "BRD.docx": true, "gap-report.json": false, ... }
}
```

### POST /api/config
Save configuration.

```json
{
  "experiment": "my-project",
  "api_key": "AIza...",
  "gemini_model": "gemini-2.5-flash",
  "whisper_model": "tiny",
  "num_speakers": 2
}
```

### GET /api/config/yaml
Returns safe YAML representation (API key partially masked).

---

## Upload

### POST /api/upload
Upload an audio file. Send as multipart/form-data with file field `file`. Include `x-upload-id` header to enable progress tracking.

Returns:
```json
{
  "ok": true,
  "filename": "meeting.mp3",
  "size_mb": 24.5,
  "duration_mins": 42.1,
  "estimated_diarization_mins": 7,
  "is_mp3": true
}
```

### POST /api/upload/start
Register an upload ID for progress tracking.
Query params: `filename`, `size` (bytes).

### GET /api/upload/progress/{uid}
```json
{ "pct": 67, "received": 8388608, "total": 12582912, "done": false }
```

### POST /api/upload/transcript
Import a pre-diarised transcript JSON (skips Steps 0 and 1).
Must be an array of utterance objects with `utterance_id`, `speaker_name`, `text`.

---

## Pipeline

### POST /api/run
Start a pipeline job.

```json
{ "steps": [0, 1, 2, 5], "doc_type": "mom" }
```

`steps` defaults to `[0,1,2,3,4,5,6]` if omitted. `doc_type` defaults to `"brd"`.

Returns: `{ "job_id": "a1b2c3d4" }`

### GET /api/jobs/{job_id}?since=0
Poll job status. Use `since` to fetch only new log entries.

```json
{
  "status": "running",
  "current_step": 2,
  "step_status": { "0": "done", "1": "done", "2": "running" },
  "step_timings": { "0": { "elapsed": 3.2 }, ... },
  "logs": [{ "step": 2, "msg": ">> Starting...", "ts": 1712345678.0 }],
  "log_total": 42,
  "error": null,
  "diar_analytics": { ... },
  "gap_report": { ... },
  "studio_outputs": { "docx": true, "filename": "MOM.docx", ... },
  "outputs": { "BRD.docx": false, ... }
}
```

`status` values: `running` | `done` | `error` | `stopped`

### POST /api/jobs/{job_id}/stop
Request pipeline stop. The job finishes its current step then halts.

---

## Downloads

### GET /api/download/{experiment}/{filename}
Download a file from `{experiment}/output/`.

### GET /api/download/input/{experiment}/{filename}
Download a file from `{experiment}/input/` (e.g. `diarization_result.json`).

### GET /api/audio/{experiment}
Stream the uploaded audio file.

---

## Speakers

### GET /api/speakers
Returns detected speaker names.

```json
{ "speakers": ["SPEAKER_0", "SPEAKER_1"] }
```

### POST /api/speakers/rename
Rename speakers in the diarisation result. Takes effect immediately for subsequent steps.

```json
{ "mapping": { "SPEAKER_0": "Alice", "SPEAKER_1": "Bob" } }
```

---

## Diarisation

### GET /api/diarization
Returns analytics for the current experiment's transcript.

Response includes: per-speaker stats (time, turns, words), swimlane segments, scatter plot points, meeting quality score inputs.

---

## Doc Types

### GET /api/doctypes
List all registered doc types (built-in BRD and MOM plus custom).

### POST /api/doctypes/register
Register a new doc type. Send as multipart/form-data:
- `key` — short identifier, e.g. `sop`
- `name` — full name, e.g. `Standard Operating Procedure`
- `label` — short label, e.g. `SOP`
- `schema_prompt` — JSON file
- `js_template` — JS file

### DELETE /api/doctypes/{key}
Delete a custom doc type (built-ins cannot be deleted).

---

## Experiments

### GET /api/experiments
List all experiment folders found in the working directory.

---

## Misc

### GET /api/ping
Health check: `{ "ok": true, "ts": 1712345678.0 }`

### GET /logo
Serves the DataNeurus logo PNG.

### GET /api/static/{filepath}
Serves files from `artifacts_library/` and `prompts/` (allowlisted paths only).
