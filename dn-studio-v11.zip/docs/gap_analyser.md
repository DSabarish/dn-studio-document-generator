# Gap Analyser

The gap analyser (Step 6, BRD only) reads the completed BRD trace and the original transcript, then asks the LLM to produce a structured audit of what is missing, uncertain, or at risk.

---

## Output schema

`{experiment}/output/gap-report.json`

```json
{
  "summary": {
    "total_gaps": 8,
    "critical": 2,
    "major": 4,
    "minor": 2,
    "overall_confidence": 72.5,
    "recommendation": "The BRD has solid coverage of functional requirements..."
  },
  "gaps": [
    {
      "id": "GAP-001",
      "severity": "critical",
      "section": "2.1 In-Scope Functionality",
      "title": "Payment integration method not discussed",
      "description": "No payment gateway was mentioned...",
      "why_null_code": "not_mentioned",
      "action": "Schedule a follow-up to confirm Stripe vs PayPal vs custom",
      "owner": "Product Manager",
      "transcript_refs": [14, 22],
      "deadline": "Before sign-off"
    }
  ],
  "open_questions": [
    {
      "id": "Q-001",
      "question": "What is the expected peak concurrent user load?",
      "context": "Scalability was raised but never quantified",
      "raised_by": "Alice",
      "urgency": "immediate"
    }
  ],
  "uncaptured_risks": [
    {
      "id": "R-001",
      "risk": "Third-party API dependency without SLA",
      "evidence": "Utterance 47: we'll just use their free tier",
      "suggested_mitigation": "Define fallback behaviour and add SLA to vendor requirements"
    }
  ],
  "confidence_scores": {
    "Header": 95,
    "Section 1 - Objectives": 88,
    "Section 2 - Functional Requirements": 71,
    "Section 3 - Non-Functional Requirements": 45
  }
}
```

---

## Severity guide

| Severity | Meaning |
|----------|---------|
| `critical` | Project cannot proceed to development without this. Affects scope, budget, or delivery date. |
| `major` | Will cause problems in UAT or delivery if not resolved. |
| `minor` | Can be deferred to a later phase without significant risk. |

---

## `why_null` codes

These codes appear on every null BRD field and are passed to the gap analyser to help it classify the severity correctly:

| Code | Meaning |
|------|---------|
| `not_mentioned` | Topic never came up in the meeting |
| `deferred_by_participants` | Explicitly deferred to a future meeting or phase |
| `not_yet_agreed` | Discussed but no consensus reached |
| `schema_excluded` | Excluded by the Step 2 schema decision |
| `insufficient_detail` | Mentioned but not enough detail to fill the field |
| `not_applicable` | Does not apply to this project |

---

## Gap report Word document

A `gap-report.docx` is auto-generated alongside `gap-report.json` using `artifacts_library/BRD/JS_gap_report.js`. It is available on the Outputs page immediately after Step 6 completes.

---

## Confidence score

`overall_confidence` (0–100) reflects how well-supported the BRD is by the transcript. A score of 100 means every field has strong utterance evidence. A low score means much of the document was inferred or is missing. It is not a quality score for the meeting itself.
