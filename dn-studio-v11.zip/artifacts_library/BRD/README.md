# BRD — Business Requirements Document

A 7-step pipeline that produces a fully-traced, gap-analysed Business Requirements Document from a meeting transcript.

## Files

| File                       | Purpose                                          |
|----------------------------|--------------------------------------------------|
| `schema_prompt.json`       | BRD field definitions + Gemini generation prompt |
| `schema_decider_prompt.json` | Step 2 prompt: decides which sections to generate |
| `JS_template.js`           | Word document template (Node.js + docx package)  |
| `JS_gap_report.js`         | Gap report Word document template                |

## Pipeline steps

| Step | What it does                              | Script                           |
|------|-------------------------------------------|----------------------------------|
| 0    | Convert audio to MP3                      | to_mp3.py                        |
| 1    | Diarise and transcribe                    | diarize.py                       |
| 2    | Decide BRD structure                      | brd_schema_decider.py            |
| 3    | Fill all requirement fields               | brd_requirements_writer.py       |
| 4    | Link fields to transcript utterances      | brd_traceability_linker.py       |
| 5    | Render Word document                      | generic_docx_runner.py           |
| 6    | Gap analysis                              | brd_gap_analyser.py              |

## Output files

- `{experiment}/output/brd-schema.json` — structure decision
- `{experiment}/output/brd-response.json` — filled BRD fields
- `{experiment}/output/brd-response-trace.json` — fields with utterance traces
- `{experiment}/output/BRD.docx` — final Word document
- `{experiment}/output/gap-report.json` — gap analysis data
- `{experiment}/output/gap-report.docx` — gap analysis Word document
