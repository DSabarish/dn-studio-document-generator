"""
brd_traceability_linker.py — BRD Pipeline Step 4: Traceability Linker

Merges the filled BRD (Step 3) with the diarisation transcript by replacing
every trace node's utterance_id reference with the full diarisation entry.

This is a pure data-merge step — no LLM call required.

Output: brd-response-trace.json  (used by docx_renderer and gap_analyser)
"""
from __future__ import annotations

import copy
import logging
import os
import sys
from typing import Any, Dict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cfg_utils import resolve_cfg
from llm_utils import load_json, save_json

log = logging.getLogger(__name__)


def _resolve_traces(node: Any, utterance_map: Dict[int, Dict]) -> None:
    """
    Walk the document tree and replace every trace node with the full
    diarisation entry keyed by the first utterance_id in the list.
    """
    if isinstance(node, dict):
        if "trace" in node and isinstance(node["trace"], dict):
            uid_list = node["trace"].get("utterance_id")
            if isinstance(uid_list, list) and uid_list:
                node["trace"] = utterance_map.get(uid_list[0])
            else:
                node["trace"] = None
        for v in node.values():
            _resolve_traces(v, utterance_map)
    elif isinstance(node, list):
        for item in node:
            _resolve_traces(item, utterance_map)


def _inject_list_item_values(node: Any) -> None:
    """
    Ensure every functional-requirement list item has a `value` key
    mirroring its `Description` field, keeping the schema consistent.
    """
    if isinstance(node, dict):
        for v in node.values():
            if isinstance(v, list):
                for item in v:
                    if isinstance(item, dict) and "Description" in item and "value" not in item:
                        new_item: Dict = {}
                        for k, val in item.items():
                            new_item[k] = val
                            if k == "Description":
                                new_item["value"] = val
                        item.clear()
                        item.update(new_item)
            _inject_list_item_values(v)
    elif isinstance(node, list):
        for item in node:
            _inject_list_item_values(item)


def run(cfg: dict) -> str:
    chain_cfg = cfg["chains"]["chain3_traceability"]

    transcript_path = chain_cfg["input"]["transcript"]
    brd_path        = chain_cfg["input"]["brd"]
    output_path     = chain_cfg["output"]["trace"]

    transcript: list = load_json(transcript_path)
    brd: dict        = load_json(brd_path)

    utterance_map: Dict[int, Dict] = {
        entry["utterance_id"]: entry for entry in transcript
    }

    trace_doc = copy.deepcopy(brd)
    _resolve_traces(trace_doc, utterance_map)
    _inject_list_item_values(trace_doc)

    save_json(trace_doc, output_path)
    log.info("[OK] Trace document written → %s", output_path)
    return output_path


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg  = resolve_cfg("configuration.yaml")
    path = run(cfg)
    print(f"\n>> Traceability Linker complete: {path}")
